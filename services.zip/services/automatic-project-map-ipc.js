'use strict';

/*
  MAP.8.1 main-process IPC helper.

  Usage from Falcon main.js:
    const { registerAutomaticProjectMapIpc } =
      require('./services/automatic-project-map-ipc');

    registerAutomaticProjectMapIpc({
      ipcMain,
      getCurrentProject: () => <return active Falcon project record>
    });
*/

const {
  loadActiveProjectMap,
  buildRendererBridgeResult,
} = require('./automatic-real-project-map-loader');

function registerAutomaticProjectMapIpc({
  ipcMain,
  getCurrentProject,
} = {}) {
  if (!ipcMain || typeof ipcMain.handle !== 'function') {
    throw new TypeError('ipcMain is required.');
  }

  if (typeof getCurrentProject !== 'function') {
    throw new TypeError('getCurrentProject function is required.');
  }

  ipcMain.handle('falcon:project:get-current-project', async () => {
    return getCurrentProject();
  });

  ipcMain.handle('falcon:project:get-current-map-model', async () => {
    const project = await getCurrentProject();

    if (!project) {
      throw new Error('No active Falcon project.');
    }

    const activeMap = loadActiveProjectMap(project);
    return buildRendererBridgeResult(activeMap).mapModel;
  });

  return true;
}

module.exports = {
  registerAutomaticProjectMapIpc,
};
