'use strict';

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function finiteNumber(value, fieldName) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    throw new TypeError(`${fieldName} must be a valid number.`);
  }
  return number;
}

function nonNegative(value, fieldName) {
  const number = finiteNumber(value, fieldName);
  if (number < 0) {
    throw new RangeError(`${fieldName} cannot be negative.`);
  }
  return number;
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function normalizeDate(value) {
  const raw = text(value);
  if (!raw) return '';

  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;

  const match = raw.match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (!match) return '';

  return `${match[3]}-${match[2]}-${match[1]}`;
}

function derivePlotStatus(plot = {}) {
  const status = upper(plot.status);
  if (['AVAILABLE', 'HOLD', 'BOOKED', 'SOLD'].includes(status)) return status;
  return 'AVAILABLE';
}

function deriveBookingStatus(booking = {}) {
  const explicit = upper(booking.status || booking.bookingStatus);

  if (['BOOKED', 'SOLD', 'CANCELLED'].includes(explicit)) return explicit;

  const total = nonNegative(
    booking.grandTotal !== undefined ? booking.grandTotal : booking.totalPrice || 0,
    'booking total'
  );
  const paid = nonNegative(booking.paidAmount || 0, 'paidAmount');

  if (booking.cancelledAt || booking.cancelled === true) return 'CANCELLED';
  if (total > 0 && paid >= total) return 'SOLD';
  return 'BOOKED';
}

function normalizeBooking(booking = {}) {
  const totalAmount = roundMoney(
    nonNegative(
      booking.grandTotal !== undefined ? booking.grandTotal : booking.totalPrice || 0,
      'booking total'
    )
  );

  const paidAmount = roundMoney(nonNegative(booking.paidAmount || 0, 'paidAmount'));
  const balanceAmount = roundMoney(
    booking.balanceAmount !== undefined
      ? nonNegative(booking.balanceAmount, 'balanceAmount')
      : Math.max(0, totalAmount - paidAmount)
  );

  return Object.freeze({
    source: booking,
    bookingId: upper(booking.bookingId || booking.id),
    projectId: upper(booking.projectId),
    projectName: text(booking.projectName),
    plotNumber: text(booking.plotNumber || booking.plotNo),
    customerName: text(booking.customerName),
    customerMobile: text(booking.customerMobile || booking.mobile),
    bookingDate: normalizeDate(booking.bookingDate || booking.date || booking.createdAt),
    status: deriveBookingStatus(booking),
    totalAmount,
    paidAmount,
    balanceAmount,
  });
}

function normalizePayment(payment = {}) {
  return Object.freeze({
    source: payment,
    paymentId: upper(payment.paymentId),
    bookingId: upper(payment.bookingId),
    projectId: upper(payment.projectId),
    projectName: text(payment.projectName),
    amount: roundMoney(nonNegative(payment.amount || 0, 'payment amount')),
    paymentDate: normalizeDate(payment.paymentDate || payment.date),
    status: upper(payment.status || 'POSTED'),
    mode: upper(payment.mode || payment.paymentMode),
    receiptNumber: upper(payment.receiptNumber),
  });
}

function normalizeProject(project = {}) {
  return Object.freeze({
    source: project,
    projectId: upper(project.projectId || project.id),
    projectName: text(project.projectName || project.name),
    status: upper(project.status || 'ACTIVE'),
  });
}

function normalizePlot(plot = {}) {
  return Object.freeze({
    source: plot,
    plotId: upper(plot.plotId || plot.id),
    projectId: upper(plot.projectId),
    plotNumber: text(plot.plotNumber || plot.plotNo || plot.number),
    status: derivePlotStatus(plot),
  });
}

function buildDashboardSnapshot({
  projects = [],
  plots = [],
  bookings = [],
  payments = [],
  today,
  recentLimit = 5,
} = {}) {
  if (![projects, plots, bookings, payments].every(Array.isArray)) {
    throw new TypeError('projects, plots, bookings and payments must be arrays.');
  }

  const normalizedToday = normalizeDate(today || new Date().toISOString().slice(0, 10));
  if (!normalizedToday) throw new Error('today must be DD-MM-YYYY or YYYY-MM-DD.');

  const projectRows = projects.map(normalizeProject);
  const plotRows = plots.map(normalizePlot);
  const bookingRows = bookings.map(normalizeBooking);
  const paymentRows = payments.map(normalizePayment);

  const plotCounts = {
    total: plotRows.length,
    available: 0,
    hold: 0,
    booked: 0,
    sold: 0,
  };

  for (const plot of plotRows) {
    if (plot.status === 'AVAILABLE') plotCounts.available += 1;
    if (plot.status === 'HOLD') plotCounts.hold += 1;
    if (plot.status === 'BOOKED') plotCounts.booked += 1;
    if (plot.status === 'SOLD') plotCounts.sold += 1;
  }

  const bookingCounts = {
    total: bookingRows.length,
    booked: 0,
    sold: 0,
    cancelled: 0,
  };

  let totalBookingValue = 0;
  let totalPaid = 0;
  let totalBalance = 0;

  for (const booking of bookingRows) {
    if (booking.status === 'BOOKED') bookingCounts.booked += 1;
    if (booking.status === 'SOLD') bookingCounts.sold += 1;
    if (booking.status === 'CANCELLED') bookingCounts.cancelled += 1;

    if (booking.status !== 'CANCELLED') {
      totalBookingValue = roundMoney(totalBookingValue + booking.totalAmount);
      totalPaid = roundMoney(totalPaid + booking.paidAmount);
      totalBalance = roundMoney(totalBalance + booking.balanceAmount);
    }
  }

  const postedPayments = paymentRows.filter((payment) => payment.status === 'POSTED');
  const totalCollected = roundMoney(
    postedPayments.reduce((sum, payment) => sum + payment.amount, 0)
  );

  const todayPayments = postedPayments.filter(
    (payment) => payment.paymentDate === normalizedToday
  );

  const todayCollection = roundMoney(
    todayPayments.reduce((sum, payment) => sum + payment.amount, 0)
  );

  const todayBookings = bookingRows.filter(
    (booking) =>
      booking.bookingDate === normalizedToday &&
      booking.status !== 'CANCELLED'
  );

  const safeLimit = Math.max(1, Math.min(50, Math.floor(Number(recentLimit) || 5)));

  const recentBookings = bookingRows
    .slice()
    .sort((a, b) => {
      if (a.bookingDate === b.bookingDate) {
        return b.bookingId.localeCompare(a.bookingId);
      }
      return b.bookingDate.localeCompare(a.bookingDate);
    })
    .slice(0, safeLimit);

  const recentPayments = postedPayments
    .slice()
    .sort((a, b) => {
      if (a.paymentDate === b.paymentDate) {
        return b.paymentId.localeCompare(a.paymentId);
      }
      return b.paymentDate.localeCompare(a.paymentDate);
    })
    .slice(0, safeLimit);

  const projectMap = new Map();

  function getProjectBucket(projectId, projectName) {
    const key = projectId || projectName || 'UNKNOWN';

    if (!projectMap.has(key)) {
      projectMap.set(key, {
        projectId,
        projectName,
        plotCount: 0,
        availablePlots: 0,
        holdPlots: 0,
        bookedPlots: 0,
        soldPlots: 0,
        bookingCount: 0,
        bookingValue: 0,
        paidAmount: 0,
        balanceAmount: 0,
        collection: 0,
      });
    }

    return projectMap.get(key);
  }

  for (const project of projectRows) {
    getProjectBucket(project.projectId, project.projectName);
  }

  for (const plot of plotRows) {
    const project = getProjectBucket(plot.projectId, '');
    project.plotCount += 1;
    if (plot.status === 'AVAILABLE') project.availablePlots += 1;
    if (plot.status === 'HOLD') project.holdPlots += 1;
    if (plot.status === 'BOOKED') project.bookedPlots += 1;
    if (plot.status === 'SOLD') project.soldPlots += 1;
  }

  for (const booking of bookingRows) {
    if (booking.status === 'CANCELLED') continue;

    const project = getProjectBucket(booking.projectId, booking.projectName);
    if (!project.projectName && booking.projectName) {
      project.projectName = booking.projectName;
    }

    project.bookingCount += 1;
    project.bookingValue = roundMoney(project.bookingValue + booking.totalAmount);
    project.paidAmount = roundMoney(project.paidAmount + booking.paidAmount);
    project.balanceAmount = roundMoney(project.balanceAmount + booking.balanceAmount);
  }

  for (const payment of postedPayments) {
    const project = getProjectBucket(payment.projectId, payment.projectName);
    if (!project.projectName && payment.projectName) {
      project.projectName = payment.projectName;
    }
    project.collection = roundMoney(project.collection + payment.amount);
  }

  const projectSummary = Array.from(projectMap.values()).sort((a, b) =>
    (a.projectName || a.projectId).localeCompare(b.projectName || b.projectId)
  );

  return Object.freeze({
    generatedForDate: normalizedToday,
    cards: Object.freeze({
      totalProjects: projectRows.length,
      totalPlots: plotCounts.total,
      availablePlots: plotCounts.available,
      holdPlots: plotCounts.hold,
      bookedPlots: plotCounts.booked,
      soldPlots: plotCounts.sold,
      totalBookings: bookingCounts.total,
      activeBookings: bookingCounts.booked,
      soldBookings: bookingCounts.sold,
      cancelledBookings: bookingCounts.cancelled,
      totalBookingValue,
      totalPaid,
      totalBalance,
      totalCollected,
      todayCollection,
      todayBookingCount: todayBookings.length,
    }),
    plotCounts: Object.freeze(plotCounts),
    bookingCounts: Object.freeze(bookingCounts),
    recentBookings: Object.freeze(recentBookings),
    recentPayments: Object.freeze(recentPayments),
    projectSummary: Object.freeze(projectSummary),
  });
}

function buildDashboardActions(snapshot) {
  if (!snapshot || typeof snapshot !== 'object') {
    throw new TypeError('snapshot is required.');
  }

  return Object.freeze([
    Object.freeze({
      id: 'OPEN_PROJECTS',
      label: 'Projects',
      target: 'PROJECT_LIST',
      value: snapshot.cards.totalProjects,
    }),
    Object.freeze({
      id: 'OPEN_AVAILABLE_PLOTS',
      label: 'Available Plots',
      target: 'PLOT_LIST',
      filter: Object.freeze({ status: 'AVAILABLE' }),
      value: snapshot.cards.availablePlots,
    }),
    Object.freeze({
      id: 'OPEN_HOLD_PLOTS',
      label: 'Hold Plots',
      target: 'PLOT_LIST',
      filter: Object.freeze({ status: 'HOLD' }),
      value: snapshot.cards.holdPlots,
    }),
    Object.freeze({
      id: 'OPEN_BOOKINGS',
      label: 'Bookings',
      target: 'BOOKING_LIST',
      value: snapshot.cards.totalBookings,
    }),
    Object.freeze({
      id: 'OPEN_PENDING',
      label: 'Pending Balance',
      target: 'PENDING_PAYMENT_REPORT',
      value: snapshot.cards.totalBalance,
    }),
    Object.freeze({
      id: 'OPEN_TODAY_COLLECTION',
      label: 'Today Collection',
      target: 'COLLECTION_REPORT',
      filter: Object.freeze({
        dateFrom: snapshot.generatedForDate,
        dateTo: snapshot.generatedForDate,
      }),
      value: snapshot.cards.todayCollection,
    }),
  ]);
}

class DashboardIntegrationService {
  build(input) {
    return buildDashboardSnapshot(input);
  }

  actions(snapshot) {
    return buildDashboardActions(snapshot);
  }
}

module.exports = {
  text,
  upper,
  finiteNumber,
  nonNegative,
  roundMoney,
  normalizeDate,
  derivePlotStatus,
  deriveBookingStatus,
  normalizeBooking,
  normalizePayment,
  normalizeProject,
  normalizePlot,
  buildDashboardSnapshot,
  buildDashboardActions,
  DashboardIntegrationService,
};
