'use strict';

const DISCOUNT_TYPES = Object.freeze({
  NONE: 'NONE',
  FIXED: 'FIXED',
  PERCENT: 'PERCENT',
});

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function number(value, fieldName) {
  const result = Number(value);
  if (!Number.isFinite(result)) {
    throw new TypeError(`${fieldName} must be a valid number.`);
  }
  return result;
}

function nonNegative(value, fieldName) {
  const result = number(value, fieldName);
  if (result < 0) {
    throw new RangeError(`${fieldName} cannot be negative.`);
  }
  return result;
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function roundQuantity(value, decimals = 4) {
  const factor = 10 ** decimals;
  return Math.round((Number(value) + Number.EPSILON) * factor) / factor;
}

function calculateBasePrice(area, ratePerUnit) {
  const safeArea = nonNegative(area, 'area');
  const safeRate = nonNegative(ratePerUnit, 'ratePerUnit');

  if (safeArea <= 0) {
    throw new RangeError('area must be greater than zero.');
  }

  return roundMoney(safeArea * safeRate);
}

function calculateDiscount(basePrice, discount = {}) {
  const safeBase = nonNegative(basePrice, 'basePrice');
  const type = upper(discount.type || DISCOUNT_TYPES.NONE);
  const value = nonNegative(discount.value || 0, 'discount.value');

  if (!Object.values(DISCOUNT_TYPES).includes(type)) {
    throw new RangeError('Unsupported discount type.');
  }

  if (type === DISCOUNT_TYPES.NONE) {
    return Object.freeze({
      type,
      value: 0,
      amount: 0,
    });
  }

  if (type === DISCOUNT_TYPES.PERCENT && value > 100) {
    throw new RangeError('Percentage discount cannot exceed 100.');
  }

  const amount =
    type === DISCOUNT_TYPES.FIXED
      ? value
      : safeBase * (value / 100);

  if (amount > safeBase) {
    throw new RangeError('Discount cannot exceed base price.');
  }

  return Object.freeze({
    type,
    value: roundQuantity(value, 4),
    amount: roundMoney(amount),
  });
}

function calculateTaxableAmount({
  basePrice,
  discountAmount = 0,
  adminCharges = 0,
  fileCharges = 0,
  otherCharges = 0,
}) {
  const base = nonNegative(basePrice, 'basePrice');
  const discount = nonNegative(discountAmount, 'discountAmount');
  const admin = nonNegative(adminCharges, 'adminCharges');
  const file = nonNegative(fileCharges, 'fileCharges');
  const other = nonNegative(otherCharges, 'otherCharges');

  if (discount > base) {
    throw new RangeError('discountAmount cannot exceed basePrice.');
  }

  return roundMoney(base - discount + admin + file + other);
}

function calculateTax(taxableAmount, taxRatePercent = 0) {
  const taxable = nonNegative(taxableAmount, 'taxableAmount');
  const rate = nonNegative(taxRatePercent, 'taxRatePercent');

  if (rate > 100) {
    throw new RangeError('taxRatePercent cannot exceed 100.');
  }

  return Object.freeze({
    ratePercent: roundQuantity(rate, 4),
    amount: roundMoney(taxable * (rate / 100)),
  });
}

function calculatePaymentPosition(grandTotal, paidAmount = 0) {
  const total = nonNegative(grandTotal, 'grandTotal');
  const paid = nonNegative(paidAmount, 'paidAmount');

  if (paid > total) {
    throw new RangeError('paidAmount cannot exceed grandTotal.');
  }

  const balance = roundMoney(total - paid);
  const paymentPercent =
    total === 0 ? 0 : roundQuantity((paid / total) * 100, 2);

  let paymentStage = 'UNPAID';
  if (paid > 0 && paid < total) paymentStage = 'PARTIAL';
  if (total > 0 && paid === total) paymentStage = 'FULL';

  return Object.freeze({
    paidAmount: roundMoney(paid),
    balanceAmount: balance,
    paymentPercent,
    paymentStage,
    soldEligible: total > 0 && paid === total,
  });
}

function buildInstallmentSchedule({
  balanceAmount,
  installmentCount,
  firstDueDate,
  frequencyMonths = 1,
}) {
  const balance = nonNegative(balanceAmount, 'balanceAmount');
  const count = number(installmentCount, 'installmentCount');
  const frequency = number(frequencyMonths, 'frequencyMonths');

  if (!Number.isInteger(count) || count <= 0) {
    throw new RangeError('installmentCount must be a positive integer.');
  }

  if (!Number.isInteger(frequency) || frequency <= 0) {
    throw new RangeError('frequencyMonths must be a positive integer.');
  }

  const dueDate = new Date(firstDueDate);
  if (Number.isNaN(dueDate.getTime())) {
    throw new TypeError('firstDueDate must be a valid date.');
  }

  const regularAmount = roundMoney(balance / count);
  const schedule = [];
  let allocated = 0;

  for (let index = 0; index < count; index += 1) {
    const date = new Date(dueDate);
    date.setUTCMonth(date.getUTCMonth() + index * frequency);

    const amount =
      index === count - 1
        ? roundMoney(balance - allocated)
        : regularAmount;

    allocated = roundMoney(allocated + amount);

    schedule.push(
      Object.freeze({
        installmentNumber: index + 1,
        dueDate: date.toISOString().slice(0, 10),
        amount,
      })
    );
  }

  return Object.freeze(schedule);
}

function calculateBooking(input = {}) {
  const area = nonNegative(input.area, 'area');
  const ratePerUnit = nonNegative(input.ratePerUnit, 'ratePerUnit');

  if (area <= 0) {
    throw new RangeError('area must be greater than zero.');
  }

  const basePrice = calculateBasePrice(area, ratePerUnit);
  const discount = calculateDiscount(basePrice, input.discount || {});

  const adminCharges = roundMoney(
    nonNegative(input.adminCharges || 0, 'adminCharges')
  );
  const fileCharges = roundMoney(
    nonNegative(input.fileCharges || 0, 'fileCharges')
  );
  const otherCharges = roundMoney(
    nonNegative(input.otherCharges || 0, 'otherCharges')
  );

  const taxableAmount = calculateTaxableAmount({
    basePrice,
    discountAmount: discount.amount,
    adminCharges,
    fileCharges,
    otherCharges,
  });

  const tax = calculateTax(
    taxableAmount,
    input.taxRatePercent || 0
  );

  const grandTotal = roundMoney(taxableAmount + tax.amount);
  const payment = calculatePaymentPosition(
    grandTotal,
    input.paidAmount || 0
  );

  return Object.freeze({
    currency: upper(input.currency || 'INR'),
    unit: upper(input.unit || 'SQ_YARD'),
    area: roundQuantity(area, 4),
    ratePerUnit: roundMoney(ratePerUnit),
    basePrice,
    discount,
    adminCharges,
    fileCharges,
    otherCharges,
    taxableAmount,
    tax,
    grandTotal,
    ...payment,
  });
}

class BookingCalculationEngine {
  calculate(input) {
    return calculateBooking(input);
  }

  calculateBasePrice(area, ratePerUnit) {
    return calculateBasePrice(area, ratePerUnit);
  }

  calculateDiscount(basePrice, discount) {
    return calculateDiscount(basePrice, discount);
  }

  calculateTax(taxableAmount, taxRatePercent) {
    return calculateTax(taxableAmount, taxRatePercent);
  }

  calculatePaymentPosition(grandTotal, paidAmount) {
    return calculatePaymentPosition(grandTotal, paidAmount);
  }

  buildInstallmentSchedule(input) {
    return buildInstallmentSchedule(input);
  }
}

module.exports = {
  DISCOUNT_TYPES,
  text,
  upper,
  number,
  nonNegative,
  roundMoney,
  roundQuantity,
  calculateBasePrice,
  calculateDiscount,
  calculateTaxableAmount,
  calculateTax,
  calculatePaymentPosition,
  buildInstallmentSchedule,
  calculateBooking,
  BookingCalculationEngine,
};
