'use strict';

const assert = require('assert');

const {
  PAYMENT_MODES,
  PAYMENT_STATUSES,
  text,
  upper,
  finiteNumber,
  nonNegative,
  positive,
  roundMoney,
  normalizeDate,
  validatePaymentMode,
  derivePaymentPosition,
  createPaymentRecord,
  postPayment,
  reversePayment,
  calculateLedgerSummary,
  PaymentEngine,
} = require('./payment-engine');

(() => {
  console.log('Falcon Payment Engine Tests');
  console.log('---------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  check(PAYMENT_MODES.CASH, 'CASH');
  check(PAYMENT_STATUSES.POSTED, 'POSTED');
  check(text(' Falcon '), 'Falcon');
  check(upper('upi'), 'UPI');
  check(finiteNumber('1250', 'amount'), 1250);
  check(nonNegative(0, 'amount'), 0);
  check(positive(1, 'amount'), 1);
  check(roundMoney(10.005), 10.01);
  check(normalizeDate('29-07-2026'), '2026-07-29');
  check(normalizeDate('2026-07-29'), '2026-07-29');
  check(validatePaymentMode('bank_transfer'), 'BANK_TRANSFER');

  assert.throws(() => finiteNumber('bad', 'amount'), /valid number/);
  assertions += 1;

  assert.throws(() => nonNegative(-1, 'amount'), /cannot be negative/);
  assertions += 1;

  assert.throws(() => positive(0, 'amount'), /greater than zero/);
  assertions += 1;

  assert.throws(() => validatePaymentMode('crypto'), /Unsupported/);
  assertions += 1;

  const unpaid = derivePaymentPosition(500000, 0);
  check(unpaid.paymentStage, 'UNPAID');
  check(unpaid.balanceAmount, 500000);
  check(unpaid.soldEligible, false);

  const partial = derivePaymentPosition(500000, 125000);
  check(partial.paymentStage, 'PARTIAL');
  check(partial.balanceAmount, 375000);
  check(partial.paymentPercent, 25);
  check(partial.soldEligible, false);

  const full = derivePaymentPosition(500000, 500000);
  check(full.paymentStage, 'FULL');
  check(full.balanceAmount, 0);
  check(full.paymentPercent, 100);
  check(full.soldEligible, true);

  assert.throws(
    () => derivePaymentPosition(500000, 500001),
    /cannot exceed totalAmount/
  );
  assertions += 1;

  const cashRecord = createPaymentRecord({
    paymentId: 'pay-000001',
    bookingId: 'fb-000001',
    amount: 100000,
    mode: 'cash',
    paymentDate: '29-07-2026',
    receiptNumber: 'rcp-000001',
    actorId: 'fu-000001',
  });

  check(cashRecord.paymentId, 'PAY-000001');
  check(cashRecord.bookingId, 'FB-000001');
  check(cashRecord.amount, 100000);
  check(cashRecord.mode, 'CASH');
  check(cashRecord.paymentDate, '2026-07-29');
  check(cashRecord.receiptNumber, 'RCP-000001');
  check(cashRecord.actorId, 'FU-000001');
  check(cashRecord.status, 'POSTED');

  assert.throws(
    () =>
      createPaymentRecord({
        paymentId: 'PAY-000002',
        bookingId: 'FB-000001',
        amount: 50000,
        mode: 'UPI',
        paymentDate: '2026-07-29',
      }),
    /referenceNumber is required/
  );
  assertions += 1;

  const booking = {
    bookingId: 'FB-000001',
    grandTotal: 500000,
  };

  const existingPayments = [
    {
      paymentId: 'PAY-000001',
      bookingId: 'FB-000001',
      amount: 100000,
      mode: 'CASH',
      status: 'POSTED',
      receiptNumber: 'RCP-000001',
    },
    {
      paymentId: 'PAY-000000',
      bookingId: 'FB-000001',
      amount: 25000,
      mode: 'CASH',
      status: 'REVERSED',
      receiptNumber: 'RCP-OLD',
    },
  ];

  const posted = postPayment({
    booking,
    existingPayments,
    payment: {
      paymentId: 'PAY-000002',
      bookingId: 'FB-000001',
      amount: 150000,
      mode: 'UPI',
      referenceNumber: 'UPI-REF-123',
      receiptNumber: 'RCP-000002',
      paymentDate: '2026-07-29',
      actorId: 'FU-000001',
    },
  });

  check(posted.summary.previousPaid, 100000);
  check(posted.summary.paymentAmount, 150000);
  check(posted.summary.cumulativePaid, 250000);
  check(posted.summary.balanceAmount, 250000);
  check(posted.summary.paymentPercent, 50);
  check(posted.summary.paymentStage, 'PARTIAL');
  check(posted.summary.soldEligible, false);

  const finalPayment = postPayment({
    booking,
    existingPayments: [
      ...existingPayments,
      posted.payment,
    ],
    payment: {
      paymentId: 'PAY-000003',
      bookingId: 'FB-000001',
      amount: 250000,
      mode: 'BANK_TRANSFER',
      referenceNumber: 'BANK-REF-999',
      receiptNumber: 'RCP-000003',
      paymentDate: '2026-07-29',
      actorId: 'FU-000001',
    },
  });

  check(finalPayment.summary.cumulativePaid, 500000);
  check(finalPayment.summary.balanceAmount, 0);
  check(finalPayment.summary.paymentStage, 'FULL');
  check(finalPayment.summary.soldEligible, true);

  assert.throws(
    () =>
      postPayment({
        booking,
        existingPayments,
        payment: {
          paymentId: 'PAY-000004',
          bookingId: 'FB-000001',
          amount: 450000,
          mode: 'CASH',
          receiptNumber: 'RCP-000004',
          paymentDate: '2026-07-29',
        },
      }),
    /exceed booking balance/
  );
  assertions += 1;

  assert.throws(
    () =>
      postPayment({
        booking,
        existingPayments,
        payment: {
          paymentId: 'PAY-000001',
          bookingId: 'FB-000001',
          amount: 10000,
          mode: 'CASH',
          receiptNumber: 'RCP-000005',
          paymentDate: '2026-07-29',
        },
      }),
    /Duplicate paymentId/
  );
  assertions += 1;

  assert.throws(
    () =>
      postPayment({
        booking,
        existingPayments,
        payment: {
          paymentId: 'PAY-000005',
          bookingId: 'FB-000001',
          amount: 10000,
          mode: 'CASH',
          receiptNumber: 'RCP-000001',
          paymentDate: '2026-07-29',
        },
      }),
    /Duplicate receiptNumber/
  );
  assertions += 1;

  const reversed = reversePayment({
    payment: posted.payment,
    actorId: 'FU-000001',
    reason: 'Wrong payment entry',
    reversedAt: '2026-07-29T10:00:00.000Z',
  });

  check(reversed.status, 'REVERSED');
  check(reversed.reversalReason, 'Wrong payment entry');
  check(reversed.reversedBy, 'FU-000001');
  check(reversed.reversedAt, '2026-07-29T10:00:00.000Z');

  assert.throws(
    () =>
      reversePayment({
        payment: reversed,
        actorId: 'FU-000001',
        reason: 'Again reverse',
      }),
    /already reversed/
  );
  assertions += 1;

  assert.throws(
    () =>
      reversePayment({
        payment: posted.payment,
        actorId: 'FU-000001',
        reason: 'No',
      }),
    /at least 5 characters/
  );
  assertions += 1;

  const summary = calculateLedgerSummary({
    booking,
    payments: [
      existingPayments[0],
      reversed,
      finalPayment.payment,
    ],
  });

  check(summary.totalAmount, 500000);
  check(summary.postedPaymentCount, 2);
  check(summary.reversedPaymentCount, 1);
  check(summary.cumulativePaid, 350000);
  check(summary.balanceAmount, 150000);
  check(summary.paymentStage, 'PARTIAL');
  check(summary.soldEligible, false);

  const engine = new PaymentEngine();
  const engineSummary = engine.summarize({
    booking,
    payments: [
      {
        paymentId: 'PAY-100001',
        amount: 500000,
        status: 'POSTED',
      },
    ],
  });

  check(engineSummary.cumulativePaid, 500000);
  check(engineSummary.balanceAmount, 0);
  check(engineSummary.soldEligible, true);

  console.log('Payment Mode Validation: PASS');
  console.log('Payment Record Creation: PASS');
  console.log('Balance Check: PASS');
  console.log('Overpayment Protection: PASS');
  console.log('Duplicate Payment Protection: PASS');
  console.log('Duplicate Receipt Protection: PASS');
  console.log('Cumulative Paid Calculation: PASS');
  console.log('100 Percent Sold Eligibility: PASS');
  console.log('Payment Reversal Safety: PASS');
  console.log('Ledger Summary: PASS');
  console.log('Reusable Payment Engine: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('---------------------------');
  console.log('PAYMENT ENGINE TEST PASS');
})();
