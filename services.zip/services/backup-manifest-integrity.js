'use strict';

const crypto = require('crypto');

const BACKUP_SECTIONS = Object.freeze([
  'projects',
  'plots',
  'customers',
  'bookings',
  'payments',
  'receipts',
  'ledger',
  'documents',
  'reports',
  'settings',
  'audit',
]);

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function normalizeSections(sections) {
  if (sections === undefined || sections === null) {
    return Object.freeze([...BACKUP_SECTIONS]);
  }

  if (!Array.isArray(sections)) {
    throw new TypeError('sections must be an array.');
  }

  const normalized = [...new Set(sections.map((item) => text(item).toLowerCase()).filter(Boolean))];

  for (const section of normalized) {
    if (!BACKUP_SECTIONS.includes(section)) {
      throw new RangeError(`Unsupported backup section: ${section}`);
    }
  }

  return Object.freeze(normalized);
}

function stableStringify(value) {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value);
  }

  if (Array.isArray(value)) {
    return `[${value.map(stableStringify).join(',')}]`;
  }

  const keys = Object.keys(value).sort();
  return `{${keys.map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
}

function sha256(value) {
  return crypto
    .createHash('sha256')
    .update(typeof value === 'string' ? value : stableStringify(value))
    .digest('hex');
}

function createSectionDigest(sectionName, data) {
  const section = text(sectionName).toLowerCase();
  if (!BACKUP_SECTIONS.includes(section)) {
    throw new RangeError(`Unsupported backup section: ${section}`);
  }

  const payload = data === undefined ? null : data;
  const count = Array.isArray(payload)
    ? payload.length
    : payload && typeof payload === 'object'
    ? Object.keys(payload).length
    : payload === null
    ? 0
    : 1;

  return Object.freeze({
    section,
    count,
    hash: sha256(payload),
  });
}

function createBackupManifest({
  backupId,
  appVersion,
  createdAt,
  actorId,
  sections,
  data = {},
  sourceDevice = '',
  projectId = '',
} = {}) {
  const cleanBackupId = upper(backupId);
  if (!cleanBackupId) throw new Error('backupId is required.');

  const selectedSections = normalizeSections(sections);
  const sectionDigests = selectedSections.map((section) =>
    createSectionDigest(section, data[section])
  );

  const manifestCore = {
    schemaVersion: 1,
    backupId: cleanBackupId,
    appVersion: text(appVersion),
    createdAt: text(createdAt) || new Date().toISOString(),
    actorId: upper(actorId),
    sourceDevice: text(sourceDevice),
    projectId: upper(projectId),
    sections: selectedSections,
    sectionDigests,
  };

  const manifestHash = sha256(manifestCore);

  return Object.freeze({
    ...manifestCore,
    manifestHash,
  });
}

function verifyBackupManifest({
  manifest,
  data = {},
}) {
  if (!manifest || typeof manifest !== 'object') {
    throw new TypeError('manifest is required.');
  }

  const selectedSections = normalizeSections(manifest.sections);

  const recalculatedDigests = selectedSections.map((section) =>
    createSectionDigest(section, data[section])
  );

  const sectionResults = recalculatedDigests.map((digest) => {
    const expected = (manifest.sectionDigests || []).find(
      (item) => item.section === digest.section
    );

    return Object.freeze({
      section: digest.section,
      valid: Boolean(
        expected &&
          expected.hash === digest.hash &&
          expected.count === digest.count
      ),
      expectedHash: expected ? expected.hash : '',
      actualHash: digest.hash,
      expectedCount: expected ? expected.count : null,
      actualCount: digest.count,
    });
  });

  const core = {
    schemaVersion: manifest.schemaVersion,
    backupId: manifest.backupId,
    appVersion: manifest.appVersion,
    createdAt: manifest.createdAt,
    actorId: manifest.actorId,
    sourceDevice: manifest.sourceDevice,
    projectId: manifest.projectId,
    sections: manifest.sections,
    sectionDigests: manifest.sectionDigests,
  };

  const manifestHashValid = sha256(core) === manifest.manifestHash;
  const allSectionsValid = sectionResults.every((item) => item.valid);

  return Object.freeze({
    valid: manifestHashValid && allSectionsValid,
    manifestHashValid,
    allSectionsValid,
    sectionResults: Object.freeze(sectionResults),
  });
}

function buildBackupPlan({
  sections,
  includeAllByDefault = true,
} = {}) {
  const selected = sections
    ? normalizeSections(sections)
    : includeAllByDefault
    ? normalizeSections()
    : Object.freeze([]);

  return Object.freeze(
    BACKUP_SECTIONS.map((section) =>
      Object.freeze({
        section,
        selected: selected.includes(section),
      })
    )
  );
}

function validateRestoreCompatibility({
  manifest,
  supportedSchemaVersion = 1,
  currentAppVersion = '',
} = {}) {
  if (!manifest || typeof manifest !== 'object') {
    throw new TypeError('manifest is required.');
  }

  const issues = [];

  if (manifest.schemaVersion !== supportedSchemaVersion) {
    issues.push('Unsupported backup schema version.');
  }

  if (!upper(manifest.backupId)) {
    issues.push('Backup ID is missing.');
  }

  if (!Array.isArray(manifest.sections) || manifest.sections.length === 0) {
    issues.push('Backup contains no sections.');
  }

  return Object.freeze({
    compatible: issues.length === 0,
    currentAppVersion: text(currentAppVersion),
    backupAppVersion: text(manifest.appVersion),
    issues: Object.freeze(issues),
  });
}

function createRestorePreview({
  manifest,
  data = {},
}) {
  const verification = verifyBackupManifest({ manifest, data });

  const rows = normalizeSections(manifest.sections).map((section) => {
    const digest = (manifest.sectionDigests || []).find(
      (item) => item.section === section
    );

    return Object.freeze({
      section,
      recordCount: digest ? digest.count : 0,
      integrityValid: verification.sectionResults.find(
        (item) => item.section === section
      ).valid,
    });
  });

  return Object.freeze({
    backupId: manifest.backupId,
    createdAt: manifest.createdAt,
    projectId: manifest.projectId,
    appVersion: manifest.appVersion,
    integrityValid: verification.valid,
    sections: Object.freeze(rows),
  });
}

class BackupManifestIntegrityService {
  sections() {
    return Object.freeze([...BACKUP_SECTIONS]);
  }

  plan(input) {
    return buildBackupPlan(input);
  }

  createManifest(input) {
    return createBackupManifest(input);
  }

  verify(input) {
    return verifyBackupManifest(input);
  }

  compatibility(input) {
    return validateRestoreCompatibility(input);
  }

  preview(input) {
    return createRestorePreview(input);
  }
}

module.exports = {
  BACKUP_SECTIONS,
  text,
  upper,
  normalizeSections,
  stableStringify,
  sha256,
  createSectionDigest,
  createBackupManifest,
  verifyBackupManifest,
  buildBackupPlan,
  validateRestoreCompatibility,
  createRestorePreview,
  BackupManifestIntegrityService,
};
