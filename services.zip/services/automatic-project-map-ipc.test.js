'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const {
  registerAutomaticProjectMapIpc,
} = require('./automatic-project-map-ipc');

(() => {
  console.log('Falcon MAP.8.1 Automatic Project IPC Bridge Tests');
  console.log('-------------------------------------------------');

  let assertions = 0;
  const yes = (v) => { assert.strictEqual(v, true); assertions += 1; };
  const check = (a, e) => { assert.deepStrictEqual(a, e); assertions += 1; };

  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'falcon-map81-ipc-'));
  const projectFolder = path.join(root, 'FP-000001');
  fs.mkdirSync(path.join(projectFolder, 'maps'), { recursive: true });

  fs.writeFileSync(
    path.join(projectFolder, 'maps', 'map-ready.json'),
    JSON.stringify({
      projectId: 'FP-000001',
      layers: {
        plots: [{
          plotNumber: '1',
          vertices: [
            { x: 0, y: 0 },
            { x: 10, y: 0 },
            { x: 10, y: 10 },
            { x: 0, y: 10 }
          ]
        }],
        roads: [],
        specialAreas: []
      }
    }, null, 2),
    'utf8'
  );

  const handlers = {};
  const ipcMain = {
    handle(name, fn) {
      handlers[name] = fn;
    }
  };

  const project = {
    projectId: 'FP-000001',
    projectName: 'Test Project',
    projectFolder,
  };

  yes(registerAutomaticProjectMapIpc({
    ipcMain,
    getCurrentProject: () => project,
  }));

  yes(typeof handlers['falcon:project:get-current-project'] === 'function');
  yes(typeof handlers['falcon:project:get-current-map-model'] === 'function');

  Promise.resolve()
    .then(async () => {
      const currentProject =
        await handlers['falcon:project:get-current-project']();

      check(currentProject.projectId, 'FP-000001');

      const mapModel =
        await handlers['falcon:project:get-current-map-model']();

      check(mapModel.projectId, 'FP-000001');
      check(mapModel.layers.plots.length, 1);

      console.log('Active Project IPC: PASS');
      console.log('Automatic Real Map IPC: PASS');
      console.log('Premium Viewer Map Model IPC: PASS');
      console.log(`Assertions Passed: ${assertions}`);
      console.log('-------------------------------------------------');
      console.log('MAP AUTOMATIC PROJECT IPC BRIDGE TEST PASS');
    })
    .catch(error => {
      console.error(error);
      process.exit(1);
    });
})();
