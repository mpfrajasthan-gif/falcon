'use strict';

const assert = require('assert');

const {
  normalizeDate,
  isWithinRange,
  deriveBookingStatus,
  derivePaymentStage,
  normalizeBooking,
  normalizePayment,
  buildBookingSummary,
  buildCollectionReport,
  buildPendingPaymentReport,
  buildSoldPlotReport,
  buildCustomerWiseReport,
  buildProjectWiseReport,
  exportReportData,
  ReportEngine,
} = require('./report-engine');

(() => {
  console.log('Falcon Report Engine Tests');
  console.log('--------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  function checkFalse(value) {
    assert.strictEqual(value, false);
    assertions += 1;
  }

  const bookings = [
    {
      bookingId: 'FB-000001',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '43',
      customerId: 'FC-000001',
      customerName: 'Shadab Aziz',
      customerMobile: '9876543210',
      bookingDate: '29-07-2026',
      grandTotal: 500000,
      paidAmount: 125000,
      balanceAmount: 375000,
      status: 'BOOKED',
    },
    {
      bookingId: 'FB-000002',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '10',
      customerId: 'FC-000002',
      customerName: 'Aamir Khan',
      customerMobile: '9123456780',
      bookingDate: '28-07-2026',
      grandTotal: 300000,
      paidAmount: 300000,
      balanceAmount: 0,
      status: 'SOLD',
    },
    {
      bookingId: 'FB-000003',
      projectId: 'FP-000002',
      projectName: 'Sawai Estate',
      plotNumber: '7',
      customerId: 'FC-000003',
      customerName: 'Nadeem Khan',
      customerMobile: '9988776655',
      bookingDate: '20-07-2026',
      grandTotal: 250000,
      paidAmount: 0,
      balanceAmount: 250000,
      status: 'CANCELLED',
    },
    {
      bookingId: 'FB-000004',
      projectId: 'FP-000002',
      projectName: 'Sawai Estate',
      plotNumber: '8',
      customerId: 'FC-000001',
      customerName: 'Shadab Aziz',
      customerMobile: '9876543210',
      bookingDate: '25-07-2026',
      grandTotal: 450000,
      paidAmount: 0,
      balanceAmount: 450000,
      status: 'BOOKED',
    },
  ];

  const payments = [
    {
      paymentId: 'PAY-000001',
      bookingId: 'FB-000001',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      amount: 100000,
      paymentDate: '29-07-2026',
      mode: 'CASH',
      status: 'POSTED',
      receiptNumber: 'RCP-000001',
    },
    {
      paymentId: 'PAY-000002',
      bookingId: 'FB-000001',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      amount: 25000,
      paymentDate: '29-07-2026',
      mode: 'UPI',
      status: 'POSTED',
      receiptNumber: 'RCP-000002',
    },
    {
      paymentId: 'PAY-000003',
      bookingId: 'FB-000002',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      amount: 300000,
      paymentDate: '28-07-2026',
      mode: 'BANK_TRANSFER',
      status: 'POSTED',
      receiptNumber: 'RCP-000003',
    },
    {
      paymentId: 'PAY-000004',
      bookingId: 'FB-000004',
      projectId: 'FP-000002',
      projectName: 'Sawai Estate',
      amount: 50000,
      paymentDate: '25-07-2026',
      mode: 'CASH',
      status: 'REVERSED',
      receiptNumber: 'RCP-000004',
    },
  ];

  check(normalizeDate('29-07-2026'), '2026-07-29');
  checkTrue(isWithinRange('2026-07-29', '2026-07-01', '2026-07-31'));
  checkFalse(isWithinRange('2026-08-01', '2026-07-01', '2026-07-31'));

  check(deriveBookingStatus(bookings[0]), 'BOOKED');
  check(deriveBookingStatus(bookings[1]), 'SOLD');
  check(derivePaymentStage(bookings[0]), 'PARTIAL');
  check(derivePaymentStage(bookings[1]), 'FULL');
  check(derivePaymentStage(bookings[2]), 'UNPAID');

  const normalizedBooking = normalizeBooking(bookings[0]);
  check(normalizedBooking.bookingDate, '2026-07-29');
  check(normalizedBooking.totalAmount, 500000);
  check(normalizedBooking.balanceAmount, 375000);

  const normalizedPayment = normalizePayment(payments[0]);
  check(normalizedPayment.paymentDate, '2026-07-29');
  check(normalizedPayment.mode, 'CASH');

  const summary = buildBookingSummary(bookings);
  check(summary.summary.totalBookings, 4);
  check(summary.summary.bookedCount, 2);
  check(summary.summary.soldCount, 1);
  check(summary.summary.cancelledCount, 1);
  check(summary.summary.unpaidCount, 2);
  check(summary.summary.partialCount, 1);
  check(summary.summary.fullCount, 1);
  check(summary.summary.totalBookingValue, 1500000);
  check(summary.summary.totalPaid, 425000);
  check(summary.summary.totalBalance, 1075000);

  const projectSummary = buildBookingSummary(bookings, {
    projectId: 'FP-000001',
  });
  check(projectSummary.summary.totalBookings, 2);
  check(projectSummary.summary.totalBookingValue, 800000);

  const collection = buildCollectionReport(payments);
  check(collection.summary.paymentCount, 3);
  check(collection.summary.totalCollection, 425000);
  check(collection.summary.byMode.CASH, 100000);
  check(collection.summary.byMode.UPI, 25000);
  check(collection.summary.byMode.BANK_TRANSFER, 300000);
  check(collection.summary.byDate['2026-07-29'], 125000);

  const dailyCollection = buildCollectionReport(payments, {
    dateFrom: '29-07-2026',
    dateTo: '29-07-2026',
  });
  check(dailyCollection.summary.totalCollection, 125000);
  check(dailyCollection.summary.paymentCount, 2);

  const pending = buildPendingPaymentReport(bookings);
  check(pending.summary.pendingBookingCount, 2);
  check(pending.summary.totalPending, 825000);

  const sold = buildSoldPlotReport(bookings);
  check(sold.summary.soldCount, 1);
  check(sold.summary.soldValue, 300000);
  check(sold.rows[0].plotNumber, '10');

  const customerWise = buildCustomerWiseReport(bookings);
  check(customerWise.summary.customerCount, 3);
  check(customerWise.summary.bookingCount, 4);
  check(customerWise.summary.totalValue, 1500000);
  check(customerWise.summary.totalPaid, 425000);
  check(customerWise.summary.totalBalance, 1075000);

  const shadab = customerWise.rows.find((row) => row.customerId === 'FC-000001');
  check(shadab.bookingCount, 2);
  check(shadab.totalValue, 950000);
  check(shadab.totalPaid, 125000);
  check(shadab.totalBalance, 825000);

  const projectWise = buildProjectWiseReport(bookings, payments);
  check(projectWise.summary.projectCount, 2);
  check(projectWise.summary.bookingCount, 4);
  check(projectWise.summary.soldCount, 1);
  check(projectWise.summary.totalBookingValue, 1500000);
  check(projectWise.summary.totalCollection, 425000);

  const jaipur = projectWise.rows.find((row) => row.projectId === 'FP-000001');
  check(jaipur.bookingCount, 2);
  check(jaipur.soldCount, 1);
  check(jaipur.totalBookingValue, 800000);
  check(jaipur.collection, 425000);

  const sawai = projectWise.rows.find((row) => row.projectId === 'FP-000002');
  check(sawai.bookingCount, 2);
  check(sawai.collection, 0);

  const exportReady = exportReportData(collection, {
    reportName: 'Daily Collection Report',
    generatedAt: '2026-07-29T12:00:00.000Z',
    filters: {
      dateFrom: '29-07-2026',
      dateTo: '29-07-2026',
    },
  });

  check(exportReady.reportName, 'Daily Collection Report');
  check(exportReady.generatedAt, '2026-07-29T12:00:00.000Z');
  check(exportReady.summary.totalCollection, 425000);
  check(exportReady.rows.length, 3);

  const engine = new ReportEngine();

  const enginePending = engine.pending(bookings, {
    projectId: 'FP-000001',
  });
  check(enginePending.summary.pendingBookingCount, 1);
  check(enginePending.summary.totalPending, 375000);

  const engineSold = engine.sold(bookings, {
    projectName: 'Jaipur',
  });
  check(engineSold.summary.soldCount, 1);

  console.log('Booking Summary Report: PASS');
  console.log('Daily Collection Report: PASS');
  console.log('Pending Payment Report: PASS');
  console.log('Sold Plot Report: PASS');
  console.log('Customer-wise Report: PASS');
  console.log('Project-wise Report: PASS');
  console.log('Date Range Filters: PASS');
  console.log('Payment Mode Summary: PASS');
  console.log('Export-ready Structure: PASS');
  console.log('Reusable Report Engine: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('--------------------------');
  console.log('REPORT ENGINE TEST PASS');
})();
