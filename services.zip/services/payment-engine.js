'use strict';

const PAYMENT_MODES = Object.freeze({
  CASH: 'CASH',
  UPI: 'UPI',
  CARD: 'CARD',
  BANK_TRANSFER: 'BANK_TRANSFER',
  CHEQUE: 'CHEQUE',
  OTHER: 'OTHER',
});

const PAYMENT_STATUSES = Object.freeze({
  POSTED: 'POSTED',
  REVERSED: 'REVERSED',
});

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function finiteNumber(value, fieldName) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    throw new TypeError(`${fieldName} must be a valid number.`);
  }
  return number;
}

function nonNegative(value, fieldName) {
  const number = finiteNumber(value, fieldName);
  if (number < 0) {
    throw new RangeError(`${fieldName} cannot be negative.`);
  }
  return number;
}

function positive(value, fieldName) {
  const number = finiteNumber(value, fieldName);
  if (number <= 0) {
    throw new RangeError(`${fieldName} must be greater than zero.`);
  }
  return number;
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function normalizeDate(value) {
  const raw = text(value);
  if (!raw) return '';

  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    return raw;
  }

  const displayMatch = raw.match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (!displayMatch) return '';

  return `${displayMatch[3]}-${displayMatch[2]}-${displayMatch[1]}`;
}

function validatePaymentMode(mode) {
  const normalized = upper(mode);
  if (!Object.values(PAYMENT_MODES).includes(normalized)) {
    throw new RangeError('Unsupported payment mode.');
  }
  return normalized;
}

function derivePaymentPosition(totalAmount, cumulativePaid) {
  const total = nonNegative(totalAmount, 'totalAmount');
  const paid = nonNegative(cumulativePaid, 'cumulativePaid');

  if (paid > total) {
    throw new RangeError('cumulativePaid cannot exceed totalAmount.');
  }

  const balanceAmount = roundMoney(total - paid);
  const paymentPercent =
    total === 0 ? 0 : roundMoney((paid / total) * 100);

  let paymentStage = 'UNPAID';
  if (paid > 0 && paid < total) paymentStage = 'PARTIAL';
  if (total > 0 && paid === total) paymentStage = 'FULL';

  return Object.freeze({
    cumulativePaid: roundMoney(paid),
    balanceAmount,
    paymentPercent,
    paymentStage,
    soldEligible: total > 0 && paid === total,
  });
}

function createPaymentRecord(input = {}) {
  const bookingId = upper(input.bookingId);
  const paymentId = upper(input.paymentId);
  const receiptNumber = upper(input.receiptNumber);
  const amount = roundMoney(positive(input.amount, 'amount'));
  const mode = validatePaymentMode(input.mode);
  const paymentDate = normalizeDate(input.paymentDate);

  if (!bookingId) {
    throw new Error('bookingId is required.');
  }

  if (!paymentId) {
    throw new Error('paymentId is required.');
  }

  if (!paymentDate) {
    throw new Error('paymentDate must be DD-MM-YYYY or YYYY-MM-DD.');
  }

  if (mode !== PAYMENT_MODES.CASH && !text(input.referenceNumber)) {
    throw new Error('referenceNumber is required for non-cash payments.');
  }

  return Object.freeze({
    paymentId,
    bookingId,
    amount,
    mode,
    referenceNumber: text(input.referenceNumber),
    receiptNumber,
    paymentDate,
    notes: text(input.notes),
    actorId: upper(input.actorId),
    status: PAYMENT_STATUSES.POSTED,
    createdAt: text(input.createdAt) || new Date().toISOString(),
    reversedAt: null,
    reversalReason: '',
    reversedBy: '',
  });
}

function postPayment({
  booking,
  payment,
  existingPayments = [],
}) {
  if (!booking || typeof booking !== 'object') {
    throw new TypeError('booking is required.');
  }

  if (!Array.isArray(existingPayments)) {
    throw new TypeError('existingPayments must be an array.');
  }

  const totalAmount = roundMoney(
    nonNegative(
      booking.grandTotal !== undefined ? booking.grandTotal : booking.totalPrice,
      'booking total'
    )
  );

  if (totalAmount <= 0) {
    throw new RangeError('booking total must be greater than zero.');
  }

  const postedTotal = existingPayments
    .filter((item) => upper(item.status || PAYMENT_STATUSES.POSTED) === PAYMENT_STATUSES.POSTED)
    .reduce((sum, item) => roundMoney(sum + nonNegative(item.amount, 'existing payment amount')), 0);

  const record = createPaymentRecord(payment);

  const duplicatePayment = existingPayments.some(
    (item) => upper(item.paymentId) === record.paymentId
  );

  if (duplicatePayment) {
    throw new Error('Duplicate paymentId is not allowed.');
  }

  const duplicateReceipt =
    record.receiptNumber &&
    existingPayments.some(
      (item) =>
        upper(item.receiptNumber) === record.receiptNumber &&
        upper(item.status || PAYMENT_STATUSES.POSTED) === PAYMENT_STATUSES.POSTED
    );

  if (duplicateReceipt) {
    throw new Error('Duplicate receiptNumber is not allowed.');
  }

  const cumulativePaid = roundMoney(postedTotal + record.amount);

  if (cumulativePaid > totalAmount) {
    throw new RangeError('Payment would exceed booking balance.');
  }

  const position = derivePaymentPosition(totalAmount, cumulativePaid);

  return Object.freeze({
    payment: record,
    summary: Object.freeze({
      bookingId: upper(booking.bookingId || booking.id),
      totalAmount,
      previousPaid: postedTotal,
      paymentAmount: record.amount,
      ...position,
    }),
  });
}

function reversePayment({
  payment,
  actorId,
  reason,
  reversedAt,
}) {
  if (!payment || typeof payment !== 'object') {
    throw new TypeError('payment is required.');
  }

  if (upper(payment.status) === PAYMENT_STATUSES.REVERSED) {
    throw new Error('Payment is already reversed.');
  }

  const cleanReason = text(reason).replace(/\s+/g, ' ');
  if (cleanReason.length < 5) {
    throw new Error('Reversal reason must contain at least 5 characters.');
  }

  const cleanActorId = upper(actorId);
  if (!cleanActorId) {
    throw new Error('actorId is required.');
  }

  return Object.freeze({
    ...payment,
    status: PAYMENT_STATUSES.REVERSED,
    reversedAt: text(reversedAt) || new Date().toISOString(),
    reversalReason: cleanReason,
    reversedBy: cleanActorId,
  });
}

function calculateLedgerSummary({
  booking,
  payments = [],
}) {
  if (!booking || typeof booking !== 'object') {
    throw new TypeError('booking is required.');
  }

  if (!Array.isArray(payments)) {
    throw new TypeError('payments must be an array.');
  }

  const totalAmount = roundMoney(
    nonNegative(
      booking.grandTotal !== undefined ? booking.grandTotal : booking.totalPrice,
      'booking total'
    )
  );

  const postedPayments = payments.filter(
    (payment) =>
      upper(payment.status || PAYMENT_STATUSES.POSTED) === PAYMENT_STATUSES.POSTED
  );

  const cumulativePaid = postedPayments.reduce(
    (sum, payment) =>
      roundMoney(sum + nonNegative(payment.amount, 'payment amount')),
    0
  );

  const position = derivePaymentPosition(totalAmount, cumulativePaid);

  return Object.freeze({
    bookingId: upper(booking.bookingId || booking.id),
    totalAmount,
    postedPaymentCount: postedPayments.length,
    reversedPaymentCount: payments.length - postedPayments.length,
    ...position,
  });
}

class PaymentEngine {
  post(input) {
    return postPayment(input);
  }

  reverse(input) {
    return reversePayment(input);
  }

  summarize(input) {
    return calculateLedgerSummary(input);
  }
}

module.exports = {
  PAYMENT_MODES,
  PAYMENT_STATUSES,
  text,
  upper,
  finiteNumber,
  nonNegative,
  positive,
  roundMoney,
  normalizeDate,
  validatePaymentMode,
  derivePaymentPosition,
  createPaymentRecord,
  postPayment,
  reversePayment,
  calculateLedgerSummary,
  PaymentEngine,
};
