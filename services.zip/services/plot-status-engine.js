'use strict';

const PLOT_STATUS = Object.freeze({
  AVAILABLE: 'AVAILABLE',
  HOLD: 'HOLD',
  BOOKED: 'BOOKED',
  SOLD: 'SOLD',
});

const USER_ROLE = Object.freeze({
  ADMIN: 'ADMIN',
  SUPER_ADMIN: 'SUPER_ADMIN',
  OPERATOR: 'OPERATOR',
});

const ALLOWED_TRANSITIONS = Object.freeze({
  AVAILABLE: Object.freeze(['HOLD', 'BOOKED']),
  HOLD: Object.freeze(['AVAILABLE', 'BOOKED']),
  BOOKED: Object.freeze(['AVAILABLE', 'SOLD']),
  SOLD: Object.freeze([]),
});

function normalizeText(value) {
  if (value === null || value === undefined) return '';
  return String(value).trim().toUpperCase();
}

function normalizeAmount(value) {
  if (
    value === null ||
    value === undefined ||
    value === '' ||
    typeof value === 'boolean'
  ) {
    return 0;
  }

  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? number : 0;
}

function isValidStatus(status) {
  return Object.values(PLOT_STATUS).includes(normalizeText(status));
}

function isAdminRole(role) {
  const normalizedRole = normalizeText(role);
  return (
    normalizedRole === USER_ROLE.ADMIN ||
    normalizedRole === USER_ROLE.SUPER_ADMIN
  );
}

function calculatePaymentProgress(totalPrice, paidAmount) {
  const total = normalizeAmount(totalPrice);
  const paid = normalizeAmount(paidAmount);

  if (total <= 0) {
    return Object.freeze({
      totalPrice: total,
      paidAmount: paid,
      balance: 0,
      percentage: 0,
      isFullyPaid: false,
    });
  }

  const appliedPaidAmount = Math.min(paid, total);
  const balance = Math.max(0, total - appliedPaidAmount);
  const percentage = Math.min(100, (appliedPaidAmount / total) * 100);

  return Object.freeze({
    totalPrice: total,
    paidAmount: appliedPaidAmount,
    balance,
    percentage,
    isFullyPaid: balance === 0,
  });
}

function canTransition(currentStatus, targetStatus) {
  const current = normalizeText(currentStatus);
  const target = normalizeText(targetStatus);

  if (!isValidStatus(current) || !isValidStatus(target)) {
    return false;
  }

  if (current === target) {
    return true;
  }

  return ALLOWED_TRANSITIONS[current].includes(target);
}

function evaluatePlotStatusChange({
  currentStatus,
  targetStatus,
  role,
  totalPrice = 0,
  paidAmount = 0,
  reason = '',
} = {}) {
  const current = normalizeText(currentStatus);
  const target = normalizeText(targetStatus);
  const normalizedRole = normalizeText(role);
  const normalizedReason = String(reason ?? '').trim();
  const payment = calculatePaymentProgress(totalPrice, paidAmount);

  if (!isValidStatus(current)) {
    return Object.freeze({
      allowed: false,
      code: 'INVALID_CURRENT_STATUS',
      message: 'Current plot status is invalid.',
      currentStatus: current,
      targetStatus: target,
      payment,
    });
  }

  if (!isValidStatus(target)) {
    return Object.freeze({
      allowed: false,
      code: 'INVALID_TARGET_STATUS',
      message: 'Target plot status is invalid.',
      currentStatus: current,
      targetStatus: target,
      payment,
    });
  }

  if (current === target) {
    return Object.freeze({
      allowed: true,
      code: 'NO_CHANGE',
      message: 'Plot is already in the requested status.',
      currentStatus: current,
      targetStatus: target,
      payment,
      auditRequired: false,
    });
  }

  if (!canTransition(current, target)) {
    return Object.freeze({
      allowed: false,
      code: 'TRANSITION_NOT_ALLOWED',
      message: `Plot status cannot change from ${current} to ${target}.`,
      currentStatus: current,
      targetStatus: target,
      payment,
    });
  }

  if (target === PLOT_STATUS.HOLD && !isAdminRole(normalizedRole)) {
    return Object.freeze({
      allowed: false,
      code: 'ADMIN_REQUIRED_FOR_HOLD',
      message: 'Only Admin or Super Admin can place a plot on hold.',
      currentStatus: current,
      targetStatus: target,
      payment,
    });
  }

  if (
    current === PLOT_STATUS.HOLD &&
    target === PLOT_STATUS.AVAILABLE &&
    !isAdminRole(normalizedRole)
  ) {
    return Object.freeze({
      allowed: false,
      code: 'ADMIN_REQUIRED_FOR_RELEASE',
      message: 'Only Admin or Super Admin can release a held plot.',
      currentStatus: current,
      targetStatus: target,
      payment,
    });
  }

  if (target === PLOT_STATUS.SOLD && !payment.isFullyPaid) {
    return Object.freeze({
      allowed: false,
      code: 'FULL_PAYMENT_REQUIRED',
      message: 'Plot can be marked SOLD only after 100% payment.',
      currentStatus: current,
      targetStatus: target,
      payment,
    });
  }

  if (
    current === PLOT_STATUS.BOOKED &&
    target === PLOT_STATUS.AVAILABLE &&
    !normalizedReason
  ) {
    return Object.freeze({
      allowed: false,
      code: 'REASON_REQUIRED',
      message: 'A reason is required to cancel or release a booked plot.',
      currentStatus: current,
      targetStatus: target,
      payment,
    });
  }

  return Object.freeze({
    allowed: true,
    code: 'TRANSITION_ALLOWED',
    message: `Plot status can change from ${current} to ${target}.`,
    currentStatus: current,
    targetStatus: target,
    payment,
    reason: normalizedReason,
    auditRequired: true,
  });
}

function deriveStatusFromPayment({
  currentStatus,
  totalPrice,
  paidAmount,
} = {}) {
  const current = normalizeText(currentStatus);
  const payment = calculatePaymentProgress(totalPrice, paidAmount);

  if (!isValidStatus(current)) {
    throw new TypeError('Current plot status is invalid.');
  }

  if (current === PLOT_STATUS.SOLD) {
    return Object.freeze({
      status: PLOT_STATUS.SOLD,
      changed: false,
      payment,
      reason: 'SOLD_STATUS_LOCKED',
    });
  }

  if (current === PLOT_STATUS.HOLD) {
    return Object.freeze({
      status: PLOT_STATUS.HOLD,
      changed: false,
      payment,
      reason: 'HOLD_STATUS_PRESERVED',
    });
  }

  if (payment.isFullyPaid && current === PLOT_STATUS.BOOKED) {
    return Object.freeze({
      status: PLOT_STATUS.SOLD,
      changed: true,
      payment,
      reason: 'FULL_PAYMENT_RECEIVED',
    });
  }

  if (current === PLOT_STATUS.BOOKED) {
    return Object.freeze({
      status: PLOT_STATUS.BOOKED,
      changed: false,
      payment,
      reason: 'PAYMENT_PENDING',
    });
  }

  return Object.freeze({
    status: current,
    changed: false,
    payment,
    reason: 'NO_STATUS_CHANGE',
  });
}

class PlotStatusEngine {
  constructor({ plotService, auditService } = {}) {
    if (!plotService || typeof plotService.getPlotById !== 'function') {
      throw new TypeError(
        'PlotStatusEngine requires plotService.getPlotById().'
      );
    }

    if (typeof plotService.updatePlot !== 'function') {
      throw new TypeError(
        'PlotStatusEngine requires plotService.updatePlot().'
      );
    }

    this.plotService = plotService;
    this.auditService = auditService ?? null;
  }

  async changeStatus({
    plotId,
    targetStatus,
    role,
    totalPrice,
    paidAmount,
    reason,
    actorId = null,
  } = {}) {
    if (!plotId || !String(plotId).trim()) {
      throw new TypeError('plotId is required.');
    }

    const plotResponse = await this.plotService.getPlotById(plotId);
    const plot = plotResponse?.data ?? plotResponse?.value ?? plotResponse;

    if (!plot || typeof plot !== 'object') {
      return Object.freeze({
        success: false,
        code: 'PLOT_NOT_FOUND',
        message: 'Plot was not found.',
      });
    }

    const evaluation = evaluatePlotStatusChange({
      currentStatus: plot.status,
      targetStatus,
      role,
      totalPrice: totalPrice ?? plot.totalPrice,
      paidAmount: paidAmount ?? plot.paidAmount,
      reason,
    });

    if (!evaluation.allowed) {
      return Object.freeze({
        success: false,
        ...evaluation,
      });
    }

    if (evaluation.code === 'NO_CHANGE') {
      return Object.freeze({
        success: true,
        changed: false,
        plot,
        ...evaluation,
      });
    }

    const updatedResponse = await this.plotService.updatePlot(plotId, {
      status: evaluation.targetStatus,
    });

    const updatedPlot =
      updatedResponse?.data ?? updatedResponse?.value ?? updatedResponse;

    if (
      this.auditService &&
      typeof this.auditService.record === 'function'
    ) {
      await this.auditService.record({
        eventType: 'PLOT_STATUS_CHANGED',
        entityType: 'PLOT',
        entityId: plotId,
        actorId,
        fromStatus: evaluation.currentStatus,
        toStatus: evaluation.targetStatus,
        reason: evaluation.reason || null,
      });
    }

    return Object.freeze({
      success: true,
      changed: true,
      plot: updatedPlot,
      ...evaluation,
    });
  }
}

module.exports = {
  PLOT_STATUS,
  USER_ROLE,
  ALLOWED_TRANSITIONS,
  normalizeText,
  normalizeAmount,
  isValidStatus,
  isAdminRole,
  calculatePaymentProgress,
  canTransition,
  evaluatePlotStatusChange,
  deriveStatusFromPayment,
  PlotStatusEngine,
};
