'use strict';

const assert = require('assert');

const {
  validateV15Draft,
  adaptV15Draft,
  buildPlotCoreRecords,
  buildMapReadyModel,
  createV15Diagnostics,
  DxfV15RealEngineBridgeService,
} = require('./dxf-v15-real-engine-bridge');

(() => {
  console.log('Falcon DXF V1.5 Real Engine Bridge Tests');
  console.log('----------------------------------------');

  let assertions = 0;
  const check = (a, e) => { assert.deepStrictEqual(a, e); assertions += 1; };
  const yes = (v) => { assert.strictEqual(v, true); assertions += 1; };

  const draft = {
    app: 'Falcon Hybrid',
    schema_version: '1.0-draft',
    project: {
      name: 'Jaipur Pride',
      source_crs: 'EPSG:32643',
      source_sha256: 'abc123',
      approval_status: 'APPROVED',
      approved_at: '2026-07-30T10:00:00.000Z',
    },
    layers: {
      plots: [
        {
          plot_no: '43',
          layer: 'POLYGON',
          vertices: [[0,0],[10,0],[10,20],[0,20]],
          centroid: [5,10],
          area_sq_m: 200,
          area_sq_yd: 239.1980092,
          side_lengths_ft: [32.8084,65.6168,32.8084,65.6168],
          source_index: 1,
          contained_labels: 1,
        },
        {
          plot_no: '44',
          layer: 'POLYGON',
          vertices: [[10,0],[20,0],[20,20],[10,20]],
          centroid: [15,10],
          area_sq_m: 200,
          area_sq_yd: 239.1980092,
          side_lengths_ft: [32.8084,65.6168,32.8084,65.6168],
          source_index: 2,
          contained_labels: 1,
        },
      ],
      roads: [
        {
          id: 'ROAD-1',
          name: "ROAD 40' WIDE",
          width_ft: 40,
          geometry_type: 'LABEL_POINT',
          label_point: [10,-5],
          vertices: [[10,-5]],
        },
      ],
      special_areas: [
        {
          name: 'OTHER LAND',
          category: 'OTHER LAND',
          layer: 'POLYGON',
          vertices: [[0,20],[20,20],[20,30],[0,30]],
          centroid: [10,25],
          area_sq_m: 200,
          area_sq_yd: 239.1980092,
          source_index: 3,
        },
      ],
    },
    import_profile: {
      renderer: 'FALCON_V10_POLISHED_2D',
      road_surface_rule: 'BACKGROUND_GAPS',
      road_labels: 'ROAD_TEXT_POINTS',
      original_geometry_locked: true,
    },
    audit: {
      metrics: {
        entities: 100,
        layers: 12,
        plot_labels: 2,
        plot_faces: 2,
        unresolved_labels: 0,
        road_layers: 1,
        khasra_layers: 1,
        special_layers: 1,
        road_features: 1,
        special_features: 1,
        selected_scope: 'SDFRG',
      },
      warnings: [],
    },
  };

  yes(validateV15Draft(draft));

  const model = adaptV15Draft({
    projectId: 'FP-000001',
    draft,
  });

  check(model.project.projectId, 'FP-000001');
  check(model.project.sourceName, 'Jaipur Pride');
  check(model.sourceEngine, 'FALCON_DXF_INTELLIGENCE_V1_5');
  yes(model.originalGeometryLocked);
  check(model.roadSurfaceRule, 'BACKGROUND_GAPS');
  check(model.plots.length, 2);
  check(model.roads.length, 1);
  check(model.specialAreas.length, 1);

  check(model.plots[0].plotNo, '43');
  check(model.plots[0].sourceLayer, 'POLYGON');
  check(model.plots[0].vertices[2], { x: 10, y: 20 });
  check(model.plots[0].sideLengthsFt.length, 4);
  check(model.roads[0].widthFt, 40);
  check(model.roads[0].labelPoint, { x: 10, y: -5 });
  check(model.specialAreas[0].category, 'OTHER LAND');

  const plotRecords = buildPlotCoreRecords(model);
  check(plotRecords.length, 2);
  check(plotRecords[0].projectId, 'FP-000001');
  check(plotRecords[0].plotNumber, '43');
  check(plotRecords[0].status, 'AVAILABLE');
  check(plotRecords[0].source.engine, 'FALCON_DXF_INTELLIGENCE_V1_5');

  const mapModel = buildMapReadyModel(model);

  check(mapModel.rendererProfile, 'FALCON_V10_POLISHED_2D');
  yes(mapModel.geometryPolicy.originalGeometryLocked);
  check(mapModel.geometryPolicy.straightenGeometry, false);
  check(mapModel.geometryPolicy.inventVertices, false);
  check(mapModel.geometryPolicy.roadSurfaceRule, 'BACKGROUND_GAPS');

  check(mapModel.visualPolicy.plotNumberPlacement, 'CENTROID');
  check(mapModel.visualPolicy.dimensionSource, 'SIDE_LENGTHS_FT');
  check(mapModel.visualPolicy.selectionStyle, 'BLUE_GLASS_TRANSPARENT');
  check(mapModel.visualPolicy.selectionBoundary, 'THIN_DOTTED_OFFSET');
  check(mapModel.visualPolicy.selectionAutoZoomPercent, [20, 30]);
  yes(mapModel.visualPolicy.smoothPanZoomRequired);
  check(mapModel.visualPolicy.defaultAreaUnit, 'SQ_YARD');

  const diagnostics = createV15Diagnostics(model);
  check(diagnostics.plotCount, 2);
  check(diagnostics.roadLabelCount, 1);
  check(diagnostics.specialAreaCount, 1);
  check(diagnostics.sourceScope, 'SDFRG');
  check(diagnostics.unresolvedLabels, 0);
  yes(diagnostics.readyForPlotCore);
  yes(diagnostics.originalGeometryLocked);

  assert.throws(
    () => validateV15Draft({
      ...draft,
      project: { ...draft.project, approval_status: 'REVIEW' },
    }),
    /must be APPROVED/
  );
  assertions += 1;

  assert.throws(
    () => validateV15Draft({
      ...draft,
      import_profile: {
        ...draft.import_profile,
        original_geometry_locked: false,
      },
    }),
    /original_geometry_locked/
  );
  assertions += 1;

  assert.throws(
    () => adaptV15Draft({
      projectId: 'FP-000001',
      draft: {
        ...draft,
        layers: {
          ...draft.layers,
          plots: [draft.layers.plots[0], draft.layers.plots[0]],
        },
      },
    }),
    /Duplicate plot numbers/
  );
  assertions += 1;

  const service = new DxfV15RealEngineBridgeService();
  yes(service.validate(draft));
  check(service.plotCore(model).length, 2);
  check(service.mapReady(model).layers.plots.length, 2);
  yes(service.diagnostics(model).readyForPlotCore);

  console.log('Recovered V1.5 Draft Validation: PASS');
  console.log('V1.5 Plot Export Mapping: PASS');
  console.log('V1.5 Road Label Mapping: PASS');
  console.log('V1.5 Special Area Mapping: PASS');
  console.log('Original Geometry Lock Enforcement: PASS');
  console.log('Background-gap Road Rule Preservation: PASS');
  console.log('Plot Core Record Handoff: PASS');
  console.log('Map-ready Geometry Model: PASS');
  console.log('Spacer-style Selection Policy Lock: PASS');
  console.log('Side-length Dimension Preservation: PASS');
  console.log('V1.5 Diagnostics: PASS');
  console.log('Reusable Real Engine Bridge: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('----------------------------------------');
  console.log('DXF V1.5 REAL ENGINE BRIDGE TEST PASS');
})();
