'use strict';

const assert = require('assert');

const {
  computeBoundsFromPlots,
  buildViewport,
  worldToScreen,
  screenToWorld,
  zoomAroundPoint,
  panViewport,
  polygonCentroid,
  pointInPolygon,
  hitTestPlot,
  buildRendererFrame,
  buildSelectionViewport,
  MapRendererCoreService,
} = require('./map-renderer-core');

(() => {
  console.log('Falcon MAP.1 Renderer Core Tests');
  console.log('-------------------------------');

  let assertions = 0;

  const check = (a, e) => {
    assert.deepStrictEqual(a, e);
    assertions += 1;
  };

  const yes = (v) => {
    assert.strictEqual(v, true);
    assertions += 1;
  };

  const plots = [
    {
      plotNo: '1',
      status: 'AVAILABLE',
      vertices: [
        { x: 0, y: 0 },
        { x: 10, y: 0 },
        { x: 10, y: 20 },
        { x: 0, y: 20 },
      ],
      centroid: { x: 5, y: 10 },
      sideLengthsFt: [32.8, 65.6, 32.8, 65.6],
      areaSqYd: 239.2,
      areaSqM: 200,
    },
    {
      plotNo: '2',
      status: 'BOOKED',
      vertices: [
        { x: 10, y: 0 },
        { x: 20, y: 0 },
        { x: 20, y: 20 },
        { x: 10, y: 20 },
      ],
      centroid: { x: 15, y: 10 },
      sideLengthsFt: [32.8, 65.6, 32.8, 65.6],
      areaSqYd: 239.2,
      areaSqM: 200,
    },
  ];

  const bounds = computeBoundsFromPlots(plots);
  check(bounds.minX, 0);
  check(bounds.minY, 0);
  check(bounds.maxX, 20);
  check(bounds.maxY, 20);
  check(bounds.width, 20);
  check(bounds.height, 20);
  check(bounds.center, { x: 10, y: 10 });

  const viewport = buildViewport({
    bounds,
    viewportWidth: 1000,
    viewportHeight: 800,
    padding: 40,
  });

  yes(viewport.zoom > 0);

  const world = { x: 5, y: 10 };
  const screen = worldToScreen(world, viewport);
  const roundTrip = screenToWorld(screen, viewport);

  yes(Math.abs(roundTrip.x - world.x) < 1e-9);
  yes(Math.abs(roundTrip.y - world.y) < 1e-9);

  const zoomed = zoomAroundPoint({
    viewport,
    screenPoint: screen,
    factor: 1.25,
  });

  yes(zoomed.zoom > viewport.zoom);

  const roundTripAfterZoom = screenToWorld(screen, zoomed);
  yes(Math.abs(roundTripAfterZoom.x - world.x) < 1e-9);
  yes(Math.abs(roundTripAfterZoom.y - world.y) < 1e-9);

  const panned = panViewport({
    viewport,
    dx: 25,
    dy: -15,
  });

  check(panned.panX, viewport.panX + 25);
  check(panned.panY, viewport.panY - 15);

  check(
    polygonCentroid(plots[0].vertices),
    { x: 5, y: 10 }
  );

  yes(pointInPolygon({ x: 5, y: 10 }, plots[0].vertices));
  check(pointInPolygon({ x: 50, y: 50 }, plots[0].vertices), false);

  const hitPoint = worldToScreen({ x: 15, y: 10 }, viewport);

  const hit = hitTestPlot({
    screenPoint: hitPoint,
    viewport,
    plots,
  });

  check(hit.plotNumber, '2');

  const missPoint = worldToScreen({ x: 50, y: 50 }, viewport);

  check(
    hitTestPlot({
      screenPoint: missPoint,
      viewport,
      plots,
    }),
    null
  );

  const mapModel = {
    layers: {
      plots,
      roads: [
        {
          id: 'R1',
          name: "ROAD 40' WIDE",
          widthFt: 40,
          labelPoint: { x: 10, y: -5 },
        },
      ],
      specialAreas: [
        {
          id: 'S1',
          category: 'OTHER LAND',
          vertices: [
            { x: 0, y: 20 },
            { x: 20, y: 20 },
            { x: 20, y: 30 },
            { x: 0, y: 30 },
          ],
        },
      ],
    },
  };

  const frame = buildRendererFrame({
    mapModel,
    viewportWidth: 1000,
    viewportHeight: 800,
    selectedPlotNumber: '2',
  });

  check(frame.plots.length, 2);
  check(frame.roads.length, 1);
  check(frame.specialAreas.length, 1);
  check(frame.selectedPlot.plotNumber, '2');
  check(frame.plots[0].labelPoint.x > 0, true);
  check(frame.plots[0].sideLengthsFt.length, 4);
  check(frame.visualPolicy.selectionStyle, 'BLUE_GLASS_TRANSPARENT');
  check(frame.visualPolicy.selectionBoundary, 'THIN_DOTTED_OFFSET');
  check(frame.visualPolicy.selectionAutoZoomPercent, [20, 30]);
  yes(frame.visualPolicy.smoothPanZoom);
  yes(frame.visualPolicy.dimensionsInFeet);
  check(frame.visualPolicy.defaultAreaUnit, 'SQ_YARD');

  const selectedViewport = buildSelectionViewport({
    frame,
    plotNumber: '2',
    zoomPercent: 25,
  });

  yes(selectedViewport.zoom > frame.viewport.zoom);

  const service = new MapRendererCoreService();

  check(service.bounds(plots).width, 20);
  yes(service.frame({
    mapModel,
    viewportWidth: 1000,
    viewportHeight: 800,
  }).plots.length === 2);

  console.log('Map Bounds Calculation: PASS');
  console.log('Home/Fit Viewport: PASS');
  console.log('World ↔ Screen Transform: PASS');
  console.log('Smooth Zoom Anchor: PASS');
  console.log('Smooth Pan Model: PASS');
  console.log('Polygon Centroid: PASS');
  console.log('Plot Hit Testing: PASS');
  console.log('Plot Number Label Model: PASS');
  console.log('Feet Dimension Model: PASS');
  console.log('Road/Special Layer Carry-through: PASS');
  console.log('Blue Glass Selection Contract: PASS');
  console.log('Dotted Selection Boundary Contract: PASS');
  console.log('20-30 Percent Selection Zoom: PASS');
  console.log('SQ_YARD Default Unit: PASS');
  console.log('Reusable Map Renderer Core: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('-------------------------------');
  console.log('MAP RENDERER CORE TEST PASS');
})();
