'use strict';

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function lower(value) {
  return text(value).toLowerCase();
}

function finiteNumber(value, fieldName) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    throw new TypeError(`${fieldName} must be a valid number.`);
  }
  return number;
}

function nonNegative(value, fieldName) {
  const number = finiteNumber(value, fieldName);
  if (number < 0) {
    throw new RangeError(`${fieldName} cannot be negative.`);
  }
  return number;
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function normalizeProfile(profile = {}) {
  const customer = profile.customer || {};
  const summary = profile.summary || {};
  const plots = Array.isArray(profile.plots) ? profile.plots : [];
  const documents = Array.isArray(profile.documents) ? profile.documents : [];

  const customerId = upper(customer.customerId || customer.id);
  if (!customerId) throw new Error('profile.customer.customerId is required.');

  return Object.freeze({
    source: profile,
    customerId,
    customerName: text(customer.customerName || customer.name),
    mobile: text(customer.mobile || customer.customerMobile),
    alternateMobile: text(customer.alternateMobile),
    email: text(customer.email),
    address: text(customer.address),
    status: upper(customer.status || 'ACTIVE'),
    bookingCount: nonNegative(summary.bookingCount || 0, 'bookingCount'),
    activeBookingCount: nonNegative(summary.activeBookingCount || 0, 'activeBookingCount'),
    soldBookingCount: nonNegative(summary.soldBookingCount || 0, 'soldBookingCount'),
    pendingBookingCount: nonNegative(summary.pendingBookingCount || 0, 'pendingBookingCount'),
    receiptCount: nonNegative(summary.receiptCount || 0, 'receiptCount'),
    documentCount: nonNegative(summary.documentCount || 0, 'documentCount'),
    identityDocumentCount: nonNegative(summary.identityDocumentCount || 0, 'identityDocumentCount'),
    hasPhoto: Boolean(summary.hasPhoto),
    hasIdentityProof: Boolean(summary.hasIdentityProof),
    totalBookingValue: roundMoney(nonNegative(summary.totalBookingValue || 0, 'totalBookingValue')),
    totalPaid: roundMoney(nonNegative(summary.totalPaid || 0, 'totalPaid')),
    totalBalance: roundMoney(nonNegative(summary.totalBalance || 0, 'totalBalance')),
    plots: Object.freeze(plots.map((plot) => Object.freeze({ ...plot }))),
    documents: Object.freeze(documents.map((doc) => Object.freeze({ ...doc }))),
  });
}

function calculateSearchScore(profile, query) {
  const q = lower(query);
  if (!q) return 0;

  let score = 0;

  if (lower(profile.customerId) === q) score += 100;
  if (lower(profile.mobile) === q) score += 95;
  if (lower(profile.customerName) === q) score += 90;
  if (lower(profile.email) === q) score += 85;

  if (lower(profile.customerId).startsWith(q)) score += 60;
  if (lower(profile.customerName).startsWith(q)) score += 55;
  if (lower(profile.mobile).startsWith(q)) score += 50;

  const plotHit = profile.plots.some((plot) =>
    [plot.projectName, plot.projectId, plot.plotNumber, plot.bookingId]
      .map(lower)
      .some((value) => value.includes(q))
  );

  if (plotHit) score += 45;

  const haystack = [
    profile.customerId,
    profile.customerName,
    profile.mobile,
    profile.alternateMobile,
    profile.email,
    profile.address,
    profile.status,
  ]
    .map(lower)
    .join(' ');

  if (haystack.includes(q)) score += 25;

  return score;
}

function matchesFilters(profile, filters = {}) {
  if (filters.status && profile.status !== upper(filters.status)) return false;

  if (
    filters.projectId &&
    !profile.plots.some((plot) => upper(plot.projectId) === upper(filters.projectId))
  ) {
    return false;
  }

  if (
    filters.projectName &&
    !profile.plots.some((plot) =>
      lower(plot.projectName).includes(lower(filters.projectName))
    )
  ) {
    return false;
  }

  if (
    filters.plotNumber &&
    !profile.plots.some((plot) => text(plot.plotNumber) === text(filters.plotNumber))
  ) {
    return false;
  }

  if (filters.hasPending === true && profile.pendingBookingCount <= 0) return false;
  if (filters.hasPending === false && profile.pendingBookingCount > 0) return false;

  if (filters.hasSold === true && profile.soldBookingCount <= 0) return false;
  if (filters.hasSold === false && profile.soldBookingCount > 0) return false;

  if (filters.hasPhoto === true && !profile.hasPhoto) return false;
  if (filters.hasPhoto === false && profile.hasPhoto) return false;

  if (filters.hasIdentityProof === true && !profile.hasIdentityProof) return false;
  if (filters.hasIdentityProof === false && profile.hasIdentityProof) return false;

  if (filters.minimumBalance !== undefined) {
    const minimumBalance = nonNegative(filters.minimumBalance, 'minimumBalance');
    if (profile.totalBalance < minimumBalance) return false;
  }

  if (filters.maximumBalance !== undefined) {
    const maximumBalance = nonNegative(filters.maximumBalance, 'maximumBalance');
    if (profile.totalBalance > maximumBalance) return false;
  }

  if (filters.minimumBookingValue !== undefined) {
    const minimumBookingValue = nonNegative(filters.minimumBookingValue, 'minimumBookingValue');
    if (profile.totalBookingValue < minimumBookingValue) return false;
  }

  return true;
}

function searchCustomerProfiles(profiles = [], options = {}) {
  if (!Array.isArray(profiles)) {
    throw new TypeError('profiles must be an array.');
  }

  const query = text(options.query);
  const filters = options.filters || {};
  const sortBy = text(options.sortBy || (query ? 'relevance' : 'customerName'));
  const direction = upper(options.direction || 'ASC');
  const page = Math.max(1, Math.floor(Number(options.page) || 1));
  const pageSize = Math.max(1, Math.min(500, Math.floor(Number(options.pageSize) || 25)));

  const entries = profiles
    .map(normalizeProfile)
    .filter((profile) => matchesFilters(profile, filters))
    .map((profile) => ({
      profile,
      score: calculateSearchScore(profile, query),
    }))
    .filter((entry) => !query || entry.score > 0);

  entries.sort((a, b) => {
    if (sortBy === 'relevance') {
      if (a.score !== b.score) return b.score - a.score;
      return a.profile.customerName.localeCompare(b.profile.customerName);
    }

    const allowedFields = new Set([
      'customerName',
      'customerId',
      'totalBookingValue',
      'totalPaid',
      'totalBalance',
      'bookingCount',
      'pendingBookingCount',
      'soldBookingCount',
    ]);

    const field = allowedFields.has(sortBy) ? sortBy : 'customerName';
    const left = a.profile[field];
    const right = b.profile[field];

    let result = 0;
    if (left < right) result = -1;
    if (left > right) result = 1;

    return direction === 'DESC' ? -result : result;
  });

  const total = entries.length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const safePage = Math.min(page, totalPages);
  const start = (safePage - 1) * pageSize;

  const items = entries
    .slice(start, start + pageSize)
    .map((entry) =>
      Object.freeze({
        ...entry.profile.source,
        _search: Object.freeze({
          score: entry.score,
          customerId: entry.profile.customerId,
          totalBalance: entry.profile.totalBalance,
          pendingBookingCount: entry.profile.pendingBookingCount,
          soldBookingCount: entry.profile.soldBookingCount,
        }),
      })
    );

  return Object.freeze({
    items: Object.freeze(items),
    pagination: Object.freeze({
      page: safePage,
      pageSize,
      total,
      totalPages,
      hasPrevious: safePage > 1,
      hasNext: safePage < totalPages,
    }),
  });
}

function buildCustomerFilterSummary(profiles = []) {
  if (!Array.isArray(profiles)) {
    throw new TypeError('profiles must be an array.');
  }

  const rows = profiles.map(normalizeProfile);

  return Object.freeze({
    totalCustomers: rows.length,
    customersWithPending: rows.filter((row) => row.pendingBookingCount > 0).length,
    customersWithSold: rows.filter((row) => row.soldBookingCount > 0).length,
    customersWithPhoto: rows.filter((row) => row.hasPhoto).length,
    customersWithIdentityProof: rows.filter((row) => row.hasIdentityProof).length,
    totalOutstanding: roundMoney(rows.reduce((sum, row) => sum + row.totalBalance, 0)),
    totalBookingValue: roundMoney(rows.reduce((sum, row) => sum + row.totalBookingValue, 0)),
  });
}

class CustomerSearchFilterIntegrationService {
  search(profiles, options) {
    return searchCustomerProfiles(profiles, options);
  }

  summary(profiles) {
    return buildCustomerFilterSummary(profiles);
  }

  matches(profile, filters) {
    return matchesFilters(normalizeProfile(profile), filters);
  }
}

module.exports = {
  text,
  upper,
  lower,
  finiteNumber,
  nonNegative,
  roundMoney,
  normalizeProfile,
  calculateSearchScore,
  matchesFilters,
  searchCustomerProfiles,
  buildCustomerFilterSummary,
  CustomerSearchFilterIntegrationService,
};
