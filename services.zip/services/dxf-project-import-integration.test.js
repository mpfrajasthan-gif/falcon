'use strict';

const assert = require('assert');

const {
  validateProjectRecord,
  createImportFingerprint,
  checkImportConflict,
  buildProjectImportPackage,
  validateImportPackage,
  buildProjectStoragePlan,
  buildPersistableProjectData,
  buildMapLaunchPacket,
  DxfProjectImportIntegrationService,
} = require('./dxf-project-import-integration');

(() => {
  console.log('Falcon DXF Actual Project Import Integration Tests');
  console.log('--------------------------------------------------');

  let assertions = 0;
  const check = (a, e) => { assert.deepStrictEqual(a, e); assertions += 1; };
  const yes = (v) => { assert.strictEqual(v, true); assertions += 1; };
  const no = (v) => { assert.strictEqual(v, false); assertions += 1; };

  const project = {
    projectId: 'FP-000001',
    projectName: 'Jaipur Pride',
    projectFolder: 'C:\\FalconHybrid\\projects\\FP-000001',
    status: 'ACTIVE',
  };

  const draft = {
    schema_version: '1.0-draft',
    project: {
      name: 'Jaipur Pride',
      source_crs: 'EPSG:32643',
      source_sha256: 'source-file-hash-001',
      approval_status: 'APPROVED',
      approved_at: '2026-07-30T10:00:00.000Z',
    },
    layers: {
      plots: [
        {
          plot_no: '43',
          layer: 'POLYGON',
          vertices: [[0,0],[10,0],[10,20],[0,20]],
          centroid: [5,10],
          area_sq_m: 200,
          area_sq_yd: 239.1980092,
          side_lengths_ft: [32.8084,65.6168,32.8084,65.6168],
          source_index: 1,
          contained_labels: 1,
        },
        {
          plot_no: '44',
          layer: 'POLYGON',
          vertices: [[10,0],[20,0],[20,20],[10,20]],
          centroid: [15,10],
          area_sq_m: 200,
          area_sq_yd: 239.1980092,
          side_lengths_ft: [32.8084,65.6168,32.8084,65.6168],
          source_index: 2,
          contained_labels: 1,
        },
      ],
      roads: [
        {
          id: 'ROAD-1',
          name: "ROAD 40' WIDE",
          width_ft: 40,
          geometry_type: 'LABEL_POINT',
          label_point: [10,-5],
          vertices: [[10,-5]],
        },
      ],
      special_areas: [],
    },
    import_profile: {
      renderer: 'FALCON_V10_POLISHED_2D',
      road_surface_rule: 'BACKGROUND_GAPS',
      road_labels: 'ROAD_TEXT_POINTS',
      original_geometry_locked: true,
    },
    audit: {
      metrics: {
        plot_labels: 2,
        plot_faces: 2,
        unresolved_labels: 0,
        road_layers: 1,
        khasra_layers: 1,
        special_layers: 0,
        selected_scope: 'SDFRG',
      },
      warnings: [],
    },
  };

  const validatedProject = validateProjectRecord(project);
  check(validatedProject.projectId, 'FP-000001');
  check(validatedProject.projectName, 'Jaipur Pride');

  const pkg = buildProjectImportPackage({
    project,
    draft,
  });

  yes(validateImportPackage(pkg));
  check(pkg.project.projectId, 'FP-000001');
  check(pkg.plotRecords.length, 2);
  check(pkg.mapReady.layers.plots.length, 2);
  check(pkg.mapReady.layers.roads.length, 1);
  check(pkg.source.engine, 'FALCON_DXF_INTELLIGENCE_V1_5');
  check(pkg.diagnostics.plotCount, 2);
  check(pkg.replaceExisting, false);
  yes(pkg.importId.startsWith('DXFI-FP-000001-'));
  check(pkg.fingerprint.length, 64);

  const fingerprint = createImportFingerprint({
    projectId: project.projectId,
    dxfModel: {
      project: { sourceSha256: pkg.source.sourceSha256 },
      sourceEngine: pkg.source.engine,
      sourceSchema: pkg.source.schema,
      plots: pkg.mapReady.layers.plots.map((p) => ({ plotNo: p.plotNo })),
      roads: pkg.mapReady.layers.roads,
      specialAreas: pkg.mapReady.layers.specialAreas,
    },
  });

  check(fingerprint.length, 64);

  const noConflict = checkImportConflict({
    project,
    existingImport: null,
    fingerprint: pkg.fingerprint,
  });

  no(noConflict.conflict);
  check(noConflict.reason, 'NO_EXISTING_IMPORT');

  const duplicateConflict = checkImportConflict({
    project,
    existingImport: {
      projectId: 'FP-000001',
      fingerprint: pkg.fingerprint,
    },
    fingerprint: pkg.fingerprint,
  });

  yes(duplicateConflict.conflict);
  yes(duplicateConflict.duplicate);
  check(duplicateConflict.reason, 'SAME_DXF_ALREADY_IMPORTED');

  assert.throws(
    () =>
      buildProjectImportPackage({
        project,
        draft,
        existingImport: {
          projectId: 'FP-000001',
          fingerprint: pkg.fingerprint,
        },
      }),
    /already attached/
  );
  assertions += 1;

  assert.throws(
    () =>
      buildProjectImportPackage({
        project,
        draft: {
          ...draft,
          project: {
            ...draft.project,
            source_sha256: 'different-source',
          },
        },
        existingImport: {
          projectId: 'FP-000001',
          fingerprint: pkg.fingerprint,
        },
      }),
    /Replacement is blocked/
  );
  assertions += 1;

  const replaced = buildProjectImportPackage({
    project,
    draft: {
      ...draft,
      project: {
        ...draft.project,
        source_sha256: 'different-source',
      },
    },
    existingImport: {
      projectId: 'FP-000001',
      fingerprint: pkg.fingerprint,
    },
    allowReplace: true,
  });

  yes(replaced.replaceExisting);

  const plan = buildProjectStoragePlan(pkg);
  check(plan.projectId, 'FP-000001');
  check(plan.relative.importMetadata, 'dxf/current-import.json');
  check(plan.relative.plots, 'maps/plots.json');
  check(plan.relative.mapModel, 'maps/map-ready.json');
  yes(plan.absolute.importMetadata.includes('FP-000001'));

  const persistable = buildPersistableProjectData(pkg);
  check(persistable.importMetadata.projectId, 'FP-000001');
  check(persistable.plots.length, 2);
  check(persistable.mapModel.layers.plots.length, 2);
  check(persistable.diagnostics.readyForPlotCore, true);

  const launch = buildMapLaunchPacket(pkg);
  check(launch.projectId, 'FP-000001');
  check(launch.projectName, 'Jaipur Pride');
  check(launch.plotCount, 2);
  check(launch.status, 'READY_FOR_MAP_VIEWER');
  check(launch.visualPolicy.selectionStyle, 'BLUE_GLASS_TRANSPARENT');
  check(launch.visualPolicy.selectionBoundary, 'THIN_DOTTED_OFFSET');
  check(launch.visualPolicy.defaultAreaUnit, 'SQ_YARD');
  yes(launch.geometryPolicy.originalGeometryLocked);
  check(launch.geometryPolicy.straightenGeometry, false);

  assert.throws(
    () =>
      validateProjectRecord({
        projectId: 'BAD-1',
        projectName: 'Bad Project',
      }),
    /Valid Falcon projectId/
  );
  assertions += 1;

  const service = new DxfProjectImportIntegrationService();

  yes(service.validate(pkg));
  check(service.storagePlan(pkg).projectId, 'FP-000001');
  check(service.persistable(pkg).plots.length, 2);
  check(service.mapLaunch(pkg).status, 'READY_FOR_MAP_VIEWER');

  console.log('Falcon Project ID Validation: PASS');
  console.log('V1.5 Draft → Project Binding: PASS');
  console.log('DXF Import Fingerprint: PASS');
  console.log('Duplicate Import Protection: PASS');
  console.log('Different DXF Replacement Block: PASS');
  console.log('Explicit Replacement Flow: PASS');
  console.log('Plot Core Import Package: PASS');
  console.log('Map-ready Import Package: PASS');
  console.log('Project Storage Plan: PASS');
  console.log('Persistable Project Data: PASS');
  console.log('Map Launch Packet: PASS');
  console.log('Original Geometry Lock Preservation: PASS');
  console.log('Spacer-style Visual Policy Preservation: PASS');
  console.log('Reusable Project Import Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('--------------------------------------------------');
  console.log('DXF ACTUAL PROJECT IMPORT INTEGRATION TEST PASS');
})();
