'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const {
  validateActiveProject,
  buildPremiumViewerSession,
  createPremiumViewerIpcHandlers,
  buildPreloadApi,
  resolvePremiumViewerFile,
  PremiumViewerLiveWiringService,
} = require('./premium-viewer-live-wiring');

(() => {
  console.log('Falcon MAP.8.2 Active Project → Premium Viewer Live Wiring Tests');
  console.log('----------------------------------------------------------------');

  let assertions = 0;
  const check = (a, e) => {
    assert.deepStrictEqual(a, e);
    assertions += 1;
  };
  const yes = (v) => {
    assert.strictEqual(v, true);
    assertions += 1;
  };

  const root = fs.mkdtempSync(
    path.join(os.tmpdir(), 'falcon-map82-')
  );

  const projectFolder = path.join(
    root,
    'projects',
    'FP-000001'
  );

  fs.mkdirSync(
    path.join(projectFolder, 'maps'),
    { recursive: true }
  );

  fs.writeFileSync(
    path.join(projectFolder, 'maps', 'map-ready.json'),
    JSON.stringify({
      projectId: 'FP-000001',
      layers: {
        plots: [
          {
            plotNumber: '1',
            status: 'AVAILABLE',
            vertices: [
              { x: 0, y: 0 },
              { x: 10, y: 0 },
              { x: 10, y: 20 },
              { x: 0, y: 20 }
            ],
            centroid: { x: 5, y: 10 },
            sideLengthsFt: [30, 45, 30, 45]
          },
          {
            plotNumber: '2',
            status: 'BOOKED',
            vertices: [
              { x: 10, y: 0 },
              { x: 20, y: 0 },
              { x: 20, y: 20 },
              { x: 10, y: 20 }
            ],
            centroid: { x: 15, y: 10 },
            sideLengthsFt: [30, 45, 30, 45]
          }
        ],
        roads: [],
        specialAreas: []
      }
    }, null, 2),
    'utf8'
  );

  const project = {
    projectId: 'FP-000001',
    projectName: 'Jaipur Pride',
    projectFolder,
  };

  const validated = validateActiveProject(project);

  check(validated.projectId, 'FP-000001');
  check(validated.projectFolder, projectFolder);

  const session = buildPremiumViewerSession(project);

  check(session.sessionType, 'PREMIUM_MAP_VIEWER');
  check(session.projectId, 'FP-000001');
  check(session.projectName, 'Jaipur Pride');
  check(session.plotCount, 2);
  yes(session.ready);
  check(session.mapModel.layers.plots.length, 2);

  const handlers = {};
  const ipcMain = {
    handle(name, fn) {
      handlers[name] = fn;
    }
  };

  const channels = createPremiumViewerIpcHandlers({
    ipcMain,
    getActiveProject: () => project,
  });

  check(
    channels.session,
    'falcon:premium-map:get-session'
  );

  check(
    channels.map,
    'falcon:premium-map:get-current-map-model'
  );

  check(
    channels.project,
    'falcon:premium-map:get-current-project'
  );

  yes(typeof handlers[channels.session] === 'function');
  yes(typeof handlers[channels.map] === 'function');
  yes(typeof handlers[channels.project] === 'function');

  const invocations = [];

  const ipcRenderer = {
    invoke(channel) {
      invocations.push(channel);
      return Promise.resolve(channel);
    }
  };

  const preload = buildPreloadApi(ipcRenderer);

  yes(typeof preload.getPremiumMapSession === 'function');
  yes(typeof preload.getCurrentMapModel === 'function');
  yes(typeof preload.getCurrentProject === 'function');

  preload.getPremiumMapSession();
  preload.getCurrentMapModel();
  preload.getCurrentProject();

  check(invocations, [
    'falcon:premium-map:get-session',
    'falcon:premium-map:get-current-map-model',
    'falcon:premium-map:get-current-project'
  ]);

  const viewerFile = resolvePremiumViewerFile(
    'C:\\FALCON_V1_DEV\\MASTER'
  );

  yes(
    viewerFile.endsWith(
      path.join(
        'ui',
        'map-viewer-premium',
        'index.html'
      )
    )
  );

  assert.throws(
    () =>
      validateActiveProject({
        projectId: 'BAD-1',
        projectFolder,
      }),
    /invalid Falcon project ID/
  );
  assertions += 1;

  const service = new PremiumViewerLiveWiringService();

  check(
    service.session(project).plotCount,
    2
  );

  yes(
    service.preload(ipcRenderer)
      .getCurrentMapModel instanceof Function
  );

  console.log('Active Project Validation: PASS');
  console.log('Premium Viewer Session Build: PASS');
  console.log('Real map-ready.json Session Load: PASS');
  console.log('Premium Map IPC Registration: PASS');
  console.log('Premium Map Preload API: PASS');
  console.log('Premium Viewer File Resolution: PASS');
  console.log('Invalid Project Protection: PASS');
  console.log('Reusable Live Wiring Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('----------------------------------------------------------------');
  console.log('MAP ACTIVE PROJECT PREMIUM VIEWER LIVE WIRING TEST PASS');
})();
