'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function ensureDir(dirPath) {
  if (!text(dirPath)) throw new Error('dirPath is required.');
  fs.mkdirSync(dirPath, { recursive: true });
  return dirPath;
}

function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  const keys = Object.keys(value).sort();
  return `{${keys.map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
}

function sha256(value) {
  return crypto
    .createHash('sha256')
    .update(typeof value === 'string' ? value : stableStringify(value))
    .digest('hex');
}

function writeJsonAtomic(filePath, data) {
  ensureDir(path.dirname(filePath));

  const tempPath = `${filePath}.tmp-${process.pid}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
  const payload = JSON.stringify(data, null, 2);

  try {
    fs.writeFileSync(tempPath, payload, 'utf8');

    const tempRead = fs.readFileSync(tempPath, 'utf8');
    if (sha256(tempRead) !== sha256(payload)) {
      throw new Error('Temporary restore write verification failed.');
    }

    if (fs.existsSync(filePath)) {
      fs.rmSync(filePath, { force: true });
    }

    fs.renameSync(tempPath, filePath);

    const finalRead = fs.readFileSync(filePath, 'utf8');
    if (sha256(finalRead) !== sha256(payload)) {
      throw new Error('Final restore write verification failed.');
    }

    return filePath;
  } catch (error) {
    if (fs.existsSync(tempPath)) {
      fs.rmSync(tempPath, { force: true });
    }
    throw error;
  }
}

function copyDirectoryRecursive(sourceDir, targetDir) {
  if (!fs.existsSync(sourceDir)) {
    ensureDir(targetDir);
    return;
  }

  ensureDir(targetDir);

  for (const entry of fs.readdirSync(sourceDir, { withFileTypes: true })) {
    const sourcePath = path.join(sourceDir, entry.name);
    const targetPath = path.join(targetDir, entry.name);

    if (entry.isDirectory()) {
      copyDirectoryRecursive(sourcePath, targetPath);
    } else {
      fs.copyFileSync(sourcePath, targetPath);
    }
  }
}

function removeDirectorySafe(dirPath) {
  if (fs.existsSync(dirPath)) {
    fs.rmSync(dirPath, { recursive: true, force: true });
  }
}

function createSafetySnapshot({
  liveDataDir,
  safetyRootDir,
  snapshotId,
} = {}) {
  if (!text(liveDataDir)) throw new Error('liveDataDir is required.');
  if (!text(safetyRootDir)) throw new Error('safetyRootDir is required.');

  const cleanId = upper(snapshotId) || `RESTORE-SAFETY-${Date.now()}`;
  const snapshotDir = path.join(safetyRootDir, cleanId);

  if (fs.existsSync(snapshotDir)) {
    throw new Error('Safety snapshot already exists.');
  }

  ensureDir(safetyRootDir);
  copyDirectoryRecursive(liveDataDir, snapshotDir);

  return Object.freeze({
    snapshotId: cleanId,
    snapshotDir,
    createdAt: new Date().toISOString(),
  });
}

function buildRestoreStaging({
  restoreData,
  stagingRootDir,
  restoreId,
} = {}) {
  if (!restoreData || typeof restoreData !== 'object') {
    throw new TypeError('restoreData is required.');
  }

  if (!text(stagingRootDir)) throw new Error('stagingRootDir is required.');

  const cleanRestoreId = upper(restoreId) || `RESTORE-${Date.now()}`;
  const stagingDir = path.join(stagingRootDir, cleanRestoreId);

  if (fs.existsSync(stagingDir)) {
    throw new Error('Restore staging directory already exists.');
  }

  ensureDir(stagingDir);

  const sectionHashes = {};

  for (const [section, value] of Object.entries(restoreData)) {
    const filePath = path.join(stagingDir, `${section}.json`);
    writeJsonAtomic(filePath, value);
    sectionHashes[section] = sha256(stableStringify(value));
  }

  const manifest = {
    restoreId: cleanRestoreId,
    sections: Object.keys(restoreData).sort(),
    sectionHashes,
  };

  writeJsonAtomic(path.join(stagingDir, 'restore-staging-manifest.json'), manifest);

  return Object.freeze({
    restoreId: cleanRestoreId,
    stagingDir,
    sections: Object.freeze(manifest.sections),
    sectionHashes: Object.freeze(sectionHashes),
  });
}

function verifyRestoreStaging(staging) {
  if (!staging || typeof staging !== 'object') {
    throw new TypeError('staging is required.');
  }

  const manifestPath = path.join(staging.stagingDir, 'restore-staging-manifest.json');
  if (!fs.existsSync(manifestPath)) {
    return Object.freeze({
      valid: false,
      error: 'Restore staging manifest is missing.',
    });
  }

  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  const results = [];

  for (const section of manifest.sections || []) {
    const filePath = path.join(staging.stagingDir, `${section}.json`);
    if (!fs.existsSync(filePath)) {
      results.push({
        section,
        valid: false,
        reason: 'Section file is missing.',
      });
      continue;
    }

    const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const actualHash = sha256(stableStringify(data));
    const expectedHash = manifest.sectionHashes[section];

    results.push({
      section,
      valid: actualHash === expectedHash,
      expectedHash,
      actualHash,
    });
  }

  const allValid = results.length > 0 && results.every((item) => item.valid);

  return Object.freeze({
    valid: allValid,
    sectionResults: Object.freeze(results.map((item) => Object.freeze(item))),
  });
}

function applyStagingToLive({
  staging,
  liveDataDir,
  allowSections = null,
} = {}) {
  if (!staging || typeof staging !== 'object') {
    throw new TypeError('staging is required.');
  }

  if (!text(liveDataDir)) throw new Error('liveDataDir is required.');

  const verification = verifyRestoreStaging(staging);
  if (!verification.valid) {
    throw new Error('Restore staging verification failed.');
  }

  const manifestPath = path.join(staging.stagingDir, 'restore-staging-manifest.json');
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

  const selectedSections = Array.isArray(allowSections)
    ? manifest.sections.filter((section) => allowSections.includes(section))
    : manifest.sections;

  if (selectedSections.length !== manifest.sections.length) {
    throw new Error('Partial restore is blocked by guarded restore policy.');
  }

  ensureDir(liveDataDir);

  for (const section of selectedSections) {
    const sourcePath = path.join(staging.stagingDir, `${section}.json`);
    const targetPath = path.join(liveDataDir, `${section}.json`);
    const content = JSON.parse(fs.readFileSync(sourcePath, 'utf8'));
    writeJsonAtomic(targetPath, content);
  }

  return Object.freeze({
    applied: true,
    sections: Object.freeze([...selectedSections]),
  });
}

function restoreSafetySnapshot({
  snapshot,
  liveDataDir,
} = {}) {
  if (!snapshot || typeof snapshot !== 'object') {
    throw new TypeError('snapshot is required.');
  }

  if (!text(liveDataDir)) throw new Error('liveDataDir is required.');

  removeDirectorySafe(liveDataDir);
  copyDirectoryRecursive(snapshot.snapshotDir, liveDataDir);

  return Object.freeze({
    rolledBack: true,
    snapshotId: snapshot.snapshotId,
    liveDataDir,
  });
}

function guardedRestore({
  liveDataDir,
  safetyRootDir,
  stagingRootDir,
  restoreData,
  restoreId,
  snapshotId,
  simulateFailureAfterApply = false,
} = {}) {
  const snapshot = createSafetySnapshot({
    liveDataDir,
    safetyRootDir,
    snapshotId,
  });

  let staging;

  try {
    staging = buildRestoreStaging({
      restoreData,
      stagingRootDir,
      restoreId,
    });

    const stagingVerification = verifyRestoreStaging(staging);

    if (!stagingVerification.valid) {
      throw new Error('Restore staging integrity verification failed.');
    }

    const applyResult = applyStagingToLive({
      staging,
      liveDataDir,
    });

    if (simulateFailureAfterApply) {
      throw new Error('Simulated restore failure after apply.');
    }

    return Object.freeze({
      completed: true,
      snapshot,
      staging,
      stagingVerification,
      applyResult,
      rolledBack: false,
    });
  } catch (error) {
    const rollback = restoreSafetySnapshot({
      snapshot,
      liveDataDir,
    });

    return Object.freeze({
      completed: false,
      snapshot,
      staging: staging || null,
      rolledBack: true,
      rollback,
      error: error.message,
    });
  }
}

class GuardedRestoreEngine {
  snapshot(input) {
    return createSafetySnapshot(input);
  }

  stage(input) {
    return buildRestoreStaging(input);
  }

  verify(staging) {
    return verifyRestoreStaging(staging);
  }

  apply(input) {
    return applyStagingToLive(input);
  }

  rollback(input) {
    return restoreSafetySnapshot(input);
  }

  restore(input) {
    return guardedRestore(input);
  }
}

module.exports = {
  text,
  upper,
  ensureDir,
  stableStringify,
  sha256,
  writeJsonAtomic,
  copyDirectoryRecursive,
  removeDirectorySafe,
  createSafetySnapshot,
  buildRestoreStaging,
  verifyRestoreStaging,
  applyStagingToLive,
  restoreSafetySnapshot,
  guardedRestore,
  GuardedRestoreEngine,
};
