'use strict';

const assert = require('assert');

const {
  RECEIPT_STATUSES,
  text,
  upper,
  finiteNumber,
  nonNegative,
  positive,
  roundMoney,
  normalizeDate,
  formatDisplayDate,
  padSequence,
  generateReceiptNumber,
  calculateReceiptFinancials,
  createIntegrityHash,
  verifyIntegrityHash,
  createReceipt,
  ensureUniqueReceipt,
  cancelReceipt,
  buildPrintableReceipt,
  buildWhatsAppReceiptMessage,
  ReceiptEngine,
} = require('./receipt-engine');

(() => {
  console.log('Falcon Receipt Engine Tests');
  console.log('---------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  function checkFalse(value) {
    assert.strictEqual(value, false);
    assertions += 1;
  }

  check(RECEIPT_STATUSES.ISSUED, 'ISSUED');
  check(text(' Falcon '), 'Falcon');
  check(upper('rcp'), 'RCP');
  check(finiteNumber('10', 'value'), 10);
  check(nonNegative(0, 'value'), 0);
  check(positive(1, 'value'), 1);
  check(roundMoney(10.005), 10.01);
  check(normalizeDate('29-07-2026'), '2026-07-29');
  check(formatDisplayDate('2026-07-29'), '29-07-2026');
  check(padSequence(12), '000012');

  check(
    generateReceiptNumber({
      sequence: 1,
    }),
    'RCP-000001'
  );

  check(
    generateReceiptNumber({
      sequence: 15,
      prefix: 'REC',
      projectCode: 'JP',
    }),
    'REC-JP-000015'
  );

  assert.throws(
    () => generateReceiptNumber({ sequence: 0 }),
    /greater than zero/
  );
  assertions += 1;

  const financials = calculateReceiptFinancials({
    totalAmount: 500000,
    previousPaid: 100000,
    currentPayment: 150000,
  });

  check(financials.totalAmount, 500000);
  check(financials.previousPaid, 100000);
  check(financials.currentPayment, 150000);
  check(financials.cumulativePaid, 250000);
  check(financials.balanceAmount, 250000);
  check(financials.paymentPercent, 50);
  check(financials.paidInFull, false);

  const finalFinancials = calculateReceiptFinancials({
    totalAmount: 500000,
    previousPaid: 250000,
    currentPayment: 250000,
  });

  check(finalFinancials.balanceAmount, 0);
  check(finalFinancials.paymentPercent, 100);
  check(finalFinancials.paidInFull, true);

  assert.throws(
    () =>
      calculateReceiptFinancials({
        totalAmount: 500000,
        previousPaid: 450000,
        currentPayment: 100000,
      }),
    /exceed total amount/
  );
  assertions += 1;

  const input = {
    receiptNumber: 'rcp-jp-000001',
    paymentId: 'pay-000001',
    bookingId: 'fb-000001',
    projectId: 'fp-000001',
    projectName: 'Jaipur Pride',
    projectAddress: 'Sawai Madhopur, Rajasthan',
    reraNumber: 'RAJ/P/2026/1234',
    reraStatus: 'APPROVED',
    companyName: 'Falcon Realty',
    companyAddress: 'Rajasthan',
    companyPhone: '9876543210',
    companyEmail: 'info@example.com',
    companyLogoPath: 'assets/logo.png',
    customerId: 'fc-000001',
    customerName: 'Shadab Aziz',
    customerMobile: '9876543210',
    customerAddress: 'Sawai Madhopur',
    plotId: 'fpl-000043',
    plotNumber: '43',
    plotArea: 125.5,
    areaUnit: 'SQ_YARD',
    rate: 4000,
    paymentMode: 'UPI',
    referenceNumber: 'UPI-REF-123',
    paymentDate: '29-07-2026',
    receivedBy: 'Admin User',
    receivedById: 'fu-000001',
    totalAmount: 500000,
    previousPaid: 100000,
    currentPayment: 150000,
    notes: 'Second installment',
    terms: [
      'Payment is subject to verification.',
      'Booking is subject to project terms.',
    ],
    qrPayload: 'falcon://receipt/RCP-JP-000001',
    integritySecret: 'falcon-secret',
    issuedAt: '2026-07-29T10:00:00.000Z',
  };

  const receipt = createReceipt(input);

  check(receipt.receiptNumber, 'RCP-JP-000001');
  check(receipt.paymentId, 'PAY-000001');
  check(receipt.bookingId, 'FB-000001');
  check(receipt.projectId, 'FP-000001');
  check(receipt.customerId, 'FC-000001');
  check(receipt.plotId, 'FPL-000043');
  check(receipt.paymentDate, '2026-07-29');
  check(receipt.paymentDateDisplay, '29-07-2026');
  check(receipt.currentPayment, 150000);
  check(receipt.cumulativePaid, 250000);
  check(receipt.balanceAmount, 250000);
  check(receipt.status, 'ISSUED');
  check(receipt.integrityHash.length, 64);

  checkTrue(
    verifyIntegrityHash(
      receipt,
      receipt.integrityHash,
      'falcon-secret'
    )
  );

  checkFalse(
    verifyIntegrityHash(
      { ...receipt, currentPayment: 150001 },
      receipt.integrityHash,
      'falcon-secret'
    )
  );

  assert.throws(
    () =>
      createReceipt({
        ...input,
        receiptNumber: '',
      }),
    /receiptNumber is required/
  );
  assertions += 1;

  assert.throws(
    () =>
      createReceipt({
        ...input,
        customerName: '',
      }),
    /customerName is required/
  );
  assertions += 1;

  checkTrue(
    ensureUniqueReceipt({
      receiptNumber: 'RCP-JP-000002',
      existingReceipts: [receipt],
    })
  );

  assert.throws(
    () =>
      ensureUniqueReceipt({
        receiptNumber: 'RCP-JP-000001',
        existingReceipts: [receipt],
      }),
    /Duplicate receiptNumber/
  );
  assertions += 1;

  const cancelledReceipt = cancelReceipt({
    receipt,
    actorId: 'FU-000001',
    reason: 'Wrong payment details',
    cancelledAt: '2026-07-29T11:00:00.000Z',
    integritySecret: 'falcon-secret',
  });

  check(cancelledReceipt.status, 'CANCELLED');
  check(cancelledReceipt.cancellationReason, 'Wrong payment details');
  check(cancelledReceipt.cancelledBy, 'FU-000001');
  check(cancelledReceipt.cancelledAt, '2026-07-29T11:00:00.000Z');
  check(cancelledReceipt.integrityHash.length, 64);

  assert.throws(
    () =>
      cancelReceipt({
        receipt: cancelledReceipt,
        actorId: 'FU-000001',
        reason: 'Cancel again',
      }),
    /already cancelled/
  );
  assertions += 1;

  const printable = buildPrintableReceipt(receipt);
  check(printable.header.title, 'PAYMENT RECEIPT');
  check(printable.header.receiptNumber, 'RCP-JP-000001');
  check(printable.project.projectName, 'Jaipur Pride');
  check(printable.customer.customerName, 'Shadab Aziz');
  check(printable.plot.plotNumber, '43');
  check(printable.payment.currentPayment, 150000);
  check(printable.payment.balanceAmount, 250000);
  check(printable.footer.poweredBy, 'Powered by Falcon');
  check(printable.footer.terms.length, 2);

  const message = buildWhatsAppReceiptMessage(receipt);
  checkTrue(message.includes('RCP-JP-000001'));
  checkTrue(message.includes('Jaipur Pride'));
  checkTrue(message.includes('Plot No: 43'));
  checkTrue(message.includes('Total Paid: 250000'));
  checkTrue(message.includes('Balance: 250000'));
  checkTrue(message.includes('UPI-REF-123'));

  const engine = new ReceiptEngine();
  check(
    engine.generateNumber({
      sequence: 99,
      projectCode: 'JP',
    }),
    'RCP-JP-000099'
  );

  const enginePrintable = engine.printable(receipt);
  check(enginePrintable.header.receiptDate, '29-07-2026');

  checkTrue(
    engine.verify(
      receipt,
      createIntegrityHash(receipt, 'falcon-secret'),
      'falcon-secret'
    )
  );

  console.log('Receipt Number Generation: PASS');
  console.log('Financial Calculation: PASS');
  console.log('Receipt Data Model: PASS');
  console.log('Duplicate Receipt Protection: PASS');
  console.log('Integrity Hash: PASS');
  console.log('Receipt Cancellation Safety: PASS');
  console.log('Printable Receipt Structure: PASS');
  console.log('WhatsApp Message Structure: PASS');
  console.log('Reusable Receipt Engine: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('---------------------------');
  console.log('RECEIPT ENGINE TEST PASS');
})();
