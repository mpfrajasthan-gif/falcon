'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const {
  resolveActiveProjectMapPath,
  validateMapReadyPayload,
  loadActiveProjectMap,
  buildRendererBridgeResult,
  AutomaticRealProjectMapLoaderService,
} = require('./automatic-real-project-map-loader');

(() => {
  console.log('Falcon MAP.8.1 Automatic Real Project Map Loader Tests');
  console.log('------------------------------------------------------');

  let assertions = 0;
  const check = (a, e) => { assert.deepStrictEqual(a, e); assertions += 1; };
  const yes = (v) => { assert.strictEqual(v, true); assertions += 1; };

  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'falcon-map81-'));
  const projectFolder = path.join(root, 'projects', 'FP-000001');
  const mapsFolder = path.join(projectFolder, 'maps');
  fs.mkdirSync(mapsFolder, { recursive: true });

  const project = {
    projectId: 'FP-000001',
    projectName: 'Jaipur Pride',
    projectFolder,
  };

  const payload = {
    projectId: 'FP-000001',
    rendererProfile: 'FALCON_V10_POLISHED_2D',
    geometryPolicy: {
      originalGeometryLocked: true,
      straightenGeometry: false,
      inventVertices: false,
      deleteVertices: false,
      roadSurfaceRule: 'BACKGROUND_GAPS',
    },
    layers: {
      plots: [
        {
          plotNumber: '1',
          status: 'AVAILABLE',
          vertices: [
            { x: 0, y: 0 },
            { x: 10, y: 0 },
            { x: 10, y: 20 },
            { x: 0, y: 20 },
          ],
          centroid: { x: 5, y: 10 },
          sideLengthsFt: [30, 45, 30, 45],
        },
        {
          plotNumber: '2',
          status: 'BOOKED',
          vertices: [
            { x: 10, y: 0 },
            { x: 20, y: 0 },
            { x: 20, y: 20 },
            { x: 10, y: 20 },
          ],
          centroid: { x: 15, y: 10 },
          sideLengthsFt: [30, 45, 30, 45],
        },
      ],
      roads: [],
      specialAreas: [],
    },
  };

  const mapPath = path.join(mapsFolder, 'map-ready.json');
  fs.writeFileSync(mapPath, JSON.stringify(payload, null, 2), 'utf8');

  check(
    resolveActiveProjectMapPath(project),
    mapPath
  );

  yes(validateMapReadyPayload(payload));

  const activeMap = loadActiveProjectMap(project);

  check(activeMap.projectId, 'FP-000001');
  check(activeMap.projectName, 'Jaipur Pride');
  check(activeMap.plotCount, 2);
  check(activeMap.source, 'ACTIVE_PROJECT_MAP_READY');
  check(activeMap.mapPath, mapPath);

  const bridge = buildRendererBridgeResult(activeMap);

  yes(bridge.readyForPremiumViewer);
  check(bridge.plotCount, 2);
  check(bridge.mapModel.layers.plots.length, 2);

  assert.throws(
    () => loadActiveProjectMap({
      projectId: 'FP-000002',
      projectName: 'Missing',
      projectFolder: path.join(root, 'projects', 'FP-000002'),
    }),
    /map-ready\.json not found/
  );
  assertions += 1;

  assert.throws(
    () => validateMapReadyPayload({
      layers: { plots: [] },
    }),
    /contains no plots/
  );
  assertions += 1;

  const service = new AutomaticRealProjectMapLoaderService();

  check(service.resolve(project), mapPath);
  check(service.load(project).plotCount, 2);
  yes(service.bridge(activeMap).readyForPremiumViewer);

  console.log('Active Project Folder Resolution: PASS');
  console.log('Automatic map-ready.json Resolution: PASS');
  console.log('Real Map Payload Validation: PASS');
  console.log('Real Project Map Load: PASS');
  console.log('Missing Map Safety: PASS');
  console.log('Empty Map Safety: PASS');
  console.log('Premium Viewer Bridge Packet: PASS');
  console.log('Reusable Automatic Loader Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('------------------------------------------------------');
  console.log('MAP AUTOMATIC REAL PROJECT MAP LOADER TEST PASS');
})();
