'use strict';

const assert = require('assert');

const {
  worldToScreen,
  buildRendererFrame,
  panViewport,
  zoomAroundPoint,
} = require('./map-renderer-core');

const {
  createSelectionState,
  selectPlot,
  clearSelection,
  resolvePlotByNumber,
  searchPlots,
  selectBySearch,
  handleMapClick,
  buildAutoFocusViewport,
  buildHomeViewport,
  preserveSelectionDuringViewportChange,
  buildPlotDetailsHandoff,
  buildInteractionSnapshot,
  MapSelectionInteractionService,
} = require('./map-selection-interaction');

(() => {
  console.log('Falcon MAP.3 Selection & Interaction Polish Tests');
  console.log('------------------------------------------------');

  let assertions = 0;
  const check = (a, e) => {
    assert.deepStrictEqual(a, e);
    assertions += 1;
  };
  const yes = (v) => {
    assert.strictEqual(v, true);
    assertions += 1;
  };

  const plots = [
    {
      plotNumber: '1',
      status: 'AVAILABLE',
      landUse: 'RESIDENTIAL',
      vertices: [
        { x: 0, y: 0 },
        { x: 10, y: 0 },
        { x: 10, y: 20 },
        { x: 0, y: 20 },
      ],
      centroid: { x: 5, y: 10 },
      areaSqYd: 150,
      areaSqM: 125.42,
      sideLengthsFt: [30, 45, 30, 45],
    },
    {
      plotNumber: '2',
      status: 'BOOKED',
      landUse: 'COMMERCIAL',
      vertices: [
        { x: 10, y: 0 },
        { x: 20, y: 0 },
        { x: 20, y: 20 },
        { x: 10, y: 20 },
      ],
      centroid: { x: 15, y: 10 },
      areaSqYd: 175,
      areaSqM: 146.32,
      sideLengthsFt: [30, 50, 30, 50],
    },
  ];

  const mapModel = {
    layers: {
      plots,
      roads: [],
      specialAreas: [],
    },
  };

  const frame = buildRendererFrame({
    mapModel,
    viewportWidth: 1000,
    viewportHeight: 800,
  });

  const initial = createSelectionState();
  check(initial.selectedPlotNumber, '');
  check(initial.revision, 0);

  const selected1 = selectPlot({
    state: initial,
    plotNumber: '1',
    source: 'CLICK',
    now: '2026-07-30T13:00:00.000Z',
  });

  check(selected1.selectedPlotNumber, '1');
  check(selected1.source, 'CLICK');
  check(selected1.revision, 1);

  const repeated = selectPlot({
    state: selected1,
    plotNumber: '1',
    source: 'CLICK',
  });

  check(repeated.revision, 1);
  check(repeated.selectedPlotNumber, '1');

  const selected2 = selectPlot({
    state: selected1,
    plotNumber: '2',
    source: 'SEARCH',
  });

  check(selected2.selectedPlotNumber, '2');
  check(selected2.revision, 2);

  const cleared = clearSelection({
    state: selected2,
  });

  check(cleared.selectedPlotNumber, '');
  check(cleared.revision, 3);

  const clearAgain = clearSelection({
    state: cleared,
  });

  check(clearAgain.revision, 3);

  check(resolvePlotByNumber(plots, '2').status, 'BOOKED');
  check(resolvePlotByNumber(plots, '99'), null);

  const searchExact = searchPlots(plots, '2');
  check(searchExact.length, 1);
  check(searchExact[0].plotNumber, '2');

  const searchStatus = searchPlots(plots, 'booked');
  check(searchStatus.length, 1);
  check(searchStatus[0].plotNumber, '2');

  const searchLandUse = searchPlots(plots, 'residential');
  check(searchLandUse.length, 1);
  check(searchLandUse[0].plotNumber, '1');

  const searchSelect = selectBySearch({
    state: initial,
    plots,
    query: '2',
  });

  yes(searchSelect.found);
  check(searchSelect.state.selectedPlotNumber, '2');
  check(searchSelect.state.source, 'SEARCH');

  const searchMiss = selectBySearch({
    state: initial,
    plots,
    query: '999',
  });

  check(searchMiss.found, false);
  check(searchMiss.state.selectedPlotNumber, '');

  const clickPoint = worldToScreen(
    { x: 15, y: 10 },
    frame.viewport
  );

  const clickResult = handleMapClick({
    state: initial,
    screenPoint: clickPoint,
    viewport: frame.viewport,
    plots,
  });

  check(clickResult.action, 'SELECT');
  check(clickResult.state.selectedPlotNumber, '2');

  const outsidePoint = worldToScreen(
    { x: 50, y: 50 },
    frame.viewport
  );

  const outsideResult = handleMapClick({
    state: clickResult.state,
    screenPoint: outsidePoint,
    viewport: frame.viewport,
    plots,
  });

  check(outsideResult.action, 'CLEAR');
  check(outsideResult.state.selectedPlotNumber, '');

  const selectedFrame = buildRendererFrame({
    mapModel,
    viewportWidth: 1000,
    viewportHeight: 800,
    selectedPlotNumber: '2',
  });

  const focusViewport = buildAutoFocusViewport({
    frame: selectedFrame,
    state: clickResult.state,
    zoomPercent: 25,
  });

  yes(focusViewport.zoom > selectedFrame.viewport.zoom);

  const homeViewport = buildHomeViewport({
    plots,
    viewportWidth: 1000,
    viewportHeight: 800,
  });

  check(homeViewport.zoom, frame.viewport.zoom);
  check(homeViewport.panX, frame.viewport.panX);
  check(homeViewport.panY, frame.viewport.panY);

  const panned = panViewport({
    viewport: frame.viewport,
    dx: 50,
    dy: 25,
  });

  const preservedPan = preserveSelectionDuringViewportChange({
    state: clickResult.state,
    viewport: panned,
  });

  check(preservedPan.state.selectedPlotNumber, '2');
  check(preservedPan.state.revision, clickResult.state.revision);
  check(preservedPan.viewport.panX, panned.panX);

  const zoomed = zoomAroundPoint({
    viewport: panned,
    screenPoint: clickPoint,
    factor: 1.1,
  });

  const preservedZoom = preserveSelectionDuringViewportChange({
    state: clickResult.state,
    viewport: zoomed,
  });

  check(preservedZoom.state.selectedPlotNumber, '2');
  yes(preservedZoom.viewport.zoom > frame.viewport.zoom);

  const details = buildPlotDetailsHandoff({
    state: clickResult.state,
    plots,
  });

  check(details.plotNumber, '2');
  check(details.status, 'BOOKED');
  check(details.areaSqYd, 175);
  check(details.sideLengthsFt, [30, 50, 30, 50]);

  const snapshot = buildInteractionSnapshot({
    state: clickResult.state,
    frame: selectedFrame,
    plots,
  });

  check(snapshot.selection.selectedPlotNumber, '2');
  check(snapshot.selectedPlot.plotNumber, '2');
  check(snapshot.visualContract.selectionFill, 'BLUE_GLASS_TRANSPARENT');
  check(snapshot.visualContract.selectionBoundary, 'THIN_DOTTED_OFFSET');
  check(snapshot.visualContract.autoZoomRangePercent, [20, 30]);
  yes(snapshot.visualContract.clickOutsideClearsSelection);
  yes(snapshot.visualContract.searchCentersSelection);
  yes(snapshot.visualContract.selectionPersistsDuringPanZoom);

  const service = new MapSelectionInteractionService();

  check(service.createState().revision, 0);
  check(service.search(plots, '2')[0].plotNumber, '2');
  check(service.details({
    state: clickResult.state,
    plots,
  }).plotNumber, '2');

  console.log('Initial Selection State: PASS');
  console.log('Click Selection: PASS');
  console.log('Repeated Click Stability: PASS');
  console.log('Search Selection: PASS');
  console.log('Search Miss Safety: PASS');
  console.log('Click-outside Clear: PASS');
  console.log('Plot Resolve/Search: PASS');
  console.log('20-30 Percent Auto-focus Zoom: PASS');
  console.log('Home/Fit Reset: PASS');
  console.log('Selection Persistence During Pan: PASS');
  console.log('Selection Persistence During Zoom: PASS');
  console.log('Plot Details Handoff: PASS');
  console.log('Blue Glass Selection Contract: PASS');
  console.log('Thin Dotted Offset Boundary Contract: PASS');
  console.log('Reusable Interaction Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('------------------------------------------------');
  console.log('MAP SELECTION & INTERACTION POLISH TEST PASS');
})();
