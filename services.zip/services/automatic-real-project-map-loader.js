'use strict';

const fs = require('fs');
const path = require('path');

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function resolveActiveProjectMapPath(projectRecord = {}) {
  const projectFolder = text(
    projectRecord.projectFolder ||
    projectRecord.folderPath ||
    projectRecord.path
  );

  if (!projectFolder) {
    throw new Error('Active project folder is required.');
  }

  return path.join(projectFolder, 'maps', 'map-ready.json');
}

function validateMapReadyPayload(payload) {
  if (!payload || typeof payload !== 'object') {
    throw new TypeError('map-ready payload is required.');
  }

  if (!payload.layers || !Array.isArray(payload.layers.plots)) {
    throw new Error('map-ready payload has no plots array.');
  }

  if (payload.layers.plots.length === 0) {
    throw new Error('map-ready payload contains no plots.');
  }

  return true;
}

function loadActiveProjectMap(projectRecord = {}) {
  const mapPath = resolveActiveProjectMapPath(projectRecord);

  if (!fs.existsSync(mapPath)) {
    throw new Error(`map-ready.json not found for active project: ${mapPath}`);
  }

  let payload;
  try {
    payload = JSON.parse(fs.readFileSync(mapPath, 'utf8'));
  } catch {
    throw new Error('Active project map-ready.json is invalid JSON.');
  }

  validateMapReadyPayload(payload);

  return Object.freeze({
    projectId: text(projectRecord.projectId || projectRecord.id),
    projectName: text(projectRecord.projectName || projectRecord.name),
    projectFolder: text(projectRecord.projectFolder || projectRecord.folderPath || projectRecord.path),
    mapPath,
    payload,
    plotCount: payload.layers.plots.length,
    source: 'ACTIVE_PROJECT_MAP_READY',
  });
}

function buildRendererBridgeResult(activeMap) {
  if (!activeMap || !activeMap.payload) {
    throw new TypeError('active map is required.');
  }

  return Object.freeze({
    projectId: activeMap.projectId,
    projectName: activeMap.projectName,
    mapPath: activeMap.mapPath,
    mapModel: activeMap.payload,
    plotCount: activeMap.plotCount,
    readyForPremiumViewer: true,
  });
}

class AutomaticRealProjectMapLoaderService {
  resolve(projectRecord) {
    return resolveActiveProjectMapPath(projectRecord);
  }

  load(projectRecord) {
    return loadActiveProjectMap(projectRecord);
  }

  bridge(activeMap) {
    return buildRendererBridgeResult(activeMap);
  }
}

module.exports = {
  text,
  resolveActiveProjectMapPath,
  validateMapReadyPayload,
  loadActiveProjectMap,
  buildRendererBridgeResult,
  AutomaticRealProjectMapLoaderService,
};
