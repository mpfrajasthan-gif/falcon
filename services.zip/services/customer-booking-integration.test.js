'use strict';

const assert = require('assert');

const {
  normalizeDate,
  normalizeCustomer,
  normalizeBooking,
  normalizePayment,
  linkCustomerBookings,
  buildCustomerAccount,
  buildCustomerDirectory,
  searchCustomerAccounts,
  buildCustomerHistory,
  CustomerBookingIntegrationService,
} = require('./customer-booking-integration');

(() => {
  console.log('Falcon Customer-Booking Integration Tests');
  console.log('-----------------------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  const customers = [
    {
      customerId: 'FC-000001',
      customerName: 'Shadab Aziz',
      mobile: '9876543210',
      email: 'shadab@example.com',
      address: 'Sawai Madhopur',
      dob: '09-03-1978',
    },
    {
      customerId: 'FC-000002',
      customerName: 'Aamir Khan',
      mobile: '9123456780',
      address: 'Jaipur',
    },
  ];

  const bookings = [
    {
      bookingId: 'FB-000001',
      customerId: 'FC-000001',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '43',
      bookingDate: '29-07-2026',
      grandTotal: 500000,
      paidAmount: 125000,
      balanceAmount: 375000,
      status: 'BOOKED',
    },
    {
      bookingId: 'FB-000002',
      customerId: 'FC-000001',
      projectId: 'FP-000002',
      projectName: 'Sawai Estate',
      plotNumber: '8',
      bookingDate: '25-07-2026',
      grandTotal: 450000,
      paidAmount: 450000,
      balanceAmount: 0,
      status: 'SOLD',
    },
    {
      bookingId: 'FB-000003',
      customerId: 'FC-000002',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '10',
      bookingDate: '28-07-2026',
      grandTotal: 300000,
      paidAmount: 300000,
      balanceAmount: 0,
      status: 'SOLD',
    },
    {
      bookingId: 'FB-000004',
      customerId: 'FC-999999',
      projectId: 'FP-000003',
      projectName: 'Unknown Project',
      plotNumber: '1',
      bookingDate: '20-07-2026',
      grandTotal: 200000,
      paidAmount: 0,
      balanceAmount: 200000,
      status: 'BOOKED',
    },
  ];

  const payments = [
    {
      paymentId: 'PAY-000001',
      bookingId: 'FB-000001',
      amount: 100000,
      paymentDate: '29-07-2026',
      status: 'POSTED',
      mode: 'CASH',
      receiptNumber: 'RCP-000001',
    },
    {
      paymentId: 'PAY-000002',
      bookingId: 'FB-000001',
      amount: 25000,
      paymentDate: '29-07-2026',
      status: 'POSTED',
      mode: 'UPI',
      receiptNumber: 'RCP-000002',
    },
    {
      paymentId: 'PAY-000003',
      bookingId: 'FB-000002',
      amount: 450000,
      paymentDate: '25-07-2026',
      status: 'POSTED',
      mode: 'BANK_TRANSFER',
      receiptNumber: 'RCP-000003',
    },
    {
      paymentId: 'PAY-000004',
      bookingId: 'FB-000001',
      amount: 10000,
      paymentDate: '29-07-2026',
      status: 'REVERSED',
      mode: 'CASH',
      receiptNumber: 'RCP-000004',
    },
  ];

  check(normalizeDate('09-03-1978'), '1978-03-09');

  const customer = normalizeCustomer(customers[0]);
  check(customer.customerId, 'FC-000001');
  check(customer.customerName, 'Shadab Aziz');
  check(customer.dob, '1978-03-09');

  const booking = normalizeBooking(bookings[0]);
  check(booking.bookingId, 'FB-000001');
  check(booking.customerId, 'FC-000001');
  check(booking.totalAmount, 500000);
  check(booking.balanceAmount, 375000);

  const payment = normalizePayment(payments[0]);
  check(payment.paymentId, 'PAY-000001');
  check(payment.bookingId, 'FB-000001');
  check(payment.amount, 100000);

  const linked = linkCustomerBookings({ customers, bookings });
  check(linked.linkedBookings.length, 3);
  check(linked.orphanBookings.length, 1);
  check(linked.orphanBookings[0].bookingId, 'FB-000004');

  const account = buildCustomerAccount({
    customer: customers[0],
    bookings,
    payments,
  });

  check(account.customer.customerId, 'FC-000001');
  check(account.summary.bookingCount, 2);
  check(account.summary.activeBookingCount, 2);
  check(account.summary.soldBookingCount, 1);
  check(account.summary.pendingBookingCount, 1);
  check(account.summary.paymentCount, 3);
  check(account.summary.totalBookingValue, 950000);
  check(account.summary.totalPaidFromBookings, 575000);
  check(account.summary.totalPostedPayments, 575000);
  check(account.summary.totalBalance, 375000);

  const directory = buildCustomerDirectory({
    customers,
    bookings,
    payments,
  });

  check(directory.length, 2);
  check(directory[0].customer.customerName, 'Aamir Khan');
  check(directory[1].customer.customerName, 'Shadab Aziz');

  const searchByName = searchCustomerAccounts(directory, 'Shadab');
  check(searchByName.length, 1);
  check(searchByName[0].customer.customerId, 'FC-000001');

  const searchByMobile = searchCustomerAccounts(directory, '9123456780');
  check(searchByMobile.length, 1);
  check(searchByMobile[0].customer.customerId, 'FC-000002');

  const history = buildCustomerHistory(account);
  check(history.length, 5);
  checkTrue(history.some((event) => event.type === 'BOOKING'));
  checkTrue(history.some((event) => event.type === 'PAYMENT'));
  checkTrue(history.some((event) => event.receiptNumber === 'RCP-000001'));

  const service = new CustomerBookingIntegrationService();

  const serviceAccount = service.account({
    customer: customers[1],
    bookings,
    payments,
  });

  check(serviceAccount.summary.bookingCount, 1);
  check(serviceAccount.summary.soldBookingCount, 1);
  check(serviceAccount.summary.totalBalance, 0);

  const serviceDirectory = service.directory({
    customers,
    bookings,
    payments,
  });

  check(serviceDirectory.length, 2);

  const serviceSearch = service.search(serviceDirectory, 'Jaipur');
  check(serviceSearch.length, 1);
  check(serviceSearch[0].customer.customerId, 'FC-000002');

  assert.throws(
    () =>
      linkCustomerBookings({
        customers: {},
        bookings,
      }),
    /must be arrays/
  );
  assertions += 1;

  assert.throws(
    () =>
      normalizeCustomer({
        customerName: 'No ID',
      }),
    /customerId is required/
  );
  assertions += 1;

  console.log('Customer Normalization: PASS');
  console.log('Booking Linkage: PASS');
  console.log('Orphan Booking Detection: PASS');
  console.log('Customer Account Summary: PASS');
  console.log('Payment Linkage: PASS');
  console.log('Posted Payment Filtering: PASS');
  console.log('Customer Directory: PASS');
  console.log('Customer Search: PASS');
  console.log('Customer History Timeline: PASS');
  console.log('Reusable Integration Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('-----------------------------------------');
  console.log('CUSTOMER-BOOKING INTEGRATION TEST PASS');
})();
