'use strict';
const assert = require('assert');
const {
  normalizeReadableAngle,
  normalizeMapModel,
  buildPlotDetail,
  mapStats,
  premiumVisualContract,
  PremiumRealViewerIntegrationService,
} = require('./map-premium-real-viewer-integration');

console.log('Falcon MAP.7 Premium Real Viewer Integration Tests');
console.log('--------------------------------------------------');

let a=0;
const check=(x,y)=>{assert.deepStrictEqual(x,y);a++;};
const yes=v=>{assert.strictEqual(v,true);a++;};

const raw={
  projectId:'FP-000001',
  projectName:'Jaipur Pride',
  layers:{
    plots:[
      {plotNumber:'1',status:'AVAILABLE',landUse:'RESIDENTIAL',vertices:[{x:0,y:0},{x:10,y:0},{x:10,y:20},{x:0,y:20}],centroid:{x:5,y:10},areaSqYd:150,sideLengthsFt:[30,45,30,45],khasraNo:'101'},
      {plotNumber:'2',status:'BOOKED',landUse:'COMMERCIAL',vertices:[{x:10,y:0},{x:20,y:0},{x:20,y:20},{x:10,y:20}],centroid:{x:15,y:10},areaSqYd:175,sideLengthsFt:[30,50,30,50]},
      {plotNumber:'3',status:'SOLD',landUse:'RESIDENTIAL',vertices:[{x:20,y:0},{x:30,y:0},{x:30,y:20},{x:20,y:20}],centroid:{x:25,y:10},areaSqYd:160,sideLengthsFt:[30,45,30,45]},
      {plotNumber:'4',status:'HOLD',landUse:'RESIDENTIAL',vertices:[{x:0,y:-20},{x:10,y:-20},{x:10,y:0},{x:0,y:0}],centroid:{x:5,y:-10},areaSqYd:145,sideLengthsFt:[30,45,30,45]},
    ],
    roads:[{id:'R1',name:"ROAD 40' WIDE",widthFt:40,labelPoint:{x:15,y:-8}}],
    specialAreas:[{id:'S1',name:'OTHER LAND',category:'OTHER LAND',vertices:[{x:0,y:20},{x:30,y:20},{x:30,y:30},{x:0,y:30}],centroid:{x:15,y:25}}],
  }
};

const model=normalizeMapModel(raw);
check(model.projectId,'FP-000001');
check(model.projectName,'Jaipur Pride');
check(model.layers.plots.length,4);
check(model.layers.roads.length,1);
check(model.layers.specialAreas.length,1);
yes(model.geometryPolicy.originalGeometryLocked);
check(model.geometryPolicy.straightenGeometry,false);

const stats=mapStats(model);
check(stats.plotCount,4);
check(stats.available,1);
check(stats.booked,1);
check(stats.sold,1);
check(stats.hold,1);

const detail=buildPlotDetail(model.layers.plots[0]);
check(detail.plotNumber,'1');
check(detail.areaSqYd,150);
check(detail.khasraNo,'101');
check(detail.dimensionsFt,[30,45,30,45]);

yes(Math.abs(normalizeReadableAngle(Math.PI))<1e-9);
yes(Math.abs(normalizeReadableAngle(3*Math.PI/4)+Math.PI/4)<1e-9);
yes(Math.abs(normalizeReadableAngle(-3*Math.PI/4)-Math.PI/4)<1e-9);

const vc=premiumVisualContract();
check(vc.defaultAreaUnit,'SQ_YARD');
check(vc.plotNumberTargetPx,15);
check(vc.selectedZoomFactor,1.25);
yes(vc.keepDimensionTextReadable);
yes(vc.thinPlotLines);
yes(vc.smoothPanZoom);
yes(vc.antiClutter);

const svc=new PremiumRealViewerIntegrationService();
check(svc.normalize(raw).layers.plots.length,4);
check(svc.details(model.layers.plots[1]).status,'BOOKED');
check(svc.stats(model).plotCount,4);

console.log('Real Map Normalization: PASS');
console.log('Project/Plot Data Preservation: PASS');
console.log('Status Summary: PASS');
console.log('Plot Detail Handoff: PASS');
console.log('Readable Dimension Orientation: PASS');
console.log('Premium Visual Contract: PASS');
console.log('Original Geometry Lock: PASS');
console.log('Reusable Premium Viewer Integration: PASS');
console.log(`Assertions Passed: ${a}`);
console.log('--------------------------------------------------');
console.log('MAP PREMIUM REAL VIEWER INTEGRATION TEST PASS');
