'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const {
  sanitizeFileName,
  sha256Buffer,
  writeBackupFileAtomic,
  verifyBackupFile,
  cleanupTemporaryBackupFiles,
  listBackupFiles,
  SafeBackupFileWriterService,
} = require('./safe-backup-file-writer');

(() => {
  console.log('Falcon Safe Backup File Writer Tests');
  console.log('------------------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  function checkFalse(value) {
    assert.strictEqual(value, false);
    assertions += 1;
  }

  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'falcon-backup-writer-'));

  check(
    sanitizeFileName('Falcon Backup 29-07-2026.fbackup'),
    'Falcon_Backup_29-07-2026.fbackup'
  );

  assert.throws(
    () => sanitizeFileName(''),
    /fileName is required/
  );
  assertions += 1;

  const payload1 = JSON.stringify({
    format: 'FALCON_ENCRYPTED_BACKUP_V1',
    backupId: 'BKP-000001',
    ciphertext: 'abc123',
  });

  const expectedHash1 = sha256Buffer(Buffer.from(payload1, 'utf8'));

  const written1 = writeBackupFileAtomic({
    directoryPath: tempRoot,
    fileName: 'backup-one.fbackup',
    serializedArchive: payload1,
    expectedHash: expectedHash1,
  });

  check(written1.fileName, 'backup-one.fbackup');
  checkTrue(written1.verified);
  check(written1.sha256, expectedHash1);
  checkTrue(fs.existsSync(written1.filePath));

  const verify1 = verifyBackupFile({
    filePath: written1.filePath,
    expectedHash: expectedHash1,
  });

  checkTrue(verify1.exists);
  checkTrue(verify1.valid);
  checkTrue(verify1.hashValid);
  checkTrue(verify1.sizeValid);

  assert.throws(
    () =>
      writeBackupFileAtomic({
        directoryPath: tempRoot,
        fileName: 'backup-one.fbackup',
        serializedArchive: payload1,
      }),
    /already exists/
  );
  assertions += 1;

  assert.throws(
    () =>
      writeBackupFileAtomic({
        directoryPath: tempRoot,
        fileName: 'wrong-hash.fbackup',
        serializedArchive: payload1,
        expectedHash: '0'.repeat(64),
      }),
    /does not match expected hash/
  );
  assertions += 1;

  checkFalse(
    fs.existsSync(path.join(tempRoot, 'wrong-hash.fbackup'))
  );

  const originalContent = fs.readFileSync(written1.filePath, 'utf8');

  const payload2 = JSON.stringify({
    format: 'FALCON_ENCRYPTED_BACKUP_V1',
    backupId: 'BKP-000002',
    ciphertext: 'xyz987',
  });

  const expectedHash2 = sha256Buffer(Buffer.from(payload2, 'utf8'));

  const replaced = writeBackupFileAtomic({
    directoryPath: tempRoot,
    fileName: 'backup-one.fbackup',
    serializedArchive: payload2,
    expectedHash: expectedHash2,
    overwrite: true,
  });

  check(replaced.sha256, expectedHash2);
  check(
    fs.readFileSync(replaced.filePath, 'utf8'),
    payload2
  );
  checkFalse(
    fs.existsSync(`${replaced.filePath}.previous`)
  );
  checkFalse(
    fs.readFileSync(replaced.filePath, 'utf8') === originalContent
  );

  const verifyWrongHash = verifyBackupFile({
    filePath: replaced.filePath,
    expectedHash: expectedHash1,
  });

  checkFalse(verifyWrongHash.valid);
  checkFalse(verifyWrongHash.hashValid);

  const missingVerification = verifyBackupFile({
    filePath: path.join(tempRoot, 'missing.fbackup'),
  });

  checkFalse(missingVerification.exists);
  checkFalse(missingVerification.valid);

  const payload3 = '{"backupId":"BKP-000003"}';

  writeBackupFileAtomic({
    directoryPath: tempRoot,
    fileName: 'backup-three.fbackup',
    serializedArchive: payload3,
  });

  const list = listBackupFiles({
    directoryPath: tempRoot,
  });

  check(list.length, 2);
  checkTrue(list.some((item) => item.fileName === 'backup-one.fbackup'));
  checkTrue(list.some((item) => item.fileName === 'backup-three.fbackup'));

  const orphanTemp1 = path.join(tempRoot, 'orphan.fbackup.tmp-123');
  const orphanTemp2 = path.join(tempRoot, 'another.tmp-456');

  fs.writeFileSync(orphanTemp1, 'temp');
  fs.writeFileSync(orphanTemp2, 'temp');

  const oldTime = new Date(Date.now() - 100000);
  fs.utimesSync(orphanTemp1, oldTime, oldTime);
  fs.utimesSync(orphanTemp2, oldTime, oldTime);

  const removed = cleanupTemporaryBackupFiles({
    directoryPath: tempRoot,
    olderThanMs: 50000,
  });

  check(removed.length, 2);
  checkFalse(fs.existsSync(orphanTemp1));
  checkFalse(fs.existsSync(orphanTemp2));

  const service = new SafeBackupFileWriterService();

  const serviceWrite = service.write({
    directoryPath: tempRoot,
    fileName: 'service-backup.fbackup',
    serializedArchive: '{"service":true}',
  });

  checkTrue(serviceWrite.verified);

  const serviceVerify = service.verify({
    filePath: serviceWrite.filePath,
  });

  checkTrue(serviceVerify.valid);

  const serviceList = service.list({
    directoryPath: tempRoot,
  });

  check(serviceList.length, 3);

  console.log('Safe Filename Handling: PASS');
  console.log('Temporary File Write: PASS');
  console.log('Disk Flush: PASS');
  console.log('Temporary File Verification: PASS');
  console.log('Atomic Final Rename: PASS');
  console.log('Safe Overwrite Replacement: PASS');
  console.log('Failed Write Cleanup: PASS');
  console.log('Final File Hash Verification: PASS');
  console.log('Missing/Damaged Backup Detection: PASS');
  console.log('Orphan Temporary File Cleanup: PASS');
  console.log('Backup File Listing: PASS');
  console.log('Reusable Safe File Writer Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('------------------------------------');
  console.log('SAFE BACKUP FILE WRITER TEST PASS');
})();
