'use strict';

const {
  createIdentity,
} = require('../core/identity/identity-engine');

const {
  toIsoTimestamp,
} = require('../core/utilities/core-utils');

const {
  success,
  failure,
} = require('../core/errors/result');

const {
  normalizeError,
} = require('../core/errors/falcon-error');

const {
  info,
  error: logError,
} = require('../core/logging/logger');

const {
  validateCustomerCreate,
  validateCustomerUpdate,
} = require('../validation/customer-validation');

const {
  applyCustomerSearch,
} = require('../search/customer-search');

class CustomerService {
  constructor(customerRepository) {
    if (
      !customerRepository ||
      typeof customerRepository.create !== 'function' ||
      typeof customerRepository.findById !== 'function' ||
      typeof customerRepository.findAll !== 'function' ||
      typeof customerRepository.update !== 'function' ||
      typeof customerRepository.delete !== 'function' ||
      typeof customerRepository.mobileExists !== 'function'
    ) {
      throw new TypeError('A valid CustomerRepository is required.');
    }

    this.customerRepository = customerRepository;
  }

  createCustomer(input) {
    try {
      const validation = validateCustomerCreate(input);

      if (!validation.valid) {
        return failure(
          'CUSTOMER_VALIDATION_FAILED',
          'Customer information is invalid.',
          { errors: validation.errors }
        );
      }

      const { name, mobile, address } = validation.value;

      if (this.customerRepository.mobileExists(mobile)) {
        return failure(
          'CUSTOMER_MOBILE_ALREADY_EXISTS',
          'A customer with this mobile number already exists.',
          { mobile }
        );
      }

      const identity = createIdentity('customer');
      const timestamp = toIsoTimestamp();

      const createdCustomer = this.customerRepository.create({
        id: identity.id,
        uuid: identity.uuid,
        name,
        mobile,
        address,
        createdAt: timestamp,
        updatedAt: timestamp,
      });

      info('Falcon customer created.', {
        customerId: createdCustomer.id,
        customerName: createdCustomer.name,
      });

      return success(
        'CUSTOMER_CREATED',
        'Falcon customer created successfully.',
        createdCustomer
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'CUSTOMER_CREATE_FAILED',
        'Falcon customer could not be created.'
      );
    }
  }

  getCustomer(customerId) {
    try {
      const customer = this.customerRepository.findById(customerId);

      if (!customer) {
        return failure(
          'CUSTOMER_NOT_FOUND',
          'Falcon customer was not found.',
          { customerId }
        );
      }

      return success(
        'CUSTOMER_FOUND',
        'Falcon customer loaded successfully.',
        customer
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'CUSTOMER_LOAD_FAILED',
        'Falcon customer could not be loaded.'
      );
    }
  }

  getAllCustomers() {
    try {
      const customers = this.customerRepository.findAll();
      const items = customers.map((customer) =>
        Object.freeze({ ...customer })
      );

      // Backward-compatible list result:
      // - data.length
      // - data.total
      // - data.items
      // - data.customers
      Object.defineProperties(items, {
        total: {
          value: items.length,
          enumerable: true,
        },
        items: {
          value: items,
          enumerable: true,
        },
        customers: {
          value: items,
          enumerable: true,
        },
      });

      Object.freeze(items);

      return success(
        'CUSTOMERS_LOADED',
        'Falcon customers loaded successfully.',
        items
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'CUSTOMER_LIST_FAILED',
        'Falcon customers could not be loaded.'
      );
    }
  }

  searchCustomers(query, options = {}) {
    try {
      const customers = this.customerRepository.findAll();

      const result = applyCustomerSearch(customers, {
        query,
        offset: options.offset,
        limit: options.limit,
      });

      const items = result.items.map((customer) =>
        Object.freeze({ ...customer })
      );

      // Backward-compatible search result:
      // Old tests/API use data.length and array indexing.
      // New search API uses data.total, data.items, pagination metadata.
      Object.defineProperties(items, {
        query: {
          value: result.query,
          enumerable: true,
        },
        total: {
          value: result.total,
          enumerable: true,
        },
        offset: {
          value: result.offset,
          enumerable: true,
        },
        limit: {
          value: result.limit,
          enumerable: true,
        },
        hasMore: {
          value: result.hasMore,
          enumerable: true,
        },
        items: {
          value: items,
          enumerable: true,
        },
      });

      Object.freeze(items);

      return success(
        'CUSTOMER_SEARCH_COMPLETE',
        'Customer search completed successfully.',
        items
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'CUSTOMER_SEARCH_FAILED',
        'Falcon customer search failed.'
      );
    }
  }

  updateCustomer(customerId, changes) {
    try {
      const existing = this.customerRepository.findById(customerId);

      if (!existing) {
        return failure(
          'CUSTOMER_NOT_FOUND',
          'Falcon customer was not found.',
          { customerId }
        );
      }

      const validation = validateCustomerUpdate(changes);

      if (!validation.valid) {
        return failure(
          'CUSTOMER_VALIDATION_FAILED',
          'Customer information is invalid.',
          { errors: validation.errors }
        );
      }

      const updateData = {
        ...validation.value,
        updatedAt: toIsoTimestamp(),
      };

      if (
        updateData.mobile &&
        this.customerRepository.mobileExists(updateData.mobile, customerId)
      ) {
        return failure(
          'CUSTOMER_MOBILE_ALREADY_EXISTS',
          'A customer with this mobile number already exists.',
          { mobile: updateData.mobile }
        );
      }

      const updatedCustomer = this.customerRepository.update(
        customerId,
        updateData
      );

      info('Falcon customer updated.', {
        customerId: updatedCustomer.id,
      });

      return success(
        'CUSTOMER_UPDATED',
        'Falcon customer updated successfully.',
        updatedCustomer
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'CUSTOMER_UPDATE_FAILED',
        'Falcon customer could not be updated.'
      );
    }
  }

  deleteCustomer(customerId) {
    try {
      if (!this.customerRepository.findById(customerId)) {
        return failure(
          'CUSTOMER_NOT_FOUND',
          'Falcon customer was not found.',
          { customerId }
        );
      }

      const deleted = this.customerRepository.delete(customerId);

      if (!deleted) {
        return failure(
          'CUSTOMER_DELETE_FAILED',
          'Falcon customer could not be deleted.',
          { customerId }
        );
      }

      info('Falcon customer deleted.', { customerId });

      return success(
        'CUSTOMER_DELETED',
        'Falcon customer deleted successfully.',
        Object.freeze({ customerId, deleted: true })
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'CUSTOMER_DELETE_FAILED',
        'Falcon customer could not be deleted.'
      );
    }
  }

  handleError(error, fallbackCode, fallbackMessage) {
    const normalizedError = normalizeError(
      error,
      fallbackCode,
      fallbackMessage
    );

    logError(fallbackMessage, {
      code: normalizedError.code,
      message: normalizedError.message,
      details: normalizedError.details,
    });

    return failure(
      normalizedError.code,
      normalizedError.message,
      normalizedError.toJSON()
    );
  }
}

module.exports = {
  CustomerService,
};
