'use strict';

const assert = require('assert');

const {
  CustomerService,
} = require('./customer-service');

function createFakeRepository() {
  const customers = new Map();

  return {
    create(customer) {
      customers.set(customer.id, { ...customer });
      return Object.freeze({ ...customer });
    },

    findById(id) {
      const customer = customers.get(id);
      return customer ? Object.freeze({ ...customer }) : null;
    },

    findAll() {
      return [...customers.values()].map(
        (customer) => Object.freeze({ ...customer })
      );
    },

    update(id, changes) {
      const existing = customers.get(id);

      if (!existing) {
        throw new Error('Customer not found.');
      }

      const updated = {
        ...existing,
        ...changes,
        id: existing.id,
        uuid: existing.uuid,
        createdAt: existing.createdAt,
      };

      customers.set(id, updated);
      return Object.freeze({ ...updated });
    },

    delete(id) {
      return customers.delete(id);
    },

    mobileExists(mobile, excludeCustomerId = null) {
      return [...customers.values()].some(
        (customer) =>
          customer.mobile === mobile &&
          customer.id !== excludeCustomerId
      );
    },
  };
}

function runCustomerServiceTests() {
  console.log('Falcon Customer Service Tests');
  console.log('-----------------------------');

  const repository = createFakeRepository();
  const service = new CustomerService(repository);

  const first = service.createCustomer({
    name: 'Shadab Aziz',
    mobile: '9876543210',
    address: 'Sawai Madhopur',
  });

  const second = service.createCustomer({
    name: 'Aamir Khan',
    mobile: '9123456789',
    address: 'Kota',
  });

  assert.strictEqual(first.success, true);
  assert.strictEqual(second.success, true);

  const nameSearch = service.searchCustomers('shadab');
  assert.strictEqual(nameSearch.success, true);
  assert.strictEqual(nameSearch.data.total, 1);
  assert.strictEqual(nameSearch.data.items[0].name, 'Shadab Aziz');

  const mobileSearch = service.searchCustomers('91234');
  assert.strictEqual(mobileSearch.data.total, 1);
  assert.strictEqual(mobileSearch.data.items[0].name, 'Aamir Khan');

  const addressSearch = service.searchCustomers('madhopur');
  assert.strictEqual(addressSearch.data.total, 1);

  const allSearch = service.searchCustomers('', {
    offset: 0,
    limit: 1,
  });

  assert.strictEqual(allSearch.data.total, 2);
  assert.strictEqual(allSearch.data.items.length, 1);
  assert.strictEqual(allSearch.data.hasMore, true);

  console.log('Search Integration: PASS');
  console.log('Pagination Integration: PASS');
  console.log('Assertions Passed: 10');
  console.log('-----------------------------');
  console.log('CUSTOMER SERVICE SEARCH TEST PASS');
}

try {
  runCustomerServiceTests();
} catch (error) {
  console.error('CUSTOMER SERVICE SEARCH TEST FAIL');
  console.error(error.stack || error.message);
  process.exitCode = 1;
}
