'use strict';

const assert = require('assert');

const {
  CUSTOMER_ROLES,
  CUSTOMER_ACTIONS,
  normalizeRole,
  normalizeAction,
  canPerformCustomerAction,
  assertCustomerPermission,
  sanitizeCustomerSnapshot,
  createCustomerAuditEvent,
  ensureUniqueAuditEventId,
  buildCustomerAuditTrail,
  validateCustomerUpdate,
  validateDocumentArchivePermission,
  buildSecuritySummary,
  CustomerSecurityAuditIntegrationService,
} = require('./customer-security-audit-integration');

(() => {
  console.log('Falcon Customer Security & Audit Integration Tests');
  console.log('--------------------------------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  function checkFalse(value) {
    assert.strictEqual(value, false);
    assertions += 1;
  }

  check(CUSTOMER_ROLES.ADMIN, 'ADMIN');
  check(CUSTOMER_ACTIONS.CUSTOMER_VIEW, 'CUSTOMER_VIEW');
  check(normalizeRole('operator'), 'OPERATOR');
  check(normalizeAction('customer_update'), 'CUSTOMER_UPDATE');

  checkTrue(canPerformCustomerAction('SUPER_ADMIN', 'CUSTOMER_DOCUMENT_ARCHIVE'));
  checkTrue(canPerformCustomerAction('ADMIN', 'CUSTOMER_DOCUMENT_ARCHIVE'));
  checkFalse(canPerformCustomerAction('OPERATOR', 'CUSTOMER_DOCUMENT_ARCHIVE'));
  checkTrue(canPerformCustomerAction('VIEWER', 'CUSTOMER_VIEW'));
  checkFalse(canPerformCustomerAction('VIEWER', 'CUSTOMER_UPDATE'));

  checkTrue(
    assertCustomerPermission({
      role: 'ADMIN',
      action: 'CUSTOMER_CREATE',
    })
  );

  assert.throws(
    () =>
      assertCustomerPermission({
        role: 'VIEWER',
        action: 'CUSTOMER_UPDATE',
      }),
    /not allowed/
  );
  assertions += 1;

  const customer = {
    customerId: 'FC-000001',
    customerName: 'Shadab Aziz',
    mobile: '9876543210',
    email: 'shadab@example.com',
    address: 'Sawai Madhopur',
    status: 'ACTIVE',
  };

  const snapshot = sanitizeCustomerSnapshot(customer);
  check(snapshot.customerId, 'FC-000001');
  check(snapshot.customerName, 'Shadab Aziz');
  check(snapshot.status, 'ACTIVE');

  const event1 = createCustomerAuditEvent({
    eventId: 'CAE-000001',
    action: 'CUSTOMER_VIEW',
    actorId: 'FU-000001',
    actorRole: 'VIEWER',
    customer,
    metadata: {
      source: 'CUSTOMER_PROFILE',
    },
    createdAt: '2026-07-29T10:00:00.000Z',
  });

  check(event1.eventId, 'CAE-000001');
  check(event1.action, 'CUSTOMER_VIEW');
  check(event1.actorRole, 'VIEWER');
  check(event1.customerId, 'FC-000001');
  check(event1.metadata.source, 'CUSTOMER_PROFILE');

  const event2 = createCustomerAuditEvent({
    eventId: 'CAE-000002',
    action: 'CUSTOMER_UPDATE',
    actorId: 'FU-000002',
    actorRole: 'OPERATOR',
    customer: {
      ...customer,
      address: 'Jaipur',
    },
    metadata: {
      changedFields: ['address'],
    },
    createdAt: '2026-07-29T11:00:00.000Z',
  });

  check(event2.action, 'CUSTOMER_UPDATE');
  check(event2.actorRole, 'OPERATOR');

  const event3 = createCustomerAuditEvent({
    eventId: 'CAE-000003',
    action: 'CUSTOMER_DOCUMENT_ARCHIVE',
    actorId: 'FU-000001',
    actorRole: 'ADMIN',
    customer,
    metadata: {
      documentId: 'DOC-000001',
      reason: 'Old document copy',
    },
    createdAt: '2026-07-29T12:00:00.000Z',
  });

  check(event3.action, 'CUSTOMER_DOCUMENT_ARCHIVE');

  checkTrue(
    ensureUniqueAuditEventId('CAE-000004', [event1, event2, event3])
  );

  assert.throws(
    () =>
      ensureUniqueAuditEventId('CAE-000001', [event1, event2, event3]),
    /Duplicate audit eventId/
  );
  assertions += 1;

  const trail = buildCustomerAuditTrail({
    customerId: 'FC-000001',
    events: [event1, event2, event3],
  });

  check(trail.length, 3);
  check(trail[0].eventId, 'CAE-000003');
  check(trail[2].eventId, 'CAE-000001');

  checkTrue(
    validateCustomerUpdate({
      before: customer,
      after: {
        ...customer,
        address: 'Jaipur',
      },
      actorRole: 'OPERATOR',
    })
  );

  assert.throws(
    () =>
      validateCustomerUpdate({
        before: customer,
        after: {
          ...customer,
          customerId: 'FC-999999',
        },
        actorRole: 'ADMIN',
      }),
    /customerId cannot be changed/
  );
  assertions += 1;

  assert.throws(
    () =>
      validateCustomerUpdate({
        before: customer,
        after: {
          ...customer,
          address: 'Jaipur',
        },
        actorRole: 'VIEWER',
      }),
    /not allowed/
  );
  assertions += 1;

  checkTrue(
    validateDocumentArchivePermission({
      actorRole: 'ADMIN',
      document: {
        documentId: 'DOC-000001',
      },
    })
  );

  assert.throws(
    () =>
      validateDocumentArchivePermission({
        actorRole: 'OPERATOR',
        document: {
          documentId: 'DOC-000001',
        },
      }),
    /not allowed/
  );
  assertions += 1;

  const summary = buildSecuritySummary([event1, event2, event3]);

  check(summary.eventCount, 3);
  check(summary.byAction.CUSTOMER_VIEW, 1);
  check(summary.byAction.CUSTOMER_UPDATE, 1);
  check(summary.byAction.CUSTOMER_DOCUMENT_ARCHIVE, 1);
  check(summary.byActor['FU-000001'], 2);
  check(summary.byActor['FU-000002'], 1);

  const service = new CustomerSecurityAuditIntegrationService();

  checkTrue(service.can('ADMIN', 'CUSTOMER_UPDATE'));
  checkFalse(service.can('VIEWER', 'CUSTOMER_CREATE'));

  const serviceEvent = service.createEvent({
    eventId: 'CAE-000004',
    action: 'CUSTOMER_STATEMENT_VIEW',
    actorId: 'FU-000003',
    actorRole: 'VIEWER',
    customer,
    createdAt: '2026-07-29T13:00:00.000Z',
  });

  check(serviceEvent.action, 'CUSTOMER_STATEMENT_VIEW');

  const serviceTrail = service.trail({
    customerId: 'FC-000001',
    events: [event1, event2, event3, serviceEvent],
  });

  check(serviceTrail.length, 4);

  console.log('Role Validation: PASS');
  console.log('Customer Action Permissions: PASS');
  console.log('Customer View Audit: PASS');
  console.log('Customer Update Audit: PASS');
  console.log('Document Archive Permission: PASS');
  console.log('Protected Customer ID: PASS');
  console.log('Duplicate Audit Event Protection: PASS');
  console.log('Customer Audit Trail: PASS');
  console.log('Security Summary: PASS');
  console.log('Reusable Security/Audit Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('--------------------------------------------------');
  console.log('CUSTOMER SECURITY & AUDIT INTEGRATION TEST PASS');
})();
