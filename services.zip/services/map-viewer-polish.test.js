'use strict';

const assert = require('assert');

const {
  computePlotLabelSize,
  shouldShowDimensions,
  shouldShowRoadLabels,
  shouldShowFacilityLabels,
  lineWeightForZoom,
  estimateTextBox,
  boxesOverlap,
  deconflictLabels,
  buildControlState,
  buildViewerDisplayRules,
  buildLabelCandidates,
  buildPolishedDisplayModel,
  MapViewerPolishService,
} = require('./map-viewer-polish');

(() => {
  console.log('Falcon MAP.4 Viewer Polish & Display Rules Tests');
  console.log('-----------------------------------------------');

  let assertions = 0;

  const check = (a, e) => {
    assert.deepStrictEqual(a, e);
    assertions += 1;
  };

  const yes = (v) => {
    assert.strictEqual(v, true);
    assertions += 1;
  };

  const lowSize = computePlotLabelSize(0.5);
  const midSize = computePlotLabelSize(1.3);
  const highSize = computePlotLabelSize(3);

  check(lowSize, 10);
  yes(midSize > 10 && midSize <= 15);
  check(highSize, 16);

  check(shouldShowDimensions(0.8, false), false);
  check(shouldShowDimensions(0.9, true), true);
  check(shouldShowDimensions(1.2, false), true);

  check(shouldShowRoadLabels(0.5), false);
  check(shouldShowRoadLabels(0.6), true);
  check(shouldShowFacilityLabels(0.6), false);
  check(shouldShowFacilityLabels(0.7), true);

  yes(lineWeightForZoom(0.5) < 1);
  check(lineWeightForZoom(1.2), 1);
  yes(lineWeightForZoom(3) > 1);

  const boxA = estimateTextBox({
    textValue: '43',
    x: 100,
    y: 100,
    fontSizePx: 15,
  });

  const boxB = estimateTextBox({
    textValue: '44',
    x: 105,
    y: 100,
    fontSizePx: 15,
  });

  const boxC = estimateTextBox({
    textValue: 'ROAD',
    x: 300,
    y: 300,
    fontSizePx: 11,
  });

  yes(boxesOverlap(boxA, boxB));
  check(boxesOverlap(boxA, boxC), false);

  const deconflicted = deconflictLabels([
    {
      id: 'P43',
      text: '43',
      point: { x: 100, y: 100 },
      fontSizePx: 15,
      priority: 100,
    },
    {
      id: 'P44',
      text: '44',
      point: { x: 105, y: 100 },
      fontSizePx: 15,
      priority: 90,
    },
    {
      id: 'R1',
      text: "ROAD 40' WIDE",
      point: { x: 300, y: 300 },
      fontSizePx: 11,
      priority: 60,
    },
  ]);

  check(deconflicted.visible.length, 2);
  check(deconflicted.hidden.length, 1);
  check(deconflicted.hidden[0].reason, 'COLLISION');

  const selectedWins = deconflictLabels([
    {
      id: 'P43',
      text: '43',
      point: { x: 100, y: 100 },
      fontSizePx: 15,
      priority: 1000,
      alwaysShow: true,
    },
    {
      id: 'P44',
      text: '44',
      point: { x: 102, y: 100 },
      fontSizePx: 15,
      priority: 100,
    },
  ]);

  check(selectedWins.visible[0].id, 'P43');
  check(selectedWins.hidden.length, 1);

  const controls = buildControlState();
  yes(controls.home.visible);
  yes(controls.home.enabled);
  check(controls.home.action, 'FIT_HOME');
  yes(controls.compass.visible);
  yes(controls.compass.northUp);
  check(controls.compass.action, 'RESET_NORTH');

  const rules = buildViewerDisplayRules({
    zoom: 1.25,
    selectedPlotNumber: '43',
  });

  yes(rules.dimensionsVisible);
  yes(rules.roadLabelsVisible);
  yes(rules.facilityLabelsVisible);
  yes(rules.antiClutter.enabled);
  check(rules.antiClutter.selectedPlotPriority, 1000);
  yes(rules.performance.smoothWheelZoom);
  yes(rules.performance.smoothPan);
  yes(rules.performance.renderOnlyVisibleLabels);
  yes(rules.visualBalance.thinPlotLines);
  yes(rules.visualBalance.compactRoadText);
  yes(rules.visualBalance.dimensionTextUnshaded);

  const candidates = buildLabelCandidates({
    zoom: 1.25,
    selectedPlotNumber: '43',
    plotLabels: [
      {
        id: 'P43',
        plotNumber: '43',
        text: '43',
        point: { x: 100, y: 100 },
      },
      {
        id: 'P44',
        plotNumber: '44',
        text: '44',
        point: { x: 104, y: 100 },
      },
    ],
    roadLabels: [
      {
        id: 'R1',
        text: "ROAD 40' WIDE",
        point: { x: 300, y: 300 },
        fontSizePx: 11,
      },
    ],
    facilityLabels: [
      {
        id: 'F1',
        text: 'PARK',
        point: { x: 400, y: 400 },
        fontSizePx: 11,
      },
    ],
    dimensionLabels: [
      {
        id: 'D1',
        text: "30.0'",
        point: { x: 200, y: 200 },
        fontSizePx: 10,
      },
    ],
  });

  yes(candidates.labels.some((l) => l.kind === 'PLOT_NUMBER'));
  yes(candidates.labels.some((l) => l.kind === 'ROAD_LABEL'));
  yes(candidates.labels.some((l) => l.kind === 'FACILITY_LABEL'));
  yes(candidates.labels.some((l) => l.kind === 'DIMENSION'));

  const display = buildPolishedDisplayModel({
    zoom: 1.25,
    selectedPlotNumber: '43',
    plotLabels: [
      {
        id: 'P43',
        plotNumber: '43',
        text: '43',
        point: { x: 100, y: 100 },
      },
      {
        id: 'P44',
        plotNumber: '44',
        text: '44',
        point: { x: 103, y: 100 },
      },
    ],
    roadLabels: [
      {
        id: 'R1',
        text: "ROAD 40' WIDE",
        point: { x: 300, y: 300 },
        fontSizePx: 11,
      },
    ],
    facilityLabels: [],
    dimensionLabels: [],
  });

  yes(display.summary.visibleLabelCount >= 2);
  yes(display.summary.hiddenLabelCount >= 1);
  yes(display.controls.home.visible);
  yes(display.controls.compass.visible);
  yes(display.rules.plotNumberSizePx > 10);

  const service = new MapViewerPolishService();

  check(service.plotLabelSize(0.5), 10);
  yes(service.showDimensions(1.2, false));
  yes(service.showRoadLabels(0.6));
  yes(service.display({
    zoom: 1.2,
    plotLabels: [],
    roadLabels: [],
    facilityLabels: [],
    dimensionLabels: [],
  }).controls.home.enabled);

  console.log('Zoom-based Plot Number Sizing: PASS');
  console.log('Dimension Visibility Rules: PASS');
  console.log('Road Label Visibility Rules: PASS');
  console.log('Facility Label Visibility Rules: PASS');
  console.log('Zoom-balanced Line Weights: PASS');
  console.log('Text Bounding Box Model: PASS');
  console.log('Label Collision Detection: PASS');
  console.log('Anti-clutter Label Deconfliction: PASS');
  console.log('Selected Plot Label Priority: PASS');
  console.log('Home Control State: PASS');
  console.log('Compass/North Control State: PASS');
  console.log('Smooth Wheel Zoom Policy: PASS');
  console.log('Smooth Pan Policy: PASS');
  console.log('Thin Line Visual Balance: PASS');
  console.log('Compact Road Text Policy: PASS');
  console.log('Unshaded Dimension Policy: PASS');
  console.log('Reusable Viewer Polish Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('-----------------------------------------------');
  console.log('MAP VIEWER POLISH & DISPLAY RULES TEST PASS');
})();
