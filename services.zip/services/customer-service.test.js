'use strict';

const assert = require('assert');

const {
  CustomerService,
} = require('./customer-service');

function createFakeRepository() {
  const customers = new Map();

  return {
    create(customer) {
      customers.set(customer.id, {
        ...customer,
      });

      return Object.freeze({
        ...customer,
      });
    },

    findById(id) {
      const customer = customers.get(id);

      return customer
        ? Object.freeze({
            ...customer,
          })
        : null;
    },

    findAll() {
      return [...customers.values()].map(
        (customer) =>
          Object.freeze({
            ...customer,
          })
      );
    },

    search(keyword) {
      const searchValue = String(
        keyword ?? ''
      ).trim().toLowerCase();

      return [...customers.values()]
        .filter((customer) => {
          if (searchValue === '') {
            return true;
          }

          return [
            customer.id,
            customer.name,
            customer.mobile,
            customer.address ?? '',
          ].some((value) =>
            String(value)
              .toLowerCase()
              .includes(searchValue)
          );
        })
        .map((customer) =>
          Object.freeze({
            ...customer,
          })
        );
    },

    update(id, changes) {
      const existing = customers.get(id);

      if (!existing) {
        throw new Error(
          'Customer not found.'
        );
      }

      const updated = {
        ...existing,
        ...changes,
        id: existing.id,
        uuid: existing.uuid,
        createdAt: existing.createdAt,
      };

      customers.set(id, updated);

      return Object.freeze({
        ...updated,
      });
    },

    delete(id) {
      return customers.delete(id);
    },

    mobileExists(mobile, excludeCustomerId = null) {
      return [...customers.values()].some(
        (customer) =>
          customer.mobile === mobile &&
          customer.id !== excludeCustomerId
      );
    },
  };
}

function runCustomerServiceTests() {
  console.log('Falcon Customer Service Tests');
  console.log('-----------------------------');

  assert.throws(
    () => new CustomerService(null),
    TypeError
  );

  const repository = createFakeRepository();
  const service = new CustomerService(
    repository
  );

  const invalidNameResult =
    service.createCustomer({
      name: '',
      mobile: '9876543210',
    });

  assert.strictEqual(
    invalidNameResult.success,
    false
  );

  assert.strictEqual(
    invalidNameResult.code,
    'CUSTOMER_VALIDATION_FAILED'
  );

  const invalidMobileResult =
    service.createCustomer({
      name: 'Shadab Aziz',
      mobile: '12345',
    });

  assert.strictEqual(
    invalidMobileResult.success,
    false
  );

  const createResult =
    service.createCustomer({
      name: '  Shadab Aziz  ',
      mobile: '98765-43210',
      address: ' Jaipur, Rajasthan ',
    });

  assert.strictEqual(
    createResult.success,
    true
  );

  assert.strictEqual(
    createResult.code,
    'CUSTOMER_CREATED'
  );

  assert.ok(
    /^FC-\d{6}$/.test(
      createResult.data.id
    )
  );

  assert.strictEqual(
    createResult.data.name,
    'Shadab Aziz'
  );

  assert.strictEqual(
    createResult.data.mobile,
    '9876543210'
  );

  assert.strictEqual(
    createResult.data.address,
    'Jaipur, Rajasthan'
  );

  assert.ok(
    typeof createResult.data.uuid ===
      'string'
  );

  const customerId =
    createResult.data.id;

  const duplicateResult =
    service.createCustomer({
      name: 'Duplicate Customer',
      mobile: '9876543210',
    });

  assert.strictEqual(
    duplicateResult.success,
    false
  );

  assert.strictEqual(
    duplicateResult.code,
    'CUSTOMER_MOBILE_ALREADY_EXISTS'
  );

  const getResult =
    service.getCustomer(customerId);

  assert.strictEqual(
    getResult.success,
    true
  );

  assert.strictEqual(
    getResult.code,
    'CUSTOMER_FOUND'
  );

  const missingResult =
    service.getCustomer('FC-999999');

  assert.strictEqual(
    missingResult.success,
    false
  );

  assert.strictEqual(
    missingResult.code,
    'CUSTOMER_NOT_FOUND'
  );

  const listResult =
    service.getAllCustomers();

  assert.strictEqual(
    listResult.success,
    true
  );

  assert.strictEqual(
    listResult.data.length,
    1
  );

  assert.strictEqual(
    Object.isFrozen(listResult.data),
    true
  );

  const searchResult =
    service.searchCustomers('Shadab');

  assert.strictEqual(
    searchResult.success,
    true
  );

  assert.strictEqual(
    searchResult.code,
    'CUSTOMER_SEARCH_COMPLETE'
  );

  assert.strictEqual(
    searchResult.data.length,
    1
  );

  const updateResult =
    service.updateCustomer(
      customerId,
      {
        name: ' Shadab A. Aziz ',
        mobile: '91234 56789',
        address:
          ' Sawai Madhopur, Rajasthan ',
      }
    );

  assert.strictEqual(
    updateResult.success,
    true
  );

  assert.strictEqual(
    updateResult.code,
    'CUSTOMER_UPDATED'
  );

  assert.strictEqual(
    updateResult.data.name,
    'Shadab A. Aziz'
  );

  assert.strictEqual(
    updateResult.data.mobile,
    '9123456789'
  );

  assert.strictEqual(
    updateResult.data.id,
    customerId
  );

  const invalidUpdate =
    service.updateCustomer(
      customerId,
      {
        mobile: '123',
      }
    );

  assert.strictEqual(
    invalidUpdate.success,
    false
  );

  assert.strictEqual(
    invalidUpdate.code,
    'CUSTOMER_VALIDATION_FAILED'
  );

  const deleteResult =
    service.deleteCustomer(customerId);

  assert.strictEqual(
    deleteResult.success,
    true
  );

  assert.strictEqual(
    deleteResult.code,
    'CUSTOMER_DELETED'
  );

  assert.strictEqual(
    deleteResult.data.deleted,
    true
  );

  const deleteAgainResult =
    service.deleteCustomer(customerId);

  assert.strictEqual(
    deleteAgainResult.success,
    false
  );

  assert.strictEqual(
    deleteAgainResult.code,
    'CUSTOMER_NOT_FOUND'
  );

  console.log(
    'Created Customer:',
    createResult.data.id
  );

  console.log(
    'Updated Customer:',
    updateResult.data.name
  );

  console.log(
    'Customer Deleted:',
    deleteResult.data.deleted
  );

  console.log('Assertions Passed: 30');
  console.log('-----------------------------');
  console.log('CUSTOMER SERVICE TEST PASS');
}

try {
  runCustomerServiceTests();
} catch (testError) {
  console.error(
    'CUSTOMER SERVICE TEST FAIL'
  );
  console.error(testError.message);
  process.exitCode = 1;
}
