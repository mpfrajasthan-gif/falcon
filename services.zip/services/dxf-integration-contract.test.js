'use strict';

const assert = require('assert');

const {
  DXF_CATEGORIES,
  ENTITY_TYPES,
  normalizeLayerName,
  classifyLayer,
  normalizeEntity,
  polygonArea,
  auditEntities,
  extractPlotCandidates,
  buildPlotEngineHandoff,
  DxfIntegrationContractService,
} = require('./dxf-integration-contract');

(() => {
  console.log('Falcon DXF Integration Contract & Audit Bridge Tests');
  console.log('----------------------------------------------------');

  let assertions = 0;
  const check = (actual, expected) => {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  };
  const yes = (value) => {
    assert.strictEqual(value, true);
    assertions += 1;
  };
  const no = (value) => {
    assert.strictEqual(value, false);
    assertions += 1;
  };

  check(DXF_CATEGORIES.PLOT, 'PLOT');
  check(ENTITY_TYPES.LWPOLYLINE, 'LWPOLYLINE');
  check(normalizeLayerName('  scheme   boundary '), 'SCHEME BOUNDARY');

  check(classifyLayer('PLOT'), 'PLOT');
  check(classifyLayer('ROAD'), 'ROAD');
  check(classifyLayer('FACILITY'), 'FACILITY');
  check(classifyLayer('KHASRA'), 'KHASRA');
  check(classifyLayer('SCHEME_BOUNDARY'), 'SCHEME_BOUNDARY');
  check(classifyLayer('OTHER LAND'), 'OTHER_LAND');
  check(classifyLayer('MISC-X'), 'UNKNOWN');

  check(
    classifyLayer('PLOT-POLYGON', {
      plot: ['PLOT-POLYGON'],
    }),
    'PLOT'
  );

  const square = [
    { x: 0, y: 0 },
    { x: 10, y: 0 },
    { x: 10, y: 10 },
    { x: 0, y: 10 },
  ];

  check(polygonArea(square), 100);

  const normalized = normalizeEntity({
    id: 'e-1',
    handle: 'h-1',
    type: 'lwpolyline',
    layer: ' plot ',
    closed: true,
    vertices: square,
  });

  check(normalized.id, 'E-1');
  check(normalized.handle, 'H-1');
  check(normalized.type, 'LWPOLYLINE');
  check(normalized.layer, 'PLOT');
  check(normalized.category, 'PLOT');
  yes(normalized.closed);
  check(normalized.vertices.length, 4);

  const goodEntities = [
    {
      id: 'E1',
      handle: 'H1',
      type: 'LWPOLYLINE',
      layer: 'PLOT',
      closed: true,
      vertices: square,
    },
    {
      id: 'E2',
      handle: 'H2',
      type: 'LWPOLYLINE',
      layer: 'ROAD',
      closed: false,
      vertices: [
        { x: 0, y: 0 },
        { x: 50, y: 0 },
      ],
    },
    {
      id: 'E3',
      handle: 'H3',
      type: 'LWPOLYLINE',
      layer: 'SCHEME_BOUNDARY',
      closed: true,
      vertices: [
        { x: -5, y: -5 },
        { x: 20, y: -5 },
        { x: 20, y: 20 },
        { x: -5, y: 20 },
      ],
    },
  ];

  const goodAudit = auditEntities(goodEntities);
  yes(goodAudit.summary.pass);
  check(goodAudit.summary.errorCount, 0);
  check(goodAudit.summary.warningCount, 0);
  check(goodAudit.summary.entityCount, 3);
  check(goodAudit.summary.categoryCounts.PLOT, 1);
  check(goodAudit.summary.categoryCounts.ROAD, 1);
  check(goodAudit.summary.categoryCounts.SCHEME_BOUNDARY, 1);

  const candidates = extractPlotCandidates(goodAudit);
  check(candidates.length, 1);
  check(candidates[0].sourceEntityId, 'E1');
  check(candidates[0].computedArea, 100);
  check(candidates[0].status, 'AVAILABLE');

  const handoff = buildPlotEngineHandoff({
    projectId: 'FP-000001',
    auditResult: goodAudit,
    unit: 'MM',
  });

  check(handoff.projectId, 'FP-000001');
  check(handoff.source, 'DXF');
  check(handoff.unit, 'MM');
  check(handoff.plotCount, 1);
  check(handoff.plots[0].sourceHandle, 'H1');

  const badEntities = [
    {
      id: 'BAD1',
      handle: 'HX',
      type: 'LWPOLYLINE',
      layer: 'PLOT',
      closed: false,
      vertices: square,
    },
    {
      id: 'BAD2',
      handle: 'HX',
      type: 'LWPOLYLINE',
      layer: 'MYSTERY',
      closed: true,
      vertices: square,
    },
  ];

  const badAudit = auditEntities(badEntities);
  no(badAudit.summary.pass);
  yes(badAudit.summary.errorCount >= 2);
  yes(badAudit.summary.warningCount >= 1);
  yes(badAudit.issues.some((i) => i.code === 'OPEN_PLOT_POLYGON'));
  yes(badAudit.issues.some((i) => i.code === 'DUPLICATE_HANDLE'));
  yes(badAudit.issues.some((i) => i.code === 'UNKNOWN_LAYER'));

  assert.throws(
    () =>
      buildPlotEngineHandoff({
        projectId: 'FP-000001',
        auditResult: badAudit,
      }),
    /audit must PASS/
  );
  assertions += 1;

  const service = new DxfIntegrationContractService();

  check(service.classifyLayer('PARK'), 'FACILITY');
  yes(service.audit(goodEntities).summary.pass);
  check(service.plotCandidates(goodAudit).length, 1);
  check(
    service.handoff({
      projectId: 'FP-000002',
      auditResult: goodAudit,
    }).plotCount,
    1
  );

  console.log('Layer Normalization: PASS');
  console.log('Layer Classification: PASS');
  console.log('DXF Entity Normalization: PASS');
  console.log('Plot Polygon Geometry Check: PASS');
  console.log('Duplicate Handle Detection: PASS');
  console.log('Unknown Layer Warning: PASS');
  console.log('Open Plot Polygon Block: PASS');
  console.log('DXF Audit Summary: PASS');
  console.log('Valid Plot Candidate Extraction: PASS');
  console.log('Plot Engine Handoff Contract: PASS');
  console.log('Reusable DXF Integration Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('----------------------------------------------------');
  console.log('DXF INTEGRATION CONTRACT & AUDIT BRIDGE TEST PASS');
})();
