'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const {
  buildBackupFileName,
  createFullBackup,
  loadBackupFile,
  verifyBackupForRestore,
  buildBackupWorkflowSummary,
  FullBackupOrchestratorService,
} = require('./full-backup-orchestrator');

(() => {
  console.log('Falcon Full Backup Orchestrator Tests');
  console.log('-------------------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function yes(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  function no(value) {
    assert.strictEqual(value, false);
    assertions += 1;
  }

  const tempRoot = fs.mkdtempSync(
    path.join(os.tmpdir(), 'falcon-full-backup-')
  );

  check(
    buildBackupFileName({
      backupId: 'BKP-000001',
      projectId: 'FP-000001',
      createdAt: '2026-07-29T21:30:00.000Z',
    }),
    'FP-000001_BKP-000001_20260729.fbackup'
  );

  const data = {
    projects: [
      { projectId: 'FP-000001', projectName: 'Jaipur Pride' },
    ],
    customers: [
      { customerId: 'FC-000001', customerName: 'Customer One' },
    ],
    bookings: [
      { bookingId: 'FB-000001', customerId: 'FC-000001' },
    ],
    payments: [
      { paymentId: 'PAY-000001', bookingId: 'FB-000001', amount: 100000 },
    ],
    receipts: [
      { receiptNumber: 'RCP-000001', paymentId: 'PAY-000001' },
    ],
  };

  const result = createFullBackup({
    backupId: 'BKP-000001',
    password: 'FalconBackup@2026',
    directoryPath: tempRoot,
    appVersion: '1.0.0',
    actorId: 'FU-000001',
    sourceDevice: 'OFFICE-PC',
    projectId: 'FP-000001',
    sections: ['projects', 'customers', 'bookings', 'payments', 'receipts'],
    data,
    createdAt: '2026-07-29T21:30:00.000Z',
  });

  yes(result.completed);
  check(result.backupId, 'BKP-000001');
  yes(fs.existsSync(result.filePath));
  yes(result.bytes > 0);
  check(result.fileSha256.length, 64);
  yes(result.verification.fileValid);
  yes(result.verification.archiveValid);
  yes(result.verification.manifestValid);

  const loadedArchive = loadBackupFile(result.filePath);
  check(loadedArchive.header.backupId, 'BKP-000001');

  const restoreReady = verifyBackupForRestore({
    filePath: result.filePath,
    password: 'FalconBackup@2026',
    currentAppVersion: '1.0.0',
  });

  yes(restoreReady.valid);
  check(restoreReady.stage, 'READY');
  check(restoreReady.backupId, 'BKP-000001');
  yes(restoreReady.manifestCheck.valid);
  yes(restoreReady.compatibility.compatible);
  yes(restoreReady.restorePreview.integrityValid);
  check(restoreReady.restorePreview.sections.length, 5);
  check(restoreReady.data.customers.length, 1);

  const wrongPassword = verifyBackupForRestore({
    filePath: result.filePath,
    password: 'WrongPassword123',
  });

  no(wrongPassword.valid);
  check(wrongPassword.stage, 'DECRYPT');

  const missing = verifyBackupForRestore({
    filePath: path.join(tempRoot, 'missing.fbackup'),
    password: 'FalconBackup@2026',
  });

  no(missing.valid);
  check(missing.stage, 'FILE');

  const summary = buildBackupWorkflowSummary(result);
  yes(summary.completed);
  yes(summary.encrypted);
  yes(summary.fileVerified);
  yes(summary.archiveVerified);
  yes(summary.manifestVerified);

  const service = new FullBackupOrchestratorService();

  const serviceResult = service.backup({
    backupId: 'BKP-000002',
    password: 'AnotherStrongPass',
    directoryPath: tempRoot,
    fileName: 'manual-name.fbackup',
    appVersion: '1.0.0',
    actorId: 'FU-000001',
    sections: ['projects', 'customers'],
    data,
    createdAt: '2026-07-29T22:00:00.000Z',
  });

  yes(serviceResult.completed);
  check(serviceResult.fileName, 'manual-name.fbackup');

  const serviceRestore = service.verifyRestore({
    filePath: serviceResult.filePath,
    password: 'AnotherStrongPass',
  });

  yes(serviceRestore.valid);
  check(serviceRestore.stage, 'READY');

  const serviceSummary = service.summary(serviceResult);
  yes(serviceSummary.completed);

  console.log('Backup File Naming: PASS');
  console.log('M06.1 Manifest Integration: PASS');
  console.log('M06.2 Encryption Integration: PASS');
  console.log('M06.3 Safe Writer Integration: PASS');
  console.log('Full Backup Workflow: PASS');
  console.log('Post-write Verification: PASS');
  console.log('Backup File Load: PASS');
  console.log('Restore Decryption Check: PASS');
  console.log('Restore Manifest Integrity Check: PASS');
  console.log('Restore Compatibility Check: PASS');
  console.log('Restore Preview Integration: PASS');
  console.log('Wrong Password Restore Block: PASS');
  console.log('Missing Backup Restore Block: PASS');
  console.log('Reusable Backup Orchestrator: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('-------------------------------------');
  console.log('FULL BACKUP ORCHESTRATOR TEST PASS');
})();
