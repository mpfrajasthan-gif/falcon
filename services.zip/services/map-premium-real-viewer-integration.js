'use strict';

function text(v){ return v == null ? '' : String(v).trim(); }
function upper(v){ return text(v).toUpperCase(); }
function clamp(v,min,max){ return Math.min(max,Math.max(min,v)); }

function normalizeReadableAngle(angle){
  let a = Number(angle);
  while(a <= -Math.PI) a += Math.PI * 2;
  while(a > Math.PI) a -= Math.PI * 2;
  if(a > Math.PI/2) a -= Math.PI;
  if(a < -Math.PI/2) a += Math.PI;
  return a;
}

function normalizeMapModel(raw){
  if(!raw || !raw.layers || !Array.isArray(raw.layers.plots)){
    throw new Error('Invalid map-ready model.');
  }

  const plots = raw.layers.plots.map((p,i)=>{
    const plotNumber = text(p.plotNumber ?? p.plotNo);
    if(!plotNumber) throw new Error(`Plot ${i+1} missing plot number.`);
    if(!Array.isArray(p.vertices) || p.vertices.length < 3){
      throw new Error(`Plot ${plotNumber} has invalid geometry.`);
    }
    return Object.freeze({
      plotNumber,
      status: upper(p.status || 'AVAILABLE'),
      landUse: upper(p.landUse || p.category || 'RESIDENTIAL').replace(/\s+/g,'_'),
      vertices: Object.freeze(p.vertices.map(v=>Object.freeze({x:Number(v.x),y:Number(v.y)}))),
      centroid: p.centroid ? Object.freeze({x:Number(p.centroid.x),y:Number(p.centroid.y)}) : null,
      areaSqYd: p.areaSqYd ?? null,
      areaSqM: p.areaSqM ?? null,
      sideLengthsFt: Object.freeze([...(p.sideLengthsFt || [])].map(Number)),
      khasraNo: text(p.khasraNo || p.khasra || ''),
      roadFacing: text(p.roadFacing || ''),
      rateSqYd: p.rateSqYd ?? null,
      totalPrice: p.totalPrice ?? null,
    });
  });

  return Object.freeze({
    projectId: text(raw.projectId),
    projectName: text(raw.projectName || raw.name),
    rendererProfile: text(raw.rendererProfile || 'FALCON_PREMIUM_2D'),
    geometryPolicy: Object.freeze({
      originalGeometryLocked: true,
      straightenGeometry: false,
      inventVertices: false,
      deleteVertices: false,
      roadSurfaceRule: 'BACKGROUND_GAPS',
    }),
    layers: Object.freeze({
      plots: Object.freeze(plots),
      roads: Object.freeze([...(raw.layers.roads || [])]),
      specialAreas: Object.freeze([...(raw.layers.specialAreas || [])]),
    }),
  });
}

function buildPlotDetail(plot){
  if(!plot) return null;
  return Object.freeze({
    plotNumber: plot.plotNumber,
    status: plot.status,
    landUse: plot.landUse,
    areaSqYd: plot.areaSqYd,
    areaSqM: plot.areaSqM,
    dimensionsFt: Object.freeze([...plot.sideLengthsFt]),
    khasraNo: plot.khasraNo,
    roadFacing: plot.roadFacing,
    rateSqYd: plot.rateSqYd,
    totalPrice: plot.totalPrice,
  });
}

function mapStats(model){
  return Object.freeze({
    plotCount: model.layers.plots.length,
    roadCount: model.layers.roads.length,
    specialAreaCount: model.layers.specialAreas.length,
    available: model.layers.plots.filter(p=>p.status==='AVAILABLE').length,
    booked: model.layers.plots.filter(p=>p.status==='BOOKED').length,
    sold: model.layers.plots.filter(p=>p.status==='SOLD').length,
    hold: model.layers.plots.filter(p=>p.status==='HOLD').length,
  });
}

function premiumVisualContract(){
  return Object.freeze({
    background: '#0c1116',
    residential: '#eadfbd',
    commercial: '#8a5a44',
    facility: '#9fc2d7',
    otherLand: '#78834d',
    road: '#30363d',
    availableAccent: '#69b34c',
    bookedAccent: '#f39c12',
    soldAccent: '#c0392b',
    holdAccent: '#3498db',
    selectionFill: 'rgba(41,128,255,0.30)',
    selectionStroke: 'rgba(102,178,255,0.98)',
    selectionDash: Object.freeze([3,3]),
    selectedZoomFactor: 1.25,
    plotNumberTargetPx: 15,
    roadLabelPx: 11,
    dimensionPx: 10,
    keepDimensionTextReadable: true,
    thinPlotLines: true,
    smoothPanZoom: true,
    antiClutter: true,
    defaultAreaUnit: 'SQ_YARD',
  });
}

class PremiumRealViewerIntegrationService {
  normalize(raw){ return normalizeMapModel(raw); }
  details(plot){ return buildPlotDetail(plot); }
  stats(model){ return mapStats(model); }
  readableAngle(angle){ return normalizeReadableAngle(angle); }
  contract(){ return premiumVisualContract(); }
}

module.exports = {
  text, upper, clamp,
  normalizeReadableAngle,
  normalizeMapModel,
  buildPlotDetail,
  mapStats,
  premiumVisualContract,
  PremiumRealViewerIntegrationService,
};
