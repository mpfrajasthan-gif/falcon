'use strict';

const {
  createFullBackup,
  verifyBackupForRestore,
} = require('./full-backup-orchestrator');

const {
  guardedRestore,
} = require('./guarded-restore-engine');

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function createVerifiedBackupAndRestore({
  backup,
  restore,
} = {}) {
  if (!backup || typeof backup !== 'object') {
    throw new TypeError('backup options are required.');
  }

  if (!restore || typeof restore !== 'object') {
    throw new TypeError('restore options are required.');
  }

  const backupResult = createFullBackup(backup);

  const verification = verifyBackupForRestore({
    filePath: backupResult.filePath,
    password: backup.password,
    supportedSchemaVersion:
      restore.supportedSchemaVersion === undefined
        ? 1
        : restore.supportedSchemaVersion,
    currentAppVersion:
      restore.currentAppVersion === undefined
        ? backup.appVersion || ''
        : restore.currentAppVersion,
  });

  if (!verification.valid || verification.stage !== 'READY') {
    return Object.freeze({
      completed: false,
      stage: 'VERIFY_RESTORE',
      backupResult,
      verification,
      restoreResult: null,
    });
  }

  const restoreResult = guardedRestore({
    liveDataDir: restore.liveDataDir,
    safetyRootDir: restore.safetyRootDir,
    stagingRootDir: restore.stagingRootDir,
    restoreData: verification.data,
    restoreId: restore.restoreId,
    snapshotId: restore.snapshotId,
    simulateFailureAfterApply: Boolean(restore.simulateFailureAfterApply),
  });

  return Object.freeze({
    completed: Boolean(restoreResult.completed),
    stage: restoreResult.completed ? 'COMPLETE' : 'GUARDED_RESTORE',
    backupResult,
    verification,
    restoreResult,
  });
}

function restoreVerifiedBackup({
  filePath,
  password,
  liveDataDir,
  safetyRootDir,
  stagingRootDir,
  restoreId,
  snapshotId,
  supportedSchemaVersion = 1,
  currentAppVersion = '',
  simulateFailureAfterApply = false,
} = {}) {
  if (!text(filePath)) throw new Error('filePath is required.');

  const verification = verifyBackupForRestore({
    filePath,
    password,
    supportedSchemaVersion,
    currentAppVersion,
  });

  if (!verification.valid || verification.stage !== 'READY') {
    return Object.freeze({
      completed: false,
      stage: 'VERIFY_RESTORE',
      verification,
      restoreResult: null,
    });
  }

  const restoreResult = guardedRestore({
    liveDataDir,
    safetyRootDir,
    stagingRootDir,
    restoreData: verification.data,
    restoreId,
    snapshotId,
    simulateFailureAfterApply,
  });

  return Object.freeze({
    completed: Boolean(restoreResult.completed),
    stage: restoreResult.completed ? 'COMPLETE' : 'GUARDED_RESTORE',
    verification,
    restoreResult,
  });
}

function buildRestoreCompletionSummary(result) {
  if (!result || typeof result !== 'object') {
    throw new TypeError('result is required.');
  }

  const backupResult = result.backupResult || null;
  const verification = result.verification || {};
  const restoreResult = result.restoreResult || {};

  return Object.freeze({
    completed: Boolean(result.completed),
    stage: result.stage || '',
    backupId:
      (backupResult && backupResult.backupId) ||
      verification.backupId ||
      '',
    backupFile:
      (backupResult && backupResult.fileName) ||
      '',
    backupVerified:
      Boolean(
        verification.valid &&
        verification.stage === 'READY' &&
        verification.manifestCheck &&
        verification.manifestCheck.valid
      ),
    safetySnapshotCreated:
      Boolean(restoreResult.snapshot && restoreResult.snapshot.snapshotDir),
    stagingVerified:
      Boolean(
        restoreResult.stagingVerification &&
        restoreResult.stagingVerification.valid
      ),
    restoreApplied:
      Boolean(
        restoreResult.applyResult &&
        restoreResult.applyResult.applied
      ),
    rolledBack: Boolean(restoreResult.rolledBack),
  });
}

class FinalRestoreOrchestratorService {
  backupAndRestore(input) {
    return createVerifiedBackupAndRestore(input);
  }

  restore(input) {
    return restoreVerifiedBackup(input);
  }

  summary(result) {
    return buildRestoreCompletionSummary(result);
  }
}

module.exports = {
  text,
  createVerifiedBackupAndRestore,
  restoreVerifiedBackup,
  buildRestoreCompletionSummary,
  FinalRestoreOrchestratorService,
};
