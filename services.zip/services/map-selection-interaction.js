'use strict';

const {
  hitTestPlot,
  buildSelectionViewport,
  buildViewport,
  computeBoundsFromPlots,
} = require('./map-renderer-core');

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function cloneState(state) {
  return Object.freeze({
    selectedPlotNumber: text(state.selectedPlotNumber),
    source: text(state.source || 'NONE'),
    selectedAt: text(state.selectedAt),
    revision: Number(state.revision || 0),
  });
}

function createSelectionState() {
  return cloneState({
    selectedPlotNumber: '',
    source: 'NONE',
    selectedAt: '',
    revision: 0,
  });
}

function selectPlot({
  state,
  plotNumber,
  source = 'CLICK',
  now = new Date().toISOString(),
} = {}) {
  const current = state || createSelectionState();
  const plot = text(plotNumber);

  if (!plot) {
    throw new Error('plotNumber is required.');
  }

  if (current.selectedPlotNumber === plot) {
    return cloneState(current);
  }

  return cloneState({
    selectedPlotNumber: plot,
    source,
    selectedAt: now,
    revision: current.revision + 1,
  });
}

function clearSelection({
  state,
  source = 'OUTSIDE_CLICK',
} = {}) {
  const current = state || createSelectionState();

  if (!current.selectedPlotNumber) {
    return cloneState(current);
  }

  return cloneState({
    selectedPlotNumber: '',
    source,
    selectedAt: '',
    revision: current.revision + 1,
  });
}

function resolvePlotByNumber(plots = [], plotNumber) {
  const target = text(plotNumber).toLowerCase();

  return (
    plots.find((plot) =>
      text(plot.plotNumber || plot.plotNo).toLowerCase() === target
    ) || null
  );
}

function searchPlots(plots = [], query = '') {
  const q = text(query).toLowerCase();
  if (!q) return Object.freeze([]);

  const matches = plots
    .filter((plot) => {
      const plotNumber = text(plot.plotNumber || plot.plotNo).toLowerCase();
      const status = text(plot.status).toLowerCase();
      const landUse = text(plot.landUse || plot.category).toLowerCase();
      return (
        plotNumber.includes(q) ||
        status.includes(q) ||
        landUse.includes(q)
      );
    })
    .sort((a, b) => {
      const an = text(a.plotNumber || a.plotNo);
      const bn = text(b.plotNumber || b.plotNo);

      const aExact = an.toLowerCase() === q ? 1 : 0;
      const bExact = bn.toLowerCase() === q ? 1 : 0;

      if (aExact !== bExact) return bExact - aExact;

      const ai = Number(an);
      const bi = Number(bn);
      if (Number.isFinite(ai) && Number.isFinite(bi)) return ai - bi;

      return an.localeCompare(bn);
    });

  return Object.freeze(matches);
}

function selectBySearch({
  state,
  plots = [],
  query,
  now,
} = {}) {
  const matches = searchPlots(plots, query);

  if (!matches.length) {
    return Object.freeze({
      found: false,
      matchCount: 0,
      state: cloneState(state || createSelectionState()),
      plot: null,
    });
  }

  const first = matches[0];
  const plotNumber = text(first.plotNumber || first.plotNo);

  return Object.freeze({
    found: true,
    matchCount: matches.length,
    state: selectPlot({
      state,
      plotNumber,
      source: 'SEARCH',
      now,
    }),
    plot: first,
  });
}

function handleMapClick({
  state,
  screenPoint,
  viewport,
  plots = [],
  now,
} = {}) {
  const hit = hitTestPlot({
    screenPoint,
    viewport,
    plots,
  });

  if (!hit) {
    return Object.freeze({
      action: 'CLEAR',
      state: clearSelection({
        state,
        source: 'OUTSIDE_CLICK',
      }),
      hit: null,
    });
  }

  return Object.freeze({
    action: 'SELECT',
    state: selectPlot({
      state,
      plotNumber: hit.plotNumber,
      source: 'CLICK',
      now,
    }),
    hit,
  });
}

function buildAutoFocusViewport({
  frame,
  state,
  zoomPercent = 25,
} = {}) {
  const selectedPlotNumber = text(state && state.selectedPlotNumber);

  if (!selectedPlotNumber) {
    return frame.viewport;
  }

  return buildSelectionViewport({
    frame,
    plotNumber: selectedPlotNumber,
    zoomPercent,
  });
}

function buildHomeViewport({
  plots,
  viewportWidth,
  viewportHeight,
  padding = 40,
} = {}) {
  const bounds = computeBoundsFromPlots(plots);

  return buildViewport({
    bounds,
    viewportWidth,
    viewportHeight,
    padding,
  });
}

function preserveSelectionDuringViewportChange({
  state,
  viewport,
} = {}) {
  return Object.freeze({
    state: cloneState(state || createSelectionState()),
    viewport: Object.freeze({ ...viewport }),
  });
}

function buildPlotDetailsHandoff({
  state,
  plots = [],
} = {}) {
  const selectedPlotNumber = text(state && state.selectedPlotNumber);
  if (!selectedPlotNumber) return null;

  const plot = resolvePlotByNumber(plots, selectedPlotNumber);
  if (!plot) return null;

  return Object.freeze({
    plotNumber: selectedPlotNumber,
    status: text(plot.status || 'AVAILABLE').toUpperCase(),
    areaSqYd: plot.areaSqYd ?? null,
    areaSqM: plot.areaSqM ?? null,
    sideLengthsFt: Object.freeze([...(plot.sideLengthsFt || [])]),
    centroid: plot.centroid || null,
    source: text(state.source),
    revision: Number(state.revision || 0),
  });
}

function buildInteractionSnapshot({
  state,
  frame,
  plots = [],
} = {}) {
  return Object.freeze({
    selection: cloneState(state || createSelectionState()),
    selectedPlot: buildPlotDetailsHandoff({
      state,
      plots,
    }),
    viewport: Object.freeze({ ...frame.viewport }),
    visualContract: Object.freeze({
      selectionFill: 'BLUE_GLASS_TRANSPARENT',
      selectionBoundary: 'THIN_DOTTED_OFFSET',
      autoZoomRangePercent: Object.freeze([20, 30]),
      clickOutsideClearsSelection: true,
      searchCentersSelection: true,
      selectionPersistsDuringPanZoom: true,
    }),
  });
}

class MapSelectionInteractionService {
  createState() {
    return createSelectionState();
  }

  select(input) {
    return selectPlot(input);
  }

  clear(input) {
    return clearSelection(input);
  }

  search(plots, query) {
    return searchPlots(plots, query);
  }

  selectBySearch(input) {
    return selectBySearch(input);
  }

  click(input) {
    return handleMapClick(input);
  }

  autoFocus(input) {
    return buildAutoFocusViewport(input);
  }

  home(input) {
    return buildHomeViewport(input);
  }

  preserve(input) {
    return preserveSelectionDuringViewportChange(input);
  }

  details(input) {
    return buildPlotDetailsHandoff(input);
  }

  snapshot(input) {
    return buildInteractionSnapshot(input);
  }
}

module.exports = {
  text,
  cloneState,
  createSelectionState,
  selectPlot,
  clearSelection,
  resolvePlotByNumber,
  searchPlots,
  selectBySearch,
  handleMapClick,
  buildAutoFocusViewport,
  buildHomeViewport,
  preserveSelectionDuringViewportChange,
  buildPlotDetailsHandoff,
  buildInteractionSnapshot,
  MapSelectionInteractionService,
};
