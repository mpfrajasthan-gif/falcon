'use strict';

const {
  createIdentity,
} = require('../core/identity/identity-engine');

const {
  normalizeText,
  roundCurrency,
  toIsoTimestamp,
} = require('../core/utilities/core-utils');

const {
  success,
  failure,
} = require('../core/errors/result');

const {
  normalizeError,
} = require('../core/errors/falcon-error');

const {
  info,
  error: logError,
} = require('../core/logging/logger');

const VALID_STATUSES = Object.freeze([
  'AVAILABLE',
  'HOLD',
  'BOOKED',
  'SOLD',
]);

function hasOwn(value, property) {
  return Object.prototype.hasOwnProperty.call(value, property);
}

function normalizeRequiredText(value, fieldName) {
  const normalized = normalizeText(value);

  if (normalized === '') {
    throw new TypeError(`${fieldName} must be a non-empty string.`);
  }

  return normalized;
}

function normalizeNumber(value, fieldName, minimum = 0) {
  const numeric = Number(value);

  if (!Number.isFinite(numeric) || numeric < minimum) {
    throw new TypeError(
      `${fieldName} must be a valid number greater than or equal to ${minimum}.`
    );
  }

  return numeric;
}

function normalizeStatus(value) {
  const status = normalizeRequiredText(value, 'Plot status').toUpperCase();

  if (!VALID_STATUSES.includes(status)) {
    throw new TypeError(
      `Plot status must be one of: ${VALID_STATUSES.join(', ')}.`
    );
  }

  return status;
}

class PlotService {
  constructor(plotRepository, options = {}) {
    if (
      !plotRepository ||
      typeof plotRepository.create !== 'function' ||
      typeof plotRepository.findById !== 'function' ||
      typeof plotRepository.findAll !== 'function' ||
      typeof plotRepository.findByProjectId !== 'function' ||
      typeof plotRepository.update !== 'function' ||
      typeof plotRepository.delete !== 'function' ||
      typeof plotRepository.plotNumberExists !== 'function'
    ) {
      throw new TypeError('A valid PlotRepository is required.');
    }

    this.plotRepository = plotRepository;
    this.identityFactory = options.identityFactory ?? createIdentity;
    this.clock = options.clock ?? (() => new Date());
    this.infoLogger = options.infoLogger ?? info;
    this.errorLogger = options.errorLogger ?? logError;

    if (typeof this.identityFactory !== 'function') {
      throw new TypeError('Plot identity factory must be a function.');
    }

    if (typeof this.clock !== 'function') {
      throw new TypeError('Plot clock must be a function.');
    }

    if (
      typeof this.infoLogger !== 'function' ||
      typeof this.errorLogger !== 'function'
    ) {
      throw new TypeError('Plot loggers must be functions.');
    }
  }

  createPlot(input) {
    try {
      if (!input || typeof input !== 'object') {
        throw new TypeError('Plot input must be an object.');
      }

      const projectId = normalizeRequiredText(
        input.projectId,
        'Plot project ID'
      );
      const plotNumber = normalizeRequiredText(
        input.plotNumber,
        'Plot number'
      );
      const category = normalizeRequiredText(
        input.category,
        'Plot category'
      );
      const areaSqYd = normalizeNumber(
        input.areaSqYd,
        'Plot area',
        0.000001
      );
      const status = normalizeStatus(input.status ?? 'AVAILABLE');
      const ratePerSqYd = roundCurrency(
        normalizeNumber(input.ratePerSqYd ?? 0, 'Plot rate')
      );
      const calculatedTotal = roundCurrency(areaSqYd * ratePerSqYd);
      const totalPrice = hasOwn(input, 'totalPrice')
        ? roundCurrency(normalizeNumber(input.totalPrice, 'Plot total price'))
        : calculatedTotal;

      if (
        this.plotRepository.plotNumberExists(
          projectId,
          plotNumber
        )
      ) {
        return failure(
          'PLOT_NUMBER_ALREADY_EXISTS',
          'This plot number already exists in the selected project.',
          { projectId, plotNumber }
        );
      }

      const identity = this.identityFactory('plot');
      const timestamp = toIsoTimestamp(this.clock());

      const createdPlot = this.plotRepository.create({
        id: identity.id,
        uuid: identity.uuid,
        projectId,
        plotNumber,
        category,
        areaSqYd,
        status,
        ratePerSqYd,
        totalPrice,
        geometryJson: input.geometryJson ?? null,
        createdAt: timestamp,
        updatedAt: timestamp,
      });

      this.infoLogger('Falcon plot created.', {
        plotId: createdPlot.id,
        projectId: createdPlot.projectId,
        plotNumber: createdPlot.plotNumber,
      });

      return success(
        'PLOT_CREATED',
        'Falcon plot created successfully.',
        createdPlot
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'PLOT_CREATE_FAILED',
        'Falcon plot could not be created.'
      );
    }
  }

  getPlot(plotId) {
    try {
      const plot = this.plotRepository.findById(plotId);

      if (!plot) {
        return failure(
          'PLOT_NOT_FOUND',
          'Falcon plot was not found.',
          { plotId }
        );
      }

      return success(
        'PLOT_FOUND',
        'Falcon plot loaded successfully.',
        plot
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'PLOT_LOAD_FAILED',
        'Falcon plot could not be loaded.'
      );
    }
  }

  getAllPlots() {
    try {
      const plots = this.plotRepository.findAll();
      const items = plots.map((plot) => Object.freeze({ ...plot }));

      Object.defineProperties(items, {
        total: { value: items.length, enumerable: true },
        items: { value: items, enumerable: true },
        plots: { value: items, enumerable: true },
      });

      Object.freeze(items);

      return success(
        'PLOTS_LOADED',
        'Falcon plots loaded successfully.',
        items
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'PLOT_LIST_FAILED',
        'Falcon plots could not be loaded.'
      );
    }
  }

  getPlotsByProject(projectId) {
    try {
      const normalizedProjectId = normalizeRequiredText(
        projectId,
        'Plot project ID'
      );
      const plots = this.plotRepository.findByProjectId(
        normalizedProjectId
      );

      return success(
        'PROJECT_PLOTS_LOADED',
        'Project plots loaded successfully.',
        Object.freeze(plots.map((plot) => Object.freeze({ ...plot })))
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'PROJECT_PLOT_LIST_FAILED',
        'Project plots could not be loaded.'
      );
    }
  }

  updatePlot(plotId, changes) {
    try {
      if (!changes || typeof changes !== 'object') {
        throw new TypeError('Plot changes must be an object.');
      }

      const existing = this.plotRepository.findById(plotId);

      if (!existing) {
        return failure(
          'PLOT_NOT_FOUND',
          'Falcon plot was not found.',
          { plotId }
        );
      }

      const updateData = {
        updatedAt: toIsoTimestamp(this.clock()),
      };

      if (hasOwn(changes, 'plotNumber')) {
        const plotNumber = normalizeRequiredText(
          changes.plotNumber,
          'Plot number'
        );

        if (
          this.plotRepository.plotNumberExists(
            existing.projectId,
            plotNumber,
            existing.id
          )
        ) {
          return failure(
            'PLOT_NUMBER_ALREADY_EXISTS',
            'This plot number already exists in the selected project.',
            {
              projectId: existing.projectId,
              plotNumber,
              plotId: existing.id,
            }
          );
        }

        updateData.plotNumber = plotNumber;
      }

      if (hasOwn(changes, 'category')) {
        updateData.category = normalizeRequiredText(
          changes.category,
          'Plot category'
        );
      }

      if (hasOwn(changes, 'areaSqYd')) {
        updateData.areaSqYd = normalizeNumber(
          changes.areaSqYd,
          'Plot area',
          0.000001
        );
      }

      if (hasOwn(changes, 'status')) {
        updateData.status = normalizeStatus(changes.status);
      }

      if (hasOwn(changes, 'ratePerSqYd')) {
        updateData.ratePerSqYd = roundCurrency(
          normalizeNumber(changes.ratePerSqYd, 'Plot rate')
        );
      }

      if (hasOwn(changes, 'totalPrice')) {
        updateData.totalPrice = roundCurrency(
          normalizeNumber(changes.totalPrice, 'Plot total price')
        );
      } else if (
        hasOwn(changes, 'areaSqYd') ||
        hasOwn(changes, 'ratePerSqYd')
      ) {
        updateData.totalPrice = roundCurrency(
          (updateData.areaSqYd ?? existing.areaSqYd) *
          (updateData.ratePerSqYd ?? existing.ratePerSqYd)
        );
      }

      if (hasOwn(changes, 'geometryJson')) {
        updateData.geometryJson = changes.geometryJson ?? null;
      }

      const updatedPlot = this.plotRepository.update(
        plotId,
        updateData
      );

      this.infoLogger('Falcon plot updated.', {
        plotId: updatedPlot.id,
        projectId: updatedPlot.projectId,
      });

      return success(
        'PLOT_UPDATED',
        'Falcon plot updated successfully.',
        updatedPlot
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'PLOT_UPDATE_FAILED',
        'Falcon plot could not be updated.'
      );
    }
  }

  deletePlot(plotId) {
    try {
      const existing = this.plotRepository.findById(plotId);

      if (!existing) {
        return failure(
          'PLOT_NOT_FOUND',
          'Falcon plot was not found.',
          { plotId }
        );
      }

      if (['BOOKED', 'SOLD'].includes(existing.status)) {
        return failure(
          'PLOT_DELETE_BLOCKED',
          'Booked or sold plots cannot be deleted.',
          { plotId, status: existing.status }
        );
      }

      const deleted = this.plotRepository.delete(plotId);

      if (!deleted) {
        return failure(
          'PLOT_DELETE_FAILED',
          'Falcon plot could not be deleted.',
          { plotId }
        );
      }

      this.infoLogger('Falcon plot deleted.', {
        plotId,
        projectId: existing.projectId,
      });

      return success(
        'PLOT_DELETED',
        'Falcon plot deleted successfully.',
        Object.freeze({ plotId, deleted: true })
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'PLOT_DELETE_FAILED',
        'Falcon plot could not be deleted.'
      );
    }
  }

  handleError(serviceError, fallbackCode, fallbackMessage) {
    const normalizedError = normalizeError(
      serviceError,
      fallbackCode,
      fallbackMessage
    );

    this.errorLogger(fallbackMessage, {
      code: normalizedError.code,
      message: normalizedError.message,
      details: normalizedError.details,
    });

    return failure(
      normalizedError.code,
      normalizedError.message,
      normalizedError.toJSON()
    );
  }
}

module.exports = {
  PlotService,
  VALID_STATUSES,
};
