'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const { buildProjectImportPackage } = require('./dxf-project-import-integration');
const {
  resolveProjectFile,
  stageProjectImport,
  applyStagedImport,
  verifyImportedProjectFiles,
  safeWriteProjectImport,
  DxfSafeProjectImportWriterService,
} = require('./dxf-safe-project-import-writer');

(() => {
  console.log('Falcon DXF Safe Project Import Writer Tests');
  console.log('-------------------------------------------');

  let assertions = 0;
  const check = (a, e) => { assert.deepStrictEqual(a, e); assertions += 1; };
  const yes = (v) => { assert.strictEqual(v, true); assertions += 1; };
  const no = (v) => { assert.strictEqual(v, false); assertions += 1; };

  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'falcon-dxf5-'));
  const projectFolder = path.join(root, 'FP-000001');

  check(
    resolveProjectFile(projectFolder, 'dxf/current-import.json'),
    path.join(projectFolder, 'dxf', 'current-import.json')
  );

  const project = {
    projectId: 'FP-000001',
    projectName: 'Jaipur Pride',
    projectFolder,
  };

  const draft = {
    schema_version: '1.0-draft',
    project: {
      name: 'Jaipur Pride',
      source_crs: 'EPSG:32643',
      source_sha256: 'source-file-hash-001',
      approval_status: 'APPROVED',
      approved_at: '2026-07-30T10:00:00.000Z',
    },
    layers: {
      plots: [
        {
          plot_no: '43',
          layer: 'POLYGON',
          vertices: [[0,0],[10,0],[10,20],[0,20]],
          centroid: [5,10],
          area_sq_m: 200,
          area_sq_yd: 239.1980092,
          side_lengths_ft: [32.8084,65.6168,32.8084,65.6168],
          source_index: 1,
          contained_labels: 1,
        },
        {
          plot_no: '44',
          layer: 'POLYGON',
          vertices: [[10,0],[20,0],[20,20],[10,20]],
          centroid: [15,10],
          area_sq_m: 200,
          area_sq_yd: 239.1980092,
          side_lengths_ft: [32.8084,65.6168,32.8084,65.6168],
          source_index: 2,
          contained_labels: 1,
        },
      ],
      roads: [{
        id: 'ROAD-1',
        name: "ROAD 40' WIDE",
        width_ft: 40,
        geometry_type: 'LABEL_POINT',
        label_point: [10,-5],
        vertices: [[10,-5]],
      }],
      special_areas: [],
    },
    import_profile: {
      renderer: 'FALCON_V10_POLISHED_2D',
      road_surface_rule: 'BACKGROUND_GAPS',
      road_labels: 'ROAD_TEXT_POINTS',
      original_geometry_locked: true,
    },
    audit: {
      metrics: {
        plot_labels: 2,
        plot_faces: 2,
        unresolved_labels: 0,
        road_layers: 1,
        khasra_layers: 0,
        special_layers: 0,
        selected_scope: 'SDFRG',
      },
      warnings: [],
    },
  };

  const pkg = buildProjectImportPackage({ project, draft });

  const staged = stageProjectImport(pkg);
  check(staged.projectId, 'FP-000001');
  check(staged.staged.length, 5);
  yes(staged.staged.every((item) => fs.existsSync(item.tempPath)));

  const applied = applyStagedImport({ staged });
  yes(applied.applied);
  no(applied.rolledBack);
  check(applied.files.length, 5);

  yes(fs.existsSync(path.join(projectFolder, 'dxf', 'current-import.json')));
  yes(fs.existsSync(path.join(projectFolder, 'dxf', 'diagnostics.json')));
  yes(fs.existsSync(path.join(projectFolder, 'dxf', 'source-metadata.json')));
  yes(fs.existsSync(path.join(projectFolder, 'maps', 'plots.json')));
  yes(fs.existsSync(path.join(projectFolder, 'maps', 'map-ready.json')));

  const verification = verifyImportedProjectFiles(pkg);
  yes(verification.valid);
  check(verification.checks.length, 5);
  yes(verification.checks.every((item) => item.valid));

  const oldImportPath = path.join(projectFolder, 'dxf', 'current-import.json');
  fs.writeFileSync(oldImportPath, JSON.stringify({ old: true }, null, 2), 'utf8');

  const stagedFailure = stageProjectImport(pkg);
  const failed = applyStagedImport({
    staged: stagedFailure,
    simulateFailureAfter: 2,
  });

  no(failed.applied);
  yes(failed.rolledBack);

  const restoredOld = JSON.parse(fs.readFileSync(oldImportPath, 'utf8'));
  check(restoredOld.old, true);

  const cleanWrite = safeWriteProjectImport({ pkg });
  yes(cleanWrite.applied);
  yes(cleanWrite.verification.valid);

  const finalPlots = JSON.parse(
    fs.readFileSync(path.join(projectFolder, 'maps', 'plots.json'), 'utf8')
  );
  check(finalPlots.length, 2);
  check(finalPlots[0].plotNumber, '43');

  const finalMap = JSON.parse(
    fs.readFileSync(path.join(projectFolder, 'maps', 'map-ready.json'), 'utf8')
  );

  check(finalMap.visualPolicy.selectionStyle, 'BLUE_GLASS_TRANSPARENT');
  check(finalMap.visualPolicy.selectionBoundary, 'THIN_DOTTED_OFFSET');
  check(finalMap.visualPolicy.defaultAreaUnit, 'SQ_YARD');
  yes(finalMap.geometryPolicy.originalGeometryLocked);
  check(finalMap.geometryPolicy.straightenGeometry, false);

  const service = new DxfSafeProjectImportWriterService();
  yes(service.verify(pkg).valid);

  console.log('Cross-platform Project Path Resolution: PASS');
  console.log('Project Import Staging: PASS');
  console.log('Temporary JSON Verification: PASS');
  console.log('Atomic Project File Apply: PASS');
  console.log('Project Folder Auto-create: PASS');
  console.log('Import Metadata Write: PASS');
  console.log('Plot Core Data Write: PASS');
  console.log('Map-ready Data Write: PASS');
  console.log('Diagnostics Write: PASS');
  console.log('Source Metadata Write: PASS');
  console.log('Rollback Snapshot: PASS');
  console.log('Failure Rollback Protection: PASS');
  console.log('Final Project File Verification: PASS');
  console.log('Spacer-style Visual Policy Persistence: PASS');
  console.log('Original Geometry Lock Persistence: PASS');
  console.log('Reusable Safe Import Writer: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('-------------------------------------------');
  console.log('DXF SAFE PROJECT IMPORT WRITER TEST PASS');
})();
