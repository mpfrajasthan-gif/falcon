'use strict';

const assert = require('assert');

const {
  DISCOUNT_TYPES,
  text,
  upper,
  number,
  nonNegative,
  roundMoney,
  roundQuantity,
  calculateBasePrice,
  calculateDiscount,
  calculateTaxableAmount,
  calculateTax,
  calculatePaymentPosition,
  buildInstallmentSchedule,
  calculateBooking,
  BookingCalculationEngine,
} = require('./booking-calculation-engine');

(() => {
  console.log('Falcon Booking Calculation Engine Tests');
  console.log('---------------------------------------');

  let assertions = 0;

  const check = (actual, expected) => {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  };

  const checkTrue = (value) => {
    assert.strictEqual(value, true);
    assertions += 1;
  };

  check(DISCOUNT_TYPES.NONE, 'NONE');
  check(DISCOUNT_TYPES.FIXED, 'FIXED');
  check(DISCOUNT_TYPES.PERCENT, 'PERCENT');
  check(text('  Falcon  '), 'Falcon');
  check(upper(' sq_yard '), 'SQ_YARD');
  check(number('12.5', 'value'), 12.5);
  check(nonNegative(0, 'value'), 0);
  check(roundMoney(10.005), 10.01);
  check(roundQuantity(12.34567, 3), 12.346);

  assert.throws(() => number('bad', 'value'), /valid number/);
  assertions += 1;

  assert.throws(() => nonNegative(-1, 'value'), /cannot be negative/);
  assertions += 1;

  check(calculateBasePrice(100, 2500), 250000);

  assert.throws(() => calculateBasePrice(0, 2500), /greater than zero/);
  assertions += 1;

  const noDiscount = calculateDiscount(250000, {
    type: 'NONE',
    value: 999,
  });
  check(noDiscount.type, 'NONE');
  check(noDiscount.amount, 0);

  const fixedDiscount = calculateDiscount(250000, {
    type: 'FIXED',
    value: 10000,
  });
  check(fixedDiscount.amount, 10000);

  const percentDiscount = calculateDiscount(250000, {
    type: 'PERCENT',
    value: 5,
  });
  check(percentDiscount.amount, 12500);
  check(percentDiscount.value, 5);

  assert.throws(
    () => calculateDiscount(250000, { type: 'PERCENT', value: 101 }),
    /cannot exceed 100/
  );
  assertions += 1;

  assert.throws(
    () => calculateDiscount(250000, { type: 'FIXED', value: 250001 }),
    /cannot exceed base price/
  );
  assertions += 1;

  const taxable = calculateTaxableAmount({
    basePrice: 250000,
    discountAmount: 10000,
    adminCharges: 5000,
    fileCharges: 2500,
    otherCharges: 500,
  });
  check(taxable, 248000);

  const tax = calculateTax(248000, 5);
  check(tax.ratePercent, 5);
  check(tax.amount, 12400);

  assert.throws(() => calculateTax(100000, 101), /cannot exceed 100/);
  assertions += 1;

  const unpaid = calculatePaymentPosition(100000, 0);
  check(unpaid.paymentStage, 'UNPAID');
  check(unpaid.balanceAmount, 100000);
  check(unpaid.paymentPercent, 0);
  check(unpaid.soldEligible, false);

  const partial = calculatePaymentPosition(100000, 25000);
  check(partial.paymentStage, 'PARTIAL');
  check(partial.balanceAmount, 75000);
  check(partial.paymentPercent, 25);
  check(partial.soldEligible, false);

  const full = calculatePaymentPosition(100000, 100000);
  check(full.paymentStage, 'FULL');
  check(full.balanceAmount, 0);
  check(full.paymentPercent, 100);
  check(full.soldEligible, true);

  assert.throws(
    () => calculatePaymentPosition(100000, 100001),
    /cannot exceed grandTotal/
  );
  assertions += 1;

  const result = calculateBooking({
    currency: 'inr',
    unit: 'sq_yard',
    area: 100,
    ratePerUnit: 2500,
    discount: {
      type: 'PERCENT',
      value: 5,
    },
    adminCharges: 5000,
    fileCharges: 2500,
    otherCharges: 500,
    taxRatePercent: 5,
    paidAmount: 100000,
  });

  check(result.currency, 'INR');
  check(result.unit, 'SQ_YARD');
  check(result.area, 100);
  check(result.ratePerUnit, 2500);
  check(result.basePrice, 250000);
  check(result.discount.amount, 12500);
  check(result.adminCharges, 5000);
  check(result.fileCharges, 2500);
  check(result.otherCharges, 500);
  check(result.taxableAmount, 245500);
  check(result.tax.amount, 12275);
  check(result.grandTotal, 257775);
  check(result.paidAmount, 100000);
  check(result.balanceAmount, 157775);
  check(result.paymentPercent, 38.79);
  check(result.paymentStage, 'PARTIAL');
  check(result.soldEligible, false);

  const soldResult = calculateBooking({
    area: 40,
    ratePerUnit: 1000,
    discount: {
      type: 'FIXED',
      value: 5000,
    },
    adminCharges: 1000,
    fileCharges: 0,
    otherCharges: 0,
    taxRatePercent: 0,
    paidAmount: 36000,
  });

  check(soldResult.grandTotal, 36000);
  check(soldResult.balanceAmount, 0);
  check(soldResult.paymentPercent, 100);
  check(soldResult.paymentStage, 'FULL');
  check(soldResult.soldEligible, true);

  const schedule = buildInstallmentSchedule({
    balanceAmount: 100000,
    installmentCount: 3,
    firstDueDate: '2026-08-15',
    frequencyMonths: 1,
  });

  check(schedule.length, 3);
  check(schedule[0].installmentNumber, 1);
  check(schedule[0].dueDate, '2026-08-15');
  check(schedule[0].amount, 33333.33);
  check(schedule[1].dueDate, '2026-09-15');
  check(schedule[1].amount, 33333.33);
  check(schedule[2].dueDate, '2026-10-15');
  check(schedule[2].amount, 33333.34);

  const scheduledTotal = schedule.reduce(
    (sum, item) => roundMoney(sum + item.amount),
    0
  );
  check(scheduledTotal, 100000);

  assert.throws(
    () =>
      buildInstallmentSchedule({
        balanceAmount: 100000,
        installmentCount: 0,
        firstDueDate: '2026-08-15',
      }),
    /positive integer/
  );
  assertions += 1;

  assert.throws(
    () =>
      buildInstallmentSchedule({
        balanceAmount: 100000,
        installmentCount: 3,
        firstDueDate: 'bad-date',
      }),
    /valid date/
  );
  assertions += 1;

  const engine = new BookingCalculationEngine();
  const engineResult = engine.calculate({
    area: 50,
    ratePerUnit: 2000,
    paidAmount: 20000,
  });

  check(engineResult.basePrice, 100000);
  check(engineResult.grandTotal, 100000);
  check(engineResult.balanceAmount, 80000);

  const engineSchedule = engine.buildInstallmentSchedule({
    balanceAmount: 60000,
    installmentCount: 2,
    firstDueDate: '2026-09-01',
    frequencyMonths: 2,
  });

  check(engineSchedule[0].amount, 30000);
  check(engineSchedule[1].dueDate, '2026-11-01');

  console.log('Base Price Calculation: PASS');
  console.log('Fixed Discount: PASS');
  console.log('Percentage Discount: PASS');
  console.log('Charge Calculation: PASS');
  console.log('Tax Calculation: PASS');
  console.log('Grand Total Calculation: PASS');
  console.log('Payment Position: PASS');
  console.log('100 Percent Sold Eligibility: PASS');
  console.log('Overpayment Protection: PASS');
  console.log('Installment Schedule: PASS');
  console.log('Rounding Safety: PASS');
  console.log('Reusable Engine Class: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('---------------------------------------');
  console.log('BOOKING CALCULATION ENGINE TEST PASS');
})();
