'use strict';

const {
  loadActiveProjectMap,
  buildRendererBridgeResult,
} = require('./automatic-real-project-map-loader');

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function validateActiveProject(project) {
  if (!project || typeof project !== 'object') {
    throw new TypeError('Active project is required.');
  }

  const projectId = text(project.projectId || project.id);
  const projectFolder = text(
    project.projectFolder ||
    project.folderPath ||
    project.path
  );

  if (!/^FP-\d{6}$/.test(projectId)) {
    throw new Error('Active project has invalid Falcon project ID.');
  }

  if (!projectFolder) {
    throw new Error('Active project folder is missing.');
  }

  return Object.freeze({
    ...project,
    projectId,
    projectFolder,
  });
}

function buildPremiumViewerSession(project) {
  const activeProject = validateActiveProject(project);
  const activeMap = loadActiveProjectMap(activeProject);
  const bridge = buildRendererBridgeResult(activeMap);

  return Object.freeze({
    sessionType: 'PREMIUM_MAP_VIEWER',
    projectId: activeProject.projectId,
    projectName: text(
      activeProject.projectName ||
      activeProject.name
    ),
    projectFolder: activeProject.projectFolder,
    mapPath: activeMap.mapPath,
    plotCount: activeMap.plotCount,
    mapModel: bridge.mapModel,
    ready: bridge.readyForPremiumViewer === true,
  });
}

function createPremiumViewerIpcHandlers({
  ipcMain,
  getActiveProject,
} = {}) {
  if (!ipcMain || typeof ipcMain.handle !== 'function') {
    throw new TypeError('ipcMain is required.');
  }

  if (typeof getActiveProject !== 'function') {
    throw new TypeError('getActiveProject function is required.');
  }

  const channels = {
    session: 'falcon:premium-map:get-session',
    map: 'falcon:premium-map:get-current-map-model',
    project: 'falcon:premium-map:get-current-project',
  };

  ipcMain.handle(channels.project, async () => {
    const project = await getActiveProject();
    return validateActiveProject(project);
  });

  ipcMain.handle(channels.map, async () => {
    const project = await getActiveProject();
    return buildPremiumViewerSession(project).mapModel;
  });

  ipcMain.handle(channels.session, async () => {
    const project = await getActiveProject();
    return buildPremiumViewerSession(project);
  });

  return Object.freeze({ ...channels });
}

function buildPreloadApi(ipcRenderer) {
  if (!ipcRenderer || typeof ipcRenderer.invoke !== 'function') {
    throw new TypeError('ipcRenderer is required.');
  }

  return Object.freeze({
    getPremiumMapSession: () =>
      ipcRenderer.invoke('falcon:premium-map:get-session'),

    getCurrentMapModel: () =>
      ipcRenderer.invoke('falcon:premium-map:get-current-map-model'),

    getCurrentProject: () =>
      ipcRenderer.invoke('falcon:premium-map:get-current-project'),
  });
}

function resolvePremiumViewerFile(appRoot) {
  const root = text(appRoot);
  if (!root) throw new Error('appRoot is required.');

  const path = require('path');

  return path.join(
    root,
    'ui',
    'map-viewer-premium',
    'index.html'
  );
}

class PremiumViewerLiveWiringService {
  validateProject(project) {
    return validateActiveProject(project);
  }

  session(project) {
    return buildPremiumViewerSession(project);
  }

  register(input) {
    return createPremiumViewerIpcHandlers(input);
  }

  preload(ipcRenderer) {
    return buildPreloadApi(ipcRenderer);
  }

  viewerFile(appRoot) {
    return resolvePremiumViewerFile(appRoot);
  }
}

module.exports = {
  text,
  validateActiveProject,
  buildPremiumViewerSession,
  createPremiumViewerIpcHandlers,
  buildPreloadApi,
  resolvePremiumViewerFile,
  PremiumViewerLiveWiringService,
};
