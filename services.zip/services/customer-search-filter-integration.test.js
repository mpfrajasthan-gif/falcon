'use strict';

const assert = require('assert');

const {
  normalizeProfile,
  calculateSearchScore,
  matchesFilters,
  searchCustomerProfiles,
  buildCustomerFilterSummary,
  CustomerSearchFilterIntegrationService,
} = require('./customer-search-filter-integration');

(() => {
  console.log('Falcon Customer Search & Filter Integration Tests');
  console.log('-------------------------------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  function checkFalse(value) {
    assert.strictEqual(value, false);
    assertions += 1;
  }

  const profiles = [
    {
      customer: {
        customerId: 'FC-000001',
        customerName: 'Shadab Aziz',
        mobile: '9876543210',
        email: 'shadab@example.com',
        address: 'Sawai Madhopur',
        status: 'ACTIVE',
      },
      summary: {
        bookingCount: 2,
        activeBookingCount: 2,
        soldBookingCount: 1,
        pendingBookingCount: 1,
        receiptCount: 3,
        documentCount: 2,
        identityDocumentCount: 1,
        hasPhoto: true,
        hasIdentityProof: true,
        totalBookingValue: 950000,
        totalPaid: 575000,
        totalBalance: 375000,
      },
      plots: [
        {
          bookingId: 'FB-000001',
          projectId: 'FP-000001',
          projectName: 'Jaipur Pride',
          plotNumber: '43',
        },
        {
          bookingId: 'FB-000002',
          projectId: 'FP-000002',
          projectName: 'Sawai Estate',
          plotNumber: '8',
        },
      ],
      documents: [],
    },
    {
      customer: {
        customerId: 'FC-000002',
        customerName: 'Aamir Khan',
        mobile: '9123456780',
        email: 'aamir@example.com',
        address: 'Jaipur',
        status: 'ACTIVE',
      },
      summary: {
        bookingCount: 1,
        activeBookingCount: 1,
        soldBookingCount: 1,
        pendingBookingCount: 0,
        receiptCount: 1,
        documentCount: 1,
        identityDocumentCount: 1,
        hasPhoto: false,
        hasIdentityProof: true,
        totalBookingValue: 300000,
        totalPaid: 300000,
        totalBalance: 0,
      },
      plots: [
        {
          bookingId: 'FB-000003',
          projectId: 'FP-000001',
          projectName: 'Jaipur Pride',
          plotNumber: '10',
        },
      ],
      documents: [],
    },
    {
      customer: {
        customerId: 'FC-000003',
        customerName: 'Nadeem Khan',
        mobile: '9988776655',
        email: 'nadeem@example.com',
        address: 'Kota',
        status: 'INACTIVE',
      },
      summary: {
        bookingCount: 1,
        activeBookingCount: 1,
        soldBookingCount: 0,
        pendingBookingCount: 1,
        receiptCount: 0,
        documentCount: 0,
        identityDocumentCount: 0,
        hasPhoto: false,
        hasIdentityProof: false,
        totalBookingValue: 250000,
        totalPaid: 0,
        totalBalance: 250000,
      },
      plots: [
        {
          bookingId: 'FB-000004',
          projectId: 'FP-000003',
          projectName: 'Green Valley',
          plotNumber: '7',
        },
      ],
      documents: [],
    },
  ];

  const normalized = normalizeProfile(profiles[0]);
  check(normalized.customerId, 'FC-000001');
  check(normalized.customerName, 'Shadab Aziz');
  check(normalized.totalBalance, 375000);
  check(normalized.pendingBookingCount, 1);
  check(normalized.hasIdentityProof, true);

  checkTrue(calculateSearchScore(normalized, 'FC-000001') >= 100);
  checkTrue(calculateSearchScore(normalized, 'Shadab') > 0);
  checkTrue(calculateSearchScore(normalized, '43') > 0);
  check(calculateSearchScore(normalized, 'Nobody'), 0);

  checkTrue(matchesFilters(normalized, { hasPending: true }));
  checkTrue(matchesFilters(normalized, { hasSold: true }));
  checkTrue(matchesFilters(normalized, { hasPhoto: true }));
  checkTrue(matchesFilters(normalized, { hasIdentityProof: true }));
  checkTrue(matchesFilters(normalized, { projectId: 'FP-000001' }));
  checkTrue(matchesFilters(normalized, { plotNumber: '43' }));
  checkFalse(matchesFilters(normalized, { plotNumber: '999' }));

  const byName = searchCustomerProfiles(profiles, {
    query: 'Shadab',
  });
  check(byName.pagination.total, 1);
  check(byName.items[0].customer.customerId, 'FC-000001');

  const byMobile = searchCustomerProfiles(profiles, {
    query: '9123456780',
  });
  check(byMobile.pagination.total, 1);
  check(byMobile.items[0].customer.customerId, 'FC-000002');

  const byPlot = searchCustomerProfiles(profiles, {
    query: '43',
  });
  check(byPlot.pagination.total, 1);
  check(byPlot.items[0].customer.customerId, 'FC-000001');

  const projectFilter = searchCustomerProfiles(profiles, {
    filters: {
      projectName: 'Jaipur Pride',
    },
  });
  check(projectFilter.pagination.total, 2);

  const pendingFilter = searchCustomerProfiles(profiles, {
    filters: {
      hasPending: true,
    },
  });
  check(pendingFilter.pagination.total, 2);

  const soldFilter = searchCustomerProfiles(profiles, {
    filters: {
      hasSold: true,
    },
  });
  check(soldFilter.pagination.total, 2);

  const identityMissing = searchCustomerProfiles(profiles, {
    filters: {
      hasIdentityProof: false,
    },
  });
  check(identityMissing.pagination.total, 1);
  check(identityMissing.items[0].customer.customerId, 'FC-000003');

  const balanceFilter = searchCustomerProfiles(profiles, {
    filters: {
      minimumBalance: 300000,
    },
  });
  check(balanceFilter.pagination.total, 1);
  check(balanceFilter.items[0].customer.customerId, 'FC-000001');

  const inactiveFilter = searchCustomerProfiles(profiles, {
    filters: {
      status: 'INACTIVE',
    },
  });
  check(inactiveFilter.pagination.total, 1);

  const sortedBalance = searchCustomerProfiles(profiles, {
    sortBy: 'totalBalance',
    direction: 'DESC',
  });
  check(sortedBalance.items[0].customer.customerId, 'FC-000001');
  check(sortedBalance.items[2].customer.customerId, 'FC-000002');

  const paged = searchCustomerProfiles(profiles, {
    sortBy: 'customerName',
    direction: 'ASC',
    page: 2,
    pageSize: 2,
  });
  check(paged.pagination.page, 2);
  check(paged.pagination.totalPages, 2);
  check(paged.items.length, 1);

  const summary = buildCustomerFilterSummary(profiles);
  check(summary.totalCustomers, 3);
  check(summary.customersWithPending, 2);
  check(summary.customersWithSold, 2);
  check(summary.customersWithPhoto, 1);
  check(summary.customersWithIdentityProof, 2);
  check(summary.totalOutstanding, 625000);
  check(summary.totalBookingValue, 1500000);

  const service = new CustomerSearchFilterIntegrationService();

  const serviceSearch = service.search(profiles, {
    filters: {
      projectId: 'FP-000001',
      hasSold: true,
    },
  });
  check(serviceSearch.pagination.total, 2);

  const serviceSummary = service.summary(profiles);
  check(serviceSummary.totalCustomers, 3);

  checkTrue(
    service.matches(profiles[0], {
      hasPending: true,
      hasIdentityProof: true,
    })
  );

  assert.throws(
    () => searchCustomerProfiles({}, {}),
    /profiles must be an array/
  );
  assertions += 1;

  console.log('Customer ID Search: PASS');
  console.log('Customer Name Search: PASS');
  console.log('Mobile Search: PASS');
  console.log('Project Search/Filter: PASS');
  console.log('Plot Search/Filter: PASS');
  console.log('Pending Balance Filter: PASS');
  console.log('Sold Status Filter: PASS');
  console.log('Photo Filter: PASS');
  console.log('Identity Proof Filter: PASS');
  console.log('Customer Status Filter: PASS');
  console.log('Sorting & Pagination: PASS');
  console.log('Customer Filter Summary: PASS');
  console.log('Reusable Search/Filter Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('-------------------------------------------------');
  console.log('CUSTOMER SEARCH & FILTER INTEGRATION TEST PASS');
})();
