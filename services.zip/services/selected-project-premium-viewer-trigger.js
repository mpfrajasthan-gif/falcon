'use strict';

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function normalizeProject(project = {}) {
  const id = text(project.id || project.projectId);
  const name = text(project.name || project.projectName);

  if (!/^FP-\d{6}$/.test(id)) {
    throw new Error('Valid selected Project ID is required.');
  }

  if (!name) {
    throw new Error('Selected project name is required.');
  }

  return Object.freeze({
    id,
    name,
    uuid: text(project.uuid),
    status: text(project.status || 'Active'),
  });
}

function resolveSelectedProject({
  projects = [],
  selectedProjectId,
} = {}) {
  if (!Array.isArray(projects)) {
    throw new TypeError('projects must be an array.');
  }

  const id = text(selectedProjectId);

  if (!id) {
    return Object.freeze({
      found: false,
      project: null,
      reason: 'NO_PROJECT_SELECTED',
    });
  }

  const project = projects.find(
    item => text(item && (item.id || item.projectId)) === id
  );

  if (!project) {
    return Object.freeze({
      found: false,
      project: null,
      reason: 'SELECTED_PROJECT_NOT_FOUND',
    });
  }

  return Object.freeze({
    found: true,
    project: normalizeProject(project),
    reason: 'OK',
  });
}

async function openSelectedProjectPremiumViewer({
  projects = [],
  selectedProjectId,
  falconDesktop,
} = {}) {
  const selected = resolveSelectedProject({
    projects,
    selectedProjectId,
  });

  if (!selected.found) {
    return Object.freeze({
      ok: false,
      error:
        selected.reason === 'NO_PROJECT_SELECTED'
          ? 'Select a Falcon project first.'
          : 'Selected Falcon project could not be found.',
      reason: selected.reason,
    });
  }

  if (
    !falconDesktop ||
    typeof falconDesktop.openPremiumMapViewer !== 'function'
  ) {
    return Object.freeze({
      ok: false,
      error: 'Premium Viewer bridge is unavailable.',
      reason: 'BRIDGE_UNAVAILABLE',
    });
  }

  const result = await falconDesktop.openPremiumMapViewer(selected.project);

  if (!result || result.ok !== true) {
    return Object.freeze({
      ok: false,
      error: text(result && result.error) || 'Premium Viewer could not be opened.',
      reason: 'OPEN_FAILED',
      project: selected.project,
    });
  }

  return Object.freeze({
    ok: true,
    project: selected.project,
    reason: 'OPENED',
  });
}

function buildProjectViewerButtonState({
  projects = [],
  selectedProjectId,
} = {}) {
  const selected = resolveSelectedProject({
    projects,
    selectedProjectId,
  });

  return Object.freeze({
    visible: true,
    enabled: selected.found,
    label: selected.found
      ? `Open Map • ${selected.project.name}`
      : 'Open Premium Map',
    selectedProjectId: selected.found ? selected.project.id : '',
    tooltip: selected.found
      ? `Open premium map for ${selected.project.name}`
      : 'Select a project first',
  });
}

class SelectedProjectPremiumViewerTriggerService {
  normalize(project) {
    return normalizeProject(project);
  }

  resolve(input) {
    return resolveSelectedProject(input);
  }

  buttonState(input) {
    return buildProjectViewerButtonState(input);
  }

  async open(input) {
    return openSelectedProjectPremiumViewer(input);
  }
}

module.exports = {
  text,
  normalizeProject,
  resolveSelectedProject,
  openSelectedProjectPremiumViewer,
  buildProjectViewerButtonState,
  SelectedProjectPremiumViewerTriggerService,
};
