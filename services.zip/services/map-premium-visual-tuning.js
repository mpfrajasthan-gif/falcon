'use strict';
function clamp(v,a,b){return Math.min(b,Math.max(a,v))}
function readableAngle(a){while(a<=-Math.PI)a+=Math.PI*2;while(a>Math.PI)a-=Math.PI*2;if(a>Math.PI/2)a-=Math.PI;if(a<-Math.PI/2)a+=Math.PI;return a}
function labelSizeForZoom(z){z=Number(z);if(z<8)return 11;if(z<16)return 13;if(z<28)return 15;return 16}
function dimensionFontForZoom(z,selected){z=Number(z);return selected?clamp(9+z/20,10,12):clamp(8+z/24,9,11)}
function dimensionOffsetPx(z){return clamp(5+Number(z)/18,5,9)}
function shouldShowDimension(z,selected){z=Number(z);return selected?z>=6.5:z>=10.5}
function shouldShowRoadLabel(z){return Number(z)>=5.5}
function plotLineWidth(z){return clamp(.75+Number(z)/100,.8,1.25)}
function selectionLineWidth(z){return clamp(1+Number(z)/120,1,1.4)}
function buildVisualTuningContract(){return Object.freeze({plotNumberTargetPx:15,dimensionTextReadable:true,topDimensionNeverUpsideDown:true,thinPlotBoundaries:true,selectedBlueGlassOpacity:.30,selectedBoundaryDash:Object.freeze([3,3]),selectedBoundaryOffsetPx:2,roadLabelBold:true,antiClutter:true,smoothPanZoom:true,defaultAreaUnit:'SQ_YARD'})}
class PremiumVisualTuningService{readableAngle(a){return readableAngle(a)}labelSize(z){return labelSizeForZoom(z)}dimensionFont(z,s){return dimensionFontForZoom(z,s)}dimensionOffset(z){return dimensionOffsetPx(z)}showDimension(z,s){return shouldShowDimension(z,s)}showRoadLabel(z){return shouldShowRoadLabel(z)}plotLine(z){return plotLineWidth(z)}selectionLine(z){return selectionLineWidth(z)}contract(){return buildVisualTuningContract()}}
module.exports={clamp,readableAngle,labelSizeForZoom,dimensionFontForZoom,dimensionOffsetPx,shouldShowDimension,shouldShowRoadLabel,plotLineWidth,selectionLineWidth,buildVisualTuningContract,PremiumVisualTuningService};
