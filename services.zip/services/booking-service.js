'use strict';

const ACTIVE_BOOKING_STATUSES = Object.freeze([
  'BOOKED',
  'SOLD',
]);

const BOOKABLE_PLOT_STATUSES = Object.freeze([
  'AVAILABLE',
]);

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function finiteNumber(value, fieldName) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    throw new TypeError(`${fieldName} must be a valid number.`);
  }
  return number;
}

function clone(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

class BookingServiceError extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.name = 'BookingServiceError';
    this.code = code;
    this.details = clone(details);
  }
}

class BookingService {
  constructor({
    bookingRepository,
    plotService,
    plotStatusEngine,
    customerService,
    auditService,
    clock,
  } = {}) {
    if (
      !bookingRepository ||
      typeof bookingRepository.create !== 'function' ||
      typeof bookingRepository.getById !== 'function' ||
      typeof bookingRepository.findActiveByPlot !== 'function' ||
      typeof bookingRepository.update !== 'function' ||
      typeof bookingRepository.archive !== 'function'
    ) {
      throw new TypeError(
        'BookingService requires a compatible bookingRepository.'
      );
    }

    if (!plotService) {
      throw new TypeError('BookingService requires plotService.');
    }

    if (!plotStatusEngine) {
      throw new TypeError('BookingService requires plotStatusEngine.');
    }

    this.bookingRepository = bookingRepository;
    this.plotService = plotService;
    this.plotStatusEngine = plotStatusEngine;
    this.customerService = customerService || null;
    this.auditService = auditService || null;
    this.clock = clock || (() => new Date());
  }

  _timestamp() {
    const value = this.clock();
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime())) {
      throw new TypeError('Clock returned an invalid date.');
    }
    return date.toISOString();
  }

  async _audit(eventType, payload) {
    if (!this.auditService) return;

    if (typeof this.auditService.record === 'function') {
      await this.auditService.record(eventType, clone(payload));
      return;
    }

    if (typeof this.auditService.log === 'function') {
      await this.auditService.log({
        eventType,
        ...clone(payload),
      });
    }
  }

  async _getPlot(projectId, plotId) {
    if (typeof this.plotService.getById === 'function') {
      const direct = await this.plotService.getById(plotId);
      if (!direct) return null;
      if (!direct.projectId || upper(direct.projectId) === projectId) {
        return direct;
      }
      return null;
    }

    if (typeof this.plotService.getPlot === 'function') {
      return this.plotService.getPlot(projectId, plotId);
    }

    if (typeof this.plotService.findById === 'function') {
      const found = await this.plotService.findById(plotId);
      if (found && (!found.projectId || upper(found.projectId) === projectId)) {
        return found;
      }
    }

    throw new TypeError(
      'plotService must provide getById(), getPlot(), or findById().'
    );
  }

  async _getCustomer(customerId) {
    if (!this.customerService || !customerId) return null;

    if (typeof this.customerService.getById === 'function') {
      return this.customerService.getById(customerId);
    }

    if (typeof this.customerService.getCustomer === 'function') {
      return this.customerService.getCustomer(customerId);
    }

    if (typeof this.customerService.findById === 'function') {
      return this.customerService.findById(customerId);
    }

    throw new TypeError(
      'customerService must provide getById(), getCustomer(), or findById().'
    );
  }

  async _changePlotStatus({
    projectId,
    plotId,
    targetStatus,
    actorId,
    reason,
    bookingId,
    payment,
  }) {
    const engine = this.plotStatusEngine;

    if (typeof engine.changeStatus === 'function') {
      return engine.changeStatus({
        projectId,
        plotId,
        targetStatus,
        actorId,
        reason,
        bookingId,
        payment,
      });
    }

    if (typeof engine.transition === 'function') {
      return engine.transition({
        projectId,
        plotId,
        toStatus: targetStatus,
        actorId,
        reason,
        bookingId,
        payment,
      });
    }

    if (typeof engine.setStatus === 'function') {
      return engine.setStatus(
        projectId,
        plotId,
        targetStatus,
        {
          actorId,
          reason,
          bookingId,
          payment,
        }
      );
    }

    throw new TypeError(
      'plotStatusEngine must provide changeStatus(), transition(), or setStatus().'
    );
  }

  _validateCreateInput(input) {
    const projectId = upper(input.projectId);
    const plotId = upper(input.plotId);
    const customerId = upper(input.customerId);
    const actorId = upper(input.actorId);

    if (!projectId) {
      throw new BookingServiceError(
        'PROJECT_REQUIRED',
        'Project is required.'
      );
    }

    if (!plotId) {
      throw new BookingServiceError(
        'PLOT_REQUIRED',
        'Plot is required.'
      );
    }

    if (!customerId) {
      throw new BookingServiceError(
        'CUSTOMER_REQUIRED',
        'Customer is required.'
      );
    }

    if (!actorId) {
      throw new BookingServiceError(
        'ACTOR_REQUIRED',
        'Logged-in user is required.'
      );
    }

    const totalPrice = finiteNumber(input.totalPrice, 'totalPrice');
    const paidAmount = finiteNumber(
      input.paidAmount === undefined ? 0 : input.paidAmount,
      'paidAmount'
    );

    if (totalPrice <= 0) {
      throw new BookingServiceError(
        'INVALID_TOTAL_PRICE',
        'Total price must be greater than zero.'
      );
    }

    if (paidAmount < 0) {
      throw new BookingServiceError(
        'INVALID_PAID_AMOUNT',
        'Paid amount cannot be negative.'
      );
    }

    if (paidAmount > totalPrice) {
      throw new BookingServiceError(
        'OVERPAYMENT_NOT_ALLOWED',
        'Paid amount cannot exceed total price.'
      );
    }

    return {
      projectId,
      plotId,
      customerId,
      actorId,
      totalPrice,
      paidAmount,
      balanceAmount: totalPrice - paidAmount,
    };
  }

  async createBooking(input = {}) {
    const validated = this._validateCreateInput(input);

    const existing = await this.bookingRepository.findActiveByPlot(
      validated.projectId,
      validated.plotId
    );

    if (existing) {
      throw new BookingServiceError(
        'PLOT_ALREADY_BOOKED',
        'This plot already has an active booking.',
        {
          bookingId: existing.bookingId,
          bookingReference: existing.bookingReference,
        }
      );
    }

    const plot = await this._getPlot(
      validated.projectId,
      validated.plotId
    );

    if (!plot) {
      throw new BookingServiceError(
        'PLOT_NOT_FOUND',
        'Selected plot was not found.'
      );
    }

    const plotStatus = upper(plot.status || 'AVAILABLE');
    if (!BOOKABLE_PLOT_STATUSES.includes(plotStatus)) {
      throw new BookingServiceError(
        'PLOT_NOT_AVAILABLE',
        `Plot cannot be booked while its status is ${plotStatus}.`,
        { plotStatus }
      );
    }

    const customer = await this._getCustomer(validated.customerId);
    if (this.customerService && !customer) {
      throw new BookingServiceError(
        'CUSTOMER_NOT_FOUND',
        'Selected customer was not found.'
      );
    }

    const bookingDate =
      text(input.bookingDate) || this._timestamp().slice(0, 10);

    let booking = null;

    try {
      booking = await this.bookingRepository.create(
        {
          projectId: validated.projectId,
          plotId: validated.plotId,
          customerId: validated.customerId,
          customerName:
            text(input.customerName) ||
            text(customer && customer.name),
          customerMobile:
            text(input.customerMobile) ||
            text(customer && customer.mobile),
          bookingDate,
          status: 'BOOKED',
          totalPrice: validated.totalPrice,
          paidAmount: validated.paidAmount,
          balanceAmount: validated.balanceAmount,
          currency: upper(input.currency || 'INR'),
          notes: text(input.notes),
        },
        { actorId: validated.actorId }
      );

      await this._changePlotStatus({
        projectId: validated.projectId,
        plotId: validated.plotId,
        targetStatus: 'BOOKED',
        actorId: validated.actorId,
        reason: 'Booking created',
        bookingId: booking.bookingId,
        payment: {
          totalPrice: validated.totalPrice,
          paidAmount: validated.paidAmount,
        },
      });

      await this._audit('BOOKING_CREATED', {
        actorId: validated.actorId,
        bookingId: booking.bookingId,
        bookingReference: booking.bookingReference,
        projectId: validated.projectId,
        plotId: validated.plotId,
        customerId: validated.customerId,
        timestamp: this._timestamp(),
      });

      return clone(booking);
    } catch (error) {
      if (booking && booking.bookingId) {
        try {
          await this.bookingRepository.archive(booking.bookingId, {
            actorId: validated.actorId,
            reason: 'Automatic rollback: plot status update failed',
          });
        } catch (_) {
          // Preserve the original failure. Recovery can be handled by audit/admin.
        }
      }

      if (error instanceof BookingServiceError) throw error;

      throw new BookingServiceError(
        'BOOKING_CREATE_FAILED',
        'Booking could not be completed safely.',
        { cause: error.message }
      );
    }
  }

  async getBooking(bookingId, options = {}) {
    const id = upper(bookingId);
    if (!id) {
      throw new BookingServiceError(
        'BOOKING_ID_REQUIRED',
        'Booking ID is required.'
      );
    }

    return this.bookingRepository.getById(id, options);
  }

  async updateBookingDetails(
    bookingId,
    changes = {},
    { actorId } = {}
  ) {
    const id = upper(bookingId);
    const actor = upper(actorId);

    if (!id) {
      throw new BookingServiceError(
        'BOOKING_ID_REQUIRED',
        'Booking ID is required.'
      );
    }

    if (!actor) {
      throw new BookingServiceError(
        'ACTOR_REQUIRED',
        'Logged-in user is required.'
      );
    }

    const forbidden = [
      'bookingId',
      'bookingReference',
      'projectId',
      'plotId',
      'status',
      'totalPrice',
      'paidAmount',
      'balanceAmount',
      'isArchived',
      'archivedAt',
      'archivedBy',
      'archiveReason',
    ];

    const attempted = forbidden.filter(
      (field) => Object.prototype.hasOwnProperty.call(changes, field)
    );

    if (attempted.length) {
      throw new BookingServiceError(
        'PROTECTED_FIELDS',
        `Protected booking fields cannot be changed here: ${attempted.join(', ')}.`
      );
    }

    const current = await this.bookingRepository.getById(id);
    if (!current) {
      throw new BookingServiceError(
        'BOOKING_NOT_FOUND',
        'Booking was not found.'
      );
    }

    const updated = await this.bookingRepository.update(
      id,
      {
        customerName:
          changes.customerName === undefined
            ? current.customerName
            : text(changes.customerName),
        customerMobile:
          changes.customerMobile === undefined
            ? current.customerMobile
            : text(changes.customerMobile),
        notes:
          changes.notes === undefined
            ? current.notes
            : text(changes.notes),
      },
      { actorId: actor }
    );

    await this._audit('BOOKING_DETAILS_UPDATED', {
      actorId: actor,
      bookingId: id,
      timestamp: this._timestamp(),
    });

    return clone(updated);
  }

  async cancelBooking(
    bookingId,
    { actorId, reason } = {}
  ) {
    const id = upper(bookingId);
    const actor = upper(actorId);
    const cancellationReason = text(reason);

    if (!id) {
      throw new BookingServiceError(
        'BOOKING_ID_REQUIRED',
        'Booking ID is required.'
      );
    }

    if (!actor) {
      throw new BookingServiceError(
        'ACTOR_REQUIRED',
        'Logged-in user is required.'
      );
    }

    if (!cancellationReason) {
      throw new BookingServiceError(
        'CANCELLATION_REASON_REQUIRED',
        'Cancellation reason is required.'
      );
    }

    const booking = await this.bookingRepository.getById(id);
    if (!booking) {
      throw new BookingServiceError(
        'BOOKING_NOT_FOUND',
        'Booking was not found.'
      );
    }

    if (upper(booking.status) === 'SOLD') {
      throw new BookingServiceError(
        'SOLD_BOOKING_LOCKED',
        'A sold booking cannot be cancelled through the normal workflow.'
      );
    }

    await this._changePlotStatus({
      projectId: upper(booking.projectId),
      plotId: upper(booking.plotId),
      targetStatus: 'AVAILABLE',
      actorId: actor,
      reason: cancellationReason,
      bookingId: id,
    });

    const archived = await this.bookingRepository.archive(id, {
      actorId: actor,
      reason: cancellationReason,
    });

    await this._audit('BOOKING_CANCELLED', {
      actorId: actor,
      bookingId: id,
      projectId: booking.projectId,
      plotId: booking.plotId,
      reason: cancellationReason,
      timestamp: this._timestamp(),
    });

    return clone(archived);
  }
}

module.exports = {
  ACTIVE_BOOKING_STATUSES,
  BOOKABLE_PLOT_STATUSES,
  text,
  upper,
  finiteNumber,
  clone,
  BookingServiceError,
  BookingService,
};
