'use strict';

const assert = require('assert');

const {
  STATUS_STYLES,
  LAND_USE_STYLES,
  DRAW_ORDER,
  normalizeStatus,
  normalizeLandUse,
  buildPlotStyle,
  buildDimensionCommands,
  buildPlotCommands,
  buildRoadCommands,
  buildSpecialAreaCommands,
  buildSelectionCommands,
  buildLayerRenderModel,
  MapLayerRenderModelService,
} = require('./map-layer-render-model');

const {
  worldToScreen,
} = require('./map-renderer-core');

(() => {
  console.log('Falcon MAP.2 Layer Render Model Tests');
  console.log('------------------------------------');

  let assertions = 0;
  const check = (a, e) => { assert.deepStrictEqual(a, e); assertions += 1; };
  const yes = (v) => { assert.strictEqual(v, true); assertions += 1; };

  check(normalizeStatus('sold'), 'SOLD');
  check(normalizeStatus('unknown'), 'AVAILABLE');
  check(normalizeLandUse('other land'), 'OTHER_LAND');
  check(STATUS_STYLES.BOOKED.fillRole, 'BOOKED_FILL');
  check(LAND_USE_STYLES.RESIDENTIAL.fillRole, 'RESIDENTIAL_CREAM');

  check(DRAW_ORDER[0], 'BACKGROUND');
  check(DRAW_ORDER[DRAW_ORDER.length - 1], 'SELECTION_BOUNDARY');

  const plot = {
    plotNumber: '43',
    status: 'BOOKED',
    landUse: 'RESIDENTIAL',
    screenVertices: [
      { x: 100, y: 100 },
      { x: 200, y: 100 },
      { x: 200, y: 250 },
      { x: 100, y: 250 },
    ],
    labelPoint: { x: 150, y: 175 },
    sideLengthsFt: [30, 45, 30, 45],
    areaSqYd: 150,
  };

  const style = buildPlotStyle(plot);
  check(style.status, 'BOOKED');
  check(style.landUse, 'RESIDENTIAL');
  check(style.label.preferredSizePx, 15);
  check(style.label.placement, 'CENTROID');

  const dims = buildDimensionCommands(plot);
  check(dims.length, 4);
  check(dims[0].text, "30.0'");
  check(dims[0].shaded, false);

  const plotCommands = buildPlotCommands(plot);
  yes(plotCommands.some((c) => c.layer === 'PLOTS'));
  yes(plotCommands.some((c) => c.layer === 'PLOT_BORDERS'));
  yes(plotCommands.some((c) => c.layer === 'PLOT_NUMBERS'));
  check(plotCommands.filter((c) => c.layer === 'DIMENSIONS').length, 4);

  const roadCommands = buildRoadCommands([
    {
      id: 'R1',
      name: "ROAD 40' WIDE",
      screenVertices: [
        { x: 100, y: 300 },
        { x: 300, y: 300 },
      ],
      labelPoint: { x: 200, y: 300 },
    },
  ]);

  yes(roadCommands.some((c) => c.layer === 'ROADS'));
  yes(roadCommands.some((c) => c.layer === 'ROAD_LABELS'));

  const specialCommands = buildSpecialAreaCommands([
    {
      id: 'S1',
      name: 'OTHER LAND',
      category: 'OTHER LAND',
      screenVertices: [
        { x: 50, y: 50 },
        { x: 80, y: 50 },
        { x: 80, y: 80 },
        { x: 50, y: 80 },
      ],
      labelPoint: { x: 65, y: 65 },
    },
  ]);

  yes(specialCommands.some((c) => c.fillRole === 'OTHER_LAND_OLIVE'));
  yes(specialCommands.some((c) => c.type === 'TEXT'));

  const selection = buildSelectionCommands(plot);
  check(selection.length, 2);
  check(selection[0].fillRole, 'SELECTION_BLUE_GLASS');
  check(selection[0].opacity, 0.28);
  check(selection[1].strokeRole, 'SELECTION_DOTTED');
  check(selection[1].dashPx, [3, 3]);
  check(selection[1].offsetPx, 2);

  const viewport = {
    zoom: 10,
    panX: 100,
    panY: 500,
  };

  const frame = {
    viewport,
    plots: [plot],
    roads: [
      {
        id: 'R2',
        name: "ROAD 60' WIDE",
        widthFt: 60,
        vertices: [
          { x: 0, y: -10 },
          { x: 20, y: -10 },
        ],
        labelPoint: { x: 10, y: -10 },
      },
    ],
    specialAreas: [
      {
        id: 'S2',
        name: 'FACILITY',
        category: 'FACILITY',
        vertices: [
          { x: 0, y: 20 },
          { x: 10, y: 20 },
          { x: 10, y: 30 },
          { x: 0, y: 30 },
        ],
        centroid: { x: 5, y: 25 },
      },
    ],
    selectedPlot: plot,
  };

  const model = buildLayerRenderModel({
    frame,
    worldToScreen,
  });

  check(model.drawOrder, DRAW_ORDER);
  check(model.summary.plotCount, 1);
  check(model.summary.roadCount, 1);
  check(model.summary.specialAreaCount, 1);
  check(model.summary.selectedPlotNumber, '43');
  yes(model.summary.commandCount > 10);

  const first = model.commands[0];
  check(first.layer, 'BACKGROUND');

  const selectedFillIndex = model.commands.findIndex(
    (c) => c.layer === 'SELECTION_FILL'
  );
  const selectedBoundaryIndex = model.commands.findIndex(
    (c) => c.layer === 'SELECTION_BOUNDARY'
  );

  yes(selectedFillIndex > 0);
  yes(selectedBoundaryIndex > selectedFillIndex);

  const plotNumberCmd = model.commands.find(
    (c) => c.layer === 'PLOT_NUMBERS'
  );

  check(plotNumberCmd.preferredSizePx, 15);
  check(plotNumberCmd.fontWeight, 600);

  const dimensionCmd = model.commands.find(
    (c) => c.layer === 'DIMENSIONS'
  );

  check(dimensionCmd.shaded, false);

  const service = new MapLayerRenderModelService();

  check(service.plotStyle(plot).status, 'BOOKED');
  check(service.selectionCommands(plot).length, 2);
  yes(service.build({ frame, worldToScreen }).commands.length > 0);

  console.log('Status Style Mapping: PASS');
  console.log('Land-use Style Mapping: PASS');
  console.log('Correct Draw Order: PASS');
  console.log('Plot Fill/Border Commands: PASS');
  console.log('Plot Number Label Commands: PASS');
  console.log('Feet Dimension Commands: PASS');
  console.log('Road Geometry Commands: PASS');
  console.log('Road Label Commands: PASS');
  console.log('Special Area Commands: PASS');
  console.log('Blue Glass Selection Fill: PASS');
  console.log('Thin Dotted Offset Boundary: PASS');
  console.log('Selection Draw-on-top Order: PASS');
  console.log('15px Plot Number Target: PASS');
  console.log('Unshaded Dimension Text: PASS');
  console.log('Reusable Layer Render Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('------------------------------------');
  console.log('MAP LAYER RENDER MODEL TEST PASS');
})();
