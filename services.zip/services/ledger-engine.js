'use strict';

const LEDGER_ENTRY_TYPES = Object.freeze({
  PAYMENT: 'PAYMENT',
  REVERSAL: 'REVERSAL',
  ADJUSTMENT: 'ADJUSTMENT',
});

const LEDGER_ENTRY_STATUSES = Object.freeze({
  ACTIVE: 'ACTIVE',
  VOID: 'VOID',
});

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}
function upper(value) { return text(value).toUpperCase(); }
function finiteNumber(value, fieldName) {
  const number = Number(value);
  if (!Number.isFinite(number)) throw new TypeError(`${fieldName} must be a valid number.`);
  return number;
}
function nonNegative(value, fieldName) {
  const number = finiteNumber(value, fieldName);
  if (number < 0) throw new RangeError(`${fieldName} cannot be negative.`);
  return number;
}
function positive(value, fieldName) {
  const number = finiteNumber(value, fieldName);
  if (number <= 0) throw new RangeError(`${fieldName} must be greater than zero.`);
  return number;
}
function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}
function normalizeDate(value) {
  const raw = text(value);
  if (!raw) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
  const match = raw.match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (!match) return '';
  return `${match[3]}-${match[2]}-${match[1]}`;
}
function validateEntryType(type) {
  const normalized = upper(type);
  if (!Object.values(LEDGER_ENTRY_TYPES).includes(normalized)) {
    throw new RangeError('Unsupported ledger entry type.');
  }
  return normalized;
}
function createLedgerEntry(input = {}) {
  const entryId = upper(input.entryId);
  const bookingId = upper(input.bookingId);
  const type = validateEntryType(input.type);
  const amount = roundMoney(positive(input.amount, 'amount'));
  const entryDate = normalizeDate(input.entryDate);

  if (!entryId) throw new Error('entryId is required.');
  if (!bookingId) throw new Error('bookingId is required.');
  if (!entryDate) throw new Error('entryDate must be DD-MM-YYYY or YYYY-MM-DD.');

  if (type === LEDGER_ENTRY_TYPES.PAYMENT && !upper(input.paymentId)) {
    throw new Error('paymentId is required for PAYMENT entry.');
  }
  if (type === LEDGER_ENTRY_TYPES.REVERSAL && !upper(input.reversalOfEntryId)) {
    throw new Error('reversalOfEntryId is required for REVERSAL entry.');
  }
  if (type === LEDGER_ENTRY_TYPES.ADJUSTMENT) {
    const direction = upper(input.adjustmentDirection);
    if (!['CREDIT', 'DEBIT'].includes(direction)) {
      throw new Error('adjustmentDirection must be CREDIT or DEBIT.');
    }
  }

  return Object.freeze({
    entryId,
    bookingId,
    type,
    amount,
    entryDate,
    entryDateTime: text(input.entryDateTime) || new Date().toISOString(),
    paymentId: upper(input.paymentId),
    receiptNumber: upper(input.receiptNumber),
    referenceNumber: text(input.referenceNumber),
    paymentMode: upper(input.paymentMode),
    reversalOfEntryId: upper(input.reversalOfEntryId),
    adjustmentDirection: upper(input.adjustmentDirection),
    notes: text(input.notes),
    actorId: upper(input.actorId),
    status: LEDGER_ENTRY_STATUSES.ACTIVE,
    voidReason: '',
    voidedAt: null,
    voidedBy: '',
  });
}
function getSignedAmount(entry) {
  const type = validateEntryType(entry.type);
  const amount = roundMoney(positive(entry.amount, 'amount'));
  if (type === LEDGER_ENTRY_TYPES.PAYMENT) return amount;
  if (type === LEDGER_ENTRY_TYPES.REVERSAL) return -amount;
  return upper(entry.adjustmentDirection) === 'DEBIT' ? -amount : amount;
}
function ensureUniqueEntryId(entryId, existingEntries = []) {
  if (!Array.isArray(existingEntries)) throw new TypeError('existingEntries must be an array.');
  const normalized = upper(entryId);
  if (existingEntries.some((entry) => upper(entry.entryId) === normalized)) {
    throw new Error('Duplicate entryId is not allowed.');
  }
  return true;
}
function validateReversal(entry, existingEntries = []) {
  const reversalOfEntryId = upper(entry.reversalOfEntryId);
  const original = existingEntries.find((item) => upper(item.entryId) === reversalOfEntryId);
  if (!original) throw new Error('Original ledger entry not found for reversal.');
  if (validateEntryType(original.type) === LEDGER_ENTRY_TYPES.REVERSAL) {
    throw new Error('A reversal entry cannot be reversed.');
  }
  const alreadyReversed = existingEntries.some(
    (item) =>
      validateEntryType(item.type) === LEDGER_ENTRY_TYPES.REVERSAL &&
      upper(item.reversalOfEntryId) === reversalOfEntryId &&
      upper(item.status || LEDGER_ENTRY_STATUSES.ACTIVE) !== LEDGER_ENTRY_STATUSES.VOID
  );
  if (alreadyReversed) throw new Error('Original ledger entry is already reversed.');
  if (roundMoney(original.amount) !== roundMoney(entry.amount)) {
    throw new Error('Reversal amount must match original entry amount.');
  }
  return original;
}
function buildLedger({ booking, entries = [] }) {
  if (!booking || typeof booking !== 'object') throw new TypeError('booking is required.');
  if (!Array.isArray(entries)) throw new TypeError('entries must be an array.');

  const bookingId = upper(booking.bookingId || booking.id);
  const totalAmount = roundMoney(nonNegative(
    booking.grandTotal !== undefined ? booking.grandTotal : booking.totalPrice,
    'booking total'
  ));
  if (!bookingId) throw new Error('bookingId is required.');
  if (totalAmount <= 0) throw new RangeError('booking total must be greater than zero.');

  const relevant = entries
    .filter((entry) => upper(entry.bookingId) === bookingId)
    .filter((entry) => upper(entry.status || LEDGER_ENTRY_STATUSES.ACTIVE) === LEDGER_ENTRY_STATUSES.ACTIVE)
    .slice()
    .sort((a, b) => {
      const aKey = `${normalizeDate(a.entryDate)}|${text(a.entryDateTime)}|${upper(a.entryId)}`;
      const bKey = `${normalizeDate(b.entryDate)}|${text(b.entryDateTime)}|${upper(b.entryId)}`;
      return aKey.localeCompare(bKey);
    });

  let runningPaid = 0;
  const rows = relevant.map((entry) => {
    const signedAmount = getSignedAmount(entry);
    runningPaid = roundMoney(runningPaid + signedAmount);
    if (runningPaid < 0) throw new RangeError('Ledger running paid amount cannot be negative.');
    if (runningPaid > totalAmount) throw new RangeError('Ledger running paid amount cannot exceed booking total.');
    const balance = roundMoney(totalAmount - runningPaid);
    return Object.freeze({
      ...entry,
      signedAmount,
      runningPaid,
      balance,
      paymentPercent: roundMoney((runningPaid / totalAmount) * 100),
    });
  });

  const finalPaid = rows.length ? rows[rows.length - 1].runningPaid : 0;
  const balanceAmount = roundMoney(totalAmount - finalPaid);

  return Object.freeze({
    bookingId,
    totalAmount,
    rows: Object.freeze(rows),
    summary: Object.freeze({
      entryCount: rows.length,
      totalPaid: finalPaid,
      balanceAmount,
      paymentPercent: roundMoney((finalPaid / totalAmount) * 100),
      paymentStage: finalPaid === 0 ? 'UNPAID' : finalPaid === totalAmount ? 'FULL' : 'PARTIAL',
      soldEligible: finalPaid === totalAmount,
    }),
  });
}
function voidLedgerEntry({ entry, actorId, reason, voidedAt }) {
  if (!entry || typeof entry !== 'object') throw new TypeError('entry is required.');
  if (upper(entry.status) === LEDGER_ENTRY_STATUSES.VOID) throw new Error('Ledger entry is already void.');
  const cleanReason = text(reason).replace(/\s+/g, ' ');
  if (cleanReason.length < 5) throw new Error('Void reason must contain at least 5 characters.');
  const cleanActorId = upper(actorId);
  if (!cleanActorId) throw new Error('actorId is required.');
  return Object.freeze({
    ...entry,
    status: LEDGER_ENTRY_STATUSES.VOID,
    voidReason: cleanReason,
    voidedAt: text(voidedAt) || new Date().toISOString(),
    voidedBy: cleanActorId,
  });
}
function createPaymentLedgerEntry(payment, options = {}) {
  if (!payment || typeof payment !== 'object') throw new TypeError('payment is required.');
  return createLedgerEntry({
    entryId: options.entryId || `LE-${upper(payment.paymentId)}`,
    bookingId: payment.bookingId,
    type: LEDGER_ENTRY_TYPES.PAYMENT,
    amount: payment.amount,
    entryDate: payment.paymentDate,
    entryDateTime: payment.createdAt || options.entryDateTime,
    paymentId: payment.paymentId,
    receiptNumber: payment.receiptNumber,
    referenceNumber: payment.referenceNumber,
    paymentMode: payment.mode || payment.paymentMode,
    notes: payment.notes,
    actorId: payment.actorId,
  });
}
function createReversalLedgerEntry(originalEntry, options = {}) {
  if (!originalEntry || typeof originalEntry !== 'object') throw new TypeError('originalEntry is required.');
  return createLedgerEntry({
    entryId: options.entryId,
    bookingId: originalEntry.bookingId,
    type: LEDGER_ENTRY_TYPES.REVERSAL,
    amount: originalEntry.amount,
    entryDate: options.entryDate,
    entryDateTime: options.entryDateTime,
    reversalOfEntryId: originalEntry.entryId,
    paymentId: originalEntry.paymentId,
    receiptNumber: originalEntry.receiptNumber,
    referenceNumber: originalEntry.referenceNumber,
    paymentMode: originalEntry.paymentMode,
    notes: options.notes || 'Payment reversal',
    actorId: options.actorId,
  });
}

class LedgerEngine {
  createEntry(input) { return createLedgerEntry(input); }
  createPaymentEntry(payment, options) { return createPaymentLedgerEntry(payment, options); }
  createReversalEntry(originalEntry, options) { return createReversalLedgerEntry(originalEntry, options); }
  ensureUnique(entryId, existingEntries) { return ensureUniqueEntryId(entryId, existingEntries); }
  validateReversal(entry, existingEntries) { return validateReversal(entry, existingEntries); }
  build(input) { return buildLedger(input); }
  void(input) { return voidLedgerEntry(input); }
}

module.exports = {
  LEDGER_ENTRY_TYPES,
  LEDGER_ENTRY_STATUSES,
  createLedgerEntry,
  getSignedAmount,
  ensureUniqueEntryId,
  validateReversal,
  buildLedger,
  voidLedgerEntry,
  createPaymentLedgerEntry,
  createReversalLedgerEntry,
  LedgerEngine,
};
