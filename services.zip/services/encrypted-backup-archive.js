'use strict';

const crypto = require('crypto');

const FORMAT = 'FALCON_ENCRYPTED_BACKUP_V1';
const CIPHER = 'aes-256-gcm';
const KDF = 'scrypt';
const KEY_LENGTH = 32;

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function requirePassword(password) {
  const value = String(password || '');
  if (value.length < 8) {
    throw new Error('Backup password must be at least 8 characters.');
  }
  return value;
}

function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  const keys = Object.keys(value).sort();
  return `{${keys.map(k => `${JSON.stringify(k)}:${stableStringify(value[k])}`).join(',')}}`;
}

function sha256(value) {
  return crypto.createHash('sha256')
    .update(typeof value === 'string' ? value : stableStringify(value))
    .digest('hex');
}

function deriveKey(password, salt) {
  requirePassword(password);
  if (!Buffer.isBuffer(salt) || salt.length < 16) {
    throw new Error('A valid salt is required.');
  }
  return crypto.scryptSync(password, salt, KEY_LENGTH);
}

function createEncryptedBackupArchive({
  backupId,
  password,
  manifest,
  data,
  createdAt,
} = {}) {
  const id = text(backupId || (manifest && manifest.backupId)).toUpperCase();
  if (!id) throw new Error('backupId is required.');
  if (!manifest || typeof manifest !== 'object') throw new TypeError('manifest is required.');
  requirePassword(password);

  const payload = {
    backupId: id,
    manifest,
    data: data === undefined ? {} : data,
  };

  const plaintext = Buffer.from(stableStringify(payload), 'utf8');
  const payloadHash = sha256(plaintext.toString('utf8'));
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);
  const key = deriveKey(password, salt);

  const cipher = crypto.createCipheriv(CIPHER, key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const authTag = cipher.getAuthTag();

  const header = {
    format: FORMAT,
    version: 1,
    cipher: CIPHER,
    kdf: KDF,
    backupId: id,
    createdAt: text(createdAt) || new Date().toISOString(),
    salt: salt.toString('base64'),
    iv: iv.toString('base64'),
    authTag: authTag.toString('base64'),
    payloadHash,
    encryptedBytes: encrypted.length,
  };

  return Object.freeze({
    header: Object.freeze(header),
    ciphertext: encrypted.toString('base64'),
  });
}

function validateArchiveStructure(archive) {
  if (!archive || typeof archive !== 'object') throw new TypeError('archive is required.');
  if (!archive.header || typeof archive.header !== 'object') throw new Error('Archive header is missing.');
  if (archive.header.format !== FORMAT) throw new Error('Unsupported backup archive format.');
  if (archive.header.version !== 1) throw new Error('Unsupported backup archive version.');
  if (archive.header.cipher !== CIPHER) throw new Error('Unsupported backup cipher.');
  if (archive.header.kdf !== KDF) throw new Error('Unsupported backup key derivation.');
  if (!text(archive.ciphertext)) throw new Error('Encrypted backup payload is missing.');
  return true;
}

function decryptBackupArchive({ archive, password } = {}) {
  validateArchiveStructure(archive);
  requirePassword(password);

  try {
    const salt = Buffer.from(archive.header.salt, 'base64');
    const iv = Buffer.from(archive.header.iv, 'base64');
    const authTag = Buffer.from(archive.header.authTag, 'base64');
    const ciphertext = Buffer.from(archive.ciphertext, 'base64');
    const key = deriveKey(password, salt);

    const decipher = crypto.createDecipheriv(CIPHER, key, iv);
    decipher.setAuthTag(authTag);

    const plaintext = Buffer.concat([
      decipher.update(ciphertext),
      decipher.final(),
    ]).toString('utf8');

    if (sha256(plaintext) !== archive.header.payloadHash) {
      throw new Error('Backup payload integrity check failed.');
    }

    const payload = JSON.parse(plaintext);

    if (text(payload.backupId).toUpperCase() !== text(archive.header.backupId).toUpperCase()) {
      throw new Error('Backup ID mismatch.');
    }

    return Object.freeze({
      backupId: payload.backupId,
      manifest: Object.freeze(payload.manifest),
      data: Object.freeze(payload.data),
      payloadHash: archive.header.payloadHash,
    });
  } catch (error) {
    if (
      /integrity check failed|Backup ID mismatch|Unexpected token|JSON/.test(error.message)
    ) {
      throw error;
    }
    throw new Error('Unable to decrypt backup. Password is incorrect or archive is damaged.');
  }
}

function serializeEncryptedArchive(archive) {
  validateArchiveStructure(archive);
  return JSON.stringify(archive, null, 2);
}

function parseEncryptedArchive(serialized) {
  let archive;
  try {
    archive = JSON.parse(String(serialized));
  } catch {
    throw new Error('Backup archive file is not valid JSON.');
  }
  validateArchiveStructure(archive);
  return archive;
}

function createRestoreSecurityPreview({ archive } = {}) {
  validateArchiveStructure(archive);
  return Object.freeze({
    backupId: archive.header.backupId,
    createdAt: archive.header.createdAt,
    encrypted: true,
    cipher: archive.header.cipher,
    kdf: archive.header.kdf,
    payloadHash: archive.header.payloadHash,
    encryptedBytes: archive.header.encryptedBytes,
    requiresPassword: true,
  });
}

function verifyEncryptedArchive({ archive, password } = {}) {
  try {
    const payload = decryptBackupArchive({ archive, password });
    return Object.freeze({
      valid: true,
      decryptable: true,
      integrityValid: true,
      backupId: payload.backupId,
      manifest: payload.manifest,
    });
  } catch (error) {
    return Object.freeze({
      valid: false,
      decryptable: false,
      integrityValid: false,
      error: error.message,
    });
  }
}

class EncryptedBackupArchiveService {
  create(input) {
    return createEncryptedBackupArchive(input);
  }
  decrypt(input) {
    return decryptBackupArchive(input);
  }
  verify(input) {
    return verifyEncryptedArchive(input);
  }
  serialize(archive) {
    return serializeEncryptedArchive(archive);
  }
  parse(serialized) {
    return parseEncryptedArchive(serialized);
  }
  preview(input) {
    return createRestoreSecurityPreview(input);
  }
}

module.exports = {
  FORMAT,
  CIPHER,
  KDF,
  KEY_LENGTH,
  text,
  requirePassword,
  stableStringify,
  sha256,
  deriveKey,
  createEncryptedBackupArchive,
  validateArchiveStructure,
  decryptBackupArchive,
  serializeEncryptedArchive,
  parseEncryptedArchive,
  createRestoreSecurityPreview,
  verifyEncryptedArchive,
  EncryptedBackupArchiveService,
};
