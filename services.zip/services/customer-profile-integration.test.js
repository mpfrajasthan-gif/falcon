'use strict';

const assert = require('assert');

const {
  normalizeDate,
  normalizeCustomer,
  normalizeBooking,
  normalizeReceipt,
  normalizeDocument,
  buildCustomerProfile,
  buildCustomerProfileViewModel,
  buildCustomerProfileActions,
  CustomerProfileIntegrationService,
} = require('./customer-profile-integration');

(() => {
  console.log('Falcon Customer Profile Integration Tests');
  console.log('-----------------------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  const customer = {
    customerId: 'FC-000001',
    customerName: 'Shadab Aziz',
    mobile: '9876543210',
    alternateMobile: '9123456780',
    email: 'shadab@example.com',
    address: 'Sawai Madhopur',
    dob: '09-03-1978',
    status: 'ACTIVE',
  };

  const bookings = [
    {
      bookingId: 'FB-000001',
      customerId: 'FC-000001',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '43',
      bookingDate: '29-07-2026',
      grandTotal: 500000,
      paidAmount: 125000,
      balanceAmount: 375000,
      status: 'BOOKED',
    },
    {
      bookingId: 'FB-000002',
      customerId: 'FC-000001',
      projectId: 'FP-000002',
      projectName: 'Sawai Estate',
      plotNumber: '8',
      bookingDate: '25-07-2026',
      grandTotal: 450000,
      paidAmount: 450000,
      balanceAmount: 0,
      status: 'SOLD',
    },
    {
      bookingId: 'FB-000003',
      customerId: 'FC-000001',
      projectId: 'FP-000003',
      projectName: 'Old Project',
      plotNumber: '2',
      bookingDate: '20-07-2026',
      grandTotal: 200000,
      paidAmount: 0,
      balanceAmount: 200000,
      status: 'CANCELLED',
    },
  ];

  const receipts = [
    {
      receiptNumber: 'RCP-000001',
      bookingId: 'FB-000001',
      paymentId: 'PAY-000001',
      customerId: 'FC-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '43',
      paymentDate: '29-07-2026',
      currentPayment: 125000,
      balanceAmount: 375000,
      paymentMode: 'UPI',
      status: 'ISSUED',
    },
    {
      receiptNumber: 'RCP-000002',
      bookingId: 'FB-000002',
      paymentId: 'PAY-000002',
      customerId: 'FC-000001',
      projectName: 'Sawai Estate',
      plotNumber: '8',
      paymentDate: '25-07-2026',
      currentPayment: 450000,
      balanceAmount: 0,
      paymentMode: 'BANK_TRANSFER',
      status: 'ISSUED',
    },
    {
      receiptNumber: 'RCP-000003',
      bookingId: 'FB-000001',
      paymentId: 'PAY-000003',
      customerId: 'FC-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '43',
      paymentDate: '29-07-2026',
      currentPayment: 10000,
      balanceAmount: 365000,
      paymentMode: 'CASH',
      status: 'CANCELLED',
    },
  ];

  const documents = [
    {
      documentId: 'DOC-000001',
      customerId: 'FC-000001',
      type: 'PHOTO',
      filePath: 'customers/FC-000001/photo.jpg',
      status: 'ACTIVE',
    },
    {
      documentId: 'DOC-000002',
      customerId: 'FC-000001',
      type: 'AADHAAR',
      maskedReference: 'XXXX-XXXX-9012',
      filePath: 'customers/FC-000001/aadhaar.pdf',
      status: 'ACTIVE',
    },
    {
      documentId: 'DOC-000003',
      customerId: 'FC-000001',
      type: 'PAN',
      maskedReference: 'ABXXXX234F',
      filePath: 'customers/FC-000001/pan.pdf',
      status: 'ARCHIVED',
    },
  ];

  check(normalizeDate('09-03-1978'), '1978-03-09');
  check(normalizeCustomer(customer).customerId, 'FC-000001');
  check(normalizeBooking(bookings[0]).bookingId, 'FB-000001');
  check(normalizeReceipt(receipts[0]).receiptNumber, 'RCP-000001');
  check(normalizeDocument(documents[0]).documentId, 'DOC-000001');

  const profile = buildCustomerProfile({
    customer,
    bookings,
    receipts,
    documents,
  });

  check(profile.customer.customerName, 'Shadab Aziz');
  check(profile.customer.dob, '1978-03-09');
  check(profile.summary.bookingCount, 3);
  check(profile.summary.activeBookingCount, 2);
  check(profile.summary.soldBookingCount, 1);
  check(profile.summary.pendingBookingCount, 1);
  check(profile.summary.receiptCount, 2);
  check(profile.summary.documentCount, 2);
  check(profile.summary.identityDocumentCount, 1);
  check(profile.summary.hasPhoto, true);
  check(profile.summary.hasIdentityProof, true);
  check(profile.summary.totalBookingValue, 950000);
  check(profile.summary.totalPaid, 575000);
  check(profile.summary.totalBalance, 375000);

  check(profile.photo.documentId, 'DOC-000001');
  check(profile.identityDocuments[0].documentId, 'DOC-000002');
  check(profile.plots.length, 2);
  check(profile.plots[0].bookingId, 'FB-000001');
  check(profile.recentBookings.length, 3);
  check(profile.recentBookings[0].bookingId, 'FB-000001');
  check(profile.recentReceipts.length, 2);
  check(profile.recentReceipts[0].receiptNumber, 'RCP-000001');

  const viewModel = buildCustomerProfileViewModel(profile);

  check(viewModel.header.customerName, 'Shadab Aziz');
  check(viewModel.header.photoPath, 'customers/FC-000001/photo.jpg');
  check(viewModel.cards.totalPlots, 2);
  check(viewModel.cards.soldPlots, 1);
  check(viewModel.cards.pendingBookings, 1);
  check(viewModel.cards.totalBookingValue, 950000);
  check(viewModel.cards.totalPaid, 575000);
  check(viewModel.cards.totalBalance, 375000);
  check(viewModel.verification.hasPhoto, true);
  check(viewModel.verification.hasIdentityProof, true);

  const actions = buildCustomerProfileActions(profile);

  check(actions.length, 4);
  check(actions[0].target, 'BOOKING_LIST');
  check(actions[0].filter.customerId, 'FC-000001');
  check(actions[1].target, 'CUSTOMER_RECEIPTS');
  check(actions[2].target, 'CUSTOMER_STATEMENT');
  check(actions[2].value, 375000);
  check(actions[3].target, 'CUSTOMER_DOCUMENTS');

  const service = new CustomerProfileIntegrationService();

  const serviceProfile = service.build({
    customer,
    bookings,
    receipts,
    documents,
  });

  check(serviceProfile.summary.totalBalance, 375000);

  const serviceView = service.viewModel(serviceProfile);
  check(serviceView.cards.receipts, 2);

  const serviceActions = service.actions(serviceProfile);
  checkTrue(serviceActions.some((action) => action.id === 'OPEN_STATEMENT'));

  assert.throws(
    () =>
      buildCustomerProfile({
        customer,
        bookings: {},
        receipts,
        documents,
      }),
    /must be arrays/
  );
  assertions += 1;

  assert.throws(
    () =>
      normalizeCustomer({
        customerName: 'Missing ID',
      }),
    /customerId is required/
  );
  assertions += 1;

  console.log('Customer Basic Profile: PASS');
  console.log('Photo Integration: PASS');
  console.log('Identity Verification Summary: PASS');
  console.log('Plot / Booking Summary: PASS');
  console.log('Receipt Summary: PASS');
  console.log('Paid / Pending Summary: PASS');
  console.log('Recent Booking List: PASS');
  console.log('Recent Receipt List: PASS');
  console.log('Customer Profile View Model: PASS');
  console.log('Clickable Profile Actions: PASS');
  console.log('Reusable Customer Profile Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('-----------------------------------------');
  console.log('CUSTOMER PROFILE INTEGRATION TEST PASS');
})();
