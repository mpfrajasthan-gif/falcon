'use strict';

const assert = require('assert');

const {
  normalizeVertex,
  extractVertices,
  detectClosed,
  mapLegacyEntity,
  detectEntityArray,
  adaptParserOutput,
  runExistingEngineAdapter,
  createAdapterDiagnostics,
  ExistingDxfEngineAdapterService,
} = require('./dxf-existing-engine-adapter');

(() => {
  console.log('Falcon DXF Existing Engine Adapter Tests');
  console.log('----------------------------------------');

  let assertions = 0;

  const check = (actual, expected) => {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  };

  const yes = (value) => {
    assert.strictEqual(value, true);
    assertions += 1;
  };

  const no = (value) => {
    assert.strictEqual(value, false);
    assertions += 1;
  };

  check(normalizeVertex({ X: 10, Y: 20 }), { x: 10, y: 20 });
  check(normalizeVertex([5, 7]), { x: 5, y: 7 });

  const points = extractVertices({
    points: [
      { x: 0, y: 0 },
      { x: 10, y: 0 },
      { x: 10, y: 10 },
      { x: 0, y: 10 },
    ],
  });

  check(points.length, 4);
  check(points[2], { x: 10, y: 10 });
  yes(detectClosed({ flags: 1 }, points));

  const mapped = mapLegacyEntity({
    entityId: 'ent-1',
    handle: 'aa1',
    entityType: 'lwpolyline',
    layerName: ' plot ',
    isClosed: true,
    points,
  });

  check(mapped.id, 'ENT-1');
  check(mapped.handle, 'AA1');
  check(mapped.type, 'LWPOLYLINE');
  check(mapped.layer, 'PLOT');
  yes(mapped.closed);
  check(mapped.vertices.length, 4);

  const legacyOutput = {
    data: {
      entities: [
        {
          handle: 'P1',
          type: 'LWPOLYLINE',
          layer: 'PLOT',
          flags: 1,
          vertices: [
            { x: 0, y: 0 },
            { x: 20, y: 0 },
            { x: 20, y: 10 },
            { x: 0, y: 10 },
          ],
        },
        {
          handle: 'R1',
          type: 'LINE',
          layer: 'ROAD',
          vertices: [
            { x: 0, y: -5 },
            { x: 20, y: -5 },
          ],
        },
        {
          handle: 'B1',
          type: 'LWPOLYLINE',
          layer: 'SCHEME_BOUNDARY',
          closed: true,
          vertices: [
            { x: -5, y: -10 },
            { x: 25, y: -10 },
            { x: 25, y: 15 },
            { x: -5, y: 15 },
          ],
        },
      ],
    },
  };

  check(detectEntityArray(legacyOutput).length, 3);

  const adapted = adaptParserOutput(legacyOutput);
  check(adapted.sourceEntityCount, 3);
  check(adapted.entities.length, 3);
  check(adapted.entities[0].handle, 'P1');

  const result = runExistingEngineAdapter({
    parserOutput: legacyOutput,
    projectId: 'FP-000001',
    unit: 'MM',
  });

  yes(result.audit.summary.pass);
  yes(result.readyForPlotCore);
  check(result.handoff.plotCount, 1);
  check(result.handoff.projectId, 'FP-000001');
  check(result.handoff.plots[0].computedArea, 200);

  const diagnostics = createAdapterDiagnostics(result);
  check(diagnostics.sourceEntityCount, 3);
  check(diagnostics.errorCount, 0);
  check(diagnostics.warningCount, 0);
  check(diagnostics.plotCount, 1);
  yes(diagnostics.readyForPlotCore);

  const badOutput = {
    entities: [
      {
        handle: 'BAD-P1',
        type: 'LWPOLYLINE',
        layer: 'PLOT',
        closed: false,
        vertices: [
          { x: 0, y: 0 },
          { x: 10, y: 0 },
          { x: 10, y: 10 },
          { x: 0, y: 10 },
        ],
      },
      {
        handle: 'M1',
        type: 'TEXT',
        layer: 'UNMAPPED-LAYER',
        value: 'Test',
      },
    ],
  };

  const badResult = runExistingEngineAdapter({
    parserOutput: badOutput,
    projectId: 'FP-000002',
  });

  no(badResult.audit.summary.pass);
  no(badResult.readyForPlotCore);
  check(badResult.handoff, null);
  yes(badResult.audit.issues.some((issue) => issue.code === 'OPEN_PLOT_POLYGON'));
  yes(badResult.audit.issues.some((issue) => issue.code === 'UNKNOWN_LAYER'));

  const badDiagnostics = createAdapterDiagnostics(badResult);
  check(badDiagnostics.plotCount, 0);
  check(badDiagnostics.unknownLayers.length, 1);
  check(badDiagnostics.unknownLayers[0], 'UNMAPPED-LAYER');

  const customLayerOutput = {
    document: {
      entities: [
        {
          id: 'CP1',
          kind: 'POLYLINE',
          group: 'PLOT-POLYGON',
          closed: true,
          coordinates: [
            [0, 0],
            [5, 0],
            [5, 5],
            [0, 5],
          ],
        },
      ],
    },
  };

  const customResult = runExistingEngineAdapter({
    parserOutput: customLayerOutput,
    projectId: 'FP-000003',
    layerRules: {
      plot: ['PLOT-POLYGON'],
    },
  });

  yes(customResult.readyForPlotCore);
  check(customResult.handoff.plotCount, 1);
  check(customResult.handoff.plots[0].computedArea, 25);

  assert.throws(
    () => detectEntityArray({ somethingElse: [] }),
    /Could not locate DXF entity array/
  );
  assertions += 1;

  const service = new ExistingDxfEngineAdapterService();

  check(
    service.mapEntity({
      id: 'X1',
      type: 'TEXT',
      layer: 'ROAD',
      label: '40 FT ROAD',
    }).text,
    '40 FT ROAD'
  );

  yes(
    service.run({
      parserOutput: legacyOutput,
      projectId: 'FP-000004',
    }).readyForPlotCore
  );

  console.log('Legacy Vertex Mapping: PASS');
  console.log('Legacy Entity Mapping: PASS');
  console.log('Parser Output Detection: PASS');
  console.log('Existing Parser Adaptation: PASS');
  console.log('DXF.1 Audit Bridge Integration: PASS');
  console.log('Plot Core Handoff Integration: PASS');
  console.log('Bad Geometry Blocking: PASS');
  console.log('Unknown Layer Diagnostics: PASS');
  console.log('Custom Layer Rule Mapping: PASS');
  console.log('Reusable Existing Engine Adapter: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('----------------------------------------');
  console.log('DXF EXISTING ENGINE ADAPTER TEST PASS');
})();
