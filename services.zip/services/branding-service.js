'use strict';

const fs = require('fs');
const path = require('path');

const DEFAULT_BRANDING = Object.freeze({
  appName: 'Falcon',
  productName: 'Falcon Hybrid',
  shortName: 'Falcon',
  companyName: '',
  developerText: 'Concept Design and Developed by Shadab Aziz',
  poweredBy: 'Powered by Falcon',
  windowTitle: 'Falcon Hybrid',
  receiptTitle: 'Payment Receipt',
  supportEmail: '',
  supportPhone: '',
  website: '',
  logoPath: 'assets/branding/logo.png',
  iconPath: 'assets/branding/app.ico',
  splashLogoPath: 'assets/branding/logo.png',
  installerProductName: 'Falcon Hybrid',
  installerShortcutName: 'Falcon Hybrid',
});

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function normalizeBranding(input = {}) {
  const branding = {
    ...DEFAULT_BRANDING,
    ...(input || {}),
  };

  branding.appName = text(branding.appName);
  branding.productName = text(branding.productName);
  branding.shortName = text(branding.shortName);
  branding.companyName = text(branding.companyName);
  branding.developerText = text(branding.developerText);
  branding.poweredBy = text(branding.poweredBy);
  branding.windowTitle = text(branding.windowTitle);
  branding.receiptTitle = text(branding.receiptTitle);
  branding.supportEmail = text(branding.supportEmail);
  branding.supportPhone = text(branding.supportPhone);
  branding.website = text(branding.website);
  branding.logoPath = text(branding.logoPath);
  branding.iconPath = text(branding.iconPath);
  branding.splashLogoPath = text(branding.splashLogoPath);
  branding.installerProductName = text(branding.installerProductName);
  branding.installerShortcutName = text(branding.installerShortcutName);

  if (!branding.appName) throw new Error('appName is required.');
  if (!branding.productName) throw new Error('productName is required.');
  if (!branding.shortName) throw new Error('shortName is required.');
  if (!branding.windowTitle) branding.windowTitle = branding.productName;
  if (!branding.installerProductName) branding.installerProductName = branding.productName;
  if (!branding.installerShortcutName) branding.installerShortcutName = branding.shortName;

  return Object.freeze(branding);
}

function resolveConfigPath(baseDir, configPath = 'config/branding.json') {
  if (!baseDir) throw new Error('baseDir is required.');
  return path.resolve(baseDir, configPath);
}

function loadBranding(baseDir, configPath = 'config/branding.json') {
  const fullPath = resolveConfigPath(baseDir, configPath);

  if (!fs.existsSync(fullPath)) {
    return normalizeBranding(DEFAULT_BRANDING);
  }

  let parsed;
  try {
    parsed = JSON.parse(fs.readFileSync(fullPath, 'utf8'));
  } catch (error) {
    throw new Error(`Invalid branding config: ${error.message}`);
  }

  return normalizeBranding(parsed);
}

function resolveAssetPath(baseDir, assetPath) {
  const clean = text(assetPath);
  if (!clean) return '';
  return path.resolve(baseDir, clean);
}

function buildBrandingContext(baseDir, branding) {
  const normalized = normalizeBranding(branding);

  return Object.freeze({
    ...normalized,
    logoAbsolutePath: resolveAssetPath(baseDir, normalized.logoPath),
    iconAbsolutePath: resolveAssetPath(baseDir, normalized.iconPath),
    splashLogoAbsolutePath: resolveAssetPath(baseDir, normalized.splashLogoPath),
  });
}

function applyTemplate(template, branding) {
  const normalized = normalizeBranding(branding);
  return String(template).replace(/\{\{brand\.([a-zA-Z0-9_]+)\}\}/g, (_, key) => {
    return Object.prototype.hasOwnProperty.call(normalized, key)
      ? String(normalized[key])
      : '';
  });
}

function buildInstallerBranding(branding) {
  const normalized = normalizeBranding(branding);

  return Object.freeze({
    productName: normalized.installerProductName,
    shortcutName: normalized.installerShortcutName,
    appIdSafeName: normalized.shortName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'app',
    iconPath: normalized.iconPath,
  });
}

function buildReceiptBranding(branding) {
  const normalized = normalizeBranding(branding);

  return Object.freeze({
    appName: normalized.appName,
    companyName: normalized.companyName,
    title: normalized.receiptTitle,
    logoPath: normalized.logoPath,
    poweredBy: normalized.poweredBy,
    supportEmail: normalized.supportEmail,
    supportPhone: normalized.supportPhone,
    website: normalized.website,
  });
}

function buildUiBranding(branding) {
  const normalized = normalizeBranding(branding);

  return Object.freeze({
    appName: normalized.appName,
    productName: normalized.productName,
    shortName: normalized.shortName,
    windowTitle: normalized.windowTitle,
    logoPath: normalized.logoPath,
    splashLogoPath: normalized.splashLogoPath,
    developerText: normalized.developerText,
  });
}

class BrandingService {
  constructor({ baseDir, configPath = 'config/branding.json' }) {
    if (!baseDir) throw new Error('baseDir is required.');
    this.baseDir = baseDir;
    this.configPath = configPath;
  }

  load() {
    return loadBranding(this.baseDir, this.configPath);
  }

  context() {
    return buildBrandingContext(this.baseDir, this.load());
  }

  ui() {
    return buildUiBranding(this.load());
  }

  receipt() {
    return buildReceiptBranding(this.load());
  }

  installer() {
    return buildInstallerBranding(this.load());
  }

  template(template) {
    return applyTemplate(template, this.load());
  }
}

module.exports = {
  DEFAULT_BRANDING,
  text,
  normalizeBranding,
  resolveConfigPath,
  loadBranding,
  resolveAssetPath,
  buildBrandingContext,
  applyTemplate,
  buildInstallerBranding,
  buildReceiptBranding,
  buildUiBranding,
  BrandingService,
};
