'use strict';

const assert = require('assert');

const {
  FORMAT,
  CIPHER,
  KDF,
  requirePassword,
  sha256,
  createEncryptedBackupArchive,
  validateArchiveStructure,
  decryptBackupArchive,
  serializeEncryptedArchive,
  parseEncryptedArchive,
  createRestoreSecurityPreview,
  verifyEncryptedArchive,
  EncryptedBackupArchiveService,
} = require('./encrypted-backup-archive');

(() => {
  console.log('Falcon Encrypted Backup Archive Engine Tests');
  console.log('--------------------------------------------');

  let assertions = 0;
  const check = (a, e) => { assert.deepStrictEqual(a, e); assertions += 1; };
  const yes = v => { assert.strictEqual(v, true); assertions += 1; };
  const no = v => { assert.strictEqual(v, false); assertions += 1; };

  check(FORMAT, 'FALCON_ENCRYPTED_BACKUP_V1');
  check(CIPHER, 'aes-256-gcm');
  check(KDF, 'scrypt');
  check(requirePassword('StrongPass123'), 'StrongPass123');
  assert.throws(() => requirePassword('short'), /at least 8/); assertions += 1;
  check(sha256('falcon').length, 64);

  const manifest = {
    schemaVersion: 1,
    backupId: 'BKP-000001',
    appVersion: '1.0.0',
    sections: ['projects', 'customers', 'bookings'],
    manifestHash: 'abc123',
  };

  const data = {
    projects: [{ projectId: 'FP-000001', name: 'Jaipur Pride' }],
    customers: [{ customerId: 'FC-000001', name: 'Customer One' }],
    bookings: [{ bookingId: 'FB-000001', customerId: 'FC-000001' }],
  };

  const archive = createEncryptedBackupArchive({
    backupId: 'BKP-000001',
    password: 'FalconBackup@2026',
    manifest,
    data,
    createdAt: '2026-07-29T21:00:00.000Z',
  });

  check(archive.header.format, FORMAT);
  check(archive.header.version, 1);
  check(archive.header.cipher, CIPHER);
  check(archive.header.kdf, KDF);
  check(archive.header.backupId, 'BKP-000001');
  check(archive.header.payloadHash.length, 64);
  yes(archive.header.encryptedBytes > 0);
  yes(typeof archive.ciphertext === 'string' && archive.ciphertext.length > 0);
  yes(validateArchiveStructure(archive));

  const decrypted = decryptBackupArchive({
    archive,
    password: 'FalconBackup@2026',
  });

  check(decrypted.backupId, 'BKP-000001');
  check(decrypted.manifest.backupId, 'BKP-000001');
  check(decrypted.data.projects.length, 1);
  check(decrypted.data.customers[0].customerId, 'FC-000001');

  const serialized = serializeEncryptedArchive(archive);
  yes(serialized.includes('"ciphertext"'));

  const parsed = parseEncryptedArchive(serialized);
  check(parsed.header.backupId, 'BKP-000001');

  const preview = createRestoreSecurityPreview({ archive });
  yes(preview.encrypted);
  yes(preview.requiresPassword);
  check(preview.cipher, 'aes-256-gcm');
  check(preview.kdf, 'scrypt');

  const verified = verifyEncryptedArchive({
    archive,
    password: 'FalconBackup@2026',
  });
  yes(verified.valid);
  yes(verified.decryptable);
  yes(verified.integrityValid);

  const wrongPassword = verifyEncryptedArchive({
    archive,
    password: 'WrongPassword123',
  });
  no(wrongPassword.valid);
  no(wrongPassword.decryptable);

  const tampered = JSON.parse(JSON.stringify(archive));
  const buf = Buffer.from(tampered.ciphertext, 'base64');
  buf[0] = buf[0] ^ 1;
  tampered.ciphertext = buf.toString('base64');

  const tamperResult = verifyEncryptedArchive({
    archive: tampered,
    password: 'FalconBackup@2026',
  });
  no(tamperResult.valid);
  no(tamperResult.integrityValid);

  assert.throws(
    () => validateArchiveStructure({ header: { format: 'BAD' }, ciphertext: 'abc' }),
    /Unsupported backup archive format/
  );
  assertions += 1;

  assert.throws(
    () => parseEncryptedArchive('not-json'),
    /not valid JSON/
  );
  assertions += 1;

  const service = new EncryptedBackupArchiveService();
  const serviceArchive = service.create({
    backupId: 'BKP-000002',
    password: 'AnotherStrongPass',
    manifest: { ...manifest, backupId: 'BKP-000002' },
    data,
  });

  check(serviceArchive.header.backupId, 'BKP-000002');
  yes(service.verify({
    archive: serviceArchive,
    password: 'AnotherStrongPass',
  }).valid);

  const serviceDecoded = service.decrypt({
    archive: serviceArchive,
    password: 'AnotherStrongPass',
  });
  check(serviceDecoded.data.bookings.length, 1);

  console.log('Password Policy: PASS');
  console.log('AES-256-GCM Encryption: PASS');
  console.log('Scrypt Key Derivation: PASS');
  console.log('Encrypted Archive Creation: PASS');
  console.log('Archive Serialization: PASS');
  console.log('Password-protected Decryption: PASS');
  console.log('Wrong Password Protection: PASS');
  console.log('Ciphertext Tamper Detection: PASS');
  console.log('Payload Integrity Verification: PASS');
  console.log('Restore Security Preview: PASS');
  console.log('Reusable Encrypted Backup Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('--------------------------------------------');
  console.log('ENCRYPTED BACKUP ARCHIVE ENGINE TEST PASS');
})();
