'use strict';

const assert = require('assert');

const {
  normalizeDate,
  derivePlotStatus,
  deriveBookingStatus,
  buildDashboardSnapshot,
  buildDashboardActions,
  DashboardIntegrationService,
} = require('./dashboard-integration');

(() => {
  console.log('Falcon Dashboard Integration Tests');
  console.log('----------------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  const projects = [
    { projectId: 'FP-000001', projectName: 'Jaipur Pride' },
    { projectId: 'FP-000002', projectName: 'Sawai Estate' },
  ];

  const plots = [
    { plotId: 'PL-1', projectId: 'FP-000001', plotNumber: '1', status: 'AVAILABLE' },
    { plotId: 'PL-2', projectId: 'FP-000001', plotNumber: '2', status: 'HOLD' },
    { plotId: 'PL-3', projectId: 'FP-000001', plotNumber: '3', status: 'BOOKED' },
    { plotId: 'PL-4', projectId: 'FP-000001', plotNumber: '4', status: 'SOLD' },
    { plotId: 'PL-5', projectId: 'FP-000002', plotNumber: '5', status: 'AVAILABLE' },
    { plotId: 'PL-6', projectId: 'FP-000002', plotNumber: '6', status: 'BOOKED' },
  ];

  const bookings = [
    {
      bookingId: 'FB-000001',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '3',
      customerName: 'Customer One',
      bookingDate: '29-07-2026',
      grandTotal: 500000,
      paidAmount: 125000,
      balanceAmount: 375000,
      status: 'BOOKED',
    },
    {
      bookingId: 'FB-000002',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '4',
      customerName: 'Customer Two',
      bookingDate: '28-07-2026',
      grandTotal: 300000,
      paidAmount: 300000,
      balanceAmount: 0,
      status: 'SOLD',
    },
    {
      bookingId: 'FB-000003',
      projectId: 'FP-000002',
      projectName: 'Sawai Estate',
      plotNumber: '6',
      customerName: 'Customer Three',
      bookingDate: '29-07-2026',
      grandTotal: 450000,
      paidAmount: 50000,
      balanceAmount: 400000,
      status: 'BOOKED',
    },
    {
      bookingId: 'FB-000004',
      projectId: 'FP-000002',
      projectName: 'Sawai Estate',
      plotNumber: '7',
      customerName: 'Cancelled Customer',
      bookingDate: '29-07-2026',
      grandTotal: 250000,
      paidAmount: 0,
      balanceAmount: 250000,
      status: 'CANCELLED',
    },
  ];

  const payments = [
    {
      paymentId: 'PAY-000001',
      bookingId: 'FB-000001',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      amount: 100000,
      paymentDate: '29-07-2026',
      status: 'POSTED',
      mode: 'CASH',
    },
    {
      paymentId: 'PAY-000002',
      bookingId: 'FB-000001',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      amount: 25000,
      paymentDate: '29-07-2026',
      status: 'POSTED',
      mode: 'UPI',
    },
    {
      paymentId: 'PAY-000003',
      bookingId: 'FB-000002',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      amount: 300000,
      paymentDate: '28-07-2026',
      status: 'POSTED',
      mode: 'BANK_TRANSFER',
    },
    {
      paymentId: 'PAY-000004',
      bookingId: 'FB-000003',
      projectId: 'FP-000002',
      projectName: 'Sawai Estate',
      amount: 50000,
      paymentDate: '29-07-2026',
      status: 'POSTED',
      mode: 'CASH',
    },
    {
      paymentId: 'PAY-000005',
      bookingId: 'FB-000003',
      projectId: 'FP-000002',
      projectName: 'Sawai Estate',
      amount: 50000,
      paymentDate: '29-07-2026',
      status: 'REVERSED',
      mode: 'CASH',
    },
  ];

  check(normalizeDate('29-07-2026'), '2026-07-29');
  check(derivePlotStatus({ status: 'sold' }), 'SOLD');
  check(deriveBookingStatus(bookings[0]), 'BOOKED');
  check(deriveBookingStatus(bookings[1]), 'SOLD');

  const snapshot = buildDashboardSnapshot({
    projects,
    plots,
    bookings,
    payments,
    today: '29-07-2026',
    recentLimit: 3,
  });

  check(snapshot.generatedForDate, '2026-07-29');

  check(snapshot.cards.totalProjects, 2);
  check(snapshot.cards.totalPlots, 6);
  check(snapshot.cards.availablePlots, 2);
  check(snapshot.cards.holdPlots, 1);
  check(snapshot.cards.bookedPlots, 2);
  check(snapshot.cards.soldPlots, 1);

  check(snapshot.cards.totalBookings, 4);
  check(snapshot.cards.activeBookings, 2);
  check(snapshot.cards.soldBookings, 1);
  check(snapshot.cards.cancelledBookings, 1);

  check(snapshot.cards.totalBookingValue, 1250000);
  check(snapshot.cards.totalPaid, 475000);
  check(snapshot.cards.totalBalance, 775000);
  check(snapshot.cards.totalCollected, 475000);
  check(snapshot.cards.todayCollection, 175000);
  check(snapshot.cards.todayBookingCount, 2);

  check(snapshot.plotCounts.total, 6);
  check(snapshot.bookingCounts.total, 4);

  check(snapshot.recentBookings.length, 3);
  check(snapshot.recentPayments.length, 3);

  check(snapshot.projectSummary.length, 2);

  const jaipur = snapshot.projectSummary.find(
    (row) => row.projectId === 'FP-000001'
  );

  check(jaipur.projectName, 'Jaipur Pride');
  check(jaipur.plotCount, 4);
  check(jaipur.availablePlots, 1);
  check(jaipur.holdPlots, 1);
  check(jaipur.bookedPlots, 1);
  check(jaipur.soldPlots, 1);
  check(jaipur.bookingCount, 2);
  check(jaipur.bookingValue, 800000);
  check(jaipur.paidAmount, 425000);
  check(jaipur.balanceAmount, 375000);
  check(jaipur.collection, 425000);

  const sawai = snapshot.projectSummary.find(
    (row) => row.projectId === 'FP-000002'
  );

  check(sawai.projectName, 'Sawai Estate');
  check(sawai.plotCount, 2);
  check(sawai.bookingCount, 1);
  check(sawai.bookingValue, 450000);
  check(sawai.paidAmount, 50000);
  check(sawai.balanceAmount, 400000);
  check(sawai.collection, 50000);

  const actions = buildDashboardActions(snapshot);

  check(actions.length, 6);
  check(actions[0].target, 'PROJECT_LIST');
  check(actions[1].filter.status, 'AVAILABLE');
  check(actions[2].filter.status, 'HOLD');
  check(actions[4].target, 'PENDING_PAYMENT_REPORT');
  check(actions[4].value, 775000);
  check(actions[5].value, 175000);
  check(actions[5].filter.dateFrom, '2026-07-29');
  check(actions[5].filter.dateTo, '2026-07-29');

  const service = new DashboardIntegrationService();
  const serviceSnapshot = service.build({
    projects,
    plots,
    bookings,
    payments,
    today: '2026-07-29',
  });

  check(serviceSnapshot.cards.totalProjects, 2);
  check(serviceSnapshot.cards.totalCollected, 475000);

  const serviceActions = service.actions(serviceSnapshot);
  checkTrue(serviceActions.some((action) => action.id === 'OPEN_BOOKINGS'));
  checkTrue(serviceActions.some((action) => action.id === 'OPEN_TODAY_COLLECTION'));

  assert.throws(
    () =>
      buildDashboardSnapshot({
        projects: {},
        plots,
        bookings,
        payments,
      }),
    /must be arrays/
  );
  assertions += 1;

  console.log('Project Count Integration: PASS');
  console.log('Plot Status Cards: PASS');
  console.log('Booking Status Cards: PASS');
  console.log('Booking Value Summary: PASS');
  console.log('Collection Summary: PASS');
  console.log('Today Collection: PASS');
  console.log('Today Booking Count: PASS');
  console.log('Recent Bookings: PASS');
  console.log('Recent Payments: PASS');
  console.log('Project-wise Dashboard Summary: PASS');
  console.log('Clickable Dashboard Actions: PASS');
  console.log('Reusable Dashboard Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('----------------------------------');
  console.log('DASHBOARD INTEGRATION TEST PASS');
})();
