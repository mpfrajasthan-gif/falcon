'use strict';

const {
  createIdentity,
} = require('../core/identity/identity-engine');

const {
  normalizeText,
  toIsoTimestamp,
} = require('../core/utilities/core-utils');

const {
  combineValidationResults,
  validateRequiredString,
} = require('../core/validation/validator');

const {
  success,
  failure,
} = require('../core/errors/result');

const {
  normalizeError,
} = require('../core/errors/falcon-error');

const {
  info,
  error: logError,
} = require('../core/logging/logger');

class ProjectService {
  constructor(projectRepository) {
    if (
      !projectRepository ||
      typeof projectRepository.create !== 'function' ||
      typeof projectRepository.findById !== 'function' ||
      typeof projectRepository.findAll !== 'function' ||
      typeof projectRepository.update !== 'function'
    ) {
      throw new TypeError(
        'A valid ProjectRepository is required.'
      );
    }

    this.projectRepository = projectRepository;
  }

  createProject(input) {
    try {
      if (!input || typeof input !== 'object') {
        throw new TypeError(
          'Project input must be an object.'
        );
      }

      const validation = combineValidationResults([
        validateRequiredString(
          input.name,
          'Project name'
        ),
      ]);

      if (!validation.valid) {
        return failure(
          'PROJECT_VALIDATION_FAILED',
          'Project information is invalid.',
          {
            errors: validation.errors,
          }
        );
      }

      const identity = createIdentity('project');
      const timestamp = toIsoTimestamp();

      const project = {
        id: identity.id,
        uuid: identity.uuid,
        name: normalizeText(input.name),
        location: normalizeText(input.location) || null,
        address: normalizeText(input.address) || null,
        reraNumber:
          normalizeText(input.reraNumber) || null,
        status:
          normalizeText(input.status) || 'ACTIVE',
        createdAt: timestamp,
        updatedAt: timestamp,
      };

      const createdProject =
        this.projectRepository.create(project);

      const result = success(
        'PROJECT_CREATED',
        'Falcon project created successfully.',
        createdProject
      );

      info('Falcon project created.', {
        projectId: createdProject.id,
        projectName: createdProject.name,
      });

      return result;
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'PROJECT_CREATE_FAILED',
        'Falcon project could not be created.'
      );
    }
  }

  getProject(projectId) {
    try {
      const project =
        this.projectRepository.findById(projectId);

      if (!project) {
        return failure(
          'PROJECT_NOT_FOUND',
          'Falcon project was not found.',
          {
            projectId,
          }
        );
      }

      return success(
        'PROJECT_FOUND',
        'Falcon project loaded successfully.',
        project
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'PROJECT_LOAD_FAILED',
        'Falcon project could not be loaded.'
      );
    }
  }

  getAllProjects() {
    try {
      const projects =
        this.projectRepository.findAll();

      return success(
        'PROJECTS_LOADED',
        'Falcon projects loaded successfully.',
        Object.freeze([...projects])
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'PROJECT_LIST_FAILED',
        'Falcon projects could not be loaded.'
      );
    }
  }

  updateProject(projectId, changes) {
    try {
      if (!changes || typeof changes !== 'object') {
        throw new TypeError(
          'Project changes must be an object.'
        );
      }

      const updateData = {
        ...changes,
        updatedAt: toIsoTimestamp(),
      };

      if (
        Object.prototype.hasOwnProperty.call(
          changes,
          'name'
        )
      ) {
        const nameValidation =
          validateRequiredString(
            changes.name,
            'Project name'
          );

        if (!nameValidation.valid) {
          return failure(
            'PROJECT_VALIDATION_FAILED',
            'Project information is invalid.',
            {
              errors: [nameValidation],
            }
          );
        }

        updateData.name = normalizeText(
          changes.name
        );
      }

      for (const field of [
        'location',
        'address',
        'reraNumber',
        'status',
      ]) {
        if (
          Object.prototype.hasOwnProperty.call(
            changes,
            field
          )
        ) {
          updateData[field] =
            normalizeText(changes[field]) || null;
        }
      }

      const updatedProject =
        this.projectRepository.update(
          projectId,
          updateData
        );

      info('Falcon project updated.', {
        projectId: updatedProject.id,
      });

      return success(
        'PROJECT_UPDATED',
        'Falcon project updated successfully.',
        updatedProject
      );
    } catch (serviceError) {
      return this.handleError(
        serviceError,
        'PROJECT_UPDATE_FAILED',
        'Falcon project could not be updated.'
      );
    }
  }

  handleError(error, fallbackCode, fallbackMessage) {
    const normalizedError = normalizeError(
      error,
      fallbackCode,
      fallbackMessage
    );

    logError(fallbackMessage, {
      code: normalizedError.code,
      message: normalizedError.message,
      details: normalizedError.details,
    });

    return failure(
      normalizedError.code,
      normalizedError.message,
      normalizedError.toJSON()
    );
  }
}

module.exports = {
  ProjectService,
};