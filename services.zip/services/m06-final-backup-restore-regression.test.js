'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const {
  createFullBackup,
} = require('./full-backup-orchestrator');

const {
  createVerifiedBackupAndRestore,
  restoreVerifiedBackup,
  buildRestoreCompletionSummary,
  FinalRestoreOrchestratorService,
} = require('./final-restore-orchestrator');

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function writeJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2), 'utf8');
}

(() => {
  console.log('Falcon M06 Final Backup/Restore Regression Tests');
  console.log('------------------------------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function yes(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  function no(value) {
    assert.strictEqual(value, false);
    assertions += 1;
  }

  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'falcon-m06-final-'));
  const backupDir = path.join(root, 'backups');
  const liveDir = path.join(root, 'live');
  const safetyDir = path.join(root, 'safety');
  const stagingDir = path.join(root, 'staging');

  writeJson(
    path.join(liveDir, 'customers.json'),
    [{ customerId: 'FC-LIVE-OLD', customerName: 'Old Live Customer' }]
  );

  writeJson(
    path.join(liveDir, 'bookings.json'),
    [{ bookingId: 'FB-LIVE-OLD', status: 'BOOKED' }]
  );

  const restoreData = {
    projects: [
      { projectId: 'FP-000001', projectName: 'Jaipur Pride' },
    ],
    plots: [
      { plotId: 'FPL-000001', projectId: 'FP-000001', plotNumber: '43', status: 'BOOKED' },
    ],
    customers: [
      { customerId: 'FC-000001', customerName: 'Customer One' },
    ],
    bookings: [
      { bookingId: 'FB-000001', customerId: 'FC-000001', plotId: 'FPL-000001' },
    ],
    payments: [
      { paymentId: 'PAY-000001', bookingId: 'FB-000001', amount: 100000, status: 'POSTED' },
    ],
    receipts: [
      { receiptNumber: 'RCP-000001', paymentId: 'PAY-000001', status: 'ISSUED' },
    ],
    ledger: [
      { ledgerId: 'LED-000001', bookingId: 'FB-000001', credit: 100000 },
    ],
    documents: [
      { documentId: 'DOC-000001', customerId: 'FC-000001', type: 'PHOTO' },
    ],
    reports: {
      generated: [],
    },
    settings: {
      areaUnit: 'sq yard',
      dateFormat: 'DD-MM-YYYY',
    },
    audit: [
      { eventId: 'AUD-000001', action: 'BACKUP_TEST' },
    ],
  };

  const finalResult = createVerifiedBackupAndRestore({
    backup: {
      backupId: 'BKP-FINAL-000001',
      password: 'FalconFinalBackup@2026',
      directoryPath: backupDir,
      appVersion: '1.0.0',
      actorId: 'FU-000001',
      sourceDevice: 'OFFICE-PC',
      projectId: 'FP-000001',
      data: restoreData,
      createdAt: '2026-07-29T22:30:00.000Z',
    },
    restore: {
      liveDataDir: liveDir,
      safetyRootDir: safetyDir,
      stagingRootDir: stagingDir,
      restoreId: 'RESTORE-FINAL-000001',
      snapshotId: 'SAFE-FINAL-000001',
      currentAppVersion: '1.0.0',
    },
  });

  yes(finalResult.completed);
  check(finalResult.stage, 'COMPLETE');
  yes(finalResult.backupResult.completed);
  yes(finalResult.backupResult.verification.fileValid);
  yes(finalResult.backupResult.verification.archiveValid);
  yes(finalResult.backupResult.verification.manifestValid);
  yes(finalResult.verification.valid);
  check(finalResult.verification.stage, 'READY');
  yes(finalResult.verification.manifestCheck.valid);
  yes(finalResult.verification.compatibility.compatible);
  yes(finalResult.restoreResult.completed);
  no(finalResult.restoreResult.rolledBack);
  yes(finalResult.restoreResult.stagingVerification.valid);
  yes(finalResult.restoreResult.applyResult.applied);

  check(readJson(path.join(liveDir, 'customers.json'))[0].customerId, 'FC-000001');
  check(readJson(path.join(liveDir, 'plots.json'))[0].plotId, 'FPL-000001');
  check(readJson(path.join(liveDir, 'payments.json'))[0].paymentId, 'PAY-000001');
  check(readJson(path.join(liveDir, 'settings.json')).dateFormat, 'DD-MM-YYYY');

  yes(
    fs.existsSync(
      path.join(
        finalResult.restoreResult.snapshot.snapshotDir,
        'customers.json'
      )
    )
  );

  check(
    readJson(
      path.join(
        finalResult.restoreResult.snapshot.snapshotDir,
        'customers.json'
      )
    )[0].customerId,
    'FC-LIVE-OLD'
  );

  const summary = buildRestoreCompletionSummary(finalResult);
  yes(summary.completed);
  yes(summary.backupVerified);
  yes(summary.safetySnapshotCreated);
  yes(summary.stagingVerified);
  yes(summary.restoreApplied);
  no(summary.rolledBack);

  const wrongPassword = restoreVerifiedBackup({
    filePath: finalResult.backupResult.filePath,
    password: 'WrongPassword123',
    liveDataDir: liveDir,
    safetyRootDir: safetyDir,
    stagingRootDir: stagingDir,
    restoreId: 'RESTORE-WRONG-PASS',
    snapshotId: 'SAFE-WRONG-PASS',
  });

  no(wrongPassword.completed);
  check(wrongPassword.stage, 'VERIFY_RESTORE');
  check(wrongPassword.verification.stage, 'DECRYPT');

  writeJson(
    path.join(liveDir, 'customers.json'),
    [{ customerId: 'FC-BEFORE-ROLLBACK', customerName: 'Rollback Customer' }]
  );

  const rollbackResult = restoreVerifiedBackup({
    filePath: finalResult.backupResult.filePath,
    password: 'FalconFinalBackup@2026',
    liveDataDir: liveDir,
    safetyRootDir: safetyDir,
    stagingRootDir: stagingDir,
    restoreId: 'RESTORE-ROLLBACK-000001',
    snapshotId: 'SAFE-ROLLBACK-000001',
    simulateFailureAfterApply: true,
  });

  no(rollbackResult.completed);
  check(rollbackResult.stage, 'GUARDED_RESTORE');
  yes(rollbackResult.restoreResult.rolledBack);
  yes(rollbackResult.restoreResult.rollback.rolledBack);

  check(
    readJson(path.join(liveDir, 'customers.json'))[0].customerId,
    'FC-BEFORE-ROLLBACK'
  );

  const incompatible = restoreVerifiedBackup({
    filePath: finalResult.backupResult.filePath,
    password: 'FalconFinalBackup@2026',
    liveDataDir: liveDir,
    safetyRootDir: safetyDir,
    stagingRootDir: stagingDir,
    restoreId: 'RESTORE-INCOMPATIBLE',
    snapshotId: 'SAFE-INCOMPATIBLE',
    supportedSchemaVersion: 99,
  });

  no(incompatible.completed);
  check(incompatible.stage, 'VERIFY_RESTORE');
  check(incompatible.verification.stage, 'COMPATIBILITY');

  const standaloneBackup = createFullBackup({
    backupId: 'BKP-FINAL-000002',
    password: 'FalconSecondBackup@2026',
    directoryPath: backupDir,
    appVersion: '1.0.0',
    actorId: 'FU-000001',
    data: restoreData,
    createdAt: '2026-07-29T22:45:00.000Z',
  });

  yes(standaloneBackup.completed);

  const service = new FinalRestoreOrchestratorService();

  const serviceRestore = service.restore({
    filePath: standaloneBackup.filePath,
    password: 'FalconSecondBackup@2026',
    liveDataDir: liveDir,
    safetyRootDir: safetyDir,
    stagingRootDir: stagingDir,
    restoreId: 'RESTORE-SERVICE-000001',
    snapshotId: 'SAFE-SERVICE-000001',
  });

  yes(serviceRestore.completed);
  check(serviceRestore.stage, 'COMPLETE');

  const serviceSummary = service.summary(serviceRestore);
  yes(serviceSummary.completed);
  yes(serviceSummary.backupVerified);
  yes(serviceSummary.safetySnapshotCreated);
  yes(serviceSummary.restoreApplied);

  console.log('M06.1 Manifest & Integrity Integration: PASS');
  console.log('M06.2 Encrypted Archive Integration: PASS');
  console.log('M06.3 Safe File Writer Integration: PASS');
  console.log('M06.4 Backup Orchestrator Integration: PASS');
  console.log('M06.5 Guarded Restore Integration: PASS');
  console.log('Full Encrypted Backup Creation: PASS');
  console.log('Post-write Backup Verification: PASS');
  console.log('Password-protected Restore Verification: PASS');
  console.log('Pre-restore Safety Snapshot: PASS');
  console.log('Restore Staging Verification: PASS');
  console.log('Full Restore Apply: PASS');
  console.log('Restored Data Consistency: PASS');
  console.log('Wrong Password Restore Block: PASS');
  console.log('Incompatible Backup Restore Block: PASS');
  console.log('Failure Rollback To Live Data: PASS');
  console.log('Reusable Final Restore Orchestrator: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('------------------------------------------------');
  console.log('M06 FINAL BACKUP/RESTORE REGRESSION TEST PASS');
})();
