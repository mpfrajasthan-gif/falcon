'use strict';

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function finiteNumber(value, fieldName) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    throw new TypeError(`${fieldName} must be a valid number.`);
  }
  return number;
}

function nonNegative(value, fieldName) {
  const number = finiteNumber(value, fieldName);
  if (number < 0) {
    throw new RangeError(`${fieldName} cannot be negative.`);
  }
  return number;
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function normalizeDate(value) {
  const raw = text(value);
  if (!raw) return '';

  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;

  const match = raw.match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (!match) return '';

  return `${match[3]}-${match[2]}-${match[1]}`;
}

function normalizeCustomer(customer = {}) {
  const customerId = upper(customer.customerId || customer.id);
  if (!customerId) throw new Error('customerId is required.');

  return Object.freeze({
    source: customer,
    customerId,
    customerName: text(customer.customerName || customer.name),
    mobile: text(customer.mobile || customer.customerMobile),
    address: text(customer.address),
    email: text(customer.email),
  });
}

function normalizeBooking(booking = {}) {
  const bookingId = upper(booking.bookingId || booking.id);
  const customerId = upper(booking.customerId);

  if (!bookingId) throw new Error('bookingId is required.');
  if (!customerId) throw new Error('booking.customerId is required.');

  const totalAmount = roundMoney(
    nonNegative(
      booking.grandTotal !== undefined ? booking.grandTotal : booking.totalPrice || 0,
      'booking total'
    )
  );
  const paidAmount = roundMoney(nonNegative(booking.paidAmount || 0, 'paidAmount'));
  const balanceAmount = roundMoney(
    booking.balanceAmount !== undefined
      ? nonNegative(booking.balanceAmount, 'balanceAmount')
      : Math.max(0, totalAmount - paidAmount)
  );

  return Object.freeze({
    source: booking,
    bookingId,
    customerId,
    projectId: upper(booking.projectId),
    projectName: text(booking.projectName),
    plotNumber: text(booking.plotNumber || booking.plotNo),
    bookingDate: normalizeDate(booking.bookingDate || booking.date || booking.createdAt),
    status: upper(booking.status || 'BOOKED'),
    totalAmount,
    paidAmount,
    balanceAmount,
  });
}

function normalizePayment(payment = {}) {
  const paymentId = upper(payment.paymentId);
  const bookingId = upper(payment.bookingId);

  if (!paymentId) throw new Error('paymentId is required.');
  if (!bookingId) throw new Error('payment.bookingId is required.');

  return Object.freeze({
    source: payment,
    paymentId,
    bookingId,
    amount: roundMoney(nonNegative(payment.amount || 0, 'payment amount')),
    paymentDate: normalizeDate(payment.paymentDate || payment.date),
    mode: upper(payment.mode || payment.paymentMode),
    status: upper(payment.status || 'POSTED'),
    receiptNumber: upper(payment.receiptNumber),
    referenceNumber: text(payment.referenceNumber),
  });
}

function normalizeReceipt(receipt = {}) {
  const receiptNumber = upper(receipt.receiptNumber);
  const bookingId = upper(receipt.bookingId);
  const paymentId = upper(receipt.paymentId);

  if (!receiptNumber) throw new Error('receiptNumber is required.');
  if (!bookingId) throw new Error('receipt.bookingId is required.');
  if (!paymentId) throw new Error('receipt.paymentId is required.');

  return Object.freeze({
    source: receipt,
    receiptNumber,
    bookingId,
    paymentId,
    customerId: upper(receipt.customerId),
    projectName: text(receipt.projectName),
    plotNumber: text(receipt.plotNumber),
    paymentDate: normalizeDate(receipt.paymentDate || receipt.receiptDate),
    currentPayment: roundMoney(
      nonNegative(
        receipt.currentPayment !== undefined ? receipt.currentPayment : receipt.amount || 0,
        'receipt payment amount'
      )
    ),
    cumulativePaid: roundMoney(nonNegative(receipt.cumulativePaid || 0, 'cumulativePaid')),
    balanceAmount: roundMoney(nonNegative(receipt.balanceAmount || 0, 'balanceAmount')),
    paymentMode: upper(receipt.paymentMode),
    referenceNumber: text(receipt.referenceNumber),
    status: upper(receipt.status || 'ISSUED'),
  });
}

function validateReceiptLinkage({
  booking,
  payment,
  receipt,
}) {
  if (!booking || !payment || !receipt) {
    throw new TypeError('booking, payment and receipt are required.');
  }

  if (booking.bookingId !== payment.bookingId) {
    throw new Error('Payment does not belong to booking.');
  }

  if (booking.bookingId !== receipt.bookingId) {
    throw new Error('Receipt does not belong to booking.');
  }

  if (payment.paymentId !== receipt.paymentId) {
    throw new Error('Receipt does not belong to payment.');
  }

  if (payment.receiptNumber && payment.receiptNumber !== receipt.receiptNumber) {
    throw new Error('Payment receipt number does not match receipt.');
  }

  return true;
}

function buildCustomerStatement({
  customer,
  bookings = [],
  payments = [],
  receipts = [],
  dateFrom = '',
  dateTo = '',
}) {
  const normalizedCustomer = normalizeCustomer(customer);

  if (![bookings, payments, receipts].every(Array.isArray)) {
    throw new TypeError('bookings, payments and receipts must be arrays.');
  }

  const normalizedBookings = bookings
    .map(normalizeBooking)
    .filter((booking) => booking.customerId === normalizedCustomer.customerId);

  const bookingMap = new Map(
    normalizedBookings.map((booking) => [booking.bookingId, booking])
  );

  const normalizedPayments = payments
    .map(normalizePayment)
    .filter(
      (payment) =>
        bookingMap.has(payment.bookingId) &&
        payment.status === 'POSTED'
    );

  const paymentMap = new Map(
    normalizedPayments.map((payment) => [payment.paymentId, payment])
  );

  const normalizedReceipts = receipts
    .map(normalizeReceipt)
    .filter(
      (receipt) =>
        bookingMap.has(receipt.bookingId) &&
        paymentMap.has(receipt.paymentId) &&
        receipt.status === 'ISSUED'
    );

  const receiptMapByPayment = new Map(
    normalizedReceipts.map((receipt) => [receipt.paymentId, receipt])
  );

  for (const payment of normalizedPayments) {
    const booking = bookingMap.get(payment.bookingId);
    const receipt = receiptMapByPayment.get(payment.paymentId);

    if (receipt) {
      validateReceiptLinkage({ booking, payment, receipt });
    }
  }

  const from = normalizeDate(dateFrom);
  const to = normalizeDate(dateTo);

  const rows = [];

  for (const booking of normalizedBookings) {
    if (booking.status === 'CANCELLED') continue;

    rows.push({
      type: 'BOOKING',
      date: booking.bookingDate,
      bookingId: booking.bookingId,
      projectName: booking.projectName,
      plotNumber: booking.plotNumber,
      debit: booking.totalAmount,
      credit: 0,
      reference: booking.bookingId,
      receiptNumber: '',
      paymentId: '',
      mode: '',
      description: `Booking - ${booking.projectName} / Plot ${booking.plotNumber}`,
    });
  }

  for (const payment of normalizedPayments) {
    const booking = bookingMap.get(payment.bookingId);
    const receipt = receiptMapByPayment.get(payment.paymentId) || null;

    rows.push({
      type: 'PAYMENT',
      date: payment.paymentDate,
      bookingId: payment.bookingId,
      projectName: booking ? booking.projectName : '',
      plotNumber: booking ? booking.plotNumber : '',
      debit: 0,
      credit: payment.amount,
      reference: payment.referenceNumber || payment.paymentId,
      receiptNumber: receipt ? receipt.receiptNumber : payment.receiptNumber,
      paymentId: payment.paymentId,
      mode: payment.mode,
      description: `Payment - ${payment.mode || 'UNKNOWN'}`,
    });
  }

  const filteredRows = rows
    .filter((row) => {
      if (from && row.date < from) return false;
      if (to && row.date > to) return false;
      return true;
    })
    .sort((a, b) => {
      if (a.date === b.date) {
        if (a.type === b.type) return a.reference.localeCompare(b.reference);
        return a.type === 'BOOKING' ? -1 : 1;
      }
      return a.date.localeCompare(b.date);
    });

  let runningBalance = 0;

  const statementRows = filteredRows.map((row) => {
    runningBalance = roundMoney(
      runningBalance + row.debit - row.credit
    );

    return Object.freeze({
      ...row,
      runningBalance,
    });
  });

  const totalBookingValue = roundMoney(
    normalizedBookings
      .filter((booking) => booking.status !== 'CANCELLED')
      .reduce((sum, booking) => sum + booking.totalAmount, 0)
  );

  const totalPayments = roundMoney(
    normalizedPayments.reduce((sum, payment) => sum + payment.amount, 0)
  );

  const totalBalance = roundMoney(totalBookingValue - totalPayments);

  return Object.freeze({
    customer: normalizedCustomer,
    bookings: Object.freeze(normalizedBookings),
    payments: Object.freeze(normalizedPayments),
    receipts: Object.freeze(normalizedReceipts),
    rows: Object.freeze(statementRows),
    summary: Object.freeze({
      bookingCount: normalizedBookings.length,
      paymentCount: normalizedPayments.length,
      receiptCount: normalizedReceipts.length,
      totalBookingValue,
      totalPayments,
      totalBalance,
    }),
  });
}

function buildCustomerReceiptIndex(statement) {
  if (!statement || typeof statement !== 'object') {
    throw new TypeError('statement is required.');
  }

  return Object.freeze(
    (statement.receipts || [])
      .slice()
      .sort((a, b) => {
        if (a.paymentDate === b.paymentDate) {
          return b.receiptNumber.localeCompare(a.receiptNumber);
        }
        return b.paymentDate.localeCompare(a.paymentDate);
      })
      .map((receipt) =>
        Object.freeze({
          receiptNumber: receipt.receiptNumber,
          bookingId: receipt.bookingId,
          paymentId: receipt.paymentId,
          projectName: receipt.projectName,
          plotNumber: receipt.plotNumber,
          paymentDate: receipt.paymentDate,
          currentPayment: receipt.currentPayment,
          cumulativePaid: receipt.cumulativePaid,
          balanceAmount: receipt.balanceAmount,
          paymentMode: receipt.paymentMode,
        })
      )
  );
}

function buildCustomerStatementPrintModel(statement) {
  if (!statement || typeof statement !== 'object') {
    throw new TypeError('statement is required.');
  }

  return Object.freeze({
    customer: Object.freeze({
      customerId: statement.customer.customerId,
      customerName: statement.customer.customerName,
      mobile: statement.customer.mobile,
      address: statement.customer.address,
      email: statement.customer.email,
    }),
    summary: statement.summary,
    rows: statement.rows,
    footer: Object.freeze({
      note: 'Statement generated from posted payments and active bookings.',
      generatedAt: new Date().toISOString(),
    }),
  });
}

class CustomerReceiptStatementIntegrationService {
  statement(input) {
    return buildCustomerStatement(input);
  }

  receiptIndex(statement) {
    return buildCustomerReceiptIndex(statement);
  }

  printModel(statement) {
    return buildCustomerStatementPrintModel(statement);
  }

  validateLinkage(input) {
    return validateReceiptLinkage(input);
  }
}

module.exports = {
  text,
  upper,
  finiteNumber,
  nonNegative,
  roundMoney,
  normalizeDate,
  normalizeCustomer,
  normalizeBooking,
  normalizePayment,
  normalizeReceipt,
  validateReceiptLinkage,
  buildCustomerStatement,
  buildCustomerReceiptIndex,
  buildCustomerStatementPrintModel,
  CustomerReceiptStatementIntegrationService,
};
