'use strict';

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function finiteNumber(value, fieldName) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    throw new TypeError(`${fieldName} must be a valid number.`);
  }
  return number;
}

function nonNegative(value, fieldName) {
  const number = finiteNumber(value, fieldName);
  if (number < 0) {
    throw new RangeError(`${fieldName} cannot be negative.`);
  }
  return number;
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function normalizeDate(value) {
  const raw = text(value);
  if (!raw) return '';

  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    return raw;
  }

  const match = raw.match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (!match) return '';

  return `${match[3]}-${match[2]}-${match[1]}`;
}

function isWithinRange(date, dateFrom, dateTo) {
  const normalized = normalizeDate(date);
  if (!normalized) return false;

  const from = normalizeDate(dateFrom);
  const to = normalizeDate(dateTo);

  if (from && normalized < from) return false;
  if (to && normalized > to) return false;
  return true;
}

function deriveBookingStatus(booking = {}) {
  const explicit = upper(booking.status || booking.bookingStatus);

  if (['AVAILABLE', 'HOLD', 'BOOKED', 'SOLD', 'CANCELLED'].includes(explicit)) {
    return explicit;
  }

  const total = nonNegative(
    booking.grandTotal !== undefined ? booking.grandTotal : booking.totalPrice || 0,
    'booking total'
  );
  const paid = nonNegative(booking.paidAmount || 0, 'paidAmount');

  if (booking.cancelledAt || booking.cancelled === true) return 'CANCELLED';
  if (total > 0 && paid >= total) return 'SOLD';
  return 'BOOKED';
}

function derivePaymentStage(booking = {}) {
  const explicit = upper(booking.paymentStage);
  if (['UNPAID', 'PARTIAL', 'FULL'].includes(explicit)) return explicit;

  const total = nonNegative(
    booking.grandTotal !== undefined ? booking.grandTotal : booking.totalPrice || 0,
    'booking total'
  );
  const paid = nonNegative(booking.paidAmount || 0, 'paidAmount');

  if (total > 0 && paid >= total) return 'FULL';
  if (paid > 0) return 'PARTIAL';
  return 'UNPAID';
}

function normalizeBooking(booking = {}) {
  const totalAmount = roundMoney(
    nonNegative(
      booking.grandTotal !== undefined ? booking.grandTotal : booking.totalPrice || 0,
      'booking total'
    )
  );

  const paidAmount = roundMoney(nonNegative(booking.paidAmount || 0, 'paidAmount'));
  const balanceAmount = roundMoney(
    booking.balanceAmount !== undefined
      ? nonNegative(booking.balanceAmount, 'balanceAmount')
      : Math.max(0, totalAmount - paidAmount)
  );

  return Object.freeze({
    source: booking,
    bookingId: upper(booking.bookingId || booking.id),
    projectId: upper(booking.projectId),
    projectName: text(booking.projectName),
    plotNumber: text(booking.plotNumber || booking.plotNo),
    customerId: upper(booking.customerId),
    customerName: text(booking.customerName),
    customerMobile: text(booking.customerMobile || booking.mobile),
    bookingDate: normalizeDate(booking.bookingDate || booking.date || booking.createdAt),
    status: deriveBookingStatus(booking),
    paymentStage: derivePaymentStage(booking),
    totalAmount,
    paidAmount,
    balanceAmount,
  });
}

function normalizePayment(payment = {}) {
  return Object.freeze({
    source: payment,
    paymentId: upper(payment.paymentId),
    bookingId: upper(payment.bookingId),
    projectId: upper(payment.projectId),
    projectName: text(payment.projectName),
    amount: roundMoney(nonNegative(payment.amount || 0, 'payment amount')),
    paymentDate: normalizeDate(payment.paymentDate || payment.date),
    mode: upper(payment.mode || payment.paymentMode),
    status: upper(payment.status || 'POSTED'),
    receiptNumber: upper(payment.receiptNumber),
    referenceNumber: text(payment.referenceNumber),
  });
}

function filterBookings(bookings = [], filters = {}) {
  return bookings
    .map(normalizeBooking)
    .filter((booking) => {
      if (filters.projectId && booking.projectId !== upper(filters.projectId)) return false;
      if (filters.projectName && !booking.projectName.toLowerCase().includes(text(filters.projectName).toLowerCase())) return false;
      if (filters.status && booking.status !== upper(filters.status)) return false;
      if (filters.paymentStage && booking.paymentStage !== upper(filters.paymentStage)) return false;
      if (filters.customerId && booking.customerId !== upper(filters.customerId)) return false;
      if (filters.customerName && !booking.customerName.toLowerCase().includes(text(filters.customerName).toLowerCase())) return false;
      if (filters.plotNumber && booking.plotNumber !== text(filters.plotNumber)) return false;
      if ((filters.dateFrom || filters.dateTo) && !isWithinRange(booking.bookingDate, filters.dateFrom, filters.dateTo)) return false;
      return true;
    });
}

function filterPayments(payments = [], filters = {}) {
  return payments
    .map(normalizePayment)
    .filter((payment) => {
      if (filters.projectId && payment.projectId !== upper(filters.projectId)) return false;
      if (filters.projectName && !payment.projectName.toLowerCase().includes(text(filters.projectName).toLowerCase())) return false;
      if (filters.mode && payment.mode !== upper(filters.mode)) return false;
      if (filters.status && payment.status !== upper(filters.status)) return false;
      if ((filters.dateFrom || filters.dateTo) && !isWithinRange(payment.paymentDate, filters.dateFrom, filters.dateTo)) return false;
      return true;
    });
}

function buildBookingSummary(bookings = [], filters = {}) {
  const rows = filterBookings(bookings, filters);

  const summary = {
    totalBookings: rows.length,
    bookedCount: 0,
    soldCount: 0,
    holdCount: 0,
    cancelledCount: 0,
    unpaidCount: 0,
    partialCount: 0,
    fullCount: 0,
    totalBookingValue: 0,
    totalPaid: 0,
    totalBalance: 0,
  };

  for (const row of rows) {
    if (row.status === 'BOOKED') summary.bookedCount += 1;
    if (row.status === 'SOLD') summary.soldCount += 1;
    if (row.status === 'HOLD') summary.holdCount += 1;
    if (row.status === 'CANCELLED') summary.cancelledCount += 1;

    if (row.paymentStage === 'UNPAID') summary.unpaidCount += 1;
    if (row.paymentStage === 'PARTIAL') summary.partialCount += 1;
    if (row.paymentStage === 'FULL') summary.fullCount += 1;

    summary.totalBookingValue = roundMoney(summary.totalBookingValue + row.totalAmount);
    summary.totalPaid = roundMoney(summary.totalPaid + row.paidAmount);
    summary.totalBalance = roundMoney(summary.totalBalance + row.balanceAmount);
  }

  return Object.freeze({
    rows: Object.freeze(rows),
    summary: Object.freeze(summary),
  });
}

function buildCollectionReport(payments = [], filters = {}) {
  const rows = filterPayments(payments, filters).filter(
    (payment) => payment.status === 'POSTED'
  );

  const byMode = {};
  const byDate = {};
  let totalCollection = 0;

  for (const row of rows) {
    totalCollection = roundMoney(totalCollection + row.amount);

    byMode[row.mode || 'UNKNOWN'] = roundMoney(
      (byMode[row.mode || 'UNKNOWN'] || 0) + row.amount
    );

    byDate[row.paymentDate || 'UNKNOWN'] = roundMoney(
      (byDate[row.paymentDate || 'UNKNOWN'] || 0) + row.amount
    );
  }

  return Object.freeze({
    rows: Object.freeze(rows),
    summary: Object.freeze({
      paymentCount: rows.length,
      totalCollection,
      byMode: Object.freeze({ ...byMode }),
      byDate: Object.freeze({ ...byDate }),
    }),
  });
}

function buildPendingPaymentReport(bookings = [], filters = {}) {
  const rows = filterBookings(bookings, filters).filter(
    (booking) => booking.balanceAmount > 0 && booking.status !== 'CANCELLED'
  );

  const totalPending = roundMoney(
    rows.reduce((sum, row) => sum + row.balanceAmount, 0)
  );

  return Object.freeze({
    rows: Object.freeze(rows),
    summary: Object.freeze({
      pendingBookingCount: rows.length,
      totalPending,
    }),
  });
}

function buildSoldPlotReport(bookings = [], filters = {}) {
  const rows = filterBookings(bookings, filters).filter(
    (booking) => booking.status === 'SOLD' || booking.paymentStage === 'FULL'
  );

  return Object.freeze({
    rows: Object.freeze(rows),
    summary: Object.freeze({
      soldCount: rows.length,
      soldValue: roundMoney(rows.reduce((sum, row) => sum + row.totalAmount, 0)),
    }),
  });
}

function buildCustomerWiseReport(bookings = [], filters = {}) {
  const rows = filterBookings(bookings, filters);
  const map = new Map();

  for (const row of rows) {
    const key = row.customerId || row.customerMobile || row.customerName || 'UNKNOWN';

    if (!map.has(key)) {
      map.set(key, {
        customerId: row.customerId,
        customerName: row.customerName,
        customerMobile: row.customerMobile,
        bookingCount: 0,
        totalValue: 0,
        totalPaid: 0,
        totalBalance: 0,
      });
    }

    const customer = map.get(key);
    customer.bookingCount += 1;
    customer.totalValue = roundMoney(customer.totalValue + row.totalAmount);
    customer.totalPaid = roundMoney(customer.totalPaid + row.paidAmount);
    customer.totalBalance = roundMoney(customer.totalBalance + row.balanceAmount);
  }

  const customerRows = Array.from(map.values()).sort((a, b) =>
    a.customerName.localeCompare(b.customerName)
  );

  return Object.freeze({
    rows: Object.freeze(customerRows),
    summary: Object.freeze({
      customerCount: customerRows.length,
      bookingCount: rows.length,
      totalValue: roundMoney(customerRows.reduce((sum, row) => sum + row.totalValue, 0)),
      totalPaid: roundMoney(customerRows.reduce((sum, row) => sum + row.totalPaid, 0)),
      totalBalance: roundMoney(customerRows.reduce((sum, row) => sum + row.totalBalance, 0)),
    }),
  });
}

function buildProjectWiseReport(bookings = [], payments = [], filters = {}) {
  const bookingRows = filterBookings(bookings, filters);
  const paymentRows = filterPayments(payments, filters).filter(
    (payment) => payment.status === 'POSTED'
  );

  const map = new Map();

  function getProject(projectId, projectName) {
    const key = projectId || projectName || 'UNKNOWN';
    if (!map.has(key)) {
      map.set(key, {
        projectId,
        projectName,
        bookingCount: 0,
        soldCount: 0,
        totalBookingValue: 0,
        totalPaidFromBookings: 0,
        totalBalance: 0,
        collection: 0,
      });
    }
    return map.get(key);
  }

  for (const row of bookingRows) {
    const project = getProject(row.projectId, row.projectName);
    project.bookingCount += 1;
    if (row.status === 'SOLD' || row.paymentStage === 'FULL') project.soldCount += 1;
    project.totalBookingValue = roundMoney(project.totalBookingValue + row.totalAmount);
    project.totalPaidFromBookings = roundMoney(project.totalPaidFromBookings + row.paidAmount);
    project.totalBalance = roundMoney(project.totalBalance + row.balanceAmount);
  }

  for (const row of paymentRows) {
    const project = getProject(row.projectId, row.projectName);
    project.collection = roundMoney(project.collection + row.amount);
  }

  const rows = Array.from(map.values()).sort((a, b) =>
    a.projectName.localeCompare(b.projectName)
  );

  return Object.freeze({
    rows: Object.freeze(rows),
    summary: Object.freeze({
      projectCount: rows.length,
      bookingCount: rows.reduce((sum, row) => sum + row.bookingCount, 0),
      soldCount: rows.reduce((sum, row) => sum + row.soldCount, 0),
      totalBookingValue: roundMoney(rows.reduce((sum, row) => sum + row.totalBookingValue, 0)),
      totalPaidFromBookings: roundMoney(rows.reduce((sum, row) => sum + row.totalPaidFromBookings, 0)),
      totalBalance: roundMoney(rows.reduce((sum, row) => sum + row.totalBalance, 0)),
      totalCollection: roundMoney(rows.reduce((sum, row) => sum + row.collection, 0)),
    }),
  });
}

function exportReportData(report, metadata = {}) {
  if (!report || typeof report !== 'object') {
    throw new TypeError('report is required.');
  }

  return Object.freeze({
    generatedAt: text(metadata.generatedAt) || new Date().toISOString(),
    reportName: text(metadata.reportName) || 'Falcon Report',
    filters: Object.freeze({ ...(metadata.filters || {}) }),
    rows: Object.freeze([...(report.rows || [])]),
    summary: Object.freeze({ ...(report.summary || {}) }),
  });
}

class ReportEngine {
  bookingSummary(bookings, filters) {
    return buildBookingSummary(bookings, filters);
  }

  collection(payments, filters) {
    return buildCollectionReport(payments, filters);
  }

  pending(bookings, filters) {
    return buildPendingPaymentReport(bookings, filters);
  }

  sold(bookings, filters) {
    return buildSoldPlotReport(bookings, filters);
  }

  customerWise(bookings, filters) {
    return buildCustomerWiseReport(bookings, filters);
  }

  projectWise(bookings, payments, filters) {
    return buildProjectWiseReport(bookings, payments, filters);
  }

  export(report, metadata) {
    return exportReportData(report, metadata);
  }
}

module.exports = {
  text,
  upper,
  finiteNumber,
  nonNegative,
  roundMoney,
  normalizeDate,
  isWithinRange,
  deriveBookingStatus,
  derivePaymentStage,
  normalizeBooking,
  normalizePayment,
  filterBookings,
  filterPayments,
  buildBookingSummary,
  buildCollectionReport,
  buildPendingPaymentReport,
  buildSoldPlotReport,
  buildCustomerWiseReport,
  buildProjectWiseReport,
  exportReportData,
  ReportEngine,
};
