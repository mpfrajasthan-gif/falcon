'use strict';

const {
  auditEntities,
  buildPlotEngineHandoff,
  normalizeLayerName,
} = require('./dxf-integration-contract');

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function numberOrNull(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function normalizeVertex(vertex) {
  if (!vertex || typeof vertex !== 'object') {
    throw new TypeError('vertex must be an object.');
  }

  const x = numberOrNull(
    vertex.x !== undefined ? vertex.x :
    vertex.X !== undefined ? vertex.X :
    Array.isArray(vertex) ? vertex[0] : null
  );

  const y = numberOrNull(
    vertex.y !== undefined ? vertex.y :
    vertex.Y !== undefined ? vertex.Y :
    Array.isArray(vertex) ? vertex[1] : null
  );

  if (x === null || y === null) {
    throw new Error('vertex requires numeric x and y.');
  }

  return Object.freeze({ x, y });
}

function extractVertices(entity = {}) {
  const candidates =
    entity.vertices ||
    entity.points ||
    entity.vertexes ||
    entity.polyline ||
    entity.coordinates ||
    [];

  if (!Array.isArray(candidates)) return Object.freeze([]);

  return Object.freeze(candidates.map(normalizeVertex));
}

function extractEntityText(entity = {}) {
  return text(
    entity.text !== undefined ? entity.text :
    entity.value !== undefined ? entity.value :
    entity.contents !== undefined ? entity.contents :
    entity.label !== undefined ? entity.label :
    ''
  );
}

function detectClosed(entity = {}, vertices = []) {
  if (
    entity.closed === true ||
    entity.isClosed === true ||
    entity.closed === 1 ||
    entity.isClosed === 1
  ) return true;

  const flags = Number(
    entity.flags !== undefined ? entity.flags :
    entity.flag !== undefined ? entity.flag :
    0
  );

  if (Number.isFinite(flags) && (flags & 1) === 1) return true;

  if (vertices.length > 2) {
    const first = vertices[0];
    const last = vertices[vertices.length - 1];
    if (first.x === last.x && first.y === last.y) return true;
  }

  return false;
}

function mapLegacyEntity(entity = {}) {
  const vertices = extractVertices(entity);

  const id = upper(
    entity.id ||
    entity.entityId ||
    entity.handle ||
    entity.uuid ||
    ''
  );

  const handle = upper(
    entity.handle ||
    entity.id ||
    entity.entityId ||
    ''
  );

  const mapped = {
    id,
    handle,
    type: upper(
      entity.type ||
      entity.entityType ||
      entity.kind ||
      entity.name ||
      'UNKNOWN'
    ),
    layer: normalizeLayerName(
      entity.layer ||
      entity.layerName ||
      entity.layer_name ||
      entity.group ||
      ''
    ),
    closed: detectClosed(entity, vertices),
    vertices,
    text: extractEntityText(entity),
  };

  const area = numberOrNull(
    entity.area !== undefined ? entity.area :
    entity.calculatedArea !== undefined ? entity.calculatedArea :
    entity.entityArea !== undefined ? entity.entityArea :
    null
  );

  if (area !== null) mapped.area = area;

  return Object.freeze(mapped);
}

function detectEntityArray(parserOutput) {
  if (Array.isArray(parserOutput)) return parserOutput;

  if (!parserOutput || typeof parserOutput !== 'object') {
    throw new TypeError('parserOutput must be an object or array.');
  }

  const candidates = [
    parserOutput.entities,
    parserOutput.data && parserOutput.data.entities,
    parserOutput.dxf && parserOutput.dxf.entities,
    parserOutput.document && parserOutput.document.entities,
    parserOutput.parsed && parserOutput.parsed.entities,
    parserOutput.items,
  ];

  const found = candidates.find(Array.isArray);

  if (!found) {
    throw new Error('Could not locate DXF entity array in parser output.');
  }

  return found;
}

function adaptParserOutput(parserOutput) {
  const entities = detectEntityArray(parserOutput);

  return Object.freeze({
    sourceEntityCount: entities.length,
    entities: Object.freeze(entities.map(mapLegacyEntity)),
  });
}

function runExistingEngineAdapter({
  parserOutput,
  projectId,
  unit = 'DXF_UNIT',
  layerRules = {},
} = {}) {
  const adapted = adaptParserOutput(parserOutput);
  const audit = auditEntities(adapted.entities, layerRules);

  let handoff = null;
  if (audit.summary.pass) {
    handoff = buildPlotEngineHandoff({
      projectId,
      auditResult: audit,
      unit,
    });
  }

  return Object.freeze({
    adapted,
    audit,
    handoff,
    readyForPlotCore: Boolean(handoff),
  });
}

function createAdapterDiagnostics(result) {
  if (!result || typeof result !== 'object') {
    throw new TypeError('result is required.');
  }

  const unknownLayers = new Set(
    (result.audit.issues || [])
      .filter((issue) => issue.code === 'UNKNOWN_LAYER')
      .map((issue) => {
        const entity = result.audit.entities.find(
          (item) => item.id === issue.entityId
        );
        return entity ? entity.layer : '';
      })
      .filter(Boolean)
  );

  return Object.freeze({
    sourceEntityCount: result.adapted.sourceEntityCount,
    normalizedEntityCount: result.audit.summary.entityCount,
    errorCount: result.audit.summary.errorCount,
    warningCount: result.audit.summary.warningCount,
    unknownLayers: Object.freeze([...unknownLayers]),
    readyForPlotCore: result.readyForPlotCore,
    plotCount: result.handoff ? result.handoff.plotCount : 0,
  });
}

class ExistingDxfEngineAdapterService {
  mapEntity(entity) {
    return mapLegacyEntity(entity);
  }

  adapt(parserOutput) {
    return adaptParserOutput(parserOutput);
  }

  run(input) {
    return runExistingEngineAdapter(input);
  }

  diagnostics(result) {
    return createAdapterDiagnostics(result);
  }
}

module.exports = {
  text,
  upper,
  numberOrNull,
  normalizeVertex,
  extractVertices,
  extractEntityText,
  detectClosed,
  mapLegacyEntity,
  detectEntityArray,
  adaptParserOutput,
  runExistingEngineAdapter,
  createAdapterDiagnostics,
  ExistingDxfEngineAdapterService,
};
