'use strict';

const crypto = require('crypto');

const RECEIPT_STATUSES = Object.freeze({
  ISSUED: 'ISSUED',
  CANCELLED: 'CANCELLED',
});

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function finiteNumber(value, fieldName) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    throw new TypeError(`${fieldName} must be a valid number.`);
  }
  return number;
}

function nonNegative(value, fieldName) {
  const number = finiteNumber(value, fieldName);
  if (number < 0) {
    throw new RangeError(`${fieldName} cannot be negative.`);
  }
  return number;
}

function positive(value, fieldName) {
  const number = finiteNumber(value, fieldName);
  if (number <= 0) {
    throw new RangeError(`${fieldName} must be greater than zero.`);
  }
  return number;
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function normalizeDate(value) {
  const raw = text(value);
  if (!raw) return '';

  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    return raw;
  }

  const match = raw.match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (!match) return '';

  return `${match[3]}-${match[2]}-${match[1]}`;
}

function formatDisplayDate(value) {
  const normalized = normalizeDate(value);
  if (!normalized) return '';
  const [year, month, day] = normalized.split('-');
  return `${day}-${month}-${year}`;
}

function padSequence(sequence, width = 6) {
  const number = Math.floor(finiteNumber(sequence, 'sequence'));
  if (number <= 0) {
    throw new RangeError('sequence must be greater than zero.');
  }
  return String(number).padStart(width, '0');
}

function generateReceiptNumber({
  sequence,
  prefix = 'RCP',
  projectCode = '',
}) {
  const cleanPrefix = upper(prefix).replace(/[^A-Z0-9]/g, '');
  const cleanProjectCode = upper(projectCode).replace(/[^A-Z0-9]/g, '');

  if (!cleanPrefix) {
    throw new Error('Receipt prefix is required.');
  }

  const middle = cleanProjectCode ? `${cleanProjectCode}-` : '';
  return `${cleanPrefix}-${middle}${padSequence(sequence)}`;
}

function calculateReceiptFinancials({
  totalAmount,
  previousPaid,
  currentPayment,
}) {
  const total = roundMoney(nonNegative(totalAmount, 'totalAmount'));
  const previous = roundMoney(nonNegative(previousPaid, 'previousPaid'));
  const current = roundMoney(positive(currentPayment, 'currentPayment'));

  if (previous > total) {
    throw new RangeError('previousPaid cannot exceed totalAmount.');
  }

  const cumulativePaid = roundMoney(previous + current);

  if (cumulativePaid > total) {
    throw new RangeError('Receipt payment would exceed total amount.');
  }

  const balanceAmount = roundMoney(total - cumulativePaid);
  const paymentPercent =
    total === 0 ? 0 : roundMoney((cumulativePaid / total) * 100);

  return Object.freeze({
    totalAmount: total,
    previousPaid: previous,
    currentPayment: current,
    cumulativePaid,
    balanceAmount,
    paymentPercent,
    paidInFull: total > 0 && cumulativePaid === total,
  });
}

function canonicalReceiptPayload(receipt) {
  return JSON.stringify({
    receiptNumber: upper(receipt.receiptNumber),
    paymentId: upper(receipt.paymentId),
    bookingId: upper(receipt.bookingId),
    projectId: upper(receipt.projectId),
    plotNumber: text(receipt.plotNumber),
    customerName: text(receipt.customerName),
    currentPayment: roundMoney(receipt.currentPayment),
    cumulativePaid: roundMoney(receipt.cumulativePaid),
    balanceAmount: roundMoney(receipt.balanceAmount),
    paymentDate: normalizeDate(receipt.paymentDate),
    status: upper(receipt.status),
  });
}

function createIntegrityHash(receipt, secret = '') {
  return crypto
    .createHash('sha256')
    .update(`${canonicalReceiptPayload(receipt)}|${text(secret)}`)
    .digest('hex');
}

function verifyIntegrityHash(receipt, expectedHash, secret = '') {
  return createIntegrityHash(receipt, secret) === text(expectedHash);
}

function createReceipt(input = {}) {
  const receiptNumber = upper(input.receiptNumber);
  const paymentId = upper(input.paymentId);
  const bookingId = upper(input.bookingId);
  const paymentDate = normalizeDate(input.paymentDate);

  if (!receiptNumber) {
    throw new Error('receiptNumber is required.');
  }

  if (!paymentId) {
    throw new Error('paymentId is required.');
  }

  if (!bookingId) {
    throw new Error('bookingId is required.');
  }

  if (!paymentDate) {
    throw new Error('paymentDate must be DD-MM-YYYY or YYYY-MM-DD.');
  }

  const financials = calculateReceiptFinancials({
    totalAmount: input.totalAmount,
    previousPaid: input.previousPaid,
    currentPayment: input.currentPayment,
  });

  const receipt = {
    receiptNumber,
    paymentId,
    bookingId,
    projectId: upper(input.projectId),
    projectName: text(input.projectName),
    projectAddress: text(input.projectAddress),
    reraNumber: text(input.reraNumber),
    reraStatus: upper(input.reraStatus || 'NOT_REGISTERED'),
    companyName: text(input.companyName),
    companyAddress: text(input.companyAddress),
    companyPhone: text(input.companyPhone),
    companyEmail: text(input.companyEmail),
    companyLogoPath: text(input.companyLogoPath),
    customerId: upper(input.customerId),
    customerName: text(input.customerName),
    customerMobile: text(input.customerMobile),
    customerAddress: text(input.customerAddress),
    plotId: upper(input.plotId),
    plotNumber: text(input.plotNumber),
    plotArea: nonNegative(input.plotArea || 0, 'plotArea'),
    areaUnit: upper(input.areaUnit || 'SQ_YARD'),
    rate: nonNegative(input.rate || 0, 'rate'),
    paymentMode: upper(input.paymentMode),
    referenceNumber: text(input.referenceNumber),
    paymentDate,
    paymentDateDisplay: formatDisplayDate(paymentDate),
    receivedBy: text(input.receivedBy),
    receivedById: upper(input.receivedById),
    notes: text(input.notes),
    terms: Array.isArray(input.terms)
      ? input.terms.map(text).filter(Boolean)
      : [],
    qrPayload: text(input.qrPayload),
    status: RECEIPT_STATUSES.ISSUED,
    issuedAt: text(input.issuedAt) || new Date().toISOString(),
    cancelledAt: null,
    cancellationReason: '',
    cancelledBy: '',
    ...financials,
  };

  if (!receipt.customerName) {
    throw new Error('customerName is required.');
  }

  if (!receipt.plotNumber) {
    throw new Error('plotNumber is required.');
  }

  if (!receipt.projectName) {
    throw new Error('projectName is required.');
  }

  if (!receipt.companyName) {
    throw new Error('companyName is required.');
  }

  receipt.integrityHash = createIntegrityHash(
    receipt,
    input.integritySecret || ''
  );

  return Object.freeze(receipt);
}

function ensureUniqueReceipt({
  receiptNumber,
  existingReceipts = [],
}) {
  if (!Array.isArray(existingReceipts)) {
    throw new TypeError('existingReceipts must be an array.');
  }

  const normalized = upper(receiptNumber);
  const duplicate = existingReceipts.some(
    (receipt) =>
      upper(receipt.receiptNumber) === normalized &&
      upper(receipt.status || RECEIPT_STATUSES.ISSUED) !==
        RECEIPT_STATUSES.CANCELLED
  );

  if (duplicate) {
    throw new Error('Duplicate receiptNumber is not allowed.');
  }

  return true;
}

function cancelReceipt({
  receipt,
  actorId,
  reason,
  cancelledAt,
  integritySecret = '',
}) {
  if (!receipt || typeof receipt !== 'object') {
    throw new TypeError('receipt is required.');
  }

  if (upper(receipt.status) === RECEIPT_STATUSES.CANCELLED) {
    throw new Error('Receipt is already cancelled.');
  }

  const cleanReason = text(reason).replace(/\s+/g, ' ');
  if (cleanReason.length < 5) {
    throw new Error('Cancellation reason must contain at least 5 characters.');
  }

  const cleanActorId = upper(actorId);
  if (!cleanActorId) {
    throw new Error('actorId is required.');
  }

  const cancelled = {
    ...receipt,
    status: RECEIPT_STATUSES.CANCELLED,
    cancelledAt: text(cancelledAt) || new Date().toISOString(),
    cancellationReason: cleanReason,
    cancelledBy: cleanActorId,
  };

  cancelled.integrityHash = createIntegrityHash(
    cancelled,
    integritySecret
  );

  return Object.freeze(cancelled);
}

function buildPrintableReceipt(receipt) {
  if (!receipt || typeof receipt !== 'object') {
    throw new TypeError('receipt is required.');
  }

  return Object.freeze({
    header: Object.freeze({
      companyName: receipt.companyName,
      companyAddress: receipt.companyAddress,
      companyPhone: receipt.companyPhone,
      companyEmail: receipt.companyEmail,
      companyLogoPath: receipt.companyLogoPath,
      title: 'PAYMENT RECEIPT',
      receiptNumber: receipt.receiptNumber,
      receiptDate: receipt.paymentDateDisplay,
    }),
    project: Object.freeze({
      projectName: receipt.projectName,
      projectAddress: receipt.projectAddress,
      reraNumber: receipt.reraNumber,
      reraStatus: receipt.reraStatus,
    }),
    customer: Object.freeze({
      customerId: receipt.customerId,
      customerName: receipt.customerName,
      customerMobile: receipt.customerMobile,
      customerAddress: receipt.customerAddress,
    }),
    plot: Object.freeze({
      plotId: receipt.plotId,
      plotNumber: receipt.plotNumber,
      plotArea: receipt.plotArea,
      areaUnit: receipt.areaUnit,
      rate: receipt.rate,
    }),
    payment: Object.freeze({
      paymentId: receipt.paymentId,
      paymentMode: receipt.paymentMode,
      referenceNumber: receipt.referenceNumber,
      currentPayment: receipt.currentPayment,
      previousPaid: receipt.previousPaid,
      cumulativePaid: receipt.cumulativePaid,
      balanceAmount: receipt.balanceAmount,
      totalAmount: receipt.totalAmount,
      paymentPercent: receipt.paymentPercent,
      receivedBy: receipt.receivedBy,
    }),
    footer: Object.freeze({
      terms: Object.freeze([...receipt.terms]),
      notes: receipt.notes,
      qrPayload: receipt.qrPayload,
      integrityHash: receipt.integrityHash,
      status: receipt.status,
      poweredBy: 'Powered by Falcon',
    }),
  });
}

function buildWhatsAppReceiptMessage(receipt) {
  const referenceLine = receipt.referenceNumber
    ? `Reference: ${receipt.referenceNumber}\n`
    : '';

  return [
    `*Payment Receipt - ${receipt.companyName}*`,
    `Receipt No: ${receipt.receiptNumber}`,
    `Project: ${receipt.projectName}`,
    `Plot No: ${receipt.plotNumber}`,
    `Customer: ${receipt.customerName}`,
    `Payment: ${receipt.currentPayment}`,
    `Total Paid: ${receipt.cumulativePaid}`,
    `Balance: ${receipt.balanceAmount}`,
    `Mode: ${receipt.paymentMode}`,
    referenceLine.trimEnd(),
    `Date: ${receipt.paymentDateDisplay}`,
    `Booking Ref: ${receipt.bookingId}`,
    'This receipt is subject to applicable terms and verification.',
  ]
    .filter(Boolean)
    .join('\n');
}

class ReceiptEngine {
  generateNumber(input) {
    return generateReceiptNumber(input);
  }

  create(input) {
    return createReceipt(input);
  }

  ensureUnique(input) {
    return ensureUniqueReceipt(input);
  }

  cancel(input) {
    return cancelReceipt(input);
  }

  printable(receipt) {
    return buildPrintableReceipt(receipt);
  }

  whatsapp(receipt) {
    return buildWhatsAppReceiptMessage(receipt);
  }

  verify(receipt, expectedHash, secret = '') {
    return verifyIntegrityHash(receipt, expectedHash, secret);
  }
}

module.exports = {
  RECEIPT_STATUSES,
  text,
  upper,
  finiteNumber,
  nonNegative,
  positive,
  roundMoney,
  normalizeDate,
  formatDisplayDate,
  padSequence,
  generateReceiptNumber,
  calculateReceiptFinancials,
  canonicalReceiptPayload,
  createIntegrityHash,
  verifyIntegrityHash,
  createReceipt,
  ensureUniqueReceipt,
  cancelReceipt,
  buildPrintableReceipt,
  buildWhatsAppReceiptMessage,
  ReceiptEngine,
};
