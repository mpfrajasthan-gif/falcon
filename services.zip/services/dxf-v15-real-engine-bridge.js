'use strict';

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function finiteNumber(value, fieldName) {
  const n = Number(value);
  if (!Number.isFinite(n)) throw new TypeError(`${fieldName} must be a valid number.`);
  return n;
}

function normalizeVertex(vertex, index = 0) {
  if (!Array.isArray(vertex) || vertex.length < 2) {
    throw new Error(`vertex ${index} must be [x,y].`);
  }
  return Object.freeze({
    x: finiteNumber(vertex[0], `vertex[${index}].x`),
    y: finiteNumber(vertex[1], `vertex[${index}].y`),
  });
}

function normalizePlot(plot = {}, index = 0) {
  const plotNo = text(plot.plot_no || plot.plotNo);
  if (!plotNo) throw new Error(`plot ${index + 1} has no plot number.`);

  const vertices = Array.isArray(plot.vertices)
    ? plot.vertices.map((v, i) => normalizeVertex(v, i))
    : [];

  if (vertices.length < 3) {
    throw new Error(`plot ${plotNo} requires at least 3 vertices.`);
  }

  const sideLengthsFt = Array.isArray(plot.side_lengths_ft)
    ? plot.side_lengths_ft.map((v, i) => finiteNumber(v, `plot ${plotNo} side ${i + 1}`))
    : [];

  return Object.freeze({
    plotNo,
    sourceLayer: text(plot.layer),
    status: 'AVAILABLE',
    vertices: Object.freeze(vertices),
    centroid: Object.freeze({
      x: finiteNumber(plot.centroid?.[0], `plot ${plotNo} centroid.x`),
      y: finiteNumber(plot.centroid?.[1], `plot ${plotNo} centroid.y`),
    }),
    areaSqM: finiteNumber(plot.area_sq_m, `plot ${plotNo} area_sq_m`),
    areaSqYd: finiteNumber(plot.area_sq_yd, `plot ${plotNo} area_sq_yd`),
    sideLengthsFt: Object.freeze(sideLengthsFt),
    topologyVerified: Boolean(plot.topology_verified),
    sourceIndex: plot.source_index ?? null,
    containedLabels: plot.contained_labels ?? null,
  });
}

function normalizeRoad(road = {}, index = 0) {
  const name = text(road.name) || `ROAD-${index + 1}`;
  const widthFt = finiteNumber(road.width_ft || 0, `${name} width_ft`);

  const point = Array.isArray(road.label_point)
    ? normalizeVertex(road.label_point, 0)
    : Array.isArray(road.vertices) && road.vertices[0]
    ? normalizeVertex(road.vertices[0], 0)
    : null;

  return Object.freeze({
    id: text(road.id) || `ROAD-${index + 1}`,
    name,
    widthFt,
    geometryType: text(road.geometry_type || 'LABEL_POINT'),
    labelPoint: point,
    roadSurfaceRule: 'BACKGROUND_GAPS',
  });
}

function normalizeSpecialArea(area = {}, index = 0) {
  const name = text(area.name || area.category) || `SPECIAL-${index + 1}`;

  const vertices = Array.isArray(area.vertices)
    ? area.vertices.map((v, i) => normalizeVertex(v, i))
    : [];

  return Object.freeze({
    id: `SPECIAL-${index + 1}`,
    name,
    category: upper(area.category || area.name || 'SPECIAL AREA'),
    sourceLayer: text(area.layer),
    vertices: Object.freeze(vertices),
    centroid: area.centroid
      ? Object.freeze({
          x: finiteNumber(area.centroid[0], `${name} centroid.x`),
          y: finiteNumber(area.centroid[1], `${name} centroid.y`),
        })
      : null,
    areaSqM: area.area_sq_m == null ? null : finiteNumber(area.area_sq_m, `${name} area_sq_m`),
    areaSqYd: area.area_sq_yd == null ? null : finiteNumber(area.area_sq_yd, `${name} area_sq_yd`),
  });
}

function validateV15Draft(draft) {
  if (!draft || typeof draft !== 'object') {
    throw new TypeError('V1.5 draft is required.');
  }

  if (upper(draft.project?.approval_status) !== 'APPROVED') {
    throw new Error('DXF V1.5 draft must be APPROVED before integration.');
  }

  if (!draft.layers || !Array.isArray(draft.layers.plots)) {
    throw new Error('DXF V1.5 draft has no plot layer export.');
  }

  const profile = draft.import_profile || {};

  if (profile.original_geometry_locked !== true) {
    throw new Error('V1.5 original_geometry_locked must be true.');
  }

  if (
    profile.road_surface_rule &&
    upper(profile.road_surface_rule) !== 'BACKGROUND_GAPS'
  ) {
    throw new Error('Unsupported V1.5 road surface rule.');
  }

  return true;
}

function adaptV15Draft({
  projectId,
  draft,
} = {}) {
  const cleanProjectId = upper(projectId);
  if (!cleanProjectId) throw new Error('projectId is required.');

  validateV15Draft(draft);

  const plots = draft.layers.plots.map(normalizePlot);
  const roads = (draft.layers.roads || []).map(normalizeRoad);
  const specialAreas = (draft.layers.special_areas || []).map(normalizeSpecialArea);

  const plotNos = plots.map((p) => p.plotNo);
  const duplicates = [...new Set(plotNos.filter((n, i) => plotNos.indexOf(n) !== i))];

  if (duplicates.length) {
    throw new Error(`Duplicate plot numbers in V1.5 draft: ${duplicates.join(', ')}`);
  }

  return Object.freeze({
    project: Object.freeze({
      projectId: cleanProjectId,
      sourceName: text(draft.project?.name),
      sourceCrs: text(draft.project?.source_crs),
      sourceSha256: text(draft.project?.source_sha256),
      approvedAt: text(draft.project?.approved_at),
    }),
    sourceEngine: 'FALCON_DXF_INTELLIGENCE_V1_5',
    sourceSchema: text(draft.schema_version),
    originalGeometryLocked: true,
    rendererProfile: text(draft.import_profile?.renderer || 'FALCON_V10_POLISHED_2D'),
    roadSurfaceRule: text(draft.import_profile?.road_surface_rule || 'BACKGROUND_GAPS'),
    roadLabels: text(draft.import_profile?.road_labels || 'ROAD_TEXT_POINTS'),
    plots: Object.freeze(plots),
    roads: Object.freeze(roads),
    specialAreas: Object.freeze(specialAreas),
    audit: Object.freeze({
      metrics: Object.freeze({ ...(draft.audit?.metrics || {}) }),
      warnings: Object.freeze([...(draft.audit?.warnings || [])]),
    }),
  });
}

function buildPlotCoreRecords(model) {
  if (!model || typeof model !== 'object') throw new TypeError('model is required.');

  return Object.freeze(
    model.plots.map((plot) =>
      Object.freeze({
        projectId: model.project.projectId,
        plotNumber: plot.plotNo,
        status: 'AVAILABLE',
        areaSqYd: plot.areaSqYd,
        areaSqM: plot.areaSqM,
        centroid: plot.centroid,
        vertices: plot.vertices,
        sideLengthsFt: plot.sideLengthsFt,
        source: Object.freeze({
          engine: model.sourceEngine,
          layer: plot.sourceLayer,
          sourceIndex: plot.sourceIndex,
          topologyVerified: plot.topologyVerified,
        }),
      })
    )
  );
}

function buildMapReadyModel(model) {
  if (!model || typeof model !== 'object') throw new TypeError('model is required.');

  return Object.freeze({
    projectId: model.project.projectId,
    rendererProfile: model.rendererProfile,
    geometryPolicy: Object.freeze({
      originalGeometryLocked: true,
      straightenGeometry: false,
      inventVertices: false,
      deleteVertices: false,
      roadSurfaceRule: 'BACKGROUND_GAPS',
    }),
    visualPolicy: Object.freeze({
      plotNumberPlacement: 'CENTROID',
      dimensionSource: 'SIDE_LENGTHS_FT',
      selectionStyle: 'BLUE_GLASS_TRANSPARENT',
      selectionBoundary: 'THIN_DOTTED_OFFSET',
      selectionAutoZoomPercent: Object.freeze([20, 30]),
      clickOutsideClearsSelection: true,
      smoothPanZoomRequired: true,
      defaultAreaUnit: 'SQ_YARD',
      availableAreaUnits: Object.freeze(['SQ_YARD', 'SQ_FT', 'SQ_M']),
    }),
    layers: Object.freeze({
      plots: model.plots,
      roads: model.roads,
      specialAreas: model.specialAreas,
    }),
  });
}

function createV15Diagnostics(model) {
  return Object.freeze({
    plotCount: model.plots.length,
    roadLabelCount: model.roads.length,
    specialAreaCount: model.specialAreas.length,
    sourceScope: model.audit.metrics.selected_scope || '',
    sourcePlotLabels: Number(model.audit.metrics.plot_labels || 0),
    sourcePlotFaces: Number(model.audit.metrics.plot_faces || model.plots.length),
    unresolvedLabels: Number(model.audit.metrics.unresolved_labels || 0),
    sourceRoadLayers: Number(model.audit.metrics.road_layers || 0),
    sourceKhasraLayers: Number(model.audit.metrics.khasra_layers || 0),
    sourceSpecialLayers: Number(model.audit.metrics.special_layers || 0),
    readyForPlotCore:
      model.plots.length > 0 &&
      Number(model.audit.metrics.unresolved_labels || 0) === 0,
    originalGeometryLocked: model.originalGeometryLocked,
  });
}

class DxfV15RealEngineBridgeService {
  validate(draft) {
    return validateV15Draft(draft);
  }

  adapt(input) {
    return adaptV15Draft(input);
  }

  plotCore(model) {
    return buildPlotCoreRecords(model);
  }

  mapReady(model) {
    return buildMapReadyModel(model);
  }

  diagnostics(model) {
    return createV15Diagnostics(model);
  }
}

module.exports = {
  text,
  upper,
  finiteNumber,
  normalizeVertex,
  normalizePlot,
  normalizeRoad,
  normalizeSpecialArea,
  validateV15Draft,
  adaptV15Draft,
  buildPlotCoreRecords,
  buildMapReadyModel,
  createV15Diagnostics,
  DxfV15RealEngineBridgeService,
};
