'use strict';

/*
  Falcon MAP.5 Actual Canvas Viewer Surface
  UMD-style module:
  - Node/CommonJS for tests and Electron preload/renderer integration
  - window.FalconMapCanvasSurface for direct browser demo
*/

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.FalconMapCanvasSurface = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  function text(value) {
    return value === null || value === undefined ? '' : String(value).trim();
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  const DEFAULT_THEME = Object.freeze({
    background: '#101418',
    plotBorder: '#2f3740',
    residential: '#eadfbd',
    commercial: '#8a5a44',
    facility: '#b8c59d',
    otherLand: '#77824d',
    availableOverlay: 'rgba(255,255,255,0)',
    holdOverlay: 'rgba(241,196,15,0.28)',
    bookedOverlay: 'rgba(230,126,34,0.28)',
    soldOverlay: 'rgba(192,57,43,0.32)',
    plotNumber: '#111418',
    dimensionText: '#394149',
    roadText: '#d8dde3',
    facilityText: '#1a1f24',
    selectionFill: 'rgba(35,125,255,0.28)',
    selectionStroke: 'rgba(83,160,255,0.95)',
    controlBackground: 'rgba(20,25,30,0.82)',
    controlText: '#f1f4f7',
  });

  function landUseFill(plot, theme) {
    const value = text(plot.landUse || plot.category || 'RESIDENTIAL')
      .toUpperCase()
      .replace(/\s+/g, '_');

    if (value === 'COMMERCIAL') return theme.commercial;
    if (value === 'FACILITY') return theme.facility;
    if (value === 'OTHER_LAND') return theme.otherLand;
    return theme.residential;
  }

  function statusOverlay(plot, theme) {
    const status = text(plot.status || 'AVAILABLE').toUpperCase();
    if (status === 'HOLD') return theme.holdOverlay;
    if (status === 'BOOKED') return theme.bookedOverlay;
    if (status === 'SOLD') return theme.soldOverlay;
    return theme.availableOverlay;
  }

  function computeBounds(plots) {
    if (!Array.isArray(plots) || plots.length === 0) {
      throw new Error('Map requires at least one plot.');
    }

    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;

    for (const plot of plots) {
      for (const v of plot.vertices || []) {
        minX = Math.min(minX, Number(v.x));
        minY = Math.min(minY, Number(v.y));
        maxX = Math.max(maxX, Number(v.x));
        maxY = Math.max(maxY, Number(v.y));
      }
    }

    if (![minX, minY, maxX, maxY].every(Number.isFinite)) {
      throw new Error('Invalid plot geometry.');
    }

    return {
      minX, minY, maxX, maxY,
      width: maxX - minX,
      height: maxY - minY,
      center: { x: (minX + maxX) / 2, y: (minY + maxY) / 2 },
    };
  }

  function buildFitViewport(bounds, width, height, padding) {
    const usableW = Math.max(1, width - padding * 2);
    const usableH = Math.max(1, height - padding * 2);
    const sx = bounds.width > 0 ? usableW / bounds.width : 1;
    const sy = bounds.height > 0 ? usableH / bounds.height : 1;
    const zoom = Math.max(0.01, Math.min(sx, sy));

    return {
      width,
      height,
      padding,
      zoom,
      panX: width / 2 - bounds.center.x * zoom,
      panY: height / 2 + bounds.center.y * zoom,
    };
  }

  function worldToScreen(point, viewport) {
    return {
      x: point.x * viewport.zoom + viewport.panX,
      y: -point.y * viewport.zoom + viewport.panY,
    };
  }

  function screenToWorld(point, viewport) {
    return {
      x: (point.x - viewport.panX) / viewport.zoom,
      y: -(point.y - viewport.panY) / viewport.zoom,
    };
  }

  function polygonCentroid(vertices) {
    if (!vertices || vertices.length < 3) return { x: 0, y: 0 };

    let area2 = 0, cx = 0, cy = 0;

    for (let i = 0; i < vertices.length; i++) {
      const a = vertices[i];
      const b = vertices[(i + 1) % vertices.length];
      const cross = a.x * b.y - b.x * a.y;
      area2 += cross;
      cx += (a.x + b.x) * cross;
      cy += (a.y + b.y) * cross;
    }

    if (Math.abs(area2) < 1e-9) {
      const sum = vertices.reduce((s, v) => ({ x: s.x + v.x, y: s.y + v.y }), { x: 0, y: 0 });
      return { x: sum.x / vertices.length, y: sum.y / vertices.length };
    }

    return { x: cx / (3 * area2), y: cy / (3 * area2) };
  }

  function pointInPolygon(point, vertices) {
    let inside = false;

    for (let i = 0, j = vertices.length - 1; i < vertices.length; j = i++) {
      const xi = vertices[i].x, yi = vertices[i].y;
      const xj = vertices[j].x, yj = vertices[j].y;
      const intersect =
        yi > point.y !== yj > point.y &&
        point.x < ((xj - xi) * (point.y - yi)) / ((yj - yi) || Number.EPSILON) + xi;

      if (intersect) inside = !inside;
    }

    return inside;
  }

  function makePath(ctx, vertices, viewport) {
    if (!vertices || !vertices.length) return;

    const first = worldToScreen(vertices[0], viewport);
    ctx.beginPath();
    ctx.moveTo(first.x, first.y);

    for (let i = 1; i < vertices.length; i++) {
      const p = worldToScreen(vertices[i], viewport);
      ctx.lineTo(p.x, p.y);
    }

    ctx.closePath();
  }

  function zoomBasedPlotFont(zoom) {
    if (zoom < 8) return 10;
    if (zoom > 35) return 16;
    return clamp(10 + (zoom - 8) * 0.22, 10, 16);
  }

  function dimensionVisible(zoom, selected) {
    if (selected) return zoom >= 7;
    return zoom >= 11;
  }

  function drawPlot(ctx, plot, viewport, theme, selectedPlotNumber) {
    const selected = text(plot.plotNumber || plot.plotNo) === text(selectedPlotNumber);

    makePath(ctx, plot.vertices, viewport);

    ctx.fillStyle = landUseFill(plot, theme);
    ctx.fill();

    const overlay = statusOverlay(plot, theme);
    if (overlay !== theme.availableOverlay) {
      makePath(ctx, plot.vertices, viewport);
      ctx.fillStyle = overlay;
      ctx.fill();
    }

    makePath(ctx, plot.vertices, viewport);
    ctx.strokeStyle = theme.plotBorder;
    ctx.lineWidth = clamp(0.8 + viewport.zoom / 80, 0.8, 1.25);
    ctx.setLineDash([]);
    ctx.stroke();

    const centroid = plot.centroid || polygonCentroid(plot.vertices);
    const labelPoint = worldToScreen(centroid, viewport);

    const fontSize = zoomBasedPlotFont(viewport.zoom);
    ctx.fillStyle = theme.plotNumber;
    ctx.font = `600 ${fontSize}px system-ui, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text(plot.plotNumber || plot.plotNo), labelPoint.x, labelPoint.y);

    if (dimensionVisible(viewport.zoom, selected)) {
      const sides = plot.sideLengthsFt || [];
      for (let i = 0; i < Math.min(sides.length, plot.vertices.length); i++) {
        const a = worldToScreen(plot.vertices[i], viewport);
        const b = worldToScreen(plot.vertices[(i + 1) % plot.vertices.length], viewport);
        const mx = (a.x + b.x) / 2;
        const my = (a.y + b.y) / 2;

        ctx.save();
        ctx.translate(mx, my);
        ctx.rotate(Math.atan2(b.y - a.y, b.x - a.x));
        ctx.fillStyle = theme.dimensionText;
        ctx.font = '10px system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';
        ctx.fillText(`${Number(sides[i]).toFixed(1)}'`, 0, -2);
        ctx.restore();
      }
    }

    if (selected) {
      makePath(ctx, plot.vertices, viewport);
      ctx.fillStyle = theme.selectionFill;
      ctx.fill();

      makePath(ctx, plot.vertices, viewport);
      ctx.strokeStyle = theme.selectionStroke;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.stroke();
      ctx.setLineDash([]);
    }
  }

  function drawRoads(ctx, roads, viewport, theme) {
    for (const road of roads || []) {
      const point = road.labelPoint || (road.vertices && road.vertices[0]) || null;
      if (!point || viewport.zoom < 6) continue;

      const p = worldToScreen(point, viewport);
      ctx.fillStyle = theme.roadText;
      ctx.font = '700 11px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text(road.name), p.x, p.y);
    }
  }

  function drawSpecialAreas(ctx, areas, viewport, theme) {
    for (const area of areas || []) {
      if (!area.vertices || area.vertices.length < 3) continue;

      makePath(ctx, area.vertices, viewport);
      ctx.fillStyle = text(area.category).toUpperCase() === 'OTHER LAND'
        ? theme.otherLand
        : theme.facility;
      ctx.fill();

      makePath(ctx, area.vertices, viewport);
      ctx.strokeStyle = theme.plotBorder;
      ctx.lineWidth = 1;
      ctx.setLineDash([]);
      ctx.stroke();

      if (viewport.zoom >= 7) {
        const c = area.centroid || polygonCentroid(area.vertices);
        const p = worldToScreen(c, viewport);
        ctx.fillStyle = theme.facilityText;
        ctx.font = '600 11px system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text(area.name || area.category), p.x, p.y);
      }
    }
  }

  function hitTestPlot(screenPoint, viewport, plots) {
    const world = screenToWorld(screenPoint, viewport);

    for (let i = plots.length - 1; i >= 0; i--) {
      if (pointInPolygon(world, plots[i].vertices || [])) {
        return plots[i];
      }
    }

    return null;
  }

  class MapCanvasViewer {
    constructor(canvas, options = {}) {
      if (!canvas || typeof canvas.getContext !== 'function') {
        throw new TypeError('A valid canvas is required.');
      }

      this.canvas = canvas;
      this.ctx = canvas.getContext('2d');
      this.theme = Object.assign({}, DEFAULT_THEME, options.theme || {});
      this.padding = Number(options.padding ?? 36);
      this.mapModel = null;
      this.viewport = null;
      this.homeViewport = null;
      this.selectedPlotNumber = '';
      this.drag = null;
      this.listeners = [];
      this.onSelectionChange =
        typeof options.onSelectionChange === 'function'
          ? options.onSelectionChange
          : null;

      this.bindEvents();
    }

    setMapModel(mapModel) {
      if (!mapModel || !mapModel.layers || !Array.isArray(mapModel.layers.plots)) {
        throw new TypeError('mapModel.layers.plots is required.');
      }

      this.mapModel = mapModel;
      this.fitHome();
      this.render();
    }

    resize(width, height) {
      this.canvas.width = Math.max(1, Math.floor(width));
      this.canvas.height = Math.max(1, Math.floor(height));

      if (this.mapModel) {
        this.fitHome();
        this.render();
      }
    }

    fitHome() {
      if (!this.mapModel) return;

      const bounds = computeBounds(this.mapModel.layers.plots);
      this.viewport = buildFitViewport(
        bounds,
        this.canvas.width || 1,
        this.canvas.height || 1,
        this.padding
      );
      this.homeViewport = Object.assign({}, this.viewport);
    }

    resetHome() {
      if (!this.homeViewport) return;
      this.viewport = Object.assign({}, this.homeViewport);
      this.render();
    }

    resetNorth() {
      // 2D V1 viewer is north-up by design.
      this.render();
    }

    selectPlot(plotNumber, autoFocus = true) {
      const target = text(plotNumber);
      const plot = (this.mapModel?.layers?.plots || []).find(
        p => text(p.plotNumber || p.plotNo) === target
      );

      if (!plot) return false;

      this.selectedPlotNumber = target;

      if (autoFocus) {
        const c = plot.centroid || polygonCentroid(plot.vertices);
        const currentZoom = this.viewport.zoom;
        const nextZoom = clamp(currentZoom * 1.25, currentZoom * 1.2, currentZoom * 1.3);
        this.viewport.zoom = nextZoom;
        this.viewport.panX = this.canvas.width / 2 - c.x * nextZoom;
        this.viewport.panY = this.canvas.height / 2 + c.y * nextZoom;
      }

      this.render();

      if (this.onSelectionChange) {
        this.onSelectionChange(plot);
      }

      return true;
    }

    clearSelection() {
      if (!this.selectedPlotNumber) return;
      this.selectedPlotNumber = '';
      this.render();
      if (this.onSelectionChange) this.onSelectionChange(null);
    }

    searchAndSelect(query) {
      const q = text(query).toLowerCase();
      if (!q || !this.mapModel) return false;

      const plot = this.mapModel.layers.plots.find(p => {
        const no = text(p.plotNumber || p.plotNo).toLowerCase();
        return no === q || no.includes(q);
      });

      if (!plot) return false;
      return this.selectPlot(text(plot.plotNumber || plot.plotNo), true);
    }

    render() {
      if (!this.mapModel || !this.viewport) return;

      const ctx = this.ctx;
      ctx.save();
      ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      ctx.fillStyle = this.theme.background;
      ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

      drawSpecialAreas(
        ctx,
        this.mapModel.layers.specialAreas || [],
        this.viewport,
        this.theme
      );

      for (const plot of this.mapModel.layers.plots) {
        drawPlot(
          ctx,
          plot,
          this.viewport,
          this.theme,
          this.selectedPlotNumber
        );
      }

      drawRoads(
        ctx,
        this.mapModel.layers.roads || [],
        this.viewport,
        this.theme
      );

      ctx.restore();
    }

    bindEvents() {
      const add = (name, handler, options) => {
        if (typeof this.canvas.addEventListener === 'function') {
          this.canvas.addEventListener(name, handler, options);
          this.listeners.push([name, handler, options]);
        }
      };

      add('wheel', (event) => {
        if (!this.viewport) return;
        if (event.preventDefault) event.preventDefault();

        const rect = this.canvas.getBoundingClientRect
          ? this.canvas.getBoundingClientRect()
          : { left: 0, top: 0 };

        const point = {
          x: event.clientX - rect.left,
          y: event.clientY - rect.top,
        };

        const before = screenToWorld(point, this.viewport);
        const factor = event.deltaY < 0 ? 1.12 : 1 / 1.12;
        const nextZoom = clamp(this.viewport.zoom * factor, 0.5, 250);

        this.viewport.zoom = nextZoom;
        this.viewport.panX = point.x - before.x * nextZoom;
        this.viewport.panY = point.y + before.y * nextZoom;

        this.render();
      }, { passive: false });

      add('mousedown', (event) => {
        this.drag = {
          x: event.clientX,
          y: event.clientY,
          panX: this.viewport ? this.viewport.panX : 0,
          panY: this.viewport ? this.viewport.panY : 0,
          moved: false,
        };
      });

      add('mousemove', (event) => {
        if (!this.drag || !this.viewport) return;

        const dx = event.clientX - this.drag.x;
        const dy = event.clientY - this.drag.y;

        if (Math.abs(dx) + Math.abs(dy) > 2) this.drag.moved = true;

        this.viewport.panX = this.drag.panX + dx;
        this.viewport.panY = this.drag.panY + dy;
        this.render();
      });

      add('mouseup', (event) => {
        if (!this.drag || !this.viewport || !this.mapModel) {
          this.drag = null;
          return;
        }

        const moved = this.drag.moved;
        this.drag = null;
        if (moved) return;

        const rect = this.canvas.getBoundingClientRect
          ? this.canvas.getBoundingClientRect()
          : { left: 0, top: 0 };

        const plot = hitTestPlot(
          { x: event.clientX - rect.left, y: event.clientY - rect.top },
          this.viewport,
          this.mapModel.layers.plots
        );

        if (plot) {
          this.selectPlot(text(plot.plotNumber || plot.plotNo), true);
        } else {
          this.clearSelection();
        }
      });

      add('mouseleave', () => {
        this.drag = null;
      });
    }

    destroy() {
      if (typeof this.canvas.removeEventListener === 'function') {
        for (const [name, handler, options] of this.listeners) {
          this.canvas.removeEventListener(name, handler, options);
        }
      }
      this.listeners = [];
    }
  }

  return {
    DEFAULT_THEME,
    landUseFill,
    statusOverlay,
    computeBounds,
    buildFitViewport,
    worldToScreen,
    screenToWorld,
    polygonCentroid,
    pointInPolygon,
    drawPlot,
    drawRoads,
    drawSpecialAreas,
    hitTestPlot,
    MapCanvasViewer,
  };
});
