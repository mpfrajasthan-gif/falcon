'use strict';

const assert = require('assert');

const {
  normalizeProject,
  resolveSelectedProject,
  openSelectedProjectPremiumViewer,
  buildProjectViewerButtonState,
  SelectedProjectPremiumViewerTriggerService,
} = require('./selected-project-premium-viewer-trigger');

(async () => {
  console.log('Falcon MAP.8.4 Selected Project Premium Viewer Trigger Tests');
  console.log('------------------------------------------------------------');

  let assertions = 0;
  const check = (a, e) => { assert.deepStrictEqual(a, e); assertions += 1; };
  const yes = (v) => { assert.strictEqual(v, true); assertions += 1; };
  const no = (v) => { assert.strictEqual(v, false); assertions += 1; };

  const projects = [
    {
      id: 'FP-000001',
      uuid: 'u1',
      name: 'Jaipur Pride',
      status: 'Active',
    },
    {
      id: 'FP-000002',
      uuid: 'u2',
      name: 'Falcon Greens',
      status: 'Active',
    },
  ];

  const normalized = normalizeProject(projects[0]);
  check(normalized.id, 'FP-000001');
  check(normalized.name, 'Jaipur Pride');

  const selected = resolveSelectedProject({
    projects,
    selectedProjectId: 'FP-000002',
  });

  yes(selected.found);
  check(selected.project.id, 'FP-000002');
  check(selected.project.name, 'Falcon Greens');

  const none = resolveSelectedProject({
    projects,
    selectedProjectId: '',
  });

  no(none.found);
  check(none.reason, 'NO_PROJECT_SELECTED');

  const missing = resolveSelectedProject({
    projects,
    selectedProjectId: 'FP-999999',
  });

  no(missing.found);
  check(missing.reason, 'SELECTED_PROJECT_NOT_FOUND');

  const disabled = buildProjectViewerButtonState({
    projects,
    selectedProjectId: '',
  });

  no(disabled.enabled);
  check(disabled.label, 'Open Premium Map');

  const enabled = buildProjectViewerButtonState({
    projects,
    selectedProjectId: 'FP-000001',
  });

  yes(enabled.enabled);
  check(enabled.selectedProjectId, 'FP-000001');
  yes(enabled.label.includes('Jaipur Pride'));

  let openedProject = null;

  const falconDesktop = {
    async openPremiumMapViewer(project) {
      openedProject = project;
      return { ok: true };
    },
  };

  const opened = await openSelectedProjectPremiumViewer({
    projects,
    selectedProjectId: 'FP-000001',
    falconDesktop,
  });

  yes(opened.ok);
  check(opened.reason, 'OPENED');
  check(openedProject.id, 'FP-000001');
  check(openedProject.name, 'Jaipur Pride');

  const noSelectionOpen = await openSelectedProjectPremiumViewer({
    projects,
    selectedProjectId: '',
    falconDesktop,
  });

  no(noSelectionOpen.ok);
  check(noSelectionOpen.reason, 'NO_PROJECT_SELECTED');

  const noBridge = await openSelectedProjectPremiumViewer({
    projects,
    selectedProjectId: 'FP-000001',
    falconDesktop: {},
  });

  no(noBridge.ok);
  check(noBridge.reason, 'BRIDGE_UNAVAILABLE');

  const failedOpen = await openSelectedProjectPremiumViewer({
    projects,
    selectedProjectId: 'FP-000001',
    falconDesktop: {
      async openPremiumMapViewer() {
        return { ok: false, error: 'Approved map-ready.json not found.' };
      },
    },
  });

  no(failedOpen.ok);
  check(failedOpen.reason, 'OPEN_FAILED');
  check(failedOpen.error, 'Approved map-ready.json not found.');

  assert.throws(
    () => normalizeProject({ id: 'BAD', name: 'Bad' }),
    /Valid selected Project ID/
  );
  assertions += 1;

  const service = new SelectedProjectPremiumViewerTriggerService();

  check(
    service.resolve({
      projects,
      selectedProjectId: 'FP-000002',
    }).project.name,
    'Falcon Greens'
  );

  yes(
    service.buttonState({
      projects,
      selectedProjectId: 'FP-000002',
    }).enabled
  );

  console.log('Selected Project Normalization: PASS');
  console.log('Selected Project Resolution: PASS');
  console.log('No-selection Safety: PASS');
  console.log('Missing-project Safety: PASS');
  console.log('Premium Map Button State: PASS');
  console.log('Selected Project → Premium Viewer Open: PASS');
  console.log('Bridge-unavailable Safety: PASS');
  console.log('Missing Map Error Handoff: PASS');
  console.log('Reusable Project Viewer Trigger Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('------------------------------------------------------------');
  console.log('MAP SELECTED PROJECT PREMIUM VIEWER TRIGGER TEST PASS');
})().catch(error => {
  console.error(error);
  process.exit(1);
});
