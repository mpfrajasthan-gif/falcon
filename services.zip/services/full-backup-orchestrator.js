'use strict';

const fs = require('fs');
const path = require('path');

const {
  createBackupManifest,
  verifyBackupManifest,
  validateRestoreCompatibility,
  createRestorePreview,
} = require('./backup-manifest-integrity');

const {
  createEncryptedBackupArchive,
  serializeEncryptedArchive,
  parseEncryptedArchive,
  decryptBackupArchive,
  verifyEncryptedArchive,
  createRestoreSecurityPreview,
} = require('./encrypted-backup-archive');

const {
  writeBackupFileAtomic,
  verifyBackupFile,
} = require('./safe-backup-file-writer');

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function buildBackupFileName({
  backupId,
  projectId = '',
  createdAt = '',
} = {}) {
  const id = text(backupId).toUpperCase();
  if (!id) throw new Error('backupId is required.');

  const project = text(projectId).toUpperCase();
  const date = text(createdAt).slice(0, 10).replace(/-/g, '') || 'backup';

  return `${project ? `${project}_` : ''}${id}_${date}.fbackup`;
}

function createFullBackup({
  backupId,
  password,
  directoryPath,
  fileName = '',
  appVersion = '',
  actorId = '',
  sourceDevice = '',
  projectId = '',
  sections,
  data = {},
  createdAt,
  overwrite = false,
} = {}) {
  if (!text(directoryPath)) {
    throw new Error('directoryPath is required.');
  }

  const manifest = createBackupManifest({
    backupId,
    appVersion,
    createdAt,
    actorId,
    sourceDevice,
    projectId,
    sections,
    data,
  });

  const encryptedArchive = createEncryptedBackupArchive({
    backupId: manifest.backupId,
    password,
    manifest,
    data,
    createdAt: manifest.createdAt,
  });

  const serializedArchive = serializeEncryptedArchive(encryptedArchive);
  const archiveHash = require('crypto')
    .createHash('sha256')
    .update(Buffer.from(serializedArchive, 'utf8'))
    .digest('hex');

  const finalFileName = text(fileName) || buildBackupFileName({
    backupId: manifest.backupId,
    projectId: manifest.projectId,
    createdAt: manifest.createdAt,
  });

  const writeResult = writeBackupFileAtomic({
    directoryPath,
    fileName: finalFileName,
    serializedArchive,
    expectedHash: archiveHash,
    overwrite,
  });

  const fileVerification = verifyBackupFile({
    filePath: writeResult.filePath,
    expectedHash: archiveHash,
  });

  const archiveVerification = verifyEncryptedArchive({
    archive: encryptedArchive,
    password,
  });

  const manifestVerification = verifyBackupManifest({
    manifest,
    data,
  });

  const completed =
    writeResult.verified &&
    fileVerification.valid &&
    archiveVerification.valid &&
    manifestVerification.valid;

  if (!completed) {
    throw new Error('Backup final verification failed.');
  }

  return Object.freeze({
    completed: true,
    backupId: manifest.backupId,
    filePath: writeResult.filePath,
    fileName: writeResult.fileName,
    bytes: writeResult.bytes,
    fileSha256: writeResult.sha256,
    manifest,
    archiveHeader: encryptedArchive.header,
    verification: Object.freeze({
      fileValid: fileVerification.valid,
      archiveValid: archiveVerification.valid,
      manifestValid: manifestVerification.valid,
    }),
  });
}

function loadBackupFile(filePath) {
  if (!text(filePath)) throw new Error('filePath is required.');
  if (!fs.existsSync(filePath)) throw new Error('Backup file does not exist.');

  const serialized = fs.readFileSync(filePath, 'utf8');
  return parseEncryptedArchive(serialized);
}

function verifyBackupForRestore({
  filePath,
  password,
  supportedSchemaVersion = 1,
  currentAppVersion = '',
} = {}) {
  const fileCheck = verifyBackupFile({ filePath });

  if (!fileCheck.exists || !fileCheck.valid) {
    return Object.freeze({
      valid: false,
      stage: 'FILE',
      error: 'Backup file is missing or unreadable.',
    });
  }

  let archive;
  try {
    archive = loadBackupFile(filePath);
  } catch (error) {
    return Object.freeze({
      valid: false,
      stage: 'ARCHIVE_PARSE',
      error: error.message,
    });
  }

  const securityPreview = createRestoreSecurityPreview({ archive });

  let decrypted;
  try {
    decrypted = decryptBackupArchive({ archive, password });
  } catch (error) {
    return Object.freeze({
      valid: false,
      stage: 'DECRYPT',
      securityPreview,
      error: error.message,
    });
  }

  const manifestCheck = verifyBackupManifest({
    manifest: decrypted.manifest,
    data: decrypted.data,
  });

  if (!manifestCheck.valid) {
    return Object.freeze({
      valid: false,
      stage: 'MANIFEST',
      securityPreview,
      manifestCheck,
      error: 'Backup manifest integrity validation failed.',
    });
  }

  const compatibility = validateRestoreCompatibility({
    manifest: decrypted.manifest,
    supportedSchemaVersion,
    currentAppVersion,
  });

  if (!compatibility.compatible) {
    return Object.freeze({
      valid: false,
      stage: 'COMPATIBILITY',
      securityPreview,
      manifestCheck,
      compatibility,
      error: 'Backup is not compatible with this restore engine.',
    });
  }

  const restorePreview = createRestorePreview({
    manifest: decrypted.manifest,
    data: decrypted.data,
  });

  return Object.freeze({
    valid: true,
    stage: 'READY',
    backupId: decrypted.backupId,
    filePath,
    fileCheck,
    securityPreview,
    manifestCheck,
    compatibility,
    restorePreview,
    manifest: decrypted.manifest,
    data: decrypted.data,
  });
}

function buildBackupWorkflowSummary(result) {
  if (!result || typeof result !== 'object') {
    throw new TypeError('result is required.');
  }

  return Object.freeze({
    backupId: result.backupId,
    fileName: result.fileName,
    filePath: result.filePath,
    bytes: result.bytes,
    encrypted: true,
    fileVerified: Boolean(result.verification && result.verification.fileValid),
    archiveVerified: Boolean(result.verification && result.verification.archiveValid),
    manifestVerified: Boolean(result.verification && result.verification.manifestValid),
    completed: Boolean(result.completed),
  });
}

class FullBackupOrchestratorService {
  backup(input) {
    return createFullBackup(input);
  }

  verifyRestore(input) {
    return verifyBackupForRestore(input);
  }

  load(filePath) {
    return loadBackupFile(filePath);
  }

  summary(result) {
    return buildBackupWorkflowSummary(result);
  }
}

module.exports = {
  text,
  buildBackupFileName,
  createFullBackup,
  loadBackupFile,
  verifyBackupForRestore,
  buildBackupWorkflowSummary,
  FullBackupOrchestratorService,
};
