'use strict';

const assert = require('assert');

const {
  normalizeDate,
  normalizeCustomer,
  normalizeBooking,
  normalizePayment,
  normalizeReceipt,
  validateReceiptLinkage,
  buildCustomerStatement,
  buildCustomerReceiptIndex,
  buildCustomerStatementPrintModel,
  CustomerReceiptStatementIntegrationService,
} = require('./customer-receipt-statement-integration');

(() => {
  console.log('Falcon Customer Receipt & Statement Integration Tests');
  console.log('-----------------------------------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  const customer = {
    customerId: 'FC-000001',
    customerName: 'Shadab Aziz',
    mobile: '9876543210',
    address: 'Sawai Madhopur',
    email: 'shadab@example.com',
  };

  const bookings = [
    {
      bookingId: 'FB-000001',
      customerId: 'FC-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '43',
      bookingDate: '25-07-2026',
      grandTotal: 500000,
      paidAmount: 125000,
      balanceAmount: 375000,
      status: 'BOOKED',
    },
    {
      bookingId: 'FB-000002',
      customerId: 'FC-000001',
      projectName: 'Sawai Estate',
      plotNumber: '8',
      bookingDate: '20-07-2026',
      grandTotal: 450000,
      paidAmount: 450000,
      balanceAmount: 0,
      status: 'SOLD',
    },
  ];

  const payments = [
    {
      paymentId: 'PAY-000001',
      bookingId: 'FB-000001',
      amount: 100000,
      paymentDate: '26-07-2026',
      mode: 'CASH',
      status: 'POSTED',
      receiptNumber: 'RCP-000001',
    },
    {
      paymentId: 'PAY-000002',
      bookingId: 'FB-000001',
      amount: 25000,
      paymentDate: '29-07-2026',
      mode: 'UPI',
      status: 'POSTED',
      receiptNumber: 'RCP-000002',
      referenceNumber: 'UPI-REF-2',
    },
    {
      paymentId: 'PAY-000003',
      bookingId: 'FB-000002',
      amount: 450000,
      paymentDate: '21-07-2026',
      mode: 'BANK_TRANSFER',
      status: 'POSTED',
      receiptNumber: 'RCP-000003',
    },
    {
      paymentId: 'PAY-000004',
      bookingId: 'FB-000001',
      amount: 10000,
      paymentDate: '29-07-2026',
      mode: 'CASH',
      status: 'REVERSED',
      receiptNumber: 'RCP-000004',
    },
  ];

  const receipts = [
    {
      receiptNumber: 'RCP-000001',
      bookingId: 'FB-000001',
      paymentId: 'PAY-000001',
      customerId: 'FC-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '43',
      paymentDate: '26-07-2026',
      currentPayment: 100000,
      cumulativePaid: 100000,
      balanceAmount: 400000,
      paymentMode: 'CASH',
      status: 'ISSUED',
    },
    {
      receiptNumber: 'RCP-000002',
      bookingId: 'FB-000001',
      paymentId: 'PAY-000002',
      customerId: 'FC-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '43',
      paymentDate: '29-07-2026',
      currentPayment: 25000,
      cumulativePaid: 125000,
      balanceAmount: 375000,
      paymentMode: 'UPI',
      referenceNumber: 'UPI-REF-2',
      status: 'ISSUED',
    },
    {
      receiptNumber: 'RCP-000003',
      bookingId: 'FB-000002',
      paymentId: 'PAY-000003',
      customerId: 'FC-000001',
      projectName: 'Sawai Estate',
      plotNumber: '8',
      paymentDate: '21-07-2026',
      currentPayment: 450000,
      cumulativePaid: 450000,
      balanceAmount: 0,
      paymentMode: 'BANK_TRANSFER',
      status: 'ISSUED',
    },
    {
      receiptNumber: 'RCP-000004',
      bookingId: 'FB-000001',
      paymentId: 'PAY-000004',
      customerId: 'FC-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '43',
      paymentDate: '29-07-2026',
      currentPayment: 10000,
      cumulativePaid: 135000,
      balanceAmount: 365000,
      paymentMode: 'CASH',
      status: 'CANCELLED',
    },
  ];

  check(normalizeDate('29-07-2026'), '2026-07-29');
  check(normalizeCustomer(customer).customerId, 'FC-000001');
  check(normalizeBooking(bookings[0]).bookingId, 'FB-000001');
  check(normalizePayment(payments[0]).paymentId, 'PAY-000001');
  check(normalizeReceipt(receipts[0]).receiptNumber, 'RCP-000001');

  const nb = normalizeBooking(bookings[0]);
  const np = normalizePayment(payments[0]);
  const nr = normalizeReceipt(receipts[0]);

  checkTrue(validateReceiptLinkage({ booking: nb, payment: np, receipt: nr }));

  const statement = buildCustomerStatement({
    customer,
    bookings,
    payments,
    receipts,
  });

  check(statement.summary.bookingCount, 2);
  check(statement.summary.paymentCount, 3);
  check(statement.summary.receiptCount, 3);
  check(statement.summary.totalBookingValue, 950000);
  check(statement.summary.totalPayments, 575000);
  check(statement.summary.totalBalance, 375000);

  check(statement.rows.length, 5);
  check(statement.rows[0].type, 'BOOKING');
  check(statement.rows[0].debit, 450000);
  check(statement.rows[0].runningBalance, 450000);

  check(statement.rows[1].type, 'PAYMENT');
  check(statement.rows[1].credit, 450000);
  check(statement.rows[1].runningBalance, 0);

  check(statement.rows[2].type, 'BOOKING');
  check(statement.rows[2].debit, 500000);
  check(statement.rows[2].runningBalance, 500000);

  check(statement.rows[3].receiptNumber, 'RCP-000001');
  check(statement.rows[3].runningBalance, 400000);

  check(statement.rows[4].receiptNumber, 'RCP-000002');
  check(statement.rows[4].runningBalance, 375000);

  const dated = buildCustomerStatement({
    customer,
    bookings,
    payments,
    receipts,
    dateFrom: '25-07-2026',
    dateTo: '29-07-2026',
  });

  check(dated.rows.length, 3);
  check(dated.rows[0].bookingId, 'FB-000001');

  const receiptIndex = buildCustomerReceiptIndex(statement);
  check(receiptIndex.length, 3);
  check(receiptIndex[0].receiptNumber, 'RCP-000002');
  check(receiptIndex[0].balanceAmount, 375000);
  checkTrue(receiptIndex.some((item) => item.receiptNumber === 'RCP-000003'));

  const printModel = buildCustomerStatementPrintModel(statement);
  check(printModel.customer.customerName, 'Shadab Aziz');
  check(printModel.summary.totalBalance, 375000);
  check(printModel.rows.length, 5);
  checkTrue(printModel.footer.note.includes('posted payments'));

  const service = new CustomerReceiptStatementIntegrationService();

  const serviceStatement = service.statement({
    customer,
    bookings,
    payments,
    receipts,
  });

  check(serviceStatement.summary.totalPayments, 575000);

  const serviceIndex = service.receiptIndex(serviceStatement);
  check(serviceIndex.length, 3);

  const badReceipt = normalizeReceipt({
    ...receipts[0],
    paymentId: 'PAY-BAD',
  });

  assert.throws(
    () =>
      validateReceiptLinkage({
        booking: nb,
        payment: np,
        receipt: badReceipt,
      }),
    /does not belong to payment/
  );
  assertions += 1;

  assert.throws(
    () =>
      buildCustomerStatement({
        customer,
        bookings: {},
        payments,
        receipts,
      }),
    /must be arrays/
  );
  assertions += 1;

  console.log('Customer ↔ Booking Linkage: PASS');
  console.log('Customer ↔ Payment Linkage: PASS');
  console.log('Payment ↔ Receipt Linkage: PASS');
  console.log('Receipt Integrity Link Validation: PASS');
  console.log('Customer Statement Debit/Credit: PASS');
  console.log('Running Balance: PASS');
  console.log('Reversed Payment Filtering: PASS');
  console.log('Cancelled Receipt Filtering: PASS');
  console.log('Date Range Statement Filter: PASS');
  console.log('Customer Receipt Index: PASS');
  console.log('Printable Statement Model: PASS');
  console.log('Reusable Statement Integration Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('-----------------------------------------------------');
  console.log('CUSTOMER RECEIPT & STATEMENT INTEGRATION TEST PASS');
})();
