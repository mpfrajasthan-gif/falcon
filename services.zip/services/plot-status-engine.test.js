'use strict';

const assert = require('assert');

const {
  PLOT_STATUS,
  USER_ROLE,
  normalizeText,
  normalizeAmount,
  isValidStatus,
  isAdminRole,
  calculatePaymentProgress,
  canTransition,
  evaluatePlotStatusChange,
  deriveStatusFromPayment,
  PlotStatusEngine,
} = require('./plot-status-engine');

(async () => {
  console.log('Falcon Plot Status Engine Tests');
  console.log('-------------------------------');

  let assertions = 0;
  const check = (actual, expected) => {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  };

  check(normalizeText(' booked '), 'BOOKED');
  check(normalizeAmount('5000'), 5000);
  check(normalizeAmount(-10), 0);
  check(isValidStatus('AVAILABLE'), true);
  check(isValidStatus('INVALID'), false);
  check(isAdminRole('ADMIN'), true);
  check(isAdminRole('SUPER_ADMIN'), true);
  check(isAdminRole('OPERATOR'), false);

  const p25 = calculatePaymentProgress(100000, 25000);
  check(p25.percentage, 25);
  check(p25.balance, 75000);
  check(p25.isFullyPaid, false);

  const p100 = calculatePaymentProgress(100000, 100000);
  check(p100.percentage, 100);
  check(p100.balance, 0);
  check(p100.isFullyPaid, true);

  const overPaid = calculatePaymentProgress(100000, 125000);
  check(overPaid.paidAmount, 100000);
  check(overPaid.percentage, 100);

  check(canTransition('AVAILABLE', 'HOLD'), true);
  check(canTransition('AVAILABLE', 'BOOKED'), true);
  check(canTransition('HOLD', 'AVAILABLE'), true);
  check(canTransition('HOLD', 'BOOKED'), true);
  check(canTransition('BOOKED', 'SOLD'), true);
  check(canTransition('SOLD', 'AVAILABLE'), false);
  check(canTransition('AVAILABLE', 'SOLD'), false);

  const operatorHold = evaluatePlotStatusChange({
    currentStatus: 'AVAILABLE',
    targetStatus: 'HOLD',
    role: 'OPERATOR',
  });
  check(operatorHold.allowed, false);
  check(operatorHold.code, 'ADMIN_REQUIRED_FOR_HOLD');

  const adminHold = evaluatePlotStatusChange({
    currentStatus: 'AVAILABLE',
    targetStatus: 'HOLD',
    role: 'ADMIN',
  });
  check(adminHold.allowed, true);

  const operatorRelease = evaluatePlotStatusChange({
    currentStatus: 'HOLD',
    targetStatus: 'AVAILABLE',
    role: 'OPERATOR',
  });
  check(operatorRelease.allowed, false);
  check(operatorRelease.code, 'ADMIN_REQUIRED_FOR_RELEASE');

  const adminRelease = evaluatePlotStatusChange({
    currentStatus: 'HOLD',
    targetStatus: 'AVAILABLE',
    role: 'SUPER_ADMIN',
  });
  check(adminRelease.allowed, true);

  const booked25 = evaluatePlotStatusChange({
    currentStatus: 'BOOKED',
    targetStatus: 'SOLD',
    role: 'ADMIN',
    totalPrice: 100000,
    paidAmount: 25000,
  });
  check(booked25.allowed, false);
  check(booked25.code, 'FULL_PAYMENT_REQUIRED');
  check(booked25.payment.percentage, 25);

  const booked50 = evaluatePlotStatusChange({
    currentStatus: 'BOOKED',
    targetStatus: 'SOLD',
    role: 'ADMIN',
    totalPrice: 100000,
    paidAmount: 50000,
  });
  check(booked50.allowed, false);
  check(booked50.payment.percentage, 50);

  const booked75 = evaluatePlotStatusChange({
    currentStatus: 'BOOKED',
    targetStatus: 'SOLD',
    role: 'ADMIN',
    totalPrice: 100000,
    paidAmount: 75000,
  });
  check(booked75.allowed, false);
  check(booked75.payment.percentage, 75);

  const booked100 = evaluatePlotStatusChange({
    currentStatus: 'BOOKED',
    targetStatus: 'SOLD',
    role: 'ADMIN',
    totalPrice: 100000,
    paidAmount: 100000,
  });
  check(booked100.allowed, true);
  check(booked100.payment.isFullyPaid, true);

  const releaseWithoutReason = evaluatePlotStatusChange({
    currentStatus: 'BOOKED',
    targetStatus: 'AVAILABLE',
    role: 'ADMIN',
  });
  check(releaseWithoutReason.allowed, false);
  check(releaseWithoutReason.code, 'REASON_REQUIRED');

  const releaseWithReason = evaluatePlotStatusChange({
    currentStatus: 'BOOKED',
    targetStatus: 'AVAILABLE',
    role: 'ADMIN',
    reason: 'Customer cancellation',
  });
  check(releaseWithReason.allowed, true);

  const soldLocked = evaluatePlotStatusChange({
    currentStatus: 'SOLD',
    targetStatus: 'AVAILABLE',
    role: 'SUPER_ADMIN',
    reason: 'Test',
  });
  check(soldLocked.allowed, false);
  check(soldLocked.code, 'TRANSITION_NOT_ALLOWED');

  const sameStatus = evaluatePlotStatusChange({
    currentStatus: 'AVAILABLE',
    targetStatus: 'AVAILABLE',
    role: 'OPERATOR',
  });
  check(sameStatus.allowed, true);
  check(sameStatus.code, 'NO_CHANGE');

  const derived25 = deriveStatusFromPayment({
    currentStatus: 'BOOKED',
    totalPrice: 100000,
    paidAmount: 25000,
  });
  check(derived25.status, 'BOOKED');
  check(derived25.changed, false);

  const derived100 = deriveStatusFromPayment({
    currentStatus: 'BOOKED',
    totalPrice: 100000,
    paidAmount: 100000,
  });
  check(derived100.status, 'SOLD');
  check(derived100.changed, true);

  const holdPreserved = deriveStatusFromPayment({
    currentStatus: 'HOLD',
    totalPrice: 100000,
    paidAmount: 100000,
  });
  check(holdPreserved.status, 'HOLD');

  const soldPreserved = deriveStatusFromPayment({
    currentStatus: 'SOLD',
    totalPrice: 100000,
    paidAmount: 0,
  });
  check(soldPreserved.status, 'SOLD');

  const store = {
    'FPL-000001': {
      plotId: 'FPL-000001',
      status: 'BOOKED',
      totalPrice: 100000,
      paidAmount: 100000,
    },
  };

  const auditEvents = [];

  const engine = new PlotStatusEngine({
    plotService: {
      async getPlotById(plotId) {
        return store[plotId] ?? null;
      },
      async updatePlot(plotId, changes) {
        store[plotId] = { ...store[plotId], ...changes };
        return store[plotId];
      },
    },
    auditService: {
      async record(event) {
        auditEvents.push(event);
      },
    },
  });

  const engineResult = await engine.changeStatus({
    plotId: 'FPL-000001',
    targetStatus: 'SOLD',
    role: USER_ROLE.ADMIN,
    actorId: 'FU-000001',
  });

  check(engineResult.success, true);
  check(engineResult.changed, true);
  check(store['FPL-000001'].status, PLOT_STATUS.SOLD);
  check(auditEvents.length, 1);
  check(auditEvents[0].eventType, 'PLOT_STATUS_CHANGED');
  check(auditEvents[0].fromStatus, 'BOOKED');
  check(auditEvents[0].toStatus, 'SOLD');

  const missingPlot = await engine.changeStatus({
    plotId: 'FPL-999999',
    targetStatus: 'BOOKED',
    role: USER_ROLE.ADMIN,
  });
  check(missingPlot.success, false);
  check(missingPlot.code, 'PLOT_NOT_FOUND');

  assert.throws(
    () => new PlotStatusEngine({}),
    /requires plotService.getPlotById/
  );
  assertions += 1;

  assert.throws(
    () => deriveStatusFromPayment({ currentStatus: 'BAD' }),
    /invalid/
  );
  assertions += 1;

  console.log('Status Rules: PASS');
  console.log('Admin Hold Security: PASS');
  console.log('Hold Release Security: PASS');
  console.log('Payment Progress: PASS');
  console.log('100% Sold Rule: PASS');
  console.log('Sold Status Lock: PASS');
  console.log('Cancellation Reason: PASS');
  console.log('Audit Integration: PASS');
  console.log('Service Integration: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('-------------------------------');
  console.log('PLOT STATUS ENGINE TEST PASS');
})().catch((error) => {
  console.error('PLOT STATUS ENGINE TEST FAIL');
  console.error(error.stack || error.message);
  process.exitCode = 1;
});
