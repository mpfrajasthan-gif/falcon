'use strict';

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function finiteNumber(value, fieldName) {
  const n = Number(value);
  if (!Number.isFinite(n)) throw new TypeError(`${fieldName} must be a valid number.`);
  return n;
}

function computePlotLabelSize(zoom, options = {}) {
  const minSize = options.minSizePx ?? 10;
  const preferred = options.preferredSizePx ?? 15;
  const maxSize = options.maxSizePx ?? 16;

  const z = finiteNumber(zoom, 'zoom');
  if (z <= 0.75) return minSize;
  if (z >= 2.0) return maxSize;

  const t = (z - 0.75) / (2.0 - 0.75);
  return clamp(minSize + (preferred - minSize) * Math.min(1, t * 1.15), minSize, maxSize);
}

function shouldShowDimensions(zoom, selected = false) {
  const z = finiteNumber(zoom, 'zoom');
  if (selected) return z >= 0.85;
  return z >= 1.15;
}

function shouldShowRoadLabels(zoom) {
  return finiteNumber(zoom, 'zoom') >= 0.6;
}

function shouldShowFacilityLabels(zoom) {
  return finiteNumber(zoom, 'zoom') >= 0.7;
}

function lineWeightForZoom(zoom, baseWidth = 1) {
  const z = finiteNumber(zoom, 'zoom');
  if (z < 0.75) return clamp(baseWidth * 0.8, 0.6, 1.2);
  if (z > 2.5) return clamp(baseWidth * 1.2, 0.8, 1.5);
  return clamp(baseWidth, 0.7, 1.3);
}

function estimateTextBox({
  textValue,
  x,
  y,
  fontSizePx,
  paddingPx = 2,
} = {}) {
  const value = text(textValue);
  const size = finiteNumber(fontSizePx, 'fontSizePx');

  const width = Math.max(size * 0.7, value.length * size * 0.58) + paddingPx * 2;
  const height = size * 1.2 + paddingPx * 2;

  return Object.freeze({
    x: finiteNumber(x, 'x') - width / 2,
    y: finiteNumber(y, 'y') - height / 2,
    width,
    height,
    right: finiteNumber(x, 'x') + width / 2,
    bottom: finiteNumber(y, 'y') + height / 2,
  });
}

function boxesOverlap(a, b, gap = 2) {
  return !(
    a.right + gap < b.x ||
    b.right + gap < a.x ||
    a.bottom + gap < b.y ||
    b.bottom + gap < a.y
  );
}

function deconflictLabels(labels = [], options = {}) {
  const gap = options.gapPx ?? 2;
  const accepted = [];
  const hidden = [];

  const sorted = labels.slice().sort((a, b) => {
    const priorityA = Number(a.priority ?? 0);
    const priorityB = Number(b.priority ?? 0);
    if (priorityA !== priorityB) return priorityB - priorityA;
    return String(a.id).localeCompare(String(b.id));
  });

  for (const label of sorted) {
    const box = estimateTextBox({
      textValue: label.text,
      x: label.point.x,
      y: label.point.y,
      fontSizePx: label.fontSizePx,
    });

    const collision = accepted.some((item) =>
      boxesOverlap(box, item.box, gap)
    );

    if (collision && !label.alwaysShow) {
      hidden.push(Object.freeze({
        ...label,
        reason: 'COLLISION',
      }));
      continue;
    }

    accepted.push(Object.freeze({
      label,
      box,
    }));
  }

  return Object.freeze({
    visible: Object.freeze(accepted.map((item) => item.label)),
    hidden: Object.freeze(hidden),
  });
}

function buildControlState({
  canHome = true,
  canCompass = true,
  northUp = true,
} = {}) {
  return Object.freeze({
    home: Object.freeze({
      visible: Boolean(canHome),
      enabled: Boolean(canHome),
      action: 'FIT_HOME',
    }),
    compass: Object.freeze({
      visible: Boolean(canCompass),
      enabled: Boolean(canCompass),
      northUp: Boolean(northUp),
      action: 'RESET_NORTH',
    }),
  });
}

function buildViewerDisplayRules({
  zoom,
  selectedPlotNumber = '',
} = {}) {
  const selected = Boolean(text(selectedPlotNumber));

  return Object.freeze({
    zoom: finiteNumber(zoom, 'zoom'),
    plotNumberSizePx: computePlotLabelSize(zoom),
    dimensionsVisible: shouldShowDimensions(zoom, selected),
    roadLabelsVisible: shouldShowRoadLabels(zoom),
    facilityLabelsVisible: shouldShowFacilityLabels(zoom),
    plotBorderWidthPx: lineWeightForZoom(zoom, 1),
    roadBorderWidthPx: lineWeightForZoom(zoom, 1),
    selectionBorderWidthPx: lineWeightForZoom(zoom, 1),
    antiClutter: Object.freeze({
      enabled: true,
      collisionGapPx: 2,
      plotNumbersPriority: 100,
      selectedPlotPriority: 1000,
      roadLabelPriority: 60,
      facilityLabelPriority: 70,
      dimensionsPriority: 40,
    }),
    performance: Object.freeze({
      smoothWheelZoom: true,
      smoothPan: true,
      avoidLayoutThrash: true,
      renderOnlyVisibleLabels: true,
    }),
    visualBalance: Object.freeze({
      thinPlotLines: true,
      compactRoadText: true,
      plotNumbersRemainReadable: true,
      selectedPlotAlwaysReadable: true,
      dimensionTextUnshaded: true,
    }),
  });
}

function buildLabelCandidates({
  plotLabels = [],
  roadLabels = [],
  facilityLabels = [],
  dimensionLabels = [],
  selectedPlotNumber = '',
  zoom,
} = {}) {
  const rules = buildViewerDisplayRules({
    zoom,
    selectedPlotNumber,
  });

  const selectedNo = text(selectedPlotNumber);

  const labels = [];

  for (const label of plotLabels) {
    labels.push(Object.freeze({
      ...label,
      fontSizePx: rules.plotNumberSizePx,
      priority: text(label.plotNumber) === selectedNo
        ? rules.antiClutter.selectedPlotPriority
        : rules.antiClutter.plotNumbersPriority,
      alwaysShow: text(label.plotNumber) === selectedNo,
      kind: 'PLOT_NUMBER',
    }));
  }

  if (rules.roadLabelsVisible) {
    for (const label of roadLabels) {
      labels.push(Object.freeze({
        ...label,
        priority: rules.antiClutter.roadLabelPriority,
        alwaysShow: false,
        kind: 'ROAD_LABEL',
      }));
    }
  }

  if (rules.facilityLabelsVisible) {
    for (const label of facilityLabels) {
      labels.push(Object.freeze({
        ...label,
        priority: rules.antiClutter.facilityLabelPriority,
        alwaysShow: false,
        kind: 'FACILITY_LABEL',
      }));
    }
  }

  if (rules.dimensionsVisible) {
    for (const label of dimensionLabels) {
      labels.push(Object.freeze({
        ...label,
        priority: rules.antiClutter.dimensionsPriority,
        alwaysShow: false,
        kind: 'DIMENSION',
      }));
    }
  }

  return Object.freeze({
    rules,
    labels: Object.freeze(labels),
  });
}

function buildPolishedDisplayModel(input = {}) {
  const candidateSet = buildLabelCandidates(input);

  const deconflicted = deconflictLabels(candidateSet.labels, {
    gapPx: candidateSet.rules.antiClutter.collisionGapPx,
  });

  return Object.freeze({
    rules: candidateSet.rules,
    controls: buildControlState(),
    labels: deconflicted,
    summary: Object.freeze({
      visibleLabelCount: deconflicted.visible.length,
      hiddenLabelCount: deconflicted.hidden.length,
      dimensionsVisible: candidateSet.rules.dimensionsVisible,
      roadLabelsVisible: candidateSet.rules.roadLabelsVisible,
      facilityLabelsVisible: candidateSet.rules.facilityLabelsVisible,
    }),
  });
}

class MapViewerPolishService {
  plotLabelSize(zoom, options) {
    return computePlotLabelSize(zoom, options);
  }

  showDimensions(zoom, selected) {
    return shouldShowDimensions(zoom, selected);
  }

  showRoadLabels(zoom) {
    return shouldShowRoadLabels(zoom);
  }

  deconflict(labels, options) {
    return deconflictLabels(labels, options);
  }

  rules(input) {
    return buildViewerDisplayRules(input);
  }

  controls(input) {
    return buildControlState(input);
  }

  display(input) {
    return buildPolishedDisplayModel(input);
  }
}

module.exports = {
  text,
  clamp,
  finiteNumber,
  computePlotLabelSize,
  shouldShowDimensions,
  shouldShowRoadLabels,
  shouldShowFacilityLabels,
  lineWeightForZoom,
  estimateTextBox,
  boxesOverlap,
  deconflictLabels,
  buildControlState,
  buildViewerDisplayRules,
  buildLabelCandidates,
  buildPolishedDisplayModel,
  MapViewerPolishService,
};
