'use strict';

const crypto = require('crypto');

const {
  adaptV15Draft,
  buildPlotCoreRecords,
  buildMapReadyModel,
  createV15Diagnostics,
} = require('./dxf-v15-real-engine-bridge');

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function stableStringify(value) {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value);
  }

  if (Array.isArray(value)) {
    return `[${value.map(stableStringify).join(',')}]`;
  }

  const keys = Object.keys(value).sort();
  return `{${keys.map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
}

function sha256(value) {
  return crypto
    .createHash('sha256')
    .update(typeof value === 'string' ? value : stableStringify(value))
    .digest('hex');
}

function validateProjectRecord(project = {}) {
  const projectId = upper(project.projectId || project.id);
  if (!/^FP-\d{6}$/.test(projectId)) {
    throw new Error('Valid Falcon projectId is required.');
  }

  if (!text(project.projectName || project.name)) {
    throw new Error('Project name is required.');
  }

  return Object.freeze({
    projectId,
    projectName: text(project.projectName || project.name),
    projectFolder: text(project.projectFolder || project.folderPath),
    status: upper(project.status || 'ACTIVE'),
  });
}

function createImportFingerprint({
  projectId,
  dxfModel,
} = {}) {
  if (!dxfModel || typeof dxfModel !== 'object') {
    throw new TypeError('dxfModel is required.');
  }

  const payload = {
    projectId: upper(projectId),
    sourceSha256: text(dxfModel.project?.sourceSha256),
    sourceEngine: text(dxfModel.sourceEngine),
    sourceSchema: text(dxfModel.sourceSchema),
    plotNumbers: dxfModel.plots.map((plot) => plot.plotNo),
    roadCount: dxfModel.roads.length,
    specialAreaCount: dxfModel.specialAreas.length,
  };

  return sha256(payload);
}

function checkImportConflict({
  project,
  existingImport = null,
  fingerprint,
} = {}) {
  const validatedProject = validateProjectRecord(project);

  if (!text(fingerprint)) {
    throw new Error('fingerprint is required.');
  }

  if (!existingImport) {
    return Object.freeze({
      conflict: false,
      reason: 'NO_EXISTING_IMPORT',
      projectId: validatedProject.projectId,
    });
  }

  if (upper(existingImport.projectId) !== validatedProject.projectId) {
    throw new Error('Existing import belongs to another project.');
  }

  if (text(existingImport.fingerprint) === text(fingerprint)) {
    return Object.freeze({
      conflict: true,
      duplicate: true,
      reason: 'SAME_DXF_ALREADY_IMPORTED',
      projectId: validatedProject.projectId,
    });
  }

  return Object.freeze({
    conflict: true,
    duplicate: false,
    reason: 'PROJECT_ALREADY_HAS_DIFFERENT_DXF_IMPORT',
    projectId: validatedProject.projectId,
  });
}

function buildProjectImportPackage({
  project,
  draft,
  existingImport = null,
  allowReplace = false,
} = {}) {
  const validatedProject = validateProjectRecord(project);

  const dxfModel = adaptV15Draft({
    projectId: validatedProject.projectId,
    draft,
  });

  const fingerprint = createImportFingerprint({
    projectId: validatedProject.projectId,
    dxfModel,
  });

  const conflict = checkImportConflict({
    project: validatedProject,
    existingImport,
    fingerprint,
  });

  if (conflict.conflict) {
    if (conflict.duplicate) {
      throw new Error('This DXF import is already attached to the project.');
    }

    if (!allowReplace) {
      throw new Error('Project already has a different DXF import. Replacement is blocked.');
    }
  }

  const plotRecords = buildPlotCoreRecords(dxfModel);
  const mapReady = buildMapReadyModel(dxfModel);
  const diagnostics = createV15Diagnostics(dxfModel);

  if (!diagnostics.readyForPlotCore) {
    throw new Error('DXF diagnostics are not ready for Plot Core import.');
  }

  const importId = `DXFI-${validatedProject.projectId}-${fingerprint.slice(0, 12).toUpperCase()}`;

  return Object.freeze({
    importId,
    project: validatedProject,
    fingerprint,
    source: Object.freeze({
      engine: dxfModel.sourceEngine,
      schema: dxfModel.sourceSchema,
      sourceName: dxfModel.project.sourceName,
      sourceCrs: dxfModel.project.sourceCrs,
      sourceSha256: dxfModel.project.sourceSha256,
      approvedAt: dxfModel.project.approvedAt,
    }),
    plotRecords,
    mapReady,
    diagnostics,
    replaceExisting: Boolean(conflict.conflict && !conflict.duplicate && allowReplace),
    createdAt: new Date().toISOString(),
  });
}

function validateImportPackage(pkg) {
  if (!pkg || typeof pkg !== 'object') {
    throw new TypeError('import package is required.');
  }

  if (!text(pkg.importId)) throw new Error('importId is required.');
  if (!pkg.project || !/^FP-\d{6}$/.test(upper(pkg.project.projectId))) {
    throw new Error('Import package has invalid project.');
  }

  if (!Array.isArray(pkg.plotRecords) || pkg.plotRecords.length === 0) {
    throw new Error('Import package contains no plot records.');
  }

  if (!pkg.mapReady || !pkg.mapReady.layers || !Array.isArray(pkg.mapReady.layers.plots)) {
    throw new Error('Import package has no map-ready plot layer.');
  }

  if (pkg.mapReady.layers.plots.length !== pkg.plotRecords.length) {
    throw new Error('Plot Core and Map plot counts do not match.');
  }

  if (pkg.mapReady.geometryPolicy.originalGeometryLocked !== true) {
    throw new Error('Original geometry lock is required.');
  }

  if (pkg.mapReady.geometryPolicy.straightenGeometry !== false) {
    throw new Error('Geometry straightening must remain disabled.');
  }

  if (pkg.mapReady.geometryPolicy.roadSurfaceRule !== 'BACKGROUND_GAPS') {
    throw new Error('Road surface rule must remain BACKGROUND_GAPS.');
  }

  return true;
}

function buildProjectStoragePlan(pkg) {
  validateImportPackage(pkg);

  const projectFolder = text(pkg.project.projectFolder);

  const relative = Object.freeze({
    importMetadata: 'dxf/current-import.json',
    plots: 'maps/plots.json',
    mapModel: 'maps/map-ready.json',
    diagnostics: 'dxf/diagnostics.json',
    sourceMetadata: 'dxf/source-metadata.json',
  });

  return Object.freeze({
    projectId: pkg.project.projectId,
    projectFolder,
    relative,
    absolute: projectFolder
      ? Object.freeze({
          importMetadata: `${projectFolder}\\${relative.importMetadata.replace(/\//g, '\\')}`,
          plots: `${projectFolder}\\${relative.plots.replace(/\//g, '\\')}`,
          mapModel: `${projectFolder}\\${relative.mapModel.replace(/\//g, '\\')}`,
          diagnostics: `${projectFolder}\\${relative.diagnostics.replace(/\//g, '\\')}`,
          sourceMetadata: `${projectFolder}\\${relative.sourceMetadata.replace(/\//g, '\\')}`,
        })
      : null,
  });
}

function buildPersistableProjectData(pkg) {
  validateImportPackage(pkg);

  return Object.freeze({
    importMetadata: Object.freeze({
      importId: pkg.importId,
      projectId: pkg.project.projectId,
      fingerprint: pkg.fingerprint,
      source: pkg.source,
      replaceExisting: pkg.replaceExisting,
      createdAt: pkg.createdAt,
    }),
    plots: pkg.plotRecords,
    mapModel: pkg.mapReady,
    diagnostics: pkg.diagnostics,
    sourceMetadata: pkg.source,
  });
}

function buildMapLaunchPacket(pkg) {
  validateImportPackage(pkg);

  return Object.freeze({
    projectId: pkg.project.projectId,
    projectName: pkg.project.projectName,
    importId: pkg.importId,
    plotCount: pkg.plotRecords.length,
    mapModel: pkg.mapReady,
    visualPolicy: pkg.mapReady.visualPolicy,
    geometryPolicy: pkg.mapReady.geometryPolicy,
    status: 'READY_FOR_MAP_VIEWER',
  });
}

class DxfProjectImportIntegrationService {
  validateProject(project) {
    return validateProjectRecord(project);
  }

  fingerprint(input) {
    return createImportFingerprint(input);
  }

  conflict(input) {
    return checkImportConflict(input);
  }

  build(input) {
    return buildProjectImportPackage(input);
  }

  validate(pkg) {
    return validateImportPackage(pkg);
  }

  storagePlan(pkg) {
    return buildProjectStoragePlan(pkg);
  }

  persistable(pkg) {
    return buildPersistableProjectData(pkg);
  }

  mapLaunch(pkg) {
    return buildMapLaunchPacket(pkg);
  }
}

module.exports = {
  text,
  upper,
  stableStringify,
  sha256,
  validateProjectRecord,
  createImportFingerprint,
  checkImportConflict,
  buildProjectImportPackage,
  validateImportPackage,
  buildProjectStoragePlan,
  buildPersistableProjectData,
  buildMapLaunchPacket,
  DxfProjectImportIntegrationService,
};
