'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');

const {
  DEFAULT_BRANDING,
  normalizeBranding,
  resolveConfigPath,
  loadBranding,
  resolveAssetPath,
  buildBrandingContext,
  applyTemplate,
  buildInstallerBranding,
  buildReceiptBranding,
  buildUiBranding,
  BrandingService,
} = require('./branding-service');

(() => {
  console.log('Falcon Central Branding System Tests');
  console.log('------------------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  check(DEFAULT_BRANDING.appName, 'Falcon');
  check(DEFAULT_BRANDING.productName, 'Falcon Hybrid');

  const normalized = normalizeBranding({
    appName: 'EstatePro',
    productName: 'EstatePro Desktop',
    shortName: 'EstatePro',
  });

  check(normalized.appName, 'EstatePro');
  check(normalized.productName, 'EstatePro Desktop');
  check(normalized.shortName, 'EstatePro');
  check(normalized.logoPath, 'assets/branding/logo.png');

  assert.throws(
    () => normalizeBranding({ appName: '' }),
    /appName is required/
  );
  assertions += 1;

  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'falcon-branding-'));
  fs.mkdirSync(path.join(tempDir, 'config'), { recursive: true });

  const configPath = resolveConfigPath(tempDir);
  checkTrue(configPath.endsWith(path.join('config', 'branding.json')));

  fs.writeFileSync(
    configPath,
    JSON.stringify(
      {
        appName: 'EstatePro',
        productName: 'EstatePro Desktop',
        shortName: 'EstatePro',
        companyName: 'EstatePro Realty',
        developerText: 'Concept Design and Developed by Shadab Aziz',
        poweredBy: 'Powered by EstatePro',
        windowTitle: 'EstatePro Desktop',
        receiptTitle: 'Payment Receipt',
        logoPath: 'assets/branding/logo.png',
        iconPath: 'assets/branding/app.ico',
        splashLogoPath: 'assets/branding/logo.png',
        installerProductName: 'EstatePro Desktop',
        installerShortcutName: 'EstatePro',
      },
      null,
      2
    ),
    'utf8'
  );

  const loaded = loadBranding(tempDir);
  check(loaded.appName, 'EstatePro');
  check(loaded.poweredBy, 'Powered by EstatePro');
  check(loaded.companyName, 'EstatePro Realty');

  const logoPath = resolveAssetPath(tempDir, loaded.logoPath);
  checkTrue(logoPath.endsWith(path.join('assets', 'branding', 'logo.png')));

  const context = buildBrandingContext(tempDir, loaded);
  check(context.appName, 'EstatePro');
  checkTrue(context.iconAbsolutePath.endsWith(path.join('assets', 'branding', 'app.ico')));

  const templated = applyTemplate(
    '{{brand.appName}} | {{brand.poweredBy}} | {{brand.productName}}',
    loaded
  );

  check(
    templated,
    'EstatePro | Powered by EstatePro | EstatePro Desktop'
  );

  const installer = buildInstallerBranding(loaded);
  check(installer.productName, 'EstatePro Desktop');
  check(installer.shortcutName, 'EstatePro');
  check(installer.appIdSafeName, 'estatepro');

  const receipt = buildReceiptBranding(loaded);
  check(receipt.appName, 'EstatePro');
  check(receipt.companyName, 'EstatePro Realty');
  check(receipt.poweredBy, 'Powered by EstatePro');

  const ui = buildUiBranding(loaded);
  check(ui.windowTitle, 'EstatePro Desktop');
  check(ui.logoPath, 'assets/branding/logo.png');
  check(ui.developerText, 'Concept Design and Developed by Shadab Aziz');

  const service = new BrandingService({ baseDir: tempDir });
  check(service.load().appName, 'EstatePro');
  check(service.ui().shortName, 'EstatePro');
  check(service.receipt().poweredBy, 'Powered by EstatePro');
  check(service.installer().productName, 'EstatePro Desktop');
  check(
    service.template('Welcome to {{brand.appName}}'),
    'Welcome to EstatePro'
  );

  const missingDir = fs.mkdtempSync(path.join(os.tmpdir(), 'falcon-branding-missing-'));
  const fallback = loadBranding(missingDir);
  check(fallback.appName, 'Falcon');
  check(fallback.productName, 'Falcon Hybrid');

  console.log('Central Config Load: PASS');
  console.log('Default Branding Fallback: PASS');
  console.log('One-place Name Change: PASS');
  console.log('Logo/Icon Path Resolution: PASS');
  console.log('UI Branding Context: PASS');
  console.log('Receipt Branding Context: PASS');
  console.log('Installer Branding Context: PASS');
  console.log('Template Branding Replacement: PASS');
  console.log('Reusable Branding Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('------------------------------------');
  console.log('CENTRAL BRANDING SYSTEM TEST PASS');
})();
