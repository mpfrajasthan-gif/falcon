'use strict';

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function finiteNumber(value, fieldName) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    throw new TypeError(`${fieldName} must be a valid number.`);
  }
  return number;
}

function nonNegative(value, fieldName) {
  const number = finiteNumber(value, fieldName);
  if (number < 0) {
    throw new RangeError(`${fieldName} cannot be negative.`);
  }
  return number;
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function normalizeDate(value) {
  const raw = text(value);
  if (!raw) return '';

  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;

  const match = raw.match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (!match) return '';

  return `${match[3]}-${match[2]}-${match[1]}`;
}

function normalizeCustomer(customer = {}) {
  const customerId = upper(customer.customerId || customer.id);

  if (!customerId) {
    throw new Error('customerId is required.');
  }

  return Object.freeze({
    source: customer,
    customerId,
    customerName: text(customer.customerName || customer.name),
    mobile: text(customer.mobile || customer.customerMobile),
    alternateMobile: text(customer.alternateMobile),
    email: text(customer.email),
    address: text(customer.address),
    dob: normalizeDate(customer.dob || customer.dateOfBirth),
    status: upper(customer.status || 'ACTIVE'),
  });
}

function normalizeBooking(booking = {}) {
  const bookingId = upper(booking.bookingId || booking.id);
  const customerId = upper(booking.customerId);

  if (!bookingId) throw new Error('bookingId is required.');
  if (!customerId) throw new Error('booking.customerId is required.');

  const totalAmount = roundMoney(
    nonNegative(
      booking.grandTotal !== undefined ? booking.grandTotal : booking.totalPrice || 0,
      'booking total'
    )
  );

  const paidAmount = roundMoney(
    nonNegative(booking.paidAmount || 0, 'paidAmount')
  );

  const balanceAmount = roundMoney(
    booking.balanceAmount !== undefined
      ? nonNegative(booking.balanceAmount, 'balanceAmount')
      : Math.max(0, totalAmount - paidAmount)
  );

  return Object.freeze({
    source: booking,
    bookingId,
    customerId,
    projectId: upper(booking.projectId),
    projectName: text(booking.projectName),
    plotNumber: text(booking.plotNumber || booking.plotNo),
    bookingDate: normalizeDate(booking.bookingDate || booking.date || booking.createdAt),
    status: upper(booking.status || 'BOOKED'),
    totalAmount,
    paidAmount,
    balanceAmount,
  });
}

function normalizePayment(payment = {}) {
  const paymentId = upper(payment.paymentId);
  const bookingId = upper(payment.bookingId);

  if (!paymentId) throw new Error('paymentId is required.');
  if (!bookingId) throw new Error('payment.bookingId is required.');

  return Object.freeze({
    source: payment,
    paymentId,
    bookingId,
    amount: roundMoney(nonNegative(payment.amount || 0, 'payment amount')),
    paymentDate: normalizeDate(payment.paymentDate || payment.date),
    mode: upper(payment.mode || payment.paymentMode),
    status: upper(payment.status || 'POSTED'),
    receiptNumber: upper(payment.receiptNumber),
    referenceNumber: text(payment.referenceNumber),
  });
}

function linkCustomerBookings({
  customers = [],
  bookings = [],
}) {
  if (!Array.isArray(customers) || !Array.isArray(bookings)) {
    throw new TypeError('customers and bookings must be arrays.');
  }

  const customerMap = new Map(
    customers.map(normalizeCustomer).map((customer) => [customer.customerId, customer])
  );

  const orphanBookings = [];
  const linkedBookings = [];

  for (const rawBooking of bookings) {
    const booking = normalizeBooking(rawBooking);
    const customer = customerMap.get(booking.customerId);

    if (!customer) {
      orphanBookings.push(booking);
      continue;
    }

    linkedBookings.push(
      Object.freeze({
        customer,
        booking,
      })
    );
  }

  return Object.freeze({
    linkedBookings: Object.freeze(linkedBookings),
    orphanBookings: Object.freeze(orphanBookings),
  });
}

function buildCustomerAccount({
  customer,
  bookings = [],
  payments = [],
}) {
  const normalizedCustomer = normalizeCustomer(customer);

  if (!Array.isArray(bookings) || !Array.isArray(payments)) {
    throw new TypeError('bookings and payments must be arrays.');
  }

  const customerBookings = bookings
    .map(normalizeBooking)
    .filter((booking) => booking.customerId === normalizedCustomer.customerId);

  const bookingIds = new Set(customerBookings.map((booking) => booking.bookingId));

  const customerPayments = payments
    .map(normalizePayment)
    .filter(
      (payment) =>
        bookingIds.has(payment.bookingId) &&
        payment.status === 'POSTED'
    );

  const totalBookingValue = roundMoney(
    customerBookings
      .filter((booking) => booking.status !== 'CANCELLED')
      .reduce((sum, booking) => sum + booking.totalAmount, 0)
  );

  const totalPaidFromBookings = roundMoney(
    customerBookings
      .filter((booking) => booking.status !== 'CANCELLED')
      .reduce((sum, booking) => sum + booking.paidAmount, 0)
  );

  const totalBalance = roundMoney(
    customerBookings
      .filter((booking) => booking.status !== 'CANCELLED')
      .reduce((sum, booking) => sum + booking.balanceAmount, 0)
  );

  const totalPostedPayments = roundMoney(
    customerPayments.reduce((sum, payment) => sum + payment.amount, 0)
  );

  const activeBookings = customerBookings.filter(
    (booking) => booking.status !== 'CANCELLED'
  );

  const soldBookings = activeBookings.filter(
    (booking) =>
      booking.status === 'SOLD' ||
      (booking.totalAmount > 0 && booking.paidAmount >= booking.totalAmount)
  );

  const pendingBookings = activeBookings.filter(
    (booking) => booking.balanceAmount > 0
  );

  return Object.freeze({
    customer: normalizedCustomer,
    bookings: Object.freeze(customerBookings),
    payments: Object.freeze(customerPayments),
    summary: Object.freeze({
      bookingCount: customerBookings.length,
      activeBookingCount: activeBookings.length,
      soldBookingCount: soldBookings.length,
      pendingBookingCount: pendingBookings.length,
      paymentCount: customerPayments.length,
      totalBookingValue,
      totalPaidFromBookings,
      totalPostedPayments,
      totalBalance,
    }),
  });
}

function buildCustomerDirectory({
  customers = [],
  bookings = [],
  payments = [],
}) {
  if (![customers, bookings, payments].every(Array.isArray)) {
    throw new TypeError('customers, bookings and payments must be arrays.');
  }

  const rows = customers.map((customer) =>
    buildCustomerAccount({
      customer,
      bookings,
      payments,
    })
  );

  rows.sort((a, b) =>
    a.customer.customerName.localeCompare(b.customer.customerName)
  );

  return Object.freeze(rows);
}

function searchCustomerAccounts(accounts = [], query = '') {
  if (!Array.isArray(accounts)) {
    throw new TypeError('accounts must be an array.');
  }

  const q = text(query).toLowerCase();
  if (!q) return Object.freeze([...accounts]);

  return Object.freeze(
    accounts.filter((account) => {
      const customer = account.customer || {};
      return [
        customer.customerId,
        customer.customerName,
        customer.mobile,
        customer.email,
        customer.address,
      ]
        .map((value) => text(value).toLowerCase())
        .some((value) => value.includes(q));
    })
  );
}

function buildCustomerHistory(account) {
  if (!account || typeof account !== 'object') {
    throw new TypeError('account is required.');
  }

  const events = [];

  for (const booking of account.bookings || []) {
    events.push({
      type: 'BOOKING',
      date: booking.bookingDate,
      id: booking.bookingId,
      projectName: booking.projectName,
      plotNumber: booking.plotNumber,
      amount: booking.totalAmount,
      status: booking.status,
    });
  }

  for (const payment of account.payments || []) {
    events.push({
      type: 'PAYMENT',
      date: payment.paymentDate,
      id: payment.paymentId,
      bookingId: payment.bookingId,
      amount: payment.amount,
      mode: payment.mode,
      receiptNumber: payment.receiptNumber,
      status: payment.status,
    });
  }

  events.sort((a, b) => {
    if (a.date === b.date) return b.id.localeCompare(a.id);
    return b.date.localeCompare(a.date);
  });

  return Object.freeze(events.map((event) => Object.freeze(event)));
}

class CustomerBookingIntegrationService {
  link(input) {
    return linkCustomerBookings(input);
  }

  account(input) {
    return buildCustomerAccount(input);
  }

  directory(input) {
    return buildCustomerDirectory(input);
  }

  search(accounts, query) {
    return searchCustomerAccounts(accounts, query);
  }

  history(account) {
    return buildCustomerHistory(account);
  }
}

module.exports = {
  text,
  upper,
  finiteNumber,
  nonNegative,
  roundMoney,
  normalizeDate,
  normalizeCustomer,
  normalizeBooking,
  normalizePayment,
  linkCustomerBookings,
  buildCustomerAccount,
  buildCustomerDirectory,
  searchCustomerAccounts,
  buildCustomerHistory,
  CustomerBookingIntegrationService,
};
