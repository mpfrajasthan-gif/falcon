'use strict';

const assert = require('assert');
const {
  LEDGER_ENTRY_TYPES,
  LEDGER_ENTRY_STATUSES,
  createLedgerEntry,
  getSignedAmount,
  ensureUniqueEntryId,
  validateReversal,
  buildLedger,
  voidLedgerEntry,
  createPaymentLedgerEntry,
  createReversalLedgerEntry,
  LedgerEngine,
} = require('./ledger-engine');

(() => {
  console.log('Falcon Ledger Engine Tests');
  console.log('--------------------------');
  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  check(LEDGER_ENTRY_TYPES.PAYMENT, 'PAYMENT');
  check(LEDGER_ENTRY_STATUSES.ACTIVE, 'ACTIVE');

  const p1 = createLedgerEntry({
    entryId: 'LE-000001',
    bookingId: 'FB-000001',
    type: 'PAYMENT',
    amount: 100000,
    entryDate: '29-07-2026',
    entryDateTime: '2026-07-29T10:00:00.000Z',
    paymentId: 'PAY-000001',
    receiptNumber: 'RCP-000001',
    paymentMode: 'CASH',
  });

  check(p1.entryId, 'LE-000001');
  check(p1.bookingId, 'FB-000001');
  check(p1.type, 'PAYMENT');
  check(p1.amount, 100000);
  check(p1.entryDate, '2026-07-29');
  check(p1.paymentId, 'PAY-000001');
  check(p1.receiptNumber, 'RCP-000001');
  check(getSignedAmount(p1), 100000);

  const credit = createLedgerEntry({
    entryId: 'LE-ADJ-1',
    bookingId: 'FB-000001',
    type: 'ADJUSTMENT',
    amount: 5000,
    adjustmentDirection: 'CREDIT',
    entryDate: '2026-07-29',
  });
  check(getSignedAmount(credit), 5000);

  const debit = createLedgerEntry({
    entryId: 'LE-ADJ-2',
    bookingId: 'FB-000001',
    type: 'ADJUSTMENT',
    amount: 5000,
    adjustmentDirection: 'DEBIT',
    entryDate: '2026-07-29',
  });
  check(getSignedAmount(debit), -5000);

  assert.throws(() => ensureUniqueEntryId('LE-000001', [p1]), /Duplicate entryId/);
  assertions += 1;
  check(ensureUniqueEntryId('LE-000002', [p1]), true);

  const p2 = createLedgerEntry({
    entryId: 'LE-000002',
    bookingId: 'FB-000001',
    type: 'PAYMENT',
    amount: 150000,
    entryDate: '2026-07-30',
    entryDateTime: '2026-07-30T10:00:00.000Z',
    paymentId: 'PAY-000002',
    receiptNumber: 'RCP-000002',
  });

  const rev = createReversalLedgerEntry(p2, {
    entryId: 'LE-000003',
    entryDate: '2026-07-31',
    entryDateTime: '2026-07-31T10:00:00.000Z',
    actorId: 'FU-000001',
  });

  check(rev.type, 'REVERSAL');
  check(rev.reversalOfEntryId, 'LE-000002');
  check(getSignedAmount(rev), -150000);
  check(validateReversal(rev, [p1, p2]).entryId, 'LE-000002');

  assert.throws(() => validateReversal(rev, [p1, p2, rev]), /already reversed/);
  assertions += 1;

  const booking = { bookingId: 'FB-000001', grandTotal: 500000 };
  const ledger = buildLedger({ booking, entries: [rev, p2, p1] });

  check(ledger.rows.length, 3);
  check(ledger.rows[0].runningPaid, 100000);
  check(ledger.rows[0].balance, 400000);
  check(ledger.rows[1].runningPaid, 250000);
  check(ledger.rows[1].balance, 250000);
  check(ledger.rows[2].runningPaid, 100000);
  check(ledger.rows[2].balance, 400000);
  check(ledger.summary.totalPaid, 100000);
  check(ledger.summary.balanceAmount, 400000);
  check(ledger.summary.paymentStage, 'PARTIAL');
  check(ledger.summary.soldEligible, false);

  const finalPayment = createLedgerEntry({
    entryId: 'LE-000004',
    bookingId: 'FB-000001',
    type: 'PAYMENT',
    amount: 400000,
    entryDate: '2026-08-01',
    paymentId: 'PAY-000004',
  });

  const fullLedger = buildLedger({ booking, entries: [p1, finalPayment] });
  check(fullLedger.summary.totalPaid, 500000);
  check(fullLedger.summary.balanceAmount, 0);
  check(fullLedger.summary.paymentPercent, 100);
  check(fullLedger.summary.paymentStage, 'FULL');
  check(fullLedger.summary.soldEligible, true);

  const voided = voidLedgerEntry({
    entry: p2,
    actorId: 'FU-000001',
    reason: 'Duplicate imported entry',
    voidedAt: '2026-07-30T12:00:00.000Z',
  });

  check(voided.status, 'VOID');
  check(voided.voidReason, 'Duplicate imported entry');
  check(voided.voidedBy, 'FU-000001');

  const linked = createPaymentLedgerEntry({
    paymentId: 'PAY-100001',
    bookingId: 'FB-000002',
    amount: 75000,
    paymentDate: '01-08-2026',
    receiptNumber: 'RCP-100001',
    referenceNumber: 'UTR-100001',
    mode: 'BANK_TRANSFER',
  }, { entryId: 'LE-100001' });

  check(linked.paymentId, 'PAY-100001');
  check(linked.receiptNumber, 'RCP-100001');
  check(linked.referenceNumber, 'UTR-100001');
  check(linked.paymentMode, 'BANK_TRANSFER');

  const engine = new LedgerEngine();
  const engineLedger = engine.build({
    booking: { bookingId: 'FB-000002', grandTotal: 100000 },
    entries: [
      linked,
      engine.createEntry({
        entryId: 'LE-100002',
        bookingId: 'FB-000002',
        type: 'PAYMENT',
        amount: 25000,
        entryDate: '2026-08-02',
        paymentId: 'PAY-100002',
      }),
    ],
  });

  check(engineLedger.summary.totalPaid, 100000);
  check(engineLedger.summary.balanceAmount, 0);
  check(engineLedger.summary.soldEligible, true);

  console.log('Ledger Entry Creation: PASS');
  console.log('Payment Linkage: PASS');
  console.log('Receipt Linkage: PASS');
  console.log('Debit/Credit Direction: PASS');
  console.log('Running Paid Total: PASS');
  console.log('Running Balance: PASS');
  console.log('Reversal Validation: PASS');
  console.log('Duplicate Entry Protection: PASS');
  console.log('Void Entry Safety: PASS');
  console.log('100 Percent Sold Eligibility: PASS');
  console.log('Reusable Ledger Engine: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('--------------------------');
  console.log('LEDGER ENGINE TEST PASS');
})();
