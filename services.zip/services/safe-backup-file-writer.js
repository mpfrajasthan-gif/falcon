'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function ensureDirectory(directoryPath) {
  if (!text(directoryPath)) {
    throw new Error('directoryPath is required.');
  }
  fs.mkdirSync(directoryPath, { recursive: true });
  return directoryPath;
}

function sanitizeFileName(name) {
  const raw = text(name);
  if (!raw) throw new Error('fileName is required.');

  const clean = raw
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, '_')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^\.+|\.+$/g, '');

  if (!clean) throw new Error('fileName is invalid.');
  return clean;
}

function sha256Buffer(buffer) {
  if (!Buffer.isBuffer(buffer)) {
    throw new TypeError('buffer must be a Buffer.');
  }

  return crypto
    .createHash('sha256')
    .update(buffer)
    .digest('hex');
}

function writeFileAndSync(filePath, buffer) {
  const fd = fs.openSync(filePath, 'w');

  try {
    fs.writeFileSync(fd, buffer);
    fs.fsyncSync(fd);
  } finally {
    fs.closeSync(fd);
  }
}

function safeReplaceFile(tempPath, finalPath) {
  if (!fs.existsSync(tempPath)) {
    throw new Error('Temporary backup file does not exist.');
  }

  if (fs.existsSync(finalPath)) {
    const replacementBackup = `${finalPath}.previous`;

    if (fs.existsSync(replacementBackup)) {
      fs.rmSync(replacementBackup, { force: true });
    }

    fs.renameSync(finalPath, replacementBackup);

    try {
      fs.renameSync(tempPath, finalPath);
      fs.rmSync(replacementBackup, { force: true });
    } catch (error) {
      if (fs.existsSync(finalPath)) {
        fs.rmSync(finalPath, { force: true });
      }

      if (fs.existsSync(replacementBackup)) {
        fs.renameSync(replacementBackup, finalPath);
      }

      throw error;
    }

    return finalPath;
  }

  fs.renameSync(tempPath, finalPath);
  return finalPath;
}

function writeBackupFileAtomic({
  directoryPath,
  fileName,
  serializedArchive,
  expectedHash = '',
  overwrite = false,
} = {}) {
  ensureDirectory(directoryPath);

  const cleanName = sanitizeFileName(fileName);
  const finalPath = path.resolve(directoryPath, cleanName);

  if (!overwrite && fs.existsSync(finalPath)) {
    throw new Error('Backup file already exists.');
  }

  const buffer = Buffer.from(String(serializedArchive), 'utf8');
  const actualHash = sha256Buffer(buffer);

  if (expectedHash && text(expectedHash).toLowerCase() !== actualHash) {
    throw new Error('Serialized backup hash does not match expected hash.');
  }

  const tempPath = `${finalPath}.tmp-${process.pid}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;

  try {
    writeFileAndSync(tempPath, buffer);

    const tempBuffer = fs.readFileSync(tempPath);
    const tempHash = sha256Buffer(tempBuffer);

    if (tempHash !== actualHash) {
      throw new Error('Temporary backup file verification failed.');
    }

    if (overwrite) {
      safeReplaceFile(tempPath, finalPath);
    } else {
      fs.renameSync(tempPath, finalPath);
    }

    const finalBuffer = fs.readFileSync(finalPath);
    const finalHash = sha256Buffer(finalBuffer);

    if (finalHash !== actualHash) {
      throw new Error('Final backup file verification failed.');
    }

    return Object.freeze({
      filePath: finalPath,
      fileName: cleanName,
      bytes: finalBuffer.length,
      sha256: finalHash,
      verified: true,
    });
  } catch (error) {
    if (fs.existsSync(tempPath)) {
      fs.rmSync(tempPath, { force: true });
    }
    throw error;
  }
}

function verifyBackupFile({
  filePath,
  expectedHash = '',
  minimumBytes = 1,
} = {}) {
  if (!text(filePath)) {
    throw new Error('filePath is required.');
  }

  if (!fs.existsSync(filePath)) {
    return Object.freeze({
      exists: false,
      valid: false,
      filePath,
      bytes: 0,
      sha256: '',
    });
  }

  const buffer = fs.readFileSync(filePath);
  const hash = sha256Buffer(buffer);
  const sizeValid = buffer.length >= Number(minimumBytes || 1);
  const hashValid = !expectedHash || hash === text(expectedHash).toLowerCase();

  return Object.freeze({
    exists: true,
    valid: sizeValid && hashValid,
    filePath,
    bytes: buffer.length,
    sha256: hash,
    sizeValid,
    hashValid,
  });
}

function cleanupTemporaryBackupFiles({
  directoryPath,
  olderThanMs = 0,
  now = Date.now(),
} = {}) {
  ensureDirectory(directoryPath);

  const removed = [];

  for (const entry of fs.readdirSync(directoryPath)) {
    if (!entry.includes('.tmp-')) continue;

    const fullPath = path.join(directoryPath, entry);
    const stat = fs.statSync(fullPath);
    const age = now - stat.mtimeMs;

    if (age >= olderThanMs) {
      fs.rmSync(fullPath, { force: true });
      removed.push(fullPath);
    }
  }

  return Object.freeze(removed);
}

function listBackupFiles({
  directoryPath,
  extension = '.fbackup',
} = {}) {
  ensureDirectory(directoryPath);

  return Object.freeze(
    fs.readdirSync(directoryPath)
      .filter((name) => name.toLowerCase().endsWith(extension.toLowerCase()))
      .map((name) => {
        const filePath = path.join(directoryPath, name);
        const stat = fs.statSync(filePath);

        return Object.freeze({
          fileName: name,
          filePath,
          bytes: stat.size,
          modifiedAt: stat.mtime.toISOString(),
        });
      })
      .sort((a, b) => b.modifiedAt.localeCompare(a.modifiedAt))
  );
}

class SafeBackupFileWriterService {
  write(input) {
    return writeBackupFileAtomic(input);
  }

  verify(input) {
    return verifyBackupFile(input);
  }

  cleanup(input) {
    return cleanupTemporaryBackupFiles(input);
  }

  list(input) {
    return listBackupFiles(input);
  }
}

module.exports = {
  text,
  ensureDirectory,
  sanitizeFileName,
  sha256Buffer,
  writeFileAndSync,
  safeReplaceFile,
  writeBackupFileAtomic,
  verifyBackupFile,
  cleanupTemporaryBackupFiles,
  listBackupFiles,
  SafeBackupFileWriterService,
};
