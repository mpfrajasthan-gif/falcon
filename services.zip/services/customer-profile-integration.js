'use strict';

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function finiteNumber(value, fieldName) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    throw new TypeError(`${fieldName} must be a valid number.`);
  }
  return number;
}

function nonNegative(value, fieldName) {
  const number = finiteNumber(value, fieldName);
  if (number < 0) {
    throw new RangeError(`${fieldName} cannot be negative.`);
  }
  return number;
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function normalizeDate(value) {
  const raw = text(value);
  if (!raw) return '';

  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;

  const match = raw.match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (!match) return '';

  return `${match[3]}-${match[2]}-${match[1]}`;
}

function normalizeCustomer(customer = {}) {
  const customerId = upper(customer.customerId || customer.id);
  if (!customerId) throw new Error('customerId is required.');

  return Object.freeze({
    source: customer,
    customerId,
    customerName: text(customer.customerName || customer.name),
    mobile: text(customer.mobile || customer.customerMobile),
    alternateMobile: text(customer.alternateMobile),
    email: text(customer.email),
    address: text(customer.address),
    dob: normalizeDate(customer.dob || customer.dateOfBirth),
    status: upper(customer.status || 'ACTIVE'),
  });
}

function normalizeBooking(booking = {}) {
  const bookingId = upper(booking.bookingId || booking.id);
  const customerId = upper(booking.customerId);

  if (!bookingId) throw new Error('bookingId is required.');
  if (!customerId) throw new Error('booking.customerId is required.');

  const totalAmount = roundMoney(
    nonNegative(
      booking.grandTotal !== undefined ? booking.grandTotal : booking.totalPrice || 0,
      'booking total'
    )
  );

  const paidAmount = roundMoney(
    nonNegative(booking.paidAmount || 0, 'paidAmount')
  );

  const balanceAmount = roundMoney(
    booking.balanceAmount !== undefined
      ? nonNegative(booking.balanceAmount, 'balanceAmount')
      : Math.max(0, totalAmount - paidAmount)
  );

  return Object.freeze({
    source: booking,
    bookingId,
    customerId,
    projectId: upper(booking.projectId),
    projectName: text(booking.projectName),
    plotNumber: text(booking.plotNumber || booking.plotNo),
    bookingDate: normalizeDate(booking.bookingDate || booking.date || booking.createdAt),
    status: upper(booking.status || 'BOOKED'),
    totalAmount,
    paidAmount,
    balanceAmount,
  });
}

function normalizeReceipt(receipt = {}) {
  return Object.freeze({
    source: receipt,
    receiptNumber: upper(receipt.receiptNumber),
    bookingId: upper(receipt.bookingId),
    paymentId: upper(receipt.paymentId),
    customerId: upper(receipt.customerId),
    projectName: text(receipt.projectName),
    plotNumber: text(receipt.plotNumber),
    paymentDate: normalizeDate(receipt.paymentDate || receipt.receiptDate),
    currentPayment: roundMoney(
      nonNegative(
        receipt.currentPayment !== undefined ? receipt.currentPayment : receipt.amount || 0,
        'receipt amount'
      )
    ),
    balanceAmount: roundMoney(nonNegative(receipt.balanceAmount || 0, 'balanceAmount')),
    paymentMode: upper(receipt.paymentMode),
    status: upper(receipt.status || 'ISSUED'),
  });
}

function normalizeDocument(document = {}) {
  return Object.freeze({
    source: document,
    documentId: upper(document.documentId),
    customerId: upper(document.customerId),
    type: upper(document.type),
    maskedReference: text(document.maskedReference),
    filePath: text(document.filePath),
    status: upper(document.status || 'ACTIVE'),
  });
}

function buildCustomerProfile({
  customer,
  bookings = [],
  receipts = [],
  documents = [],
}) {
  const normalizedCustomer = normalizeCustomer(customer);

  if (![bookings, receipts, documents].every(Array.isArray)) {
    throw new TypeError('bookings, receipts and documents must be arrays.');
  }

  const customerBookings = bookings
    .map(normalizeBooking)
    .filter((booking) => booking.customerId === normalizedCustomer.customerId);

  const bookingIds = new Set(customerBookings.map((booking) => booking.bookingId));

  const customerReceipts = receipts
    .map(normalizeReceipt)
    .filter(
      (receipt) =>
        bookingIds.has(receipt.bookingId) &&
        receipt.status === 'ISSUED'
    );

  const customerDocuments = documents
    .map(normalizeDocument)
    .filter(
      (document) =>
        document.customerId === normalizedCustomer.customerId &&
        document.status === 'ACTIVE'
    );

  const photo =
    customerDocuments.find((document) => document.type === 'PHOTO') || null;

  const identityDocuments = customerDocuments.filter((document) =>
    ['AADHAAR', 'PAN', 'PASSPORT', 'DRIVING_LICENCE', 'VOTER_ID'].includes(document.type)
  );

  const activeBookings = customerBookings.filter(
    (booking) => booking.status !== 'CANCELLED'
  );

  const soldBookings = activeBookings.filter(
    (booking) =>
      booking.status === 'SOLD' ||
      (booking.totalAmount > 0 && booking.paidAmount >= booking.totalAmount)
  );

  const pendingBookings = activeBookings.filter(
    (booking) => booking.balanceAmount > 0
  );

  const totalBookingValue = roundMoney(
    activeBookings.reduce((sum, booking) => sum + booking.totalAmount, 0)
  );

  const totalPaid = roundMoney(
    activeBookings.reduce((sum, booking) => sum + booking.paidAmount, 0)
  );

  const totalBalance = roundMoney(
    activeBookings.reduce((sum, booking) => sum + booking.balanceAmount, 0)
  );

  const recentBookings = customerBookings
    .slice()
    .sort((a, b) => {
      if (a.bookingDate === b.bookingDate) {
        return b.bookingId.localeCompare(a.bookingId);
      }
      return b.bookingDate.localeCompare(a.bookingDate);
    })
    .slice(0, 5);

  const recentReceipts = customerReceipts
    .slice()
    .sort((a, b) => {
      if (a.paymentDate === b.paymentDate) {
        return b.receiptNumber.localeCompare(a.receiptNumber);
      }
      return b.paymentDate.localeCompare(a.paymentDate);
    })
    .slice(0, 5);

  const plots = activeBookings.map((booking) =>
    Object.freeze({
      bookingId: booking.bookingId,
      projectId: booking.projectId,
      projectName: booking.projectName,
      plotNumber: booking.plotNumber,
      status: booking.status,
      totalAmount: booking.totalAmount,
      paidAmount: booking.paidAmount,
      balanceAmount: booking.balanceAmount,
    })
  );

  return Object.freeze({
    customer: normalizedCustomer,
    photo,
    identityDocuments: Object.freeze(identityDocuments),
    documents: Object.freeze(customerDocuments),
    bookings: Object.freeze(customerBookings),
    receipts: Object.freeze(customerReceipts),
    plots: Object.freeze(plots),
    recentBookings: Object.freeze(recentBookings),
    recentReceipts: Object.freeze(recentReceipts),
    summary: Object.freeze({
      bookingCount: customerBookings.length,
      activeBookingCount: activeBookings.length,
      soldBookingCount: soldBookings.length,
      pendingBookingCount: pendingBookings.length,
      receiptCount: customerReceipts.length,
      documentCount: customerDocuments.length,
      identityDocumentCount: identityDocuments.length,
      hasPhoto: Boolean(photo),
      hasIdentityProof: identityDocuments.length > 0,
      totalBookingValue,
      totalPaid,
      totalBalance,
    }),
  });
}

function buildCustomerProfileViewModel(profile) {
  if (!profile || typeof profile !== 'object') {
    throw new TypeError('profile is required.');
  }

  return Object.freeze({
    header: Object.freeze({
      customerId: profile.customer.customerId,
      customerName: profile.customer.customerName,
      mobile: profile.customer.mobile,
      alternateMobile: profile.customer.alternateMobile,
      email: profile.customer.email,
      address: profile.customer.address,
      dob: profile.customer.dob,
      status: profile.customer.status,
      photoPath: profile.photo ? profile.photo.filePath : '',
    }),
    cards: Object.freeze({
      totalPlots: profile.plots.length,
      soldPlots: profile.summary.soldBookingCount,
      pendingBookings: profile.summary.pendingBookingCount,
      totalBookingValue: profile.summary.totalBookingValue,
      totalPaid: profile.summary.totalPaid,
      totalBalance: profile.summary.totalBalance,
      receipts: profile.summary.receiptCount,
      documents: profile.summary.documentCount,
    }),
    verification: Object.freeze({
      hasPhoto: profile.summary.hasPhoto,
      hasIdentityProof: profile.summary.hasIdentityProof,
      identityDocumentCount: profile.summary.identityDocumentCount,
    }),
    plots: profile.plots,
    recentBookings: profile.recentBookings,
    recentReceipts: profile.recentReceipts,
  });
}

function buildCustomerProfileActions(profile) {
  if (!profile || typeof profile !== 'object') {
    throw new TypeError('profile is required.');
  }

  return Object.freeze([
    Object.freeze({
      id: 'OPEN_BOOKINGS',
      label: 'Bookings',
      target: 'BOOKING_LIST',
      filter: Object.freeze({
        customerId: profile.customer.customerId,
      }),
      value: profile.summary.bookingCount,
    }),
    Object.freeze({
      id: 'OPEN_RECEIPTS',
      label: 'Receipts',
      target: 'CUSTOMER_RECEIPTS',
      filter: Object.freeze({
        customerId: profile.customer.customerId,
      }),
      value: profile.summary.receiptCount,
    }),
    Object.freeze({
      id: 'OPEN_STATEMENT',
      label: 'Account Statement',
      target: 'CUSTOMER_STATEMENT',
      filter: Object.freeze({
        customerId: profile.customer.customerId,
      }),
      value: profile.summary.totalBalance,
    }),
    Object.freeze({
      id: 'OPEN_DOCUMENTS',
      label: 'Documents',
      target: 'CUSTOMER_DOCUMENTS',
      filter: Object.freeze({
        customerId: profile.customer.customerId,
      }),
      value: profile.summary.documentCount,
    }),
  ]);
}

class CustomerProfileIntegrationService {
  build(input) {
    return buildCustomerProfile(input);
  }

  viewModel(profile) {
    return buildCustomerProfileViewModel(profile);
  }

  actions(profile) {
    return buildCustomerProfileActions(profile);
  }
}

module.exports = {
  text,
  upper,
  finiteNumber,
  nonNegative,
  roundMoney,
  normalizeDate,
  normalizeCustomer,
  normalizeBooking,
  normalizeReceipt,
  normalizeDocument,
  buildCustomerProfile,
  buildCustomerProfileViewModel,
  buildCustomerProfileActions,
  CustomerProfileIntegrationService,
};
