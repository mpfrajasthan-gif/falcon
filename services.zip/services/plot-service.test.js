'use strict';

const assert = require('assert');

const {
  PlotService,
  VALID_STATUSES,
} = require('./plot-service');

function createFakeRepository() {
  const plots = new Map();

  return {
    create(plot) {
      const frozen = Object.freeze({ ...plot });
      plots.set(plot.id, frozen);
      return frozen;
    },
    findById(id) {
      return plots.get(id) ?? null;
    },
    findAll() {
      return [...plots.values()];
    },
    findByProjectId(projectId) {
      return [...plots.values()].filter(
        (plot) => plot.projectId === projectId
      );
    },
    update(id, changes) {
      const current = plots.get(id);
      const updated = Object.freeze({
        ...current,
        ...changes,
        id: current.id,
        uuid: current.uuid,
        projectId: current.projectId,
        createdAt: current.createdAt,
      });
      plots.set(id, updated);
      return updated;
    },
    delete(id) {
      return plots.delete(id);
    },
    plotNumberExists(projectId, plotNumber, excludePlotId = null) {
      return [...plots.values()].some(
        (plot) =>
          plot.projectId === projectId &&
          plot.plotNumber === plotNumber &&
          plot.id !== excludePlotId
      );
    },
  };
}

function runPlotServiceTests() {
  console.log('Falcon Plot Service Tests');
  console.log('-------------------------');

  assert.deepStrictEqual(
    VALID_STATUSES,
    ['AVAILABLE', 'HOLD', 'BOOKED', 'SOLD']
  );
  assert.throws(() => new PlotService(null), TypeError);

  const repository = createFakeRepository();
  const logs = [];
  let identitySequence = 0;
  let clockTick = 0;

  const service = new PlotService(repository, {
    identityFactory(entityType) {
      assert.strictEqual(entityType, 'plot');
      identitySequence += 1;
      return {
        id: `FPL-${String(identitySequence).padStart(6, '0')}`,
        uuid: `plot-uuid-${identitySequence}`,
      };
    },
    clock() {
      const date = new Date('2026-07-25T10:00:00.000Z');
      date.setMinutes(date.getMinutes() + clockTick);
      clockTick += 1;
      return date;
    },
    infoLogger(message, context) {
      logs.push({ level: 'info', message, context });
    },
    errorLogger(message, context) {
      logs.push({ level: 'error', message, context });
    },
  });

  const created = service.createPlot({
    projectId: ' FP-000001 ',
    plotNumber: ' 1 ',
    category: ' Residential ',
    areaSqYd: 100,
    ratePerSqYd: 5000,
    geometryJson: '{"type":"Polygon"}',
  });

  assert.strictEqual(created.success, true);
  assert.strictEqual(created.code, 'PLOT_CREATED');
  assert.strictEqual(created.data.id, 'FPL-000001');
  assert.strictEqual(created.data.projectId, 'FP-000001');
  assert.strictEqual(created.data.plotNumber, '1');
  assert.strictEqual(created.data.category, 'Residential');
  assert.strictEqual(created.data.status, 'AVAILABLE');
  assert.strictEqual(created.data.areaSqYd, 100);
  assert.strictEqual(created.data.ratePerSqYd, 5000);
  assert.strictEqual(created.data.totalPrice, 500000);
  assert.strictEqual(created.data.createdAt, '2026-07-25T10:00:00.000Z');

  const duplicate = service.createPlot({
    projectId: 'FP-000001',
    plotNumber: '1',
    category: 'Commercial',
    areaSqYd: 90,
  });
  assert.strictEqual(duplicate.success, false);
  assert.strictEqual(duplicate.code, 'PLOT_NUMBER_ALREADY_EXISTS');

  const sameNumberOtherProject = service.createPlot({
    projectId: 'FP-000002',
    plotNumber: '1',
    category: 'Commercial',
    areaSqYd: 120,
    status: 'hold',
    ratePerSqYd: 6000,
    totalPrice: 725000,
  });
  assert.strictEqual(sameNumberOtherProject.success, true);
  assert.strictEqual(sameNumberOtherProject.data.status, 'HOLD');
  assert.strictEqual(sameNumberOtherProject.data.totalPrice, 725000);

  const invalid = service.createPlot({
    projectId: '',
    plotNumber: '',
    category: '',
    areaSqYd: 0,
  });
  assert.strictEqual(invalid.success, false);
  assert.strictEqual(invalid.code, 'PLOT_CREATE_FAILED');

  const loaded = service.getPlot('FPL-000001');
  assert.strictEqual(loaded.success, true);
  assert.strictEqual(loaded.data.plotNumber, '1');

  const missing = service.getPlot('FPL-999999');
  assert.strictEqual(missing.success, false);
  assert.strictEqual(missing.code, 'PLOT_NOT_FOUND');

  const all = service.getAllPlots();
  assert.strictEqual(all.success, true);
  assert.strictEqual(all.data.length, 2);
  assert.strictEqual(all.data.total, 2);
  assert.strictEqual(all.data.items, all.data);
  assert.strictEqual(all.data.plots, all.data);
  assert.strictEqual(Object.isFrozen(all.data), true);

  const projectPlots = service.getPlotsByProject('FP-000001');
  assert.strictEqual(projectPlots.success, true);
  assert.strictEqual(projectPlots.data.length, 1);
  assert.strictEqual(projectPlots.data[0].projectId, 'FP-000001');

  const updated = service.updatePlot('FPL-000001', {
    plotNumber: '2',
    category: 'Residential Corner',
    areaSqYd: 105,
    status: 'booked',
    ratePerSqYd: 5500,
  });
  assert.strictEqual(updated.success, true);
  assert.strictEqual(updated.code, 'PLOT_UPDATED');
  assert.strictEqual(updated.data.plotNumber, '2');
  assert.strictEqual(updated.data.status, 'BOOKED');
  assert.strictEqual(updated.data.totalPrice, 577500);
  assert.strictEqual(updated.data.updatedAt, '2026-07-25T10:02:00.000Z');

  const createdThird = service.createPlot({
    projectId: 'FP-000001',
    plotNumber: '3',
    category: 'Residential',
    areaSqYd: 80,
  });
  assert.strictEqual(createdThird.success, true);

  const duplicateUpdate = service.updatePlot('FPL-000003', {
    plotNumber: '2',
  });
  assert.strictEqual(duplicateUpdate.success, false);
  assert.strictEqual(
    duplicateUpdate.code,
    'PLOT_NUMBER_ALREADY_EXISTS'
  );

  const blockedDelete = service.deletePlot('FPL-000001');
  assert.strictEqual(blockedDelete.success, false);
  assert.strictEqual(blockedDelete.code, 'PLOT_DELETE_BLOCKED');

  const deleted = service.deletePlot('FPL-000003');
  assert.strictEqual(deleted.success, true);
  assert.strictEqual(deleted.code, 'PLOT_DELETED');
  assert.strictEqual(deleted.data.deleted, true);
  assert.strictEqual(repository.findById('FPL-000003'), null);

  const deleteMissing = service.deletePlot('FPL-999999');
  assert.strictEqual(deleteMissing.success, false);
  assert.strictEqual(deleteMissing.code, 'PLOT_NOT_FOUND');

  assert.strictEqual(
    logs.some((entry) => entry.message === 'Falcon plot created.'),
    true
  );
  assert.strictEqual(
    logs.some((entry) => entry.message === 'Falcon plot updated.'),
    true
  );
  assert.strictEqual(
    logs.some((entry) => entry.message === 'Falcon plot deleted.'),
    true
  );
  assert.strictEqual(
    logs.some((entry) => entry.level === 'error'),
    true
  );

  console.log(`Created Plot: ${created.data.id}`);
  console.log(`Updated Plot Status: ${updated.data.status}`);
  console.log(`Plot Deleted: ${deleted.data.deleted}`);
  console.log('Assertions Passed: 55');
  console.log('-------------------------');
  console.log('PLOT SERVICE TEST PASS');
}

runPlotServiceTests();
