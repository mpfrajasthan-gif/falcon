'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const { buildProjectImportPackage, buildMapLaunchPacket } =
  require('./dxf-project-import-integration');
const { safeWriteProjectImport, verifyImportedProjectFiles } =
  require('./dxf-safe-project-import-writer');

(() => {
  console.log('Falcon DXF End-to-End Integration Regression Tests');
  console.log('--------------------------------------------------');

  let assertions = 0;
  const check = (a, e) => { assert.deepStrictEqual(a, e); assertions += 1; };
  const yes = (v) => { assert.strictEqual(v, true); assertions += 1; };
  const no = (v) => { assert.strictEqual(v, false); assertions += 1; };

  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'falcon-dxf6-'));
  const projectFolder = path.join(root, 'projects', 'FP-000001');

  const project = {
    projectId: 'FP-000001',
    projectName: 'DXF E2E Test Project',
    projectFolder,
    status: 'ACTIVE',
  };

  // Representative approved V1.5 draft using the real locked V1.5 export contract.
  const draft = {
    schema_version: '1.0-draft',
    project: {
      name: 'DXF E2E Test Project',
      source_crs: 'EPSG:32643',
      source_sha256: 'e2e-real-v15-contract-source-hash',
      approval_status: 'APPROVED',
      approved_at: '2026-07-30T12:00:00.000Z',
    },
    layers: {
      plots: [
        {
          plot_no: '1',
          layer: 'POLYGON',
          vertices: [[0,0],[12,0],[12,20],[0,20]],
          centroid: [6,10],
          area_sq_m: 240,
          area_sq_yd: 287.037611,
          side_lengths_ft: [39.3701,65.6168,39.3701,65.6168],
          source_index: 101,
          contained_labels: 1,
          topology_verified: true,
        },
        {
          plot_no: '2',
          layer: 'POLYGON',
          vertices: [[12,0],[24,0],[24,20],[12,20]],
          centroid: [18,10],
          area_sq_m: 240,
          area_sq_yd: 287.037611,
          side_lengths_ft: [39.3701,65.6168,39.3701,65.6168],
          source_index: 102,
          contained_labels: 1,
          topology_verified: true,
        },
        {
          plot_no: '3',
          layer: 'POLYGON',
          vertices: [[24,0],[36,0],[36,20],[24,20]],
          centroid: [30,10],
          area_sq_m: 240,
          area_sq_yd: 287.037611,
          side_lengths_ft: [39.3701,65.6168,39.3701,65.6168],
          source_index: 103,
          contained_labels: 1,
          topology_verified: true,
        },
      ],
      roads: [
        {
          id: 'ROAD-40',
          name: "ROAD 40' WIDE",
          width_ft: 40,
          geometry_type: 'LABEL_POINT',
          label_point: [18,-8],
          vertices: [[18,-8]],
        },
      ],
      special_areas: [
        {
          name: 'OTHER LAND',
          category: 'OTHER LAND',
          layer: 'POLYGON',
          vertices: [[0,20],[36,20],[36,30],[0,30]],
          centroid: [18,25],
          area_sq_m: 360,
          area_sq_yd: 430.556416,
          source_index: 201,
        },
      ],
    },
    import_profile: {
      renderer: 'FALCON_V10_POLISHED_2D',
      road_surface_rule: 'BACKGROUND_GAPS',
      road_labels: 'ROAD_TEXT_POINTS',
      original_geometry_locked: true,
    },
    audit: {
      metrics: {
        entities: 250,
        layers: 14,
        plot_labels: 3,
        plot_faces: 3,
        unresolved_labels: 0,
        road_layers: 1,
        khasra_layers: 1,
        special_layers: 1,
        road_features: 1,
        special_features: 1,
        selected_scope: 'MODELSPACE',
      },
      warnings: [],
    },
  };

  // 1. Real V1.5 contract -> project package.
  const pkg = buildProjectImportPackage({ project, draft });

  check(pkg.project.projectId, 'FP-000001');
  check(pkg.plotRecords.length, 3);
  check(pkg.mapReady.layers.plots.length, 3);
  check(pkg.mapReady.layers.roads.length, 1);
  check(pkg.mapReady.layers.specialAreas.length, 1);
  check(pkg.diagnostics.unresolvedLabels, 0);
  yes(pkg.diagnostics.readyForPlotCore);
  check(pkg.fingerprint.length, 64);
  yes(pkg.importId.startsWith('DXFI-FP-000001-'));

  // 2. Exact geometry preservation.
  check(pkg.plotRecords[0].vertices[0], { x: 0, y: 0 });
  check(pkg.plotRecords[0].vertices[2], { x: 12, y: 20 });
  check(pkg.plotRecords[1].vertices[0], { x: 12, y: 0 });
  check(pkg.plotRecords[2].vertices[2], { x: 36, y: 20 });
  check(pkg.plotRecords[0].sideLengthsFt.length, 4);
  yes(pkg.plotRecords[0].source.topologyVerified);

  // 3. Safe project write.
  const writeResult = safeWriteProjectImport({ pkg });
  yes(writeResult.applied);
  no(writeResult.rolledBack);
  yes(writeResult.verification.valid);
  check(writeResult.files.length, 5);

  // 4. Verify real project files.
  const verify = verifyImportedProjectFiles(pkg);
  yes(verify.valid);
  yes(verify.checks.every((item) => item.exists));
  yes(verify.checks.every((item) => item.valid));

  const currentImportPath = path.join(projectFolder, 'dxf', 'current-import.json');
  const diagnosticsPath = path.join(projectFolder, 'dxf', 'diagnostics.json');
  const sourcePath = path.join(projectFolder, 'dxf', 'source-metadata.json');
  const plotsPath = path.join(projectFolder, 'maps', 'plots.json');
  const mapPath = path.join(projectFolder, 'maps', 'map-ready.json');

  yes(fs.existsSync(currentImportPath));
  yes(fs.existsSync(diagnosticsPath));
  yes(fs.existsSync(sourcePath));
  yes(fs.existsSync(plotsPath));
  yes(fs.existsSync(mapPath));

  const savedImport = JSON.parse(fs.readFileSync(currentImportPath, 'utf8'));
  const savedDiagnostics = JSON.parse(fs.readFileSync(diagnosticsPath, 'utf8'));
  const savedPlots = JSON.parse(fs.readFileSync(plotsPath, 'utf8'));
  const savedMap = JSON.parse(fs.readFileSync(mapPath, 'utf8'));

  check(savedImport.projectId, 'FP-000001');
  check(savedImport.fingerprint, pkg.fingerprint);
  check(savedDiagnostics.plotCount, 3);
  check(savedDiagnostics.unresolvedLabels, 0);
  check(savedPlots.length, 3);
  check(savedPlots[0].plotNumber, '1');
  check(savedPlots[1].plotNumber, '2');
  check(savedPlots[2].plotNumber, '3');

  // 5. Locked map visual contract.
  check(savedMap.rendererProfile, 'FALCON_V10_POLISHED_2D');
  yes(savedMap.geometryPolicy.originalGeometryLocked);
  check(savedMap.geometryPolicy.straightenGeometry, false);
  check(savedMap.geometryPolicy.inventVertices, false);
  check(savedMap.geometryPolicy.deleteVertices, false);
  check(savedMap.geometryPolicy.roadSurfaceRule, 'BACKGROUND_GAPS');

  check(savedMap.visualPolicy.plotNumberPlacement, 'CENTROID');
  check(savedMap.visualPolicy.dimensionSource, 'SIDE_LENGTHS_FT');
  check(savedMap.visualPolicy.selectionStyle, 'BLUE_GLASS_TRANSPARENT');
  check(savedMap.visualPolicy.selectionBoundary, 'THIN_DOTTED_OFFSET');
  check(savedMap.visualPolicy.selectionAutoZoomPercent, [20, 30]);
  yes(savedMap.visualPolicy.clickOutsideClearsSelection);
  yes(savedMap.visualPolicy.smoothPanZoomRequired);
  check(savedMap.visualPolicy.defaultAreaUnit, 'SQ_YARD');
  check(savedMap.visualPolicy.availableAreaUnits, ['SQ_YARD','SQ_FT','SQ_M']);

  // 6. Roads/special areas survive the full chain.
  check(savedMap.layers.roads.length, 1);
  check(savedMap.layers.roads[0].widthFt, 40);
  check(savedMap.layers.roads[0].name, "ROAD 40' WIDE");
  check(savedMap.layers.specialAreas.length, 1);
  check(savedMap.layers.specialAreas[0].category, 'OTHER LAND');

  // 7. Map launch packet.
  const launch = buildMapLaunchPacket(pkg);
  check(launch.projectId, 'FP-000001');
  check(launch.plotCount, 3);
  check(launch.status, 'READY_FOR_MAP_VIEWER');
  check(launch.visualPolicy.selectionStyle, 'BLUE_GLASS_TRANSPARENT');
  yes(launch.geometryPolicy.originalGeometryLocked);

  // 8. Duplicate import safety remains active after successful import.
  assert.throws(
    () => buildProjectImportPackage({
      project,
      draft,
      existingImport: savedImport,
    }),
    /already attached/
  );
  assertions += 1;

  // 9. Different DXF replacement remains blocked unless explicitly allowed.
  assert.throws(
    () => buildProjectImportPackage({
      project,
      draft: {
        ...draft,
        project: {
          ...draft.project,
          source_sha256: 'changed-source-hash',
        },
      },
      existingImport: savedImport,
    }),
    /Replacement is blocked/
  );
  assertions += 1;

  console.log('V1.5 Approved Draft Input: PASS');
  console.log('Falcon Project Binding: PASS');
  console.log('DXF Fingerprint & Import ID: PASS');
  console.log('Exact Plot Geometry Preservation: PASS');
  console.log('Plot Number / Area / Dimension Flow: PASS');
  console.log('Road Label & Width Flow: PASS');
  console.log('Special Area Flow: PASS');
  console.log('Safe Atomic Project Write: PASS');
  console.log('Final Project File Verification: PASS');
  console.log('Duplicate Import Protection: PASS');
  console.log('Replacement Protection: PASS');
  console.log('Original Geometry Lock: PASS');
  console.log('Background-gap Road Policy: PASS');
  console.log('Spacer-style Visual Contract: PASS');
  console.log('Map Viewer Launch Packet: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('--------------------------------------------------');
  console.log('DXF END-TO-END INTEGRATION REGRESSION TEST PASS');
})();
