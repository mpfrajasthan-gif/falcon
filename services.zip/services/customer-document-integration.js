'use strict';

const DOCUMENT_TYPES = Object.freeze({
  PHOTO: 'PHOTO',
  AADHAAR: 'AADHAAR',
  PAN: 'PAN',
  PASSPORT: 'PASSPORT',
  DRIVING_LICENCE: 'DRIVING_LICENCE',
  VOTER_ID: 'VOTER_ID',
  ADDRESS_PROOF: 'ADDRESS_PROOF',
  OTHER: 'OTHER',
});

const DOCUMENT_STATUSES = Object.freeze({
  ACTIVE: 'ACTIVE',
  ARCHIVED: 'ARCHIVED',
});

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function normalizeDate(value) {
  const raw = text(value);
  if (!raw) return '';

  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;

  const match = raw.match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (!match) return '';

  return `${match[3]}-${match[2]}-${match[1]}`;
}

function validateDocumentType(type) {
  const normalized = upper(type);
  if (!Object.values(DOCUMENT_TYPES).includes(normalized)) {
    throw new RangeError('Unsupported document type.');
  }
  return normalized;
}

function normalizeReference(value) {
  return upper(value).replace(/\s+/g, '');
}

function maskReference(type, reference) {
  const normalizedType = validateDocumentType(type);
  const ref = normalizeReference(reference);

  if (!ref) return '';

  if (normalizedType === DOCUMENT_TYPES.AADHAAR && ref.length >= 4) {
    return `XXXX-XXXX-${ref.slice(-4)}`;
  }

  if (normalizedType === DOCUMENT_TYPES.PAN && ref.length >= 4) {
    return `${ref.slice(0, 2)}XXXX${ref.slice(-4)}`;
  }

  if (ref.length <= 4) return ref;

  return `${'*'.repeat(Math.max(0, ref.length - 4))}${ref.slice(-4)}`;
}

function createCustomerDocument(input = {}) {
  const documentId = upper(input.documentId);
  const customerId = upper(input.customerId);
  const type = validateDocumentType(input.type);
  const filePath = text(input.filePath);

  if (!documentId) throw new Error('documentId is required.');
  if (!customerId) throw new Error('customerId is required.');
  if (!filePath) throw new Error('filePath is required.');

  const reference = normalizeReference(input.referenceNumber);
  const issueDate = normalizeDate(input.issueDate);
  const expiryDate = normalizeDate(input.expiryDate);

  if (input.issueDate && !issueDate) {
    throw new Error('issueDate must be DD-MM-YYYY or YYYY-MM-DD.');
  }

  if (input.expiryDate && !expiryDate) {
    throw new Error('expiryDate must be DD-MM-YYYY or YYYY-MM-DD.');
  }

  if (issueDate && expiryDate && expiryDate < issueDate) {
    throw new Error('expiryDate cannot be before issueDate.');
  }

  if (
    !reference &&
    ![DOCUMENT_TYPES.PHOTO, DOCUMENT_TYPES.ADDRESS_PROOF, DOCUMENT_TYPES.OTHER].includes(type)
  ) {
    throw new Error('referenceNumber is required for this document type.');
  }

  return Object.freeze({
    documentId,
    customerId,
    type,
    referenceNumber: reference,
    maskedReference: reference ? maskReference(type, reference) : '',
    filePath,
    fileName: text(input.fileName),
    mimeType: text(input.mimeType),
    issueDate,
    expiryDate,
    notes: text(input.notes),
    uploadedBy: upper(input.uploadedBy),
    uploadedAt: text(input.uploadedAt) || new Date().toISOString(),
    status: DOCUMENT_STATUSES.ACTIVE,
    archivedAt: null,
    archivedBy: '',
    archiveReason: '',
  });
}

function ensureUniqueDocument({
  document,
  existingDocuments = [],
}) {
  if (!document || typeof document !== 'object') {
    throw new TypeError('document is required.');
  }

  if (!Array.isArray(existingDocuments)) {
    throw new TypeError('existingDocuments must be an array.');
  }

  const duplicateId = existingDocuments.some(
    (item) => upper(item.documentId) === upper(document.documentId)
  );

  if (duplicateId) {
    throw new Error('Duplicate documentId is not allowed.');
  }

  if (document.referenceNumber) {
    const duplicateReference = existingDocuments.some(
      (item) =>
        upper(item.status || DOCUMENT_STATUSES.ACTIVE) === DOCUMENT_STATUSES.ACTIVE &&
        upper(item.type) === upper(document.type) &&
        normalizeReference(item.referenceNumber) === normalizeReference(document.referenceNumber) &&
        upper(item.customerId) === upper(document.customerId)
    );

    if (duplicateReference) {
      throw new Error('Duplicate active document reference is not allowed for this customer.');
    }
  }

  return true;
}

function archiveCustomerDocument({
  document,
  actorId,
  reason,
  archivedAt,
}) {
  if (!document || typeof document !== 'object') {
    throw new TypeError('document is required.');
  }

  if (upper(document.status) === DOCUMENT_STATUSES.ARCHIVED) {
    throw new Error('Document is already archived.');
  }

  const cleanReason = text(reason).replace(/\s+/g, ' ');
  if (cleanReason.length < 5) {
    throw new Error('Archive reason must contain at least 5 characters.');
  }

  const cleanActorId = upper(actorId);
  if (!cleanActorId) {
    throw new Error('actorId is required.');
  }

  return Object.freeze({
    ...document,
    status: DOCUMENT_STATUSES.ARCHIVED,
    archivedAt: text(archivedAt) || new Date().toISOString(),
    archivedBy: cleanActorId,
    archiveReason: cleanReason,
  });
}

function buildCustomerDocumentProfile({
  customer,
  documents = [],
  bookings = [],
}) {
  if (!customer || typeof customer !== 'object') {
    throw new TypeError('customer is required.');
  }

  if (!Array.isArray(documents) || !Array.isArray(bookings)) {
    throw new TypeError('documents and bookings must be arrays.');
  }

  const customerId = upper(customer.customerId || customer.id);
  if (!customerId) throw new Error('customerId is required.');

  const customerDocuments = documents
    .filter((document) => upper(document.customerId) === customerId)
    .map((document) => Object.freeze({ ...document }));

  const activeDocuments = customerDocuments.filter(
    (document) => upper(document.status || DOCUMENT_STATUSES.ACTIVE) === DOCUMENT_STATUSES.ACTIVE
  );

  const customerBookings = bookings
    .filter((booking) => upper(booking.customerId) === customerId)
    .map((booking) =>
      Object.freeze({
        bookingId: upper(booking.bookingId || booking.id),
        projectId: upper(booking.projectId),
        projectName: text(booking.projectName),
        plotNumber: text(booking.plotNumber || booking.plotNo),
        status: upper(booking.status || 'BOOKED'),
      })
    );

  const primaryPhoto = activeDocuments.find(
    (document) => upper(document.type) === DOCUMENT_TYPES.PHOTO
  ) || null;

  const idDocuments = activeDocuments.filter((document) =>
    [
      DOCUMENT_TYPES.AADHAAR,
      DOCUMENT_TYPES.PAN,
      DOCUMENT_TYPES.PASSPORT,
      DOCUMENT_TYPES.DRIVING_LICENCE,
      DOCUMENT_TYPES.VOTER_ID,
    ].includes(upper(document.type))
  );

  return Object.freeze({
    customerId,
    customerName: text(customer.customerName || customer.name),
    mobile: text(customer.mobile || customer.customerMobile),
    documents: Object.freeze(customerDocuments),
    activeDocuments: Object.freeze(activeDocuments),
    primaryPhoto,
    idDocuments: Object.freeze(idDocuments),
    bookings: Object.freeze(customerBookings),
    summary: Object.freeze({
      documentCount: customerDocuments.length,
      activeDocumentCount: activeDocuments.length,
      archivedDocumentCount: customerDocuments.length - activeDocuments.length,
      idDocumentCount: idDocuments.length,
      bookingCount: customerBookings.length,
      hasPhoto: Boolean(primaryPhoto),
      hasIdentityProof: idDocuments.length > 0,
    }),
  });
}

function buildBookingDocumentPacket({
  booking,
  customer,
  documents = [],
}) {
  if (!booking || typeof booking !== 'object') {
    throw new TypeError('booking is required.');
  }

  const bookingId = upper(booking.bookingId || booking.id);
  const bookingCustomerId = upper(booking.customerId);
  const customerId = upper(customer && (customer.customerId || customer.id));

  if (!bookingId) throw new Error('bookingId is required.');
  if (!bookingCustomerId) throw new Error('booking.customerId is required.');
  if (!customerId) throw new Error('customerId is required.');
  if (bookingCustomerId !== customerId) {
    throw new Error('Booking customer and supplied customer do not match.');
  }

  const profile = buildCustomerDocumentProfile({
    customer,
    documents,
    bookings: [booking],
  });

  return Object.freeze({
    bookingId,
    customerId,
    projectId: upper(booking.projectId),
    projectName: text(booking.projectName),
    plotNumber: text(booking.plotNumber || booking.plotNo),
    customerName: profile.customerName,
    customerMobile: profile.mobile,
    photo: profile.primaryPhoto,
    identityDocuments: profile.idDocuments,
    allActiveDocuments: profile.activeDocuments,
    documentStatus: Object.freeze({
      hasPhoto: profile.summary.hasPhoto,
      hasIdentityProof: profile.summary.hasIdentityProof,
      readyForProfileDisplay:
        profile.summary.hasPhoto || profile.summary.hasIdentityProof,
    }),
  });
}

class CustomerDocumentIntegrationService {
  create(input) {
    return createCustomerDocument(input);
  }

  ensureUnique(input) {
    return ensureUniqueDocument(input);
  }

  archive(input) {
    return archiveCustomerDocument(input);
  }

  profile(input) {
    return buildCustomerDocumentProfile(input);
  }

  bookingPacket(input) {
    return buildBookingDocumentPacket(input);
  }
}

module.exports = {
  DOCUMENT_TYPES,
  DOCUMENT_STATUSES,
  text,
  upper,
  normalizeDate,
  validateDocumentType,
  normalizeReference,
  maskReference,
  createCustomerDocument,
  ensureUniqueDocument,
  archiveCustomerDocument,
  buildCustomerDocumentProfile,
  buildBookingDocumentPacket,
  CustomerDocumentIntegrationService,
};
