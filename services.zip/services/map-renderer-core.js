'use strict';

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function finiteNumber(value, fieldName) {
  const n = Number(value);
  if (!Number.isFinite(n)) throw new TypeError(`${fieldName} must be a valid number.`);
  return n;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function computeBoundsFromPlots(plots = []) {
  if (!Array.isArray(plots) || plots.length === 0) {
    throw new Error('plots are required.');
  }

  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  for (const plot of plots) {
    const vertices = plot.vertices || [];
    for (const v of vertices) {
      const x = finiteNumber(v.x, 'vertex.x');
      const y = finiteNumber(v.y, 'vertex.y');
      minX = Math.min(minX, x);
      minY = Math.min(minY, y);
      maxX = Math.max(maxX, x);
      maxY = Math.max(maxY, y);
    }
  }

  if (![minX, minY, maxX, maxY].every(Number.isFinite)) {
    throw new Error('Could not compute map bounds.');
  }

  return Object.freeze({
    minX,
    minY,
    maxX,
    maxY,
    width: maxX - minX,
    height: maxY - minY,
    center: Object.freeze({
      x: (minX + maxX) / 2,
      y: (minY + maxY) / 2,
    }),
  });
}

function buildViewport({
  bounds,
  viewportWidth,
  viewportHeight,
  padding = 40,
  minZoom = 0.1,
  maxZoom = 100,
} = {}) {
  if (!bounds) throw new Error('bounds are required.');

  const vw = finiteNumber(viewportWidth, 'viewportWidth');
  const vh = finiteNumber(viewportHeight, 'viewportHeight');
  const usableW = Math.max(1, vw - padding * 2);
  const usableH = Math.max(1, vh - padding * 2);

  const sx = bounds.width > 0 ? usableW / bounds.width : maxZoom;
  const sy = bounds.height > 0 ? usableH / bounds.height : maxZoom;
  const zoom = clamp(Math.min(sx, sy), minZoom, maxZoom);

  return Object.freeze({
    viewportWidth: vw,
    viewportHeight: vh,
    padding,
    zoom,
    panX: vw / 2 - bounds.center.x * zoom,
    panY: vh / 2 + bounds.center.y * zoom,
    bounds,
  });
}

function worldToScreen(point, viewport) {
  return Object.freeze({
    x: point.x * viewport.zoom + viewport.panX,
    y: -point.y * viewport.zoom + viewport.panY,
  });
}

function screenToWorld(point, viewport) {
  return Object.freeze({
    x: (point.x - viewport.panX) / viewport.zoom,
    y: -(point.y - viewport.panY) / viewport.zoom,
  });
}

function zoomAroundPoint({
  viewport,
  screenPoint,
  factor,
  minZoom = 0.1,
  maxZoom = 100,
} = {}) {
  const oldWorld = screenToWorld(screenPoint, viewport);
  const nextZoom = clamp(viewport.zoom * finiteNumber(factor, 'factor'), minZoom, maxZoom);

  const next = {
    ...viewport,
    zoom: nextZoom,
    panX: screenPoint.x - oldWorld.x * nextZoom,
    panY: screenPoint.y + oldWorld.y * nextZoom,
  };

  return Object.freeze(next);
}

function panViewport({ viewport, dx, dy } = {}) {
  return Object.freeze({
    ...viewport,
    panX: viewport.panX + finiteNumber(dx, 'dx'),
    panY: viewport.panY + finiteNumber(dy, 'dy'),
  });
}

function polygonCentroid(vertices = []) {
  if (!Array.isArray(vertices) || vertices.length < 3) {
    throw new Error('polygon requires at least 3 vertices.');
  }

  let signedArea = 0;
  let cx = 0;
  let cy = 0;

  for (let i = 0; i < vertices.length; i += 1) {
    const p0 = vertices[i];
    const p1 = vertices[(i + 1) % vertices.length];
    const a = p0.x * p1.y - p1.x * p0.y;
    signedArea += a;
    cx += (p0.x + p1.x) * a;
    cy += (p0.y + p1.y) * a;
  }

  signedArea *= 0.5;

  if (Math.abs(signedArea) < 1e-9) {
    const avg = vertices.reduce(
      (acc, v) => ({ x: acc.x + v.x, y: acc.y + v.y }),
      { x: 0, y: 0 }
    );
    return Object.freeze({
      x: avg.x / vertices.length,
      y: avg.y / vertices.length,
    });
  }

  return Object.freeze({
    x: cx / (6 * signedArea),
    y: cy / (6 * signedArea),
  });
}

function pointInPolygon(point, vertices = []) {
  let inside = false;

  for (let i = 0, j = vertices.length - 1; i < vertices.length; j = i++) {
    const xi = vertices[i].x;
    const yi = vertices[i].y;
    const xj = vertices[j].x;
    const yj = vertices[j].y;

    const intersect =
      yi > point.y !== yj > point.y &&
      point.x <
        ((xj - xi) * (point.y - yi)) / ((yj - yi) || Number.EPSILON) + xi;

    if (intersect) inside = !inside;
  }

  return inside;
}

function hitTestPlot({ screenPoint, viewport, plots = [] } = {}) {
  const worldPoint = screenToWorld(screenPoint, viewport);

  for (let i = plots.length - 1; i >= 0; i -= 1) {
    const plot = plots[i];
    if (pointInPolygon(worldPoint, plot.vertices || [])) {
      return Object.freeze({
        plotNumber: text(plot.plotNo || plot.plotNumber),
        plot,
        worldPoint,
      });
    }
  }

  return null;
}

function buildPlotRenderModel(plot, viewport) {
  const plotNumber = text(plot.plotNo || plot.plotNumber);
  const centroid = plot.centroid || polygonCentroid(plot.vertices);

  return Object.freeze({
    plotNumber,
    status: upper(plot.status || 'AVAILABLE'),
    screenVertices: Object.freeze(
      plot.vertices.map((v) => worldToScreen(v, viewport))
    ),
    labelPoint: worldToScreen(centroid, viewport),
    sideLengthsFt: Object.freeze([...(plot.sideLengthsFt || [])]),
    areaSqYd: plot.areaSqYd ?? null,
    areaSqM: plot.areaSqM ?? null,
  });
}

function buildRendererFrame({
  mapModel,
  viewportWidth,
  viewportHeight,
  selectedPlotNumber = '',
} = {}) {
  if (!mapModel || !mapModel.layers) {
    throw new TypeError('mapModel is required.');
  }

  const plots = mapModel.layers.plots || [];
  const bounds = computeBoundsFromPlots(plots);
  const viewport = buildViewport({
    bounds,
    viewportWidth,
    viewportHeight,
  });

  const plotRenderModels = plots.map((plot) =>
    buildPlotRenderModel(plot, viewport)
  );

  const selected = text(selectedPlotNumber);
  const selectedPlot = selected
    ? plotRenderModels.find((plot) => plot.plotNumber === selected) || null
    : null;

  return Object.freeze({
    viewport,
    bounds,
    plots: Object.freeze(plotRenderModels),
    roads: Object.freeze([...(mapModel.layers.roads || [])]),
    specialAreas: Object.freeze([...(mapModel.layers.specialAreas || [])]),
    selectedPlot,
    visualPolicy: Object.freeze({
      smoothPanZoom: true,
      plotNumberPlacement: 'CENTROID',
      dimensionsInFeet: true,
      selectionStyle: 'BLUE_GLASS_TRANSPARENT',
      selectionBoundary: 'THIN_DOTTED_OFFSET',
      selectionAutoZoomPercent: Object.freeze([20, 30]),
      clickOutsideClearsSelection: true,
      defaultAreaUnit: 'SQ_YARD',
    }),
  });
}

function buildSelectionViewport({
  frame,
  plotNumber,
  zoomPercent = 25,
} = {}) {
  const plot = frame.plots.find((item) => item.plotNumber === text(plotNumber));
  if (!plot) throw new Error('Selected plot not found.');

  const factor = 1 + clamp(finiteNumber(zoomPercent, 'zoomPercent'), 20, 30) / 100;

  const center = plot.labelPoint;

  return zoomAroundPoint({
    viewport: frame.viewport,
    screenPoint: center,
    factor,
  });
}

class MapRendererCoreService {
  bounds(plots) {
    return computeBoundsFromPlots(plots);
  }

  viewport(input) {
    return buildViewport(input);
  }

  worldToScreen(point, viewport) {
    return worldToScreen(point, viewport);
  }

  screenToWorld(point, viewport) {
    return screenToWorld(point, viewport);
  }

  zoom(input) {
    return zoomAroundPoint(input);
  }

  pan(input) {
    return panViewport(input);
  }

  hitTest(input) {
    return hitTestPlot(input);
  }

  frame(input) {
    return buildRendererFrame(input);
  }

  selectionViewport(input) {
    return buildSelectionViewport(input);
  }
}

module.exports = {
  text,
  upper,
  finiteNumber,
  clamp,
  computeBoundsFromPlots,
  buildViewport,
  worldToScreen,
  screenToWorld,
  zoomAroundPoint,
  panViewport,
  polygonCentroid,
  pointInPolygon,
  hitTestPlot,
  buildPlotRenderModel,
  buildRendererFrame,
  buildSelectionViewport,
  MapRendererCoreService,
};
