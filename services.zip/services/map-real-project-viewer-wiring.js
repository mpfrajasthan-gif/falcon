'use strict';
const fs=require('fs'), path=require('path');
const text=v=>v==null?'':String(v).trim();
function resolveMapReadyPath(projectFolder){const f=text(projectFolder);if(!f)throw new Error('projectFolder is required.');return path.join(f,'maps','map-ready.json');}
function readMapReadyJson(filePath){const p=path.resolve(text(filePath));if(!p)throw new Error('filePath is required.');if(!fs.existsSync(p))throw new Error('map-ready.json not found.');let m;try{m=JSON.parse(fs.readFileSync(p,'utf8'));}catch{throw new Error('map-ready.json is invalid JSON.');}if(!m.layers||!Array.isArray(m.layers.plots))throw new Error('map-ready.json has no plots layer.');return m;}
function createViewerBootstrapPayload({projectId,projectName,projectFolder,mapFilePath}={}){const p=mapFilePath||resolveMapReadyPath(projectFolder);const mapModel=readMapReadyJson(p);return Object.freeze({projectId:text(projectId||mapModel.projectId),projectName:text(projectName||'Falcon Project'),projectFolder:text(projectFolder),mapFilePath:p,mapModel,source:'REAL_PROJECT_MAP_READY',ready:true});}
function buildViewerBootstrapScript(payload){if(!payload||payload.ready!==true)throw new Error('viewer bootstrap payload must be ready.');return 'window.FALCON_REAL_PROJECT = '+JSON.stringify(payload)+';';}
class RealProjectViewerWiringService{resolve(f){return resolveMapReadyPath(f)} read(p){return readMapReadyJson(p)} payload(i){return createViewerBootstrapPayload(i)} script(p){return buildViewerBootstrapScript(p)}}
module.exports={text,resolveMapReadyPath,readMapReadyJson,createViewerBootstrapPayload,buildViewerBootstrapScript,RealProjectViewerWiringService};
