'use strict';

const assert = require('assert');

const {
  ProjectService,
} = require('./project-service');

function createFakeRepository() {
  const projects = new Map();

  return {
    create(project) {
      projects.set(project.id, project);
      return Object.freeze({ ...project });
    },

    findById(id) {
      const project = projects.get(id);
      return project
        ? Object.freeze({ ...project })
        : null;
    },

    findAll() {
      return [...projects.values()].map(
        (project) =>
          Object.freeze({ ...project })
      );
    },

    update(id, changes) {
      const existing = projects.get(id);

      if (!existing) {
        const error = new Error(
          'Project not found.'
        );

        error.code = 'PROJECT_NOT_FOUND';
        throw error;
      }

      const updated = {
        ...existing,
        ...changes,
        id: existing.id,
        uuid: existing.uuid,
        createdAt: existing.createdAt,
      };

      projects.set(id, updated);

      return Object.freeze({ ...updated });
    },
  };
}

function runProjectServiceTests() {
  console.log('Falcon Project Service Tests');
  console.log('----------------------------');

  assert.throws(
    () => new ProjectService(null),
    TypeError
  );

  const repository = createFakeRepository();
  const service = new ProjectService(repository);

  const invalidResult = service.createProject({
    name: '',
  });

  assert.strictEqual(
    invalidResult.success,
    false
  );

  assert.strictEqual(
    invalidResult.code,
    'PROJECT_VALIDATION_FAILED'
  );

  const createResult = service.createProject({
    name: '  Jaipur Pride  ',
    location: '  Jaipur  ',
    address: ' Rajasthan ',
    reraNumber: ' RAJ/P/2026/001 ',
  });

  assert.strictEqual(
    createResult.success,
    true
  );

  assert.strictEqual(
    createResult.code,
    'PROJECT_CREATED'
  );

  assert.ok(
    /^FP-\d{6}$/.test(createResult.data.id)
  );

  assert.strictEqual(
    createResult.data.name,
    'Jaipur Pride'
  );

  assert.strictEqual(
    createResult.data.location,
    'Jaipur'
  );

  assert.strictEqual(
    createResult.data.status,
    'ACTIVE'
  );

  assert.ok(
    typeof createResult.data.uuid === 'string'
  );

  const projectId = createResult.data.id;

  const getResult =
    service.getProject(projectId);

  assert.strictEqual(
    getResult.success,
    true
  );

  assert.strictEqual(
    getResult.code,
    'PROJECT_FOUND'
  );

  const missingResult =
    service.getProject('FP-999999');

  assert.strictEqual(
    missingResult.success,
    false
  );

  assert.strictEqual(
    missingResult.code,
    'PROJECT_NOT_FOUND'
  );

  const listResult =
    service.getAllProjects();

  assert.strictEqual(
    listResult.success,
    true
  );

  assert.strictEqual(
    listResult.data.length,
    1
  );

  assert.strictEqual(
    Object.isFrozen(listResult.data),
    true
  );

  const updateResult =
    service.updateProject(
      projectId,
      {
        name: ' Jaipur Pride Phase 1 ',
        status: 'INACTIVE',
      }
    );

  assert.strictEqual(
    updateResult.success,
    true
  );

  assert.strictEqual(
    updateResult.code,
    'PROJECT_UPDATED'
  );

  assert.strictEqual(
    updateResult.data.name,
    'Jaipur Pride Phase 1'
  );

  assert.strictEqual(
    updateResult.data.status,
    'INACTIVE'
  );

  assert.strictEqual(
    updateResult.data.id,
    projectId
  );

  const invalidUpdate =
    service.updateProject(
      projectId,
      {
        name: '',
      }
    );

  assert.strictEqual(
    invalidUpdate.success,
    false
  );

  assert.strictEqual(
    invalidUpdate.code,
    'PROJECT_VALIDATION_FAILED'
  );

  console.log(
    'Created Project:',
    createResult.data.id
  );

  console.log(
    'Updated Project:',
    updateResult.data.name
  );

  console.log('Assertions Passed: 22');
  console.log('----------------------------');
  console.log('PROJECT SERVICE TEST PASS');
}

try {
  runProjectServiceTests();
} catch (testError) {
  console.error(
    'PROJECT SERVICE TEST FAIL'
  );
  console.error(testError.message);
  process.exitCode = 1;
}