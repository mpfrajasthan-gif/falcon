'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const {
  writeJsonAtomic,
  createSafetySnapshot,
  buildRestoreStaging,
  verifyRestoreStaging,
  applyStagingToLive,
  restoreSafetySnapshot,
  guardedRestore,
  GuardedRestoreEngine,
} = require('./guarded-restore-engine');

(() => {
  console.log('Falcon Guarded Restore Engine Tests');
  console.log('-----------------------------------');

  let assertions = 0;

  const check = (actual, expected) => {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  };

  const yes = (value) => {
    assert.strictEqual(value, true);
    assertions += 1;
  };

  const no = (value) => {
    assert.strictEqual(value, false);
    assertions += 1;
  };

  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'falcon-restore-'));
  const liveDir = path.join(root, 'live');
  const safetyDir = path.join(root, 'safety');
  const stagingDir = path.join(root, 'staging');

  fs.mkdirSync(liveDir, { recursive: true });

  writeJsonAtomic(
    path.join(liveDir, 'customers.json'),
    [{ customerId: 'FC-OLD', name: 'Old Customer' }]
  );

  writeJsonAtomic(
    path.join(liveDir, 'bookings.json'),
    [{ bookingId: 'FB-OLD', status: 'BOOKED' }]
  );

  const snapshot = createSafetySnapshot({
    liveDataDir: liveDir,
    safetyRootDir: safetyDir,
    snapshotId: 'SAFE-000001',
  });

  check(snapshot.snapshotId, 'SAFE-000001');
  yes(fs.existsSync(path.join(snapshot.snapshotDir, 'customers.json')));
  yes(fs.existsSync(path.join(snapshot.snapshotDir, 'bookings.json')));

  const restoreData = {
    customers: [
      { customerId: 'FC-NEW', name: 'New Customer' },
    ],
    bookings: [
      { bookingId: 'FB-NEW', status: 'SOLD' },
    ],
    payments: [
      { paymentId: 'PAY-NEW', amount: 100000 },
    ],
  };

  const staging = buildRestoreStaging({
    restoreData,
    stagingRootDir: stagingDir,
    restoreId: 'RESTORE-000001',
  });

  check(staging.restoreId, 'RESTORE-000001');
  check(staging.sections.length, 3);
  yes(fs.existsSync(path.join(staging.stagingDir, 'restore-staging-manifest.json')));

  const verification = verifyRestoreStaging(staging);
  yes(verification.valid);
  check(verification.sectionResults.length, 3);

  const applied = applyStagingToLive({
    staging,
    liveDataDir: liveDir,
  });

  yes(applied.applied);
  check(applied.sections.length, 3);

  const newCustomers = JSON.parse(
    fs.readFileSync(path.join(liveDir, 'customers.json'), 'utf8')
  );

  check(newCustomers[0].customerId, 'FC-NEW');

  assert.throws(
    () =>
      applyStagingToLive({
        staging,
        liveDataDir: liveDir,
        allowSections: ['customers'],
      }),
    /Partial restore is blocked/
  );
  assertions += 1;

  const rollback = restoreSafetySnapshot({
    snapshot,
    liveDataDir: liveDir,
  });

  yes(rollback.rolledBack);

  const rolledBackCustomers = JSON.parse(
    fs.readFileSync(path.join(liveDir, 'customers.json'), 'utf8')
  );

  check(rolledBackCustomers[0].customerId, 'FC-OLD');

  const guardedSuccess = guardedRestore({
    liveDataDir: liveDir,
    safetyRootDir: safetyDir,
    stagingRootDir: stagingDir,
    restoreData,
    restoreId: 'RESTORE-000002',
    snapshotId: 'SAFE-000002',
  });

  yes(guardedSuccess.completed);
  no(guardedSuccess.rolledBack);
  yes(guardedSuccess.stagingVerification.valid);
  yes(guardedSuccess.applyResult.applied);

  const successfulCustomers = JSON.parse(
    fs.readFileSync(path.join(liveDir, 'customers.json'), 'utf8')
  );
  check(successfulCustomers[0].customerId, 'FC-NEW');

  writeJsonAtomic(
    path.join(liveDir, 'customers.json'),
    [{ customerId: 'FC-BEFORE-FAIL', name: 'Before Failure' }]
  );

  const guardedFailure = guardedRestore({
    liveDataDir: liveDir,
    safetyRootDir: safetyDir,
    stagingRootDir: stagingDir,
    restoreData,
    restoreId: 'RESTORE-000003',
    snapshotId: 'SAFE-000003',
    simulateFailureAfterApply: true,
  });

  no(guardedFailure.completed);
  yes(guardedFailure.rolledBack);
  yes(guardedFailure.rollback.rolledBack);

  const afterFailureCustomers = JSON.parse(
    fs.readFileSync(path.join(liveDir, 'customers.json'), 'utf8')
  );

  check(afterFailureCustomers[0].customerId, 'FC-BEFORE-FAIL');

  const tamperedStaging = buildRestoreStaging({
    restoreData,
    stagingRootDir: stagingDir,
    restoreId: 'RESTORE-000004',
  });

  fs.writeFileSync(
    path.join(tamperedStaging.stagingDir, 'customers.json'),
    JSON.stringify([{ customerId: 'TAMPERED' }], null, 2),
    'utf8'
  );

  const tamperedVerification = verifyRestoreStaging(tamperedStaging);
  no(tamperedVerification.valid);

  assert.throws(
    () =>
      applyStagingToLive({
        staging: tamperedStaging,
        liveDataDir: liveDir,
      }),
    /verification failed/
  );
  assertions += 1;

  const service = new GuardedRestoreEngine();

  const serviceStaging = service.stage({
    restoreData,
    stagingRootDir: stagingDir,
    restoreId: 'RESTORE-000005',
  });

  yes(service.verify(serviceStaging).valid);

  const serviceSnapshot = service.snapshot({
    liveDataDir: liveDir,
    safetyRootDir: safetyDir,
    snapshotId: 'SAFE-000005',
  });

  check(serviceSnapshot.snapshotId, 'SAFE-000005');

  console.log('Pre-restore Safety Snapshot: PASS');
  console.log('Restore Staging Area: PASS');
  console.log('Staging Integrity Verification: PASS');
  console.log('Atomic Restore Writes: PASS');
  console.log('Partial Restore Block: PASS');
  console.log('Manual Rollback: PASS');
  console.log('Guarded Restore Success Flow: PASS');
  console.log('Restore Failure Rollback: PASS');
  console.log('Tampered Staging Detection: PASS');
  console.log('Reusable Guarded Restore Engine: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('-----------------------------------');
  console.log('GUARDED RESTORE ENGINE TEST PASS');
})();
