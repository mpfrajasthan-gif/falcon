'use strict';

const DXF_CATEGORIES = Object.freeze({
  PLOT: 'PLOT',
  ROAD: 'ROAD',
  FACILITY: 'FACILITY',
  KHASRA: 'KHASRA',
  SCHEME_BOUNDARY: 'SCHEME_BOUNDARY',
  OTHER_LAND: 'OTHER_LAND',
  UNKNOWN: 'UNKNOWN',
});

const ENTITY_TYPES = Object.freeze({
  LWPOLYLINE: 'LWPOLYLINE',
  POLYLINE: 'POLYLINE',
  TEXT: 'TEXT',
  MTEXT: 'MTEXT',
  LINE: 'LINE',
  HATCH: 'HATCH',
  INSERT: 'INSERT',
  UNKNOWN: 'UNKNOWN',
});

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function finiteNumber(value, fieldName) {
  const n = Number(value);
  if (!Number.isFinite(n)) throw new TypeError(`${fieldName} must be a valid number.`);
  return n;
}

function normalizeLayerName(value) {
  return upper(value).replace(/\s+/g, ' ').trim();
}

function classifyLayer(layerName, rules = {}) {
  const layer = normalizeLayerName(layerName);

  const defaults = {
    plot: ['PLOT', 'PLOTS', 'RESIDENTIAL', 'COMMERCIAL'],
    road: ['ROAD', 'ROADS', 'STREET'],
    facility: ['FACILITY', 'FACILITIES', 'PARK', 'IBADATGAH'],
    khasra: ['KHASRA', 'KHASRA BOUNDARY', 'KHASRA_BOUNDARY'],
    schemeBoundary: ['SCHEME BOUNDARY', 'SCHEME_BOUNDARY', 'BOUNDARY'],
    otherLand: ['OTHER LAND', 'OTHER_LAND'],
  };

  const merged = {
    plot: [...defaults.plot, ...(rules.plot || [])].map(normalizeLayerName),
    road: [...defaults.road, ...(rules.road || [])].map(normalizeLayerName),
    facility: [...defaults.facility, ...(rules.facility || [])].map(normalizeLayerName),
    khasra: [...defaults.khasra, ...(rules.khasra || [])].map(normalizeLayerName),
    schemeBoundary: [...defaults.schemeBoundary, ...(rules.schemeBoundary || [])].map(normalizeLayerName),
    otherLand: [...defaults.otherLand, ...(rules.otherLand || [])].map(normalizeLayerName),
  };

  if (merged.plot.includes(layer)) return DXF_CATEGORIES.PLOT;
  if (merged.road.includes(layer)) return DXF_CATEGORIES.ROAD;
  if (merged.facility.includes(layer)) return DXF_CATEGORIES.FACILITY;
  if (merged.khasra.includes(layer)) return DXF_CATEGORIES.KHASRA;
  if (merged.schemeBoundary.includes(layer)) return DXF_CATEGORIES.SCHEME_BOUNDARY;
  if (merged.otherLand.includes(layer)) return DXF_CATEGORIES.OTHER_LAND;

  return DXF_CATEGORIES.UNKNOWN;
}

function normalizeEntity(entity = {}, rules = {}) {
  const type = upper(entity.type || 'UNKNOWN');
  const normalizedType = Object.values(ENTITY_TYPES).includes(type)
    ? type
    : ENTITY_TYPES.UNKNOWN;

  const vertices = Array.isArray(entity.vertices)
    ? entity.vertices.map((v, index) => Object.freeze({
        index,
        x: finiteNumber(v.x, `vertices[${index}].x`),
        y: finiteNumber(v.y, `vertices[${index}].y`),
      }))
    : [];

  const closed = Boolean(
    entity.closed === true ||
    entity.isClosed === true ||
    (vertices.length > 2 &&
      vertices[0].x === vertices[vertices.length - 1].x &&
      vertices[0].y === vertices[vertices.length - 1].y)
  );

  return Object.freeze({
    id: upper(entity.id || entity.handle),
    handle: upper(entity.handle || entity.id),
    type: normalizedType,
    layer: normalizeLayerName(entity.layer),
    category: classifyLayer(entity.layer, rules),
    closed,
    vertices: Object.freeze(vertices),
    text: text(entity.text || entity.value),
    area: entity.area === undefined || entity.area === null || entity.area === ''
      ? null
      : finiteNumber(entity.area, 'entity.area'),
    source: entity,
  });
}

function polygonArea(vertices = []) {
  if (!Array.isArray(vertices) || vertices.length < 3) return 0;

  let area = 0;
  for (let i = 0; i < vertices.length; i += 1) {
    const a = vertices[i];
    const b = vertices[(i + 1) % vertices.length];
    area += a.x * b.y - b.x * a.y;
  }
  return Math.abs(area) / 2;
}

function auditEntities(entities = [], rules = {}) {
  if (!Array.isArray(entities)) throw new TypeError('entities must be an array.');

  const normalized = entities.map((entity) => normalizeEntity(entity, rules));
  const issues = [];
  const seenHandles = new Set();

  for (const entity of normalized) {
    if (!entity.layer) {
      issues.push(Object.freeze({
        severity: 'ERROR',
        code: 'MISSING_LAYER',
        entityId: entity.id,
        message: 'Entity has no layer.',
      }));
    }

    if (entity.handle) {
      if (seenHandles.has(entity.handle)) {
        issues.push(Object.freeze({
          severity: 'ERROR',
          code: 'DUPLICATE_HANDLE',
          entityId: entity.id,
          message: `Duplicate entity handle: ${entity.handle}`,
        }));
      }
      seenHandles.add(entity.handle);
    }

    if (entity.category === DXF_CATEGORIES.UNKNOWN) {
      issues.push(Object.freeze({
        severity: 'WARNING',
        code: 'UNKNOWN_LAYER',
        entityId: entity.id,
        message: `Unclassified layer: ${entity.layer || '(blank)'}`,
      }));
    }

    if (
      entity.category === DXF_CATEGORIES.PLOT &&
      [ENTITY_TYPES.LWPOLYLINE, ENTITY_TYPES.POLYLINE].includes(entity.type)
    ) {
      if (!entity.closed) {
        issues.push(Object.freeze({
          severity: 'ERROR',
          code: 'OPEN_PLOT_POLYGON',
          entityId: entity.id,
          message: 'Plot polygon must be closed.',
        }));
      }

      if (entity.vertices.length < 3) {
        issues.push(Object.freeze({
          severity: 'ERROR',
          code: 'PLOT_TOO_FEW_VERTICES',
          entityId: entity.id,
          message: 'Plot polygon requires at least 3 vertices.',
        }));
      }

      const computedArea = polygonArea(entity.vertices);
      if (computedArea <= 0) {
        issues.push(Object.freeze({
          severity: 'ERROR',
          code: 'INVALID_PLOT_AREA',
          entityId: entity.id,
          message: 'Plot polygon area must be greater than zero.',
        }));
      }
    }
  }

  const errorCount = issues.filter((i) => i.severity === 'ERROR').length;
  const warningCount = issues.filter((i) => i.severity === 'WARNING').length;

  const categoryCounts = {};
  for (const entity of normalized) {
    categoryCounts[entity.category] = (categoryCounts[entity.category] || 0) + 1;
  }

  return Object.freeze({
    entities: Object.freeze(normalized),
    issues: Object.freeze(issues),
    summary: Object.freeze({
      entityCount: normalized.length,
      errorCount,
      warningCount,
      pass: errorCount === 0,
      categoryCounts: Object.freeze({ ...categoryCounts }),
    }),
  });
}

function extractPlotCandidates(auditResult) {
  if (!auditResult || typeof auditResult !== 'object') {
    throw new TypeError('auditResult is required.');
  }

  const errorEntityIds = new Set(
    (auditResult.issues || [])
      .filter((issue) => issue.severity === 'ERROR')
      .map((issue) => issue.entityId)
  );

  return Object.freeze(
    (auditResult.entities || [])
      .filter((entity) => entity.category === DXF_CATEGORIES.PLOT)
      .filter((entity) => [ENTITY_TYPES.LWPOLYLINE, ENTITY_TYPES.POLYLINE].includes(entity.type))
      .filter((entity) => !errorEntityIds.has(entity.id))
      .map((entity) => Object.freeze({
        sourceEntityId: entity.id,
        sourceHandle: entity.handle,
        layer: entity.layer,
        vertices: entity.vertices,
        computedArea: polygonArea(entity.vertices),
        status: 'AVAILABLE',
      }))
  );
}

function buildPlotEngineHandoff({
  projectId,
  auditResult,
  unit = 'DXF_UNIT',
} = {}) {
  const cleanProjectId = upper(projectId);
  if (!cleanProjectId) throw new Error('projectId is required.');
  if (!auditResult || typeof auditResult !== 'object') {
    throw new TypeError('auditResult is required.');
  }

  if (!auditResult.summary || auditResult.summary.pass !== true) {
    throw new Error('DXF audit must PASS before plot handoff.');
  }

  const plots = extractPlotCandidates(auditResult);

  return Object.freeze({
    projectId: cleanProjectId,
    source: 'DXF',
    unit: upper(unit),
    generatedAt: new Date().toISOString(),
    plotCount: plots.length,
    plots,
    auditSummary: auditResult.summary,
  });
}

class DxfIntegrationContractService {
  classifyLayer(layerName, rules) {
    return classifyLayer(layerName, rules);
  }

  normalizeEntity(entity, rules) {
    return normalizeEntity(entity, rules);
  }

  audit(entities, rules) {
    return auditEntities(entities, rules);
  }

  plotCandidates(auditResult) {
    return extractPlotCandidates(auditResult);
  }

  handoff(input) {
    return buildPlotEngineHandoff(input);
  }
}

module.exports = {
  DXF_CATEGORIES,
  ENTITY_TYPES,
  text,
  upper,
  finiteNumber,
  normalizeLayerName,
  classifyLayer,
  normalizeEntity,
  polygonArea,
  auditEntities,
  extractPlotCandidates,
  buildPlotEngineHandoff,
  DxfIntegrationContractService,
};
