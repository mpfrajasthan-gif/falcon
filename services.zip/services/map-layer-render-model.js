'use strict';

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

const STATUS_STYLES = Object.freeze({
  AVAILABLE: Object.freeze({
    fillRole: 'AVAILABLE_FILL',
    strokeRole: 'PLOT_BORDER',
    opacity: 1,
  }),
  HOLD: Object.freeze({
    fillRole: 'HOLD_FILL',
    strokeRole: 'PLOT_BORDER',
    opacity: 1,
  }),
  BOOKED: Object.freeze({
    fillRole: 'BOOKED_FILL',
    strokeRole: 'PLOT_BORDER',
    opacity: 1,
  }),
  SOLD: Object.freeze({
    fillRole: 'SOLD_FILL',
    strokeRole: 'PLOT_BORDER',
    opacity: 1,
  }),
});

const LAND_USE_STYLES = Object.freeze({
  RESIDENTIAL: Object.freeze({ fillRole: 'RESIDENTIAL_CREAM' }),
  COMMERCIAL: Object.freeze({ fillRole: 'COMMERCIAL_BROWN' }),
  FACILITY: Object.freeze({ fillRole: 'FACILITY_FILL' }),
  OTHER_LAND: Object.freeze({ fillRole: 'OTHER_LAND_OLIVE' }),
});

const DRAW_ORDER = Object.freeze([
  'BACKGROUND',
  'SPECIAL_AREAS',
  'PLOTS',
  'PLOT_BORDERS',
  'ROADS',
  'ROAD_LABELS',
  'DIMENSIONS',
  'PLOT_NUMBERS',
  'SELECTION_FILL',
  'SELECTION_BOUNDARY',
]);

function normalizeStatus(value) {
  const status = upper(value || 'AVAILABLE');
  return Object.prototype.hasOwnProperty.call(STATUS_STYLES, status)
    ? status
    : 'AVAILABLE';
}

function normalizeLandUse(value) {
  const v = upper(value || 'RESIDENTIAL').replace(/\s+/g, '_');
  return Object.prototype.hasOwnProperty.call(LAND_USE_STYLES, v)
    ? v
    : 'RESIDENTIAL';
}

function buildPlotStyle(plot = {}) {
  const status = normalizeStatus(plot.status);
  const landUse = normalizeLandUse(plot.landUse || plot.category || plot.type);

  return Object.freeze({
    status,
    landUse,
    statusStyle: STATUS_STYLES[status],
    landUseStyle: LAND_USE_STYLES[landUse],
    border: Object.freeze({
      role: 'PLOT_BORDER',
      widthPx: 1,
    }),
    label: Object.freeze({
      role: 'PLOT_NUMBER',
      fontWeight: 600,
      preferredSizePx: 15,
      minSizePx: 10,
      maxSizePx: 16,
      placement: 'CENTROID',
    }),
  });
}

function buildDimensionCommands(plot = {}) {
  const vertices = Array.isArray(plot.screenVertices) ? plot.screenVertices : [];
  const sideLengthsFt = Array.isArray(plot.sideLengthsFt) ? plot.sideLengthsFt : [];

  const commands = [];

  const sideCount = Math.min(vertices.length, sideLengthsFt.length);

  for (let i = 0; i < sideCount; i += 1) {
    const a = vertices[i];
    const b = vertices[(i + 1) % vertices.length];
    if (!a || !b) continue;

    commands.push(Object.freeze({
      type: 'DIMENSION_LABEL',
      role: 'DIMENSION_TEXT',
      sideIndex: i,
      valueFt: Number(sideLengthsFt[i]),
      text: `${Number(sideLengthsFt[i]).toFixed(1)}'`,
      midpoint: Object.freeze({
        x: (a.x + b.x) / 2,
        y: (a.y + b.y) / 2,
      }),
      angleRad: Math.atan2(b.y - a.y, b.x - a.x),
      fontSizePx: 10,
      shaded: false,
    }));
  }

  return Object.freeze(commands);
}

function buildPlotCommands(plot = {}) {
  const style = buildPlotStyle(plot);

  return Object.freeze([
    Object.freeze({
      layer: 'PLOTS',
      type: 'POLYGON_FILL',
      plotNumber: text(plot.plotNumber),
      points: Object.freeze([...(plot.screenVertices || [])]),
      fillRole: style.landUseStyle.fillRole,
      statusOverlayRole: style.statusStyle.fillRole,
      opacity: style.statusStyle.opacity,
    }),
    Object.freeze({
      layer: 'PLOT_BORDERS',
      type: 'POLYGON_STROKE',
      plotNumber: text(plot.plotNumber),
      points: Object.freeze([...(plot.screenVertices || [])]),
      strokeRole: style.border.role,
      widthPx: style.border.widthPx,
    }),
    Object.freeze({
      layer: 'PLOT_NUMBERS',
      type: 'TEXT',
      plotNumber: text(plot.plotNumber),
      text: text(plot.plotNumber),
      point: plot.labelPoint,
      role: style.label.role,
      fontWeight: style.label.fontWeight,
      preferredSizePx: style.label.preferredSizePx,
      minSizePx: style.label.minSizePx,
      maxSizePx: style.label.maxSizePx,
      placement: style.label.placement,
    }),
    ...buildDimensionCommands(plot).map((cmd) =>
      Object.freeze({
        ...cmd,
        layer: 'DIMENSIONS',
        plotNumber: text(plot.plotNumber),
      })
    ),
  ]);
}

function buildRoadCommands(roads = []) {
  return Object.freeze(
    roads.flatMap((road, index) => {
      const name = text(road.name || `ROAD-${index + 1}`);
      const commands = [];

      if (Array.isArray(road.screenVertices) && road.screenVertices.length >= 2) {
        commands.push(Object.freeze({
          layer: 'ROADS',
          type: 'POLYLINE',
          roadId: text(road.id || `ROAD-${index + 1}`),
          points: Object.freeze([...road.screenVertices]),
          role: 'ROAD_EDGE',
          widthPx: 1,
        }));
      }

      if (road.labelPoint) {
        commands.push(Object.freeze({
          layer: 'ROAD_LABELS',
          type: 'TEXT',
          roadId: text(road.id || `ROAD-${index + 1}`),
          text: name,
          point: road.labelPoint,
          role: 'ROAD_TEXT',
          fontWeight: 700,
          preferredSizePx: 11,
        }));
      }

      return commands;
    })
  );
}

function buildSpecialAreaCommands(areas = []) {
  return Object.freeze(
    areas.flatMap((area, index) => {
      const commands = [];
      const id = text(area.id || `SPECIAL-${index + 1}`);

      if (Array.isArray(area.screenVertices) && area.screenVertices.length >= 3) {
        commands.push(Object.freeze({
          layer: 'SPECIAL_AREAS',
          type: 'POLYGON_FILL',
          specialId: id,
          category: upper(area.category || area.name),
          points: Object.freeze([...area.screenVertices]),
          fillRole: upper(area.category || area.name) === 'OTHER LAND'
            ? 'OTHER_LAND_OLIVE'
            : 'FACILITY_FILL',
          opacity: 1,
        }));
      }

      if (area.labelPoint) {
        commands.push(Object.freeze({
          layer: 'SPECIAL_AREAS',
          type: 'TEXT',
          specialId: id,
          text: text(area.name || area.category),
          point: area.labelPoint,
          role: 'FACILITY_TEXT',
          fontWeight: 600,
          preferredSizePx: 11,
        }));
      }

      return commands;
    })
  );
}

function buildSelectionCommands(selectedPlot) {
  if (!selectedPlot) return Object.freeze([]);

  const points = Object.freeze([...(selectedPlot.screenVertices || [])]);

  return Object.freeze([
    Object.freeze({
      layer: 'SELECTION_FILL',
      type: 'POLYGON_FILL',
      plotNumber: selectedPlot.plotNumber,
      points,
      fillRole: 'SELECTION_BLUE_GLASS',
      opacity: 0.28,
    }),
    Object.freeze({
      layer: 'SELECTION_BOUNDARY',
      type: 'POLYGON_STROKE',
      plotNumber: selectedPlot.plotNumber,
      points,
      strokeRole: 'SELECTION_DOTTED',
      widthPx: 1,
      dashPx: Object.freeze([3, 3]),
      offsetPx: 2,
    }),
  ]);
}

function transformRoadsToScreen(roads = [], viewport, worldToScreen) {
  return Object.freeze(
    roads.map((road) => {
      const screenVertices = Array.isArray(road.vertices)
        ? road.vertices.map((v) => worldToScreen(v, viewport))
        : [];

      const labelPoint = road.labelPoint
        ? worldToScreen(road.labelPoint, viewport)
        : null;

      return Object.freeze({
        ...road,
        screenVertices: Object.freeze(screenVertices),
        labelPoint,
      });
    })
  );
}

function transformSpecialAreasToScreen(areas = [], viewport, worldToScreen) {
  return Object.freeze(
    areas.map((area) => {
      const screenVertices = Array.isArray(area.vertices)
        ? area.vertices.map((v) => worldToScreen(v, viewport))
        : [];

      let labelPoint = null;

      if (area.centroid) {
        labelPoint = worldToScreen(area.centroid, viewport);
      }

      return Object.freeze({
        ...area,
        screenVertices: Object.freeze(screenVertices),
        labelPoint,
      });
    })
  );
}

function buildLayerRenderModel({
  frame,
  worldToScreen,
} = {}) {
  if (!frame || typeof frame !== 'object') {
    throw new TypeError('frame is required.');
  }

  if (typeof worldToScreen !== 'function') {
    throw new TypeError('worldToScreen function is required.');
  }

  const roads = transformRoadsToScreen(
    frame.roads || [],
    frame.viewport,
    worldToScreen
  );

  const specialAreas = transformSpecialAreasToScreen(
    frame.specialAreas || [],
    frame.viewport,
    worldToScreen
  );

  const commands = [
    Object.freeze({
      layer: 'BACKGROUND',
      type: 'BACKGROUND',
      role: 'MAP_BACKGROUND',
    }),
    ...buildSpecialAreaCommands(specialAreas),
    ...frame.plots.flatMap(buildPlotCommands),
    ...buildRoadCommands(roads),
    ...buildSelectionCommands(frame.selectedPlot),
  ];

  const orderIndex = new Map(DRAW_ORDER.map((name, index) => [name, index]));

  commands.sort(
    (a, b) =>
      (orderIndex.get(a.layer) ?? 999) -
      (orderIndex.get(b.layer) ?? 999)
  );

  return Object.freeze({
    drawOrder: DRAW_ORDER,
    commands: Object.freeze(commands),
    summary: Object.freeze({
      plotCount: frame.plots.length,
      roadCount: roads.length,
      specialAreaCount: specialAreas.length,
      selectedPlotNumber: frame.selectedPlot
        ? frame.selectedPlot.plotNumber
        : '',
      commandCount: commands.length,
    }),
  });
}

class MapLayerRenderModelService {
  plotStyle(plot) {
    return buildPlotStyle(plot);
  }

  plotCommands(plot) {
    return buildPlotCommands(plot);
  }

  roadCommands(roads) {
    return buildRoadCommands(roads);
  }

  specialAreaCommands(areas) {
    return buildSpecialAreaCommands(areas);
  }

  selectionCommands(selectedPlot) {
    return buildSelectionCommands(selectedPlot);
  }

  build(input) {
    return buildLayerRenderModel(input);
  }
}

module.exports = {
  STATUS_STYLES,
  LAND_USE_STYLES,
  DRAW_ORDER,
  text,
  upper,
  normalizeStatus,
  normalizeLandUse,
  buildPlotStyle,
  buildDimensionCommands,
  buildPlotCommands,
  buildRoadCommands,
  buildSpecialAreaCommands,
  buildSelectionCommands,
  transformRoadsToScreen,
  transformSpecialAreasToScreen,
  buildLayerRenderModel,
  MapLayerRenderModelService,
};
