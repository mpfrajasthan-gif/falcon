'use strict';

const assert = require('assert');

const {
  BACKUP_SECTIONS,
  normalizeSections,
  stableStringify,
  sha256,
  createSectionDigest,
  createBackupManifest,
  verifyBackupManifest,
  buildBackupPlan,
  validateRestoreCompatibility,
  createRestorePreview,
  BackupManifestIntegrityService,
} = require('./backup-manifest-integrity');

(() => {
  console.log('Falcon Backup Manifest & Integrity Tests');
  console.log('----------------------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  function checkFalse(value) {
    assert.strictEqual(value, false);
    assertions += 1;
  }

  check(BACKUP_SECTIONS.length, 11);
  check(normalizeSections().length, 11);
  check(normalizeSections(['projects', 'customers']).length, 2);

  assert.throws(
    () => normalizeSections(['unknown']),
    /Unsupported backup section/
  );
  assertions += 1;

  const s1 = stableStringify({ b: 2, a: 1 });
  const s2 = stableStringify({ a: 1, b: 2 });
  check(s1, s2);
  check(sha256({ a: 1 }).length, 64);

  const data = {
    projects: [
      { projectId: 'FP-000001', name: 'Jaipur Pride' },
    ],
    customers: [
      { customerId: 'FC-000001', name: 'Customer One' },
      { customerId: 'FC-000002', name: 'Customer Two' },
    ],
    bookings: [
      { bookingId: 'FB-000001', customerId: 'FC-000001' },
    ],
    payments: [
      { paymentId: 'PAY-000001', amount: 100000 },
    ],
  };

  const digest = createSectionDigest('customers', data.customers);
  check(digest.section, 'customers');
  check(digest.count, 2);
  check(digest.hash.length, 64);

  const manifest = createBackupManifest({
    backupId: 'BKP-000001',
    appVersion: '1.0.0',
    createdAt: '2026-07-29T20:30:00.000Z',
    actorId: 'FU-000001',
    sourceDevice: 'OFFICE-PC',
    projectId: 'FP-000001',
    sections: ['projects', 'customers', 'bookings', 'payments'],
    data,
  });

  check(manifest.backupId, 'BKP-000001');
  check(manifest.schemaVersion, 1);
  check(manifest.sections.length, 4);
  check(manifest.sectionDigests.length, 4);
  check(manifest.manifestHash.length, 64);
  check(manifest.projectId, 'FP-000001');

  const verified = verifyBackupManifest({
    manifest,
    data,
  });

  checkTrue(verified.valid);
  checkTrue(verified.manifestHashValid);
  checkTrue(verified.allSectionsValid);
  check(verified.sectionResults.length, 4);

  const tamperedData = {
    ...data,
    payments: [
      { paymentId: 'PAY-000001', amount: 999999 },
    ],
  };

  const tampered = verifyBackupManifest({
    manifest,
    data: tamperedData,
  });

  checkFalse(tampered.valid);
  checkTrue(tampered.manifestHashValid);
  checkFalse(tampered.allSectionsValid);

  const paymentResult = tampered.sectionResults.find(
    (item) => item.section === 'payments'
  );
  checkFalse(paymentResult.valid);

  const allPlan = buildBackupPlan();
  check(allPlan.length, 11);
  check(allPlan.every((item) => item.selected), true);

  const partialPlan = buildBackupPlan({
    sections: ['projects', 'customers'],
  });

  check(
    partialPlan.filter((item) => item.selected).length,
    2
  );

  const compatibility = validateRestoreCompatibility({
    manifest,
    currentAppVersion: '1.0.0',
  });

  checkTrue(compatibility.compatible);
  check(compatibility.backupAppVersion, '1.0.0');

  const badCompatibility = validateRestoreCompatibility({
    manifest: {
      ...manifest,
      schemaVersion: 99,
    },
  });

  checkFalse(badCompatibility.compatible);
  check(badCompatibility.issues.length, 1);

  const preview = createRestorePreview({
    manifest,
    data,
  });

  check(preview.backupId, 'BKP-000001');
  check(preview.integrityValid, true);
  check(preview.sections.length, 4);

  const customerPreview = preview.sections.find(
    (item) => item.section === 'customers'
  );

  check(customerPreview.recordCount, 2);
  check(customerPreview.integrityValid, true);

  const service = new BackupManifestIntegrityService();

  check(service.sections().length, 11);
  check(service.plan().every((item) => item.selected), true);

  const serviceVerification = service.verify({
    manifest,
    data,
  });

  checkTrue(serviceVerification.valid);

  const servicePreview = service.preview({
    manifest,
    data,
  });

  check(servicePreview.integrityValid, true);

  console.log('Backup Section Registry: PASS');
  console.log('Default Select-All Plan: PASS');
  console.log('Section Digest Generation: PASS');
  console.log('Manifest Generation: PASS');
  console.log('Manifest SHA-256 Integrity: PASS');
  console.log('Tamper Detection: PASS');
  console.log('Restore Compatibility Check: PASS');
  console.log('Restore Preview: PASS');
  console.log('Reusable Backup Integrity Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('----------------------------------------');
  console.log('BACKUP MANIFEST & INTEGRITY TEST PASS');
})();
