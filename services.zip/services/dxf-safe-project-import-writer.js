'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const {
  validateImportPackage,
  buildProjectStoragePlan,
  buildPersistableProjectData,
} = require('./dxf-project-import-integration');

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function ensureDir(dirPath) {
  if (!text(dirPath)) throw new Error('dirPath is required.');
  fs.mkdirSync(dirPath, { recursive: true });
  return dirPath;
}

function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  const keys = Object.keys(value).sort();
  return `{${keys.map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
}

function sha256(value) {
  return crypto
    .createHash('sha256')
    .update(typeof value === 'string' ? value : stableStringify(value))
    .digest('hex');
}

function resolveProjectFile(projectFolder, relativePath) {
  if (!text(projectFolder)) throw new Error('projectFolder is required.');
  const parts = text(relativePath).split(/[\\/]+/).filter(Boolean);
  return path.join(projectFolder, ...parts);
}

function writeJsonVerified(filePath, data) {
  ensureDir(path.dirname(filePath));

  const payload = JSON.stringify(data, null, 2);
  const tempPath = `${filePath}.tmp-${process.pid}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;

  try {
    fs.writeFileSync(tempPath, payload, 'utf8');

    const tempRead = fs.readFileSync(tempPath, 'utf8');
    if (sha256(tempRead) !== sha256(payload)) {
      throw new Error('Temporary import file verification failed.');
    }

    return Object.freeze({
      tempPath,
      finalPath: filePath,
      sha256: sha256(payload),
      bytes: Buffer.byteLength(payload, 'utf8'),
    });
  } catch (error) {
    if (fs.existsSync(tempPath)) fs.rmSync(tempPath, { force: true });
    throw error;
  }
}

function getWriteEntries(pkg) {
  validateImportPackage(pkg);

  const plan = buildProjectStoragePlan(pkg);
  const data = buildPersistableProjectData(pkg);

  if (!text(plan.projectFolder)) {
    throw new Error('Project folder is required for safe import write.');
  }

  return [
    ['importMetadata', resolveProjectFile(plan.projectFolder, plan.relative.importMetadata), data.importMetadata],
    ['plots', resolveProjectFile(plan.projectFolder, plan.relative.plots), data.plots],
    ['mapModel', resolveProjectFile(plan.projectFolder, plan.relative.mapModel), data.mapModel],
    ['diagnostics', resolveProjectFile(plan.projectFolder, plan.relative.diagnostics), data.diagnostics],
    ['sourceMetadata', resolveProjectFile(plan.projectFolder, plan.relative.sourceMetadata), data.sourceMetadata],
  ];
}

function stageProjectImport(pkg) {
  const entries = getWriteEntries(pkg);
  const staged = [];

  try {
    for (const [key, finalPath, value] of entries) {
      const result = writeJsonVerified(finalPath, value);
      staged.push(Object.freeze({ key, ...result }));
    }
  } catch (error) {
    for (const item of staged) {
      if (fs.existsSync(item.tempPath)) fs.rmSync(item.tempPath, { force: true });
    }
    throw error;
  }

  return Object.freeze({
    projectId: pkg.project.projectId,
    importId: pkg.importId,
    staged: Object.freeze(staged),
  });
}

function createRollbackSnapshot(staged) {
  if (!staged || !Array.isArray(staged.staged)) {
    throw new TypeError('staged import is required.');
  }

  const backups = staged.staged.map((item) => {
    const existedBefore = fs.existsSync(item.finalPath);
    const backupPath = existedBefore
      ? `${item.finalPath}.rollback-${process.pid}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`
      : '';

    if (existedBefore) fs.copyFileSync(item.finalPath, backupPath);

    return Object.freeze({
      key: item.key,
      finalPath: item.finalPath,
      existedBefore,
      backupPath,
    });
  });

  return Object.freeze({
    projectId: staged.projectId,
    importId: staged.importId,
    backups: Object.freeze(backups),
  });
}

function cleanupRollbackCopies(rollback) {
  for (const entry of rollback.backups) {
    if (entry.backupPath && fs.existsSync(entry.backupPath)) {
      fs.rmSync(entry.backupPath, { force: true });
    }
  }
}

function rollbackAppliedImport(rollback, staged) {
  for (const entry of rollback.backups) {
    if (fs.existsSync(entry.finalPath)) {
      fs.rmSync(entry.finalPath, { force: true });
    }

    if (entry.existedBefore && entry.backupPath && fs.existsSync(entry.backupPath)) {
      ensureDir(path.dirname(entry.finalPath));
      fs.renameSync(entry.backupPath, entry.finalPath);
    }
  }

  for (const item of staged.staged) {
    if (fs.existsSync(item.tempPath)) fs.rmSync(item.tempPath, { force: true });
  }

  cleanupRollbackCopies(rollback);
}

function applyStagedImport({ staged, simulateFailureAfter = 0 } = {}) {
  if (!staged || !Array.isArray(staged.staged)) {
    throw new TypeError('staged import is required.');
  }

  const rollback = createRollbackSnapshot(staged);
  const applied = [];

  try {
    let index = 0;

    for (const item of staged.staged) {
      index += 1;

      if (!fs.existsSync(item.tempPath)) {
        throw new Error(`Missing staged temp file for ${item.key}.`);
      }

      if (fs.existsSync(item.finalPath)) {
        fs.rmSync(item.finalPath, { force: true });
      }

      fs.renameSync(item.tempPath, item.finalPath);

      const finalRead = fs.readFileSync(item.finalPath, 'utf8');
      if (sha256(finalRead) !== item.sha256) {
        throw new Error(`Final verification failed for ${item.key}.`);
      }

      applied.push(item);

      if (simulateFailureAfter > 0 && index === simulateFailureAfter) {
        throw new Error('Simulated project import failure.');
      }
    }

    cleanupRollbackCopies(rollback);

    return Object.freeze({
      applied: true,
      projectId: staged.projectId,
      importId: staged.importId,
      files: Object.freeze(applied.map((item) => Object.freeze({
        key: item.key,
        filePath: item.finalPath,
        sha256: item.sha256,
        bytes: item.bytes,
      }))),
      rolledBack: false,
    });
  } catch (error) {
    rollbackAppliedImport(rollback, staged);

    return Object.freeze({
      applied: false,
      projectId: staged.projectId,
      importId: staged.importId,
      rolledBack: true,
      error: error.message,
    });
  }
}

function verifyImportedProjectFiles(pkg) {
  const entries = getWriteEntries(pkg);

  const checks = entries.map(([key, filePath, expected]) => {
    if (!fs.existsSync(filePath)) {
      return Object.freeze({ key, filePath, exists: false, valid: false });
    }

    try {
      const actual = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      return Object.freeze({
        key,
        filePath,
        exists: true,
        valid: sha256(actual) === sha256(expected),
      });
    } catch {
      return Object.freeze({ key, filePath, exists: true, valid: false });
    }
  });

  return Object.freeze({
    valid: checks.every((item) => item.valid),
    checks: Object.freeze(checks),
  });
}

function safeWriteProjectImport({ pkg, simulateFailureAfter = 0 } = {}) {
  const staged = stageProjectImport(pkg);
  const result = applyStagedImport({ staged, simulateFailureAfter });

  if (!result.applied) return result;

  const verification = verifyImportedProjectFiles(pkg);
  if (!verification.valid) {
    throw new Error('Imported project files failed final verification.');
  }

  return Object.freeze({ ...result, verification });
}

class DxfSafeProjectImportWriterService {
  stage(pkg) { return stageProjectImport(pkg); }
  apply(input) { return applyStagedImport(input); }
  verify(pkg) { return verifyImportedProjectFiles(pkg); }
  write(input) { return safeWriteProjectImport(input); }
}

module.exports = {
  text,
  ensureDir,
  stableStringify,
  sha256,
  resolveProjectFile,
  writeJsonVerified,
  getWriteEntries,
  stageProjectImport,
  createRollbackSnapshot,
  cleanupRollbackCopies,
  rollbackAppliedImport,
  applyStagedImport,
  verifyImportedProjectFiles,
  safeWriteProjectImport,
  DxfSafeProjectImportWriterService,
};
