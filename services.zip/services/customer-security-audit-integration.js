'use strict';

const CUSTOMER_ROLES = Object.freeze({
  ADMIN: 'ADMIN',
  SUPER_ADMIN: 'SUPER_ADMIN',
  OPERATOR: 'OPERATOR',
  VIEWER: 'VIEWER',
});

const CUSTOMER_ACTIONS = Object.freeze({
  CUSTOMER_CREATE: 'CUSTOMER_CREATE',
  CUSTOMER_UPDATE: 'CUSTOMER_UPDATE',
  CUSTOMER_VIEW: 'CUSTOMER_VIEW',
  CUSTOMER_DOCUMENT_ARCHIVE: 'CUSTOMER_DOCUMENT_ARCHIVE',
  CUSTOMER_STATEMENT_VIEW: 'CUSTOMER_STATEMENT_VIEW',
});

function text(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function upper(value) {
  return text(value).toUpperCase();
}

function normalizeRole(role) {
  const normalized = upper(role);
  if (!Object.values(CUSTOMER_ROLES).includes(normalized)) {
    throw new RangeError('Unsupported role.');
  }
  return normalized;
}

function normalizeAction(action) {
  const normalized = upper(action);
  if (!Object.values(CUSTOMER_ACTIONS).includes(normalized)) {
    throw new RangeError('Unsupported customer action.');
  }
  return normalized;
}

function canPerformCustomerAction(role, action) {
  const normalizedRole = normalizeRole(role);
  const normalizedAction = normalizeAction(action);

  const matrix = {
    SUPER_ADMIN: new Set(Object.values(CUSTOMER_ACTIONS)),
    ADMIN: new Set([
      CUSTOMER_ACTIONS.CUSTOMER_CREATE,
      CUSTOMER_ACTIONS.CUSTOMER_UPDATE,
      CUSTOMER_ACTIONS.CUSTOMER_VIEW,
      CUSTOMER_ACTIONS.CUSTOMER_DOCUMENT_ARCHIVE,
      CUSTOMER_ACTIONS.CUSTOMER_STATEMENT_VIEW,
    ]),
    OPERATOR: new Set([
      CUSTOMER_ACTIONS.CUSTOMER_CREATE,
      CUSTOMER_ACTIONS.CUSTOMER_UPDATE,
      CUSTOMER_ACTIONS.CUSTOMER_VIEW,
      CUSTOMER_ACTIONS.CUSTOMER_STATEMENT_VIEW,
    ]),
    VIEWER: new Set([
      CUSTOMER_ACTIONS.CUSTOMER_VIEW,
      CUSTOMER_ACTIONS.CUSTOMER_STATEMENT_VIEW,
    ]),
  };

  return matrix[normalizedRole].has(normalizedAction);
}

function assertCustomerPermission({ role, action }) {
  if (!canPerformCustomerAction(role, action)) {
    throw new Error(`Role ${upper(role)} is not allowed to perform ${upper(action)}.`);
  }
  return true;
}

function sanitizeCustomerSnapshot(customer = {}) {
  return Object.freeze({
    customerId: upper(customer.customerId || customer.id),
    customerName: text(customer.customerName || customer.name),
    mobile: text(customer.mobile || customer.customerMobile),
    email: text(customer.email),
    address: text(customer.address),
    status: upper(customer.status || 'ACTIVE'),
  });
}

function createCustomerAuditEvent({
  eventId,
  action,
  actorId,
  actorRole,
  customer,
  metadata = {},
  createdAt,
}) {
  const normalizedAction = normalizeAction(action);
  const normalizedRole = normalizeRole(actorRole);
  const cleanEventId = upper(eventId);
  const cleanActorId = upper(actorId);

  if (!cleanEventId) throw new Error('eventId is required.');
  if (!cleanActorId) throw new Error('actorId is required.');

  assertCustomerPermission({
    role: normalizedRole,
    action: normalizedAction,
  });

  const customerSnapshot = sanitizeCustomerSnapshot(customer);

  if (!customerSnapshot.customerId) {
    throw new Error('customerId is required for audit event.');
  }

  return Object.freeze({
    eventId: cleanEventId,
    action: normalizedAction,
    actorId: cleanActorId,
    actorRole: normalizedRole,
    customerId: customerSnapshot.customerId,
    customerSnapshot,
    metadata: Object.freeze({ ...(metadata || {}) }),
    createdAt: text(createdAt) || new Date().toISOString(),
  });
}

function ensureUniqueAuditEventId(eventId, existingEvents = []) {
  if (!Array.isArray(existingEvents)) {
    throw new TypeError('existingEvents must be an array.');
  }

  const normalized = upper(eventId);
  const duplicate = existingEvents.some(
    (event) => upper(event.eventId) === normalized
  );

  if (duplicate) {
    throw new Error('Duplicate audit eventId is not allowed.');
  }

  return true;
}

function buildCustomerAuditTrail({
  customerId,
  events = [],
}) {
  if (!Array.isArray(events)) {
    throw new TypeError('events must be an array.');
  }

  const normalizedCustomerId = upper(customerId);
  if (!normalizedCustomerId) throw new Error('customerId is required.');

  const rows = events
    .filter((event) => upper(event.customerId) === normalizedCustomerId)
    .slice()
    .sort((a, b) => {
      const aTime = text(a.createdAt);
      const bTime = text(b.createdAt);
      if (aTime === bTime) return upper(b.eventId).localeCompare(upper(a.eventId));
      return bTime.localeCompare(aTime);
    })
    .map((event) => Object.freeze({ ...event }));

  return Object.freeze(rows);
}

function validateCustomerUpdate({
  before,
  after,
  actorRole,
}) {
  const normalizedRole = normalizeRole(actorRole);

  if (!before || !after) {
    throw new TypeError('before and after customer records are required.');
  }

  const beforeId = upper(before.customerId || before.id);
  const afterId = upper(after.customerId || after.id);

  if (!beforeId || !afterId) {
    throw new Error('customerId is required.');
  }

  if (beforeId !== afterId) {
    throw new Error('customerId cannot be changed.');
  }

  assertCustomerPermission({
    role: normalizedRole,
    action: CUSTOMER_ACTIONS.CUSTOMER_UPDATE,
  });

  const protectedFields = ['customerId'];

  for (const field of protectedFields) {
    if (text(before[field]) !== text(after[field])) {
      throw new Error(`${field} cannot be modified.`);
    }
  }

  return true;
}

function validateDocumentArchivePermission({
  actorRole,
  document,
}) {
  assertCustomerPermission({
    role: actorRole,
    action: CUSTOMER_ACTIONS.CUSTOMER_DOCUMENT_ARCHIVE,
  });

  if (!document || typeof document !== 'object') {
    throw new TypeError('document is required.');
  }

  if (!upper(document.documentId)) {
    throw new Error('documentId is required.');
  }

  return true;
}

function buildSecuritySummary(events = []) {
  if (!Array.isArray(events)) {
    throw new TypeError('events must be an array.');
  }

  const counts = {};
  const actorCounts = {};

  for (const event of events) {
    const action = normalizeAction(event.action);
    counts[action] = (counts[action] || 0) + 1;

    const actorId = upper(event.actorId) || 'UNKNOWN';
    actorCounts[actorId] = (actorCounts[actorId] || 0) + 1;
  }

  return Object.freeze({
    eventCount: events.length,
    byAction: Object.freeze({ ...counts }),
    byActor: Object.freeze({ ...actorCounts }),
  });
}

class CustomerSecurityAuditIntegrationService {
  can(role, action) {
    return canPerformCustomerAction(role, action);
  }

  assertPermission(input) {
    return assertCustomerPermission(input);
  }

  createEvent(input) {
    return createCustomerAuditEvent(input);
  }

  ensureUnique(eventId, existingEvents) {
    return ensureUniqueAuditEventId(eventId, existingEvents);
  }

  trail(input) {
    return buildCustomerAuditTrail(input);
  }

  validateUpdate(input) {
    return validateCustomerUpdate(input);
  }

  validateDocumentArchive(input) {
    return validateDocumentArchivePermission(input);
  }

  summary(events) {
    return buildSecuritySummary(events);
  }
}

module.exports = {
  CUSTOMER_ROLES,
  CUSTOMER_ACTIONS,
  text,
  upper,
  normalizeRole,
  normalizeAction,
  canPerformCustomerAction,
  assertCustomerPermission,
  sanitizeCustomerSnapshot,
  createCustomerAuditEvent,
  ensureUniqueAuditEventId,
  buildCustomerAuditTrail,
  validateCustomerUpdate,
  validateDocumentArchivePermission,
  buildSecuritySummary,
  CustomerSecurityAuditIntegrationService,
};
