'use strict';

const assert = require('assert');

const {
  DOCUMENT_TYPES,
  DOCUMENT_STATUSES,
  normalizeDate,
  maskReference,
  createCustomerDocument,
  ensureUniqueDocument,
  archiveCustomerDocument,
  buildCustomerDocumentProfile,
  buildBookingDocumentPacket,
  CustomerDocumentIntegrationService,
} = require('./customer-document-integration');

(() => {
  console.log('Falcon Customer Document & ID Integration Tests');
  console.log('-----------------------------------------------');

  let assertions = 0;

  function check(actual, expected) {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  }

  function checkTrue(value) {
    assert.strictEqual(value, true);
    assertions += 1;
  }

  check(DOCUMENT_TYPES.AADHAAR, 'AADHAAR');
  check(DOCUMENT_STATUSES.ACTIVE, 'ACTIVE');
  check(normalizeDate('29-07-2026'), '2026-07-29');
  check(maskReference('AADHAAR', '1234 5678 9012'), 'XXXX-XXXX-9012');

  const photo = createCustomerDocument({
    documentId: 'DOC-000001',
    customerId: 'FC-000001',
    type: 'PHOTO',
    filePath: 'customers/FC-000001/photo.jpg',
    fileName: 'photo.jpg',
    mimeType: 'image/jpeg',
    uploadedBy: 'FU-000001',
    uploadedAt: '2026-07-29T10:00:00.000Z',
  });

  check(photo.documentId, 'DOC-000001');
  check(photo.customerId, 'FC-000001');
  check(photo.type, 'PHOTO');
  check(photo.status, 'ACTIVE');

  const aadhaar = createCustomerDocument({
    documentId: 'DOC-000002',
    customerId: 'FC-000001',
    type: 'AADHAAR',
    referenceNumber: '1234 5678 9012',
    filePath: 'customers/FC-000001/aadhaar.pdf',
    fileName: 'aadhaar.pdf',
    mimeType: 'application/pdf',
    issueDate: '01-01-2020',
    uploadedBy: 'FU-000001',
  });

  check(aadhaar.referenceNumber, '123456789012');
  check(aadhaar.maskedReference, 'XXXX-XXXX-9012');
  check(aadhaar.issueDate, '2020-01-01');

  const pan = createCustomerDocument({
    documentId: 'DOC-000003',
    customerId: 'FC-000001',
    type: 'PAN',
    referenceNumber: 'ABCDE1234F',
    filePath: 'customers/FC-000001/pan.pdf',
    uploadedBy: 'FU-000001',
  });

  check(pan.type, 'PAN');
  checkTrue(pan.maskedReference.endsWith('234F'));

  checkTrue(
    ensureUniqueDocument({
      document: pan,
      existingDocuments: [photo, aadhaar],
    })
  );

  assert.throws(
    () =>
      ensureUniqueDocument({
        document: aadhaar,
        existingDocuments: [aadhaar],
      }),
    /Duplicate documentId/
  );
  assertions += 1;

  const aadhaarCopy = createCustomerDocument({
    documentId: 'DOC-000004',
    customerId: 'FC-000001',
    type: 'AADHAAR',
    referenceNumber: '123456789012',
    filePath: 'customers/FC-000001/aadhaar-copy.pdf',
  });

  assert.throws(
    () =>
      ensureUniqueDocument({
        document: aadhaarCopy,
        existingDocuments: [aadhaar],
      }),
    /Duplicate active document reference/
  );
  assertions += 1;

  const archivedPan = archiveCustomerDocument({
    document: pan,
    actorId: 'FU-000001',
    reason: 'Old scanned copy',
    archivedAt: '2026-07-29T11:00:00.000Z',
  });

  check(archivedPan.status, 'ARCHIVED');
  check(archivedPan.archivedBy, 'FU-000001');
  check(archivedPan.archiveReason, 'Old scanned copy');

  const customer = {
    customerId: 'FC-000001',
    customerName: 'Shadab Aziz',
    mobile: '9876543210',
  };

  const bookings = [
    {
      bookingId: 'FB-000001',
      customerId: 'FC-000001',
      projectId: 'FP-000001',
      projectName: 'Jaipur Pride',
      plotNumber: '43',
      status: 'BOOKED',
    },
    {
      bookingId: 'FB-000002',
      customerId: 'FC-000001',
      projectId: 'FP-000002',
      projectName: 'Sawai Estate',
      plotNumber: '8',
      status: 'SOLD',
    },
  ];

  const profile = buildCustomerDocumentProfile({
    customer,
    documents: [photo, aadhaar, archivedPan],
    bookings,
  });

  check(profile.customerId, 'FC-000001');
  check(profile.summary.documentCount, 3);
  check(profile.summary.activeDocumentCount, 2);
  check(profile.summary.archivedDocumentCount, 1);
  check(profile.summary.idDocumentCount, 1);
  check(profile.summary.bookingCount, 2);
  check(profile.summary.hasPhoto, true);
  check(profile.summary.hasIdentityProof, true);
  check(profile.primaryPhoto.documentId, 'DOC-000001');
  check(profile.idDocuments[0].documentId, 'DOC-000002');

  const packet = buildBookingDocumentPacket({
    booking: bookings[0],
    customer,
    documents: [photo, aadhaar, archivedPan],
  });

  check(packet.bookingId, 'FB-000001');
  check(packet.customerId, 'FC-000001');
  check(packet.projectName, 'Jaipur Pride');
  check(packet.plotNumber, '43');
  check(packet.photo.documentId, 'DOC-000001');
  check(packet.identityDocuments.length, 1);
  check(packet.allActiveDocuments.length, 2);
  check(packet.documentStatus.hasPhoto, true);
  check(packet.documentStatus.hasIdentityProof, true);
  check(packet.documentStatus.readyForProfileDisplay, true);

  assert.throws(
    () =>
      buildBookingDocumentPacket({
        booking: {
          ...bookings[0],
          customerId: 'FC-999999',
        },
        customer,
        documents: [],
      }),
    /do not match/
  );
  assertions += 1;

  assert.throws(
    () =>
      createCustomerDocument({
        documentId: 'DOC-X1',
        customerId: 'FC-000001',
        type: 'PASSPORT',
        filePath: 'passport.pdf',
      }),
    /referenceNumber is required/
  );
  assertions += 1;

  assert.throws(
    () =>
      archiveCustomerDocument({
        document: archivedPan,
        actorId: 'FU-000001',
        reason: 'Again archive',
      }),
    /already archived/
  );
  assertions += 1;

  const service = new CustomerDocumentIntegrationService();

  const serviceProfile = service.profile({
    customer,
    documents: [photo, aadhaar],
    bookings,
  });

  check(serviceProfile.summary.activeDocumentCount, 2);

  const servicePacket = service.bookingPacket({
    booking: bookings[1],
    customer,
    documents: [photo, aadhaar],
  });

  check(servicePacket.bookingId, 'FB-000002');
  check(servicePacket.projectName, 'Sawai Estate');

  console.log('Document Type Validation: PASS');
  console.log('Customer Photo Integration: PASS');
  console.log('Identity Document Integration: PASS');
  console.log('Masked Reference Protection: PASS');
  console.log('Duplicate Document ID Protection: PASS');
  console.log('Duplicate Reference Protection: PASS');
  console.log('Document Archive Safety: PASS');
  console.log('Customer Document Profile: PASS');
  console.log('Booking Document Packet: PASS');
  console.log('Reusable Document Integration Service: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('-----------------------------------------------');
  console.log('CUSTOMER DOCUMENT & ID INTEGRATION TEST PASS');
})();
