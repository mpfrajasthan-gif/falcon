'use strict';

const assert = require('assert');

const {
  ACTIVE_BOOKING_STATUSES,
  BOOKABLE_PLOT_STATUSES,
  text,
  upper,
  finiteNumber,
  clone,
  BookingServiceError,
  BookingService,
} = require('./booking-service');

(async () => {
  console.log('Falcon Booking Service Tests');
  console.log('----------------------------');

  let assertions = 0;
  const check = (actual, expected) => {
    assert.deepStrictEqual(actual, expected);
    assertions += 1;
  };

  check(ACTIVE_BOOKING_STATUSES.includes('BOOKED'), true);
  check(ACTIVE_BOOKING_STATUSES.includes('SOLD'), true);
  check(BOOKABLE_PLOT_STATUSES, ['AVAILABLE']);
  check(text('  Falcon  '), 'Falcon');
  check(upper(' fp-000001 '), 'FP-000001');
  check(finiteNumber('1250', 'amount'), 1250);

  assert.throws(
    () => finiteNumber('bad', 'amount'),
    /valid number/
  );
  assertions += 1;

  const original = { nested: { value: 1 } };
  const copied = clone(original);
  copied.nested.value = 5;
  check(original.nested.value, 1);

  class FakeBookingRepository {
    constructor() {
      this.rows = [];
      this.sequence = 0;
      this.archives = [];
    }

    async create(input, context) {
      this.sequence += 1;
      const row = {
        ...input,
        bookingId: `FB-${String(this.sequence).padStart(6, '0')}`,
        bookingReference: `FBR-20260729-${String(this.sequence).padStart(4, '0')}`,
        createdBy: context.actorId,
        version: 1,
        isArchived: false,
      };
      this.rows.push(row);
      return clone(row);
    }

    async getById(id, options = {}) {
      const row = this.rows.find(
        (item) =>
          item.bookingId === id &&
          (options.includeArchived || !item.isArchived)
      );
      return row ? clone(row) : null;
    }

    async findActiveByPlot(projectId, plotId) {
      const row = this.rows.find(
        (item) =>
          !item.isArchived &&
          item.projectId === projectId &&
          item.plotId === plotId &&
          !['CANCELLED', 'REJECTED'].includes(item.status)
      );
      return row ? clone(row) : null;
    }

    async update(id, changes, context) {
      const index = this.rows.findIndex((item) => item.bookingId === id);
      if (index < 0) return null;
      this.rows[index] = {
        ...this.rows[index],
        ...changes,
        updatedBy: context.actorId,
        version: this.rows[index].version + 1,
      };
      return clone(this.rows[index]);
    }

    async archive(id, { actorId, reason }) {
      const index = this.rows.findIndex((item) => item.bookingId === id);
      if (index < 0) return null;
      this.rows[index] = {
        ...this.rows[index],
        isArchived: true,
        archivedBy: actorId,
        archiveReason: reason,
        version: this.rows[index].version + 1,
      };
      this.archives.push({ id, actorId, reason });
      return clone(this.rows[index]);
    }
  }

  const repository = new FakeBookingRepository();

  const plots = new Map([
    [
      'FPL-000001',
      {
        plotId: 'FPL-000001',
        projectId: 'FP-000001',
        status: 'AVAILABLE',
      },
    ],
    [
      'FPL-000002',
      {
        plotId: 'FPL-000002',
        projectId: 'FP-000001',
        status: 'HOLD',
      },
    ],
    [
      'FPL-000003',
      {
        plotId: 'FPL-000003',
        projectId: 'FP-000001',
        status: 'AVAILABLE',
      },
    ],
  ]);

  const plotService = {
    async getById(plotId) {
      return clone(plots.get(plotId) || null);
    },
  };

  const statusCalls = [];
  const plotStatusEngine = {
    async changeStatus(payload) {
      statusCalls.push(clone(payload));
      const plot = plots.get(payload.plotId);
      if (!plot) throw new Error('Plot missing');
      plot.status = payload.targetStatus;
      return clone(plot);
    },
  };

  const customers = new Map([
    [
      'FC-000001',
      {
        customerId: 'FC-000001',
        name: 'Customer One',
        mobile: '9999900001',
      },
    ],
  ]);

  const customerService = {
    async getById(customerId) {
      return clone(customers.get(customerId) || null);
    },
  };

  const audits = [];
  const auditService = {
    async record(eventType, payload) {
      audits.push({ eventType, payload: clone(payload) });
    },
  };

  const service = new BookingService({
    bookingRepository: repository,
    plotService,
    plotStatusEngine,
    customerService,
    auditService,
    clock: () => new Date('2026-07-29T10:00:00.000Z'),
  });

  const booking = await service.createBooking({
    projectId: 'fp-000001',
    plotId: 'fpl-000001',
    customerId: 'fc-000001',
    actorId: 'fu-000001',
    totalPrice: 500000,
    paidAmount: 125000,
    notes: 'Initial booking',
  });

  check(booking.bookingId, 'FB-000001');
  check(booking.projectId, 'FP-000001');
  check(booking.plotId, 'FPL-000001');
  check(booking.customerId, 'FC-000001');
  check(booking.customerName, 'Customer One');
  check(booking.customerMobile, '9999900001');
  check(booking.totalPrice, 500000);
  check(booking.paidAmount, 125000);
  check(booking.balanceAmount, 375000);
  check(booking.status, 'BOOKED');
  check(statusCalls.length, 1);
  check(statusCalls[0].targetStatus, 'BOOKED');
  check(plots.get('FPL-000001').status, 'BOOKED');
  check(audits[0].eventType, 'BOOKING_CREATED');

  const fetched = await service.getBooking('fb-000001');
  check(fetched.bookingReference, 'FBR-20260729-0001');

  await assert.rejects(
    () =>
      service.createBooking({
        projectId: 'FP-000001',
        plotId: 'FPL-000001',
        customerId: 'FC-000001',
        actorId: 'FU-000001',
        totalPrice: 500000,
        paidAmount: 100000,
      }),
    (error) =>
      error instanceof BookingServiceError &&
      error.code === 'PLOT_ALREADY_BOOKED'
  );
  assertions += 1;

  await assert.rejects(
    () =>
      service.createBooking({
        projectId: 'FP-000001',
        plotId: 'FPL-000002',
        customerId: 'FC-000001',
        actorId: 'FU-000001',
        totalPrice: 500000,
        paidAmount: 100000,
      }),
    (error) =>
      error instanceof BookingServiceError &&
      error.code === 'PLOT_NOT_AVAILABLE'
  );
  assertions += 1;

  await assert.rejects(
    () =>
      service.createBooking({
        projectId: 'FP-000001',
        plotId: 'FPL-999999',
        customerId: 'FC-000001',
        actorId: 'FU-000001',
        totalPrice: 500000,
        paidAmount: 100000,
      }),
    (error) =>
      error instanceof BookingServiceError &&
      error.code === 'PLOT_NOT_FOUND'
  );
  assertions += 1;

  await assert.rejects(
    () =>
      service.createBooking({
        projectId: 'FP-000001',
        plotId: 'FPL-000003',
        customerId: 'FC-999999',
        actorId: 'FU-000001',
        totalPrice: 500000,
        paidAmount: 100000,
      }),
    (error) =>
      error instanceof BookingServiceError &&
      error.code === 'CUSTOMER_NOT_FOUND'
  );
  assertions += 1;

  await assert.rejects(
    () =>
      service.createBooking({
        projectId: 'FP-000001',
        plotId: 'FPL-000003',
        customerId: 'FC-000001',
        actorId: 'FU-000001',
        totalPrice: 0,
        paidAmount: 0,
      }),
    (error) => error.code === 'INVALID_TOTAL_PRICE'
  );
  assertions += 1;

  await assert.rejects(
    () =>
      service.createBooking({
        projectId: 'FP-000001',
        plotId: 'FPL-000003',
        customerId: 'FC-000001',
        actorId: 'FU-000001',
        totalPrice: 100000,
        paidAmount: 100001,
      }),
    (error) => error.code === 'OVERPAYMENT_NOT_ALLOWED'
  );
  assertions += 1;

  const updated = await service.updateBookingDetails(
    'FB-000001',
    {
      customerName: 'Updated Customer',
      customerMobile: '8888800000',
      notes: 'Updated note',
    },
    { actorId: 'FU-000002' }
  );

  check(updated.customerName, 'Updated Customer');
  check(updated.customerMobile, '8888800000');
  check(updated.notes, 'Updated note');
  check(updated.updatedBy, 'FU-000002');
  check(updated.version, 2);
  check(audits[1].eventType, 'BOOKING_DETAILS_UPDATED');

  await assert.rejects(
    () =>
      service.updateBookingDetails(
        'FB-000001',
        { paidAmount: 400000 },
        { actorId: 'FU-000001' }
      ),
    (error) => error.code === 'PROTECTED_FIELDS'
  );
  assertions += 1;

  await assert.rejects(
    () =>
      service.cancelBooking('FB-000001', {
        actorId: 'FU-000001',
      }),
    (error) => error.code === 'CANCELLATION_REASON_REQUIRED'
  );
  assertions += 1;

  const cancelled = await service.cancelBooking('FB-000001', {
    actorId: 'FU-000001',
    reason: 'Customer requested cancellation',
  });

  check(cancelled.isArchived, true);
  check(cancelled.archiveReason, 'Customer requested cancellation');
  check(plots.get('FPL-000001').status, 'AVAILABLE');
  check(statusCalls[1].targetStatus, 'AVAILABLE');
  check(audits[2].eventType, 'BOOKING_CANCELLED');

  const soldRepo = new FakeBookingRepository();
  soldRepo.rows.push({
    bookingId: 'FB-000010',
    bookingReference: 'FBR-20260729-0010',
    projectId: 'FP-000001',
    plotId: 'FPL-000010',
    customerId: 'FC-000001',
    status: 'SOLD',
    isArchived: false,
    version: 1,
  });

  const soldService = new BookingService({
    bookingRepository: soldRepo,
    plotService,
    plotStatusEngine,
  });

  await assert.rejects(
    () =>
      soldService.cancelBooking('FB-000010', {
        actorId: 'FU-000001',
        reason: 'Try normal cancellation',
      }),
    (error) => error.code === 'SOLD_BOOKING_LOCKED'
  );
  assertions += 1;

  const rollbackRepo = new FakeBookingRepository();
  const rollbackService = new BookingService({
    bookingRepository: rollbackRepo,
    plotService: {
      async getById() {
        return {
          plotId: 'FPL-000020',
          projectId: 'FP-000002',
          status: 'AVAILABLE',
        };
      },
    },
    plotStatusEngine: {
      async changeStatus() {
        throw new Error('Status engine failed');
      },
    },
  });

  await assert.rejects(
    () =>
      rollbackService.createBooking({
        projectId: 'FP-000002',
        plotId: 'FPL-000020',
        customerId: 'FC-000020',
        actorId: 'FU-000001',
        totalPrice: 200000,
        paidAmount: 50000,
      }),
    (error) => error.code === 'BOOKING_CREATE_FAILED'
  );
  assertions += 1;

  check(rollbackRepo.rows.length, 1);
  check(rollbackRepo.rows[0].isArchived, true);
  check(
    rollbackRepo.rows[0].archiveReason,
    'Automatic rollback: plot status update failed'
  );

  assert.throws(
    () => new BookingService({}),
    /bookingRepository/
  );
  assertions += 1;

  assert.throws(
    () =>
      new BookingService({
        bookingRepository: repository,
      }),
    /plotService/
  );
  assertions += 1;

  assert.throws(
    () =>
      new BookingService({
        bookingRepository: repository,
        plotService,
      }),
    /plotStatusEngine/
  );
  assertions += 1;

  console.log('Dependency Contracts: PASS');
  console.log('Create Booking Workflow: PASS');
  console.log('Plot Availability Security: PASS');
  console.log('Duplicate Booking Block: PASS');
  console.log('Customer Verification: PASS');
  console.log('Amount Validation: PASS');
  console.log('Protected Field Security: PASS');
  console.log('Safe Detail Update: PASS');
  console.log('Cancellation Workflow: PASS');
  console.log('Sold Booking Lock: PASS');
  console.log('Automatic Rollback: PASS');
  console.log('Audit Integration: PASS');
  console.log(`Assertions Passed: ${assertions}`);
  console.log('----------------------------');
  console.log('BOOKING SERVICE TEST PASS');
})().catch((error) => {
  console.error('BOOKING SERVICE TEST FAIL');
  console.error(error.stack || error.message);
  process.exitCode = 1;
});
