'use strict';

const assert = require('assert');

const {
  MigrationRunner,
  sortAndValidateMigrations,
  validateMigration,
} = require('./migration-runner');

const {
  FalconError,
} = require('../../core/errors/falcon-error');

function createFakeDatabase(
  initiallyAppliedVersions = []
) {
  const state = {
    appliedVersions: new Set(
      initiallyAppliedVersions
    ),
    statements: [],
    transactions: 0,
  };

  return {
    state,

    execute(sql, parameters = []) {
      state.statements.push({
        sql,
        parameters,
      });

      if (
        sql.includes(
          'INSERT INTO schema_migrations'
        )
      ) {
        state.appliedVersions.add(
          parameters[0]
        );
      }

      return {
        changes: 1,
      };
    },

    queryAll(sql) {
      state.statements.push({
        sql,
        parameters: [],
      });

      return [...state.appliedVersions]
        .sort((first, second) => first - second)
        .map((version) => ({
          version,
        }));
    },

    transaction(work) {
      state.transactions += 1;
      return work(this);
    },
  };
}

function runMigrationRunnerTests() {
  console.log('Falcon Migration Runner Tests');
  console.log('-----------------------------');

  const migrationOne = {
    version: 1,
    name: 'Create projects table',

    up(database) {
      database.execute(
        'CREATE TABLE projects (id TEXT PRIMARY KEY);'
      );
    },
  };

  const migrationTwo = {
    version: 2,
    name: 'Create plots table',

    up(database) {
      database.execute(
        'CREATE TABLE plots (id TEXT PRIMARY KEY);'
      );
    },
  };

  assert.strictEqual(
    validateMigration(migrationOne),
    migrationOne
  );

  assert.throws(
    () => validateMigration(null),
    TypeError
  );

  assert.throws(
    () =>
      validateMigration({
        version: 0,
        name: 'Invalid',
        up() {},
      }),
    TypeError
  );

  assert.throws(
    () =>
      validateMigration({
        version: 1,
        name: '',
        up() {},
      }),
    TypeError
  );

  assert.throws(
    () =>
      validateMigration({
        version: 1,
        name: 'Invalid',
      }),
    TypeError
  );

  const sorted =
    sortAndValidateMigrations([
      migrationTwo,
      migrationOne,
    ]);

  assert.strictEqual(sorted[0].version, 1);
  assert.strictEqual(sorted[1].version, 2);

  assert.throws(
    () =>
      sortAndValidateMigrations([
        migrationOne,
        {
          ...migrationTwo,
          version: 1,
        },
      ]),
    (error) =>
      error instanceof FalconError &&
      error.code ===
        'DUPLICATE_MIGRATION_VERSION'
  );

  const database = createFakeDatabase([1]);

  const runner = new MigrationRunner(
    database,
    [
      migrationTwo,
      migrationOne,
    ]
  );

  const pending =
    runner.getPendingMigrations();

  assert.strictEqual(pending.length, 1);
  assert.strictEqual(pending[0].version, 2);

  const result = runner.runPending();

  assert.strictEqual(result.appliedCount, 1);
  assert.strictEqual(result.applied.length, 1);
  assert.strictEqual(
    result.applied[0].version,
    2
  );

  assert.strictEqual(
    Object.isFrozen(result),
    true
  );

  assert.strictEqual(
    Object.isFrozen(result.applied),
    true
  );

  assert.strictEqual(
    database.state.appliedVersions.has(2),
    true
  );

  assert.strictEqual(
    database.state.transactions,
    1
  );

  const secondRun = runner.runPending();

  assert.strictEqual(
    secondRun.appliedCount,
    0,
    'Applied migrations must not run again.'
  );

  assert.throws(
    () => new MigrationRunner(null, []),
    TypeError
  );

  assert.throws(
    () => new MigrationRunner(database, null),
    TypeError
  );

  console.log(
    'Applied Migration:',
    result.applied[0].version
  );
  console.log(
    'Transactions:',
    database.state.transactions
  );
  console.log('Assertions Passed: 19');
  console.log('-----------------------------');
  console.log('MIGRATION RUNNER TEST PASS');
}

try {
  runMigrationRunnerTests();
} catch (testError) {
  console.error(
    'MIGRATION RUNNER TEST FAIL'
  );
  console.error(testError.message);
  process.exitCode = 1;
}