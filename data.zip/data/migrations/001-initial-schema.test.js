'use strict';

const assert = require('assert');

const {
  INITIAL_SCHEMA_SQL,
  initialSchemaMigration,
} = require('./001-initial-schema');

function createFakeDatabase() {
  const state = {
    statements: [],
  };

  return {
    state,

    execute(sql, parameters = []) {
      state.statements.push({
        sql,
        parameters,
      });

      return {
        changes: 0,
      };
    },
  };
}

function runInitialSchemaTests() {
  console.log('Falcon Initial Schema Tests');
  console.log('---------------------------');

  assert.strictEqual(
    initialSchemaMigration.version,
    1
  );

  assert.strictEqual(
    initialSchemaMigration.name,
    'Create initial Falcon schema'
  );

  assert.strictEqual(
    typeof initialSchemaMigration.up,
    'function'
  );

  assert.strictEqual(
    Object.isFrozen(initialSchemaMigration),
    true
  );

  const expectedTables = [
    'projects',
    'plots',
    'customers',
    'bookings',
    'payments',
  ];

  for (const tableName of expectedTables) {
    assert.ok(
      INITIAL_SCHEMA_SQL.includes(
        `CREATE TABLE IF NOT EXISTS ${tableName}`
      ),
      `Missing table definition: ${tableName}`
    );
  }

  assert.ok(
    INITIAL_SCHEMA_SQL.includes(
      'FOREIGN KEY (project_id)'
    )
  );

  assert.ok(
    INITIAL_SCHEMA_SQL.includes(
      'FOREIGN KEY (plot_id)'
    )
  );

  assert.ok(
    INITIAL_SCHEMA_SQL.includes(
      'FOREIGN KEY (customer_id)'
    )
  );

  assert.ok(
    INITIAL_SCHEMA_SQL.includes(
      'FOREIGN KEY (booking_id)'
    )
  );

  assert.ok(
    INITIAL_SCHEMA_SQL.includes(
      'UNIQUE (project_id, plot_number)'
    )
  );

  assert.ok(
    INITIAL_SCHEMA_SQL.includes(
      'status TEXT NOT NULL DEFAULT \'AVAILABLE\''
    )
  );

  assert.ok(
    INITIAL_SCHEMA_SQL.includes(
      'status TEXT NOT NULL DEFAULT \'BOOKED\''
    )
  );

  const database = createFakeDatabase();

  initialSchemaMigration.up(database);

  assert.strictEqual(
    database.state.statements.length,
    1
  );

  assert.strictEqual(
    database.state.statements[0].sql,
    INITIAL_SCHEMA_SQL
  );

  assert.deepStrictEqual(
    database.state.statements[0].parameters,
    []
  );

  const indexNames = [
    'idx_plots_project_id',
    'idx_plots_status',
    'idx_customers_mobile',
    'idx_bookings_project_id',
    'idx_bookings_plot_id',
    'idx_bookings_customer_id',
    'idx_bookings_status',
    'idx_payments_booking_id',
  ];

  for (const indexName of indexNames) {
    assert.ok(
      INITIAL_SCHEMA_SQL.includes(indexName),
      `Missing database index: ${indexName}`
    );
  }

  console.log(
    'Schema Tables:',
    expectedTables.length
  );
  console.log(
    'Schema Indexes:',
    indexNames.length
  );
  console.log('Assertions Passed: 26');
  console.log('---------------------------');
  console.log('INITIAL SCHEMA TEST PASS');
}

try {
  runInitialSchemaTests();
} catch (testError) {
  console.error('INITIAL SCHEMA TEST FAIL');
  console.error(testError.message);
  process.exitCode = 1;
}