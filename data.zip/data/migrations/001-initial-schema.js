'use strict';

const INITIAL_SCHEMA_SQL = `
  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    uuid TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    location TEXT,
    address TEXT,
    rera_number TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS plots (
    id TEXT PRIMARY KEY,
    uuid TEXT NOT NULL UNIQUE,
    project_id TEXT NOT NULL,
    plot_number TEXT NOT NULL,
    category TEXT NOT NULL,
    area_sq_yd REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'AVAILABLE',
    rate_per_sq_yd REAL NOT NULL DEFAULT 0,
    total_price REAL NOT NULL DEFAULT 0,
    geometry_json TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,

    FOREIGN KEY (project_id)
      REFERENCES projects(id)
      ON UPDATE CASCADE
      ON DELETE RESTRICT,

    UNIQUE (project_id, plot_number)
  );

  CREATE TABLE IF NOT EXISTS customers (
    id TEXT PRIMARY KEY,
    uuid TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    mobile TEXT NOT NULL,
    address TEXT,
    date_of_birth TEXT,
    photo_path TEXT,
    identity_document_path TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS bookings (
    id TEXT PRIMARY KEY,
    uuid TEXT NOT NULL UNIQUE,
    project_id TEXT NOT NULL,
    plot_id TEXT NOT NULL,
    customer_id TEXT NOT NULL,
    booking_date TEXT NOT NULL,
    rate_per_sq_yd REAL NOT NULL,
    base_amount REAL NOT NULL,
    admin_charges REAL NOT NULL DEFAULT 0,
    discount_amount REAL NOT NULL DEFAULT 0,
    grand_total REAL NOT NULL,
    paid_amount REAL NOT NULL DEFAULT 0,
    balance_amount REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'BOOKED',
    notes TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,

    FOREIGN KEY (project_id)
      REFERENCES projects(id)
      ON UPDATE CASCADE
      ON DELETE RESTRICT,

    FOREIGN KEY (plot_id)
      REFERENCES plots(id)
      ON UPDATE CASCADE
      ON DELETE RESTRICT,

    FOREIGN KEY (customer_id)
      REFERENCES customers(id)
      ON UPDATE CASCADE
      ON DELETE RESTRICT
  );

  CREATE TABLE IF NOT EXISTS payments (
    id TEXT PRIMARY KEY,
    uuid TEXT NOT NULL UNIQUE,
    booking_id TEXT NOT NULL,
    payment_date TEXT NOT NULL,
    amount REAL NOT NULL,
    payment_mode TEXT NOT NULL,
    reference_number TEXT,
    receipt_number TEXT,
    notes TEXT,
    created_at TEXT NOT NULL,

    FOREIGN KEY (booking_id)
      REFERENCES bookings(id)
      ON UPDATE CASCADE
      ON DELETE RESTRICT
  );

  CREATE INDEX IF NOT EXISTS idx_plots_project_id
    ON plots(project_id);

  CREATE INDEX IF NOT EXISTS idx_plots_status
    ON plots(status);

  CREATE INDEX IF NOT EXISTS idx_customers_mobile
    ON customers(mobile);

  CREATE INDEX IF NOT EXISTS idx_bookings_project_id
    ON bookings(project_id);

  CREATE INDEX IF NOT EXISTS idx_bookings_plot_id
    ON bookings(plot_id);

  CREATE INDEX IF NOT EXISTS idx_bookings_customer_id
    ON bookings(customer_id);

  CREATE INDEX IF NOT EXISTS idx_bookings_status
    ON bookings(status);

  CREATE INDEX IF NOT EXISTS idx_payments_booking_id
    ON payments(booking_id);
`;

const initialSchemaMigration = Object.freeze({
  version: 1,
  name: 'Create initial Falcon schema',

  up(database) {
    database.execute(INITIAL_SCHEMA_SQL);
  },
});

module.exports = {
  INITIAL_SCHEMA_SQL,
  initialSchemaMigration,
};