'use strict';

const {
  initialSchemaMigration,
} = require('./001-initial-schema');

const MIGRATIONS = Object.freeze([
  initialSchemaMigration,
]);

function getMigrations() {
  return [...MIGRATIONS];
}

function getLatestMigrationVersion() {
  if (MIGRATIONS.length === 0) {
    return 0;
  }

  return Math.max(
    ...MIGRATIONS.map(
      (migration) => migration.version
    )
  );
}

function getMigrationByVersion(version) {
  if (
    !Number.isSafeInteger(version) ||
    version <= 0
  ) {
    throw new TypeError(
      'Migration version must be a positive safe integer.'
    );
  }

  return (
    MIGRATIONS.find(
      (migration) =>
        migration.version === version
    ) ?? null
  );
}

module.exports = {
  MIGRATIONS,
  getLatestMigrationVersion,
  getMigrationByVersion,
  getMigrations,
};