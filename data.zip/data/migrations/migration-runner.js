'use strict';

const {
  createFalconError,
} = require('../../core/errors/falcon-error');

const MIGRATION_TABLE_SQL = `
  CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    applied_at TEXT NOT NULL
  );
`;

function validateMigration(migration) {
  if (!migration || typeof migration !== 'object') {
    throw new TypeError('Migration must be an object.');
  }

  if (
    !Number.isSafeInteger(migration.version) ||
    migration.version <= 0
  ) {
    throw new TypeError(
      'Migration version must be a positive safe integer.'
    );
  }

  if (
    typeof migration.name !== 'string' ||
    migration.name.trim() === ''
  ) {
    throw new TypeError(
      'Migration name must be a non-empty string.'
    );
  }

  if (typeof migration.up !== 'function') {
    throw new TypeError(
      'Migration up handler must be a function.'
    );
  }

  return migration;
}

function sortAndValidateMigrations(migrations) {
  if (!Array.isArray(migrations)) {
    throw new TypeError('Migrations must be an array.');
  }

  const validated = migrations.map(validateMigration);
  const versions = new Set();

  for (const migration of validated) {
    if (versions.has(migration.version)) {
      throw createFalconError(
        'DUPLICATE_MIGRATION_VERSION',
        `Migration version ${migration.version} is duplicated.`,
        {
          version: migration.version,
        }
      );
    }

    versions.add(migration.version);
  }

  return [...validated].sort(
    (first, second) => first.version - second.version
  );
}

class MigrationRunner {
  constructor(database, migrations = []) {
    if (
      !database ||
      typeof database.execute !== 'function' ||
      typeof database.queryAll !== 'function' ||
      typeof database.transaction !== 'function'
    ) {
      throw new TypeError(
        'A valid Falcon database adapter is required.'
      );
    }

    this.database = database;
    this.migrations = sortAndValidateMigrations(
      migrations
    );
  }

  ensureMigrationTable() {
    this.database.execute(MIGRATION_TABLE_SQL);
  }

  getAppliedVersions() {
    this.ensureMigrationTable();

    const rows = this.database.queryAll(
      `
        SELECT version
        FROM schema_migrations
        ORDER BY version ASC;
      `
    );

    return new Set(
      rows
        .map((row) => Number(row.version))
        .filter(
          (version) =>
            Number.isSafeInteger(version) &&
            version > 0
        )
    );
  }

  getPendingMigrations() {
    const appliedVersions =
      this.getAppliedVersions();

    return this.migrations.filter(
      (migration) =>
        !appliedVersions.has(migration.version)
    );
  }

  runPending() {
    const pendingMigrations =
      this.getPendingMigrations();

    const applied = [];

    for (const migration of pendingMigrations) {
      this.database.transaction((database) => {
        migration.up(database);

        database.execute(
          `
            INSERT INTO schema_migrations
              (version, name, applied_at)
            VALUES (?, ?, ?);
          `,
          [
            migration.version,
            migration.name.trim(),
            new Date().toISOString(),
          ]
        );
      });

      applied.push(
        Object.freeze({
          version: migration.version,
          name: migration.name.trim(),
        })
      );
    }

    return Object.freeze({
      applied: Object.freeze(applied),
      appliedCount: applied.length,
    });
  }
}

module.exports = {
  MIGRATION_TABLE_SQL,
  MigrationRunner,
  sortAndValidateMigrations,
  validateMigration,
};