'use strict';

const assert = require('assert');

const {
  MIGRATIONS,
  getLatestMigrationVersion,
  getMigrationByVersion,
  getMigrations,
} = require('./index');

function runMigrationRegistryTests() {
  console.log('Falcon Migration Registry Tests');
  console.log('-------------------------------');

  assert.strictEqual(
    Array.isArray(MIGRATIONS),
    true
  );

  assert.strictEqual(
    Object.isFrozen(MIGRATIONS),
    true
  );

  assert.strictEqual(
    MIGRATIONS.length,
    1
  );

  assert.strictEqual(
    MIGRATIONS[0].version,
    1
  );

  assert.strictEqual(
    MIGRATIONS[0].name,
    'Create initial Falcon schema'
  );

  assert.strictEqual(
    typeof MIGRATIONS[0].up,
    'function'
  );

  const migrationsCopy = getMigrations();

  assert.strictEqual(
    Array.isArray(migrationsCopy),
    true
  );

  assert.notStrictEqual(
    migrationsCopy,
    MIGRATIONS,
    'Registry must return a defensive array copy.'
  );

  assert.strictEqual(
    migrationsCopy.length,
    MIGRATIONS.length
  );

  migrationsCopy.push({
    version: 999,
    name: 'Temporary test migration',
    up() {},
  });

  assert.strictEqual(
    MIGRATIONS.length,
    1,
    'External changes must not modify the registry.'
  );

  assert.strictEqual(
    getLatestMigrationVersion(),
    1
  );

  const migrationOne =
    getMigrationByVersion(1);

  assert.strictEqual(
    migrationOne,
    MIGRATIONS[0]
  );

  assert.strictEqual(
    getMigrationByVersion(2),
    null
  );

  assert.throws(
    () => getMigrationByVersion(0),
    TypeError
  );

  assert.throws(
    () => getMigrationByVersion(-1),
    TypeError
  );

  assert.throws(
    () => getMigrationByVersion('1'),
    TypeError
  );

  const versions = MIGRATIONS.map(
    (migration) => migration.version
  );

  const uniqueVersions = new Set(versions);

  assert.strictEqual(
    uniqueVersions.size,
    versions.length,
    'Registered migration versions must be unique.'
  );

  const sortedVersions = [...versions].sort(
    (first, second) => first - second
  );

  assert.deepStrictEqual(
    versions,
    sortedVersions,
    'Migrations must be registered in version order.'
  );

  console.log(
    'Registered Migrations:',
    MIGRATIONS.length
  );

  console.log(
    'Latest Version:',
    getLatestMigrationVersion()
  );

  console.log('Assertions Passed: 18');
  console.log('-------------------------------');
  console.log('MIGRATION REGISTRY TEST PASS');
}

try {
  runMigrationRegistryTests();
} catch (testError) {
  console.error(
    'MIGRATION REGISTRY TEST FAIL'
  );
  console.error(testError.message);
  process.exitCode = 1;
}