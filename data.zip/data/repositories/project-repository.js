'use strict';

const {
  BaseRepository,
} = require('./base-repository');

const {
  createFalconError,
} = require('../../core/errors/falcon-error');

class ProjectRepository extends BaseRepository {
  constructor(database) {
    super('Project');

    if (
      !database ||
      typeof database.execute !== 'function' ||
      typeof database.queryOne !== 'function' ||
      typeof database.queryAll !== 'function'
    ) {
      throw new TypeError(
        'A valid Falcon database adapter is required.'
      );
    }

    this.database = database;
  }

  create(project) {
    this.validateProject(project);

    this.database.execute(
      `
        INSERT INTO projects (
          id,
          uuid,
          name,
          location,
          address,
          rera_number,
          status,
          created_at,
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
      `,
      [
        project.id,
        project.uuid,
        project.name.trim(),
        project.location ?? null,
        project.address ?? null,
        project.reraNumber ?? null,
        project.status ?? 'ACTIVE',
        project.createdAt,
        project.updatedAt,
      ]
    );

    return this.findById(project.id);
  }

  findById(id) {
    this.validateId(id);

    const row = this.database.queryOne(
      `
        SELECT
          id,
          uuid,
          name,
          location,
          address,
          rera_number,
          status,
          created_at,
          updated_at
        FROM projects
        WHERE id = ?;
      `,
      [id.trim()]
    );

    return row ? this.mapRow(row) : null;
  }

  findAll() {
    const rows = this.database.queryAll(
      `
        SELECT
          id,
          uuid,
          name,
          location,
          address,
          rera_number,
          status,
          created_at,
          updated_at
        FROM projects
        ORDER BY name ASC;
      `
    );

    return rows.map((row) => this.mapRow(row));
  }

  update(id, changes) {
    this.validateId(id);

    if (!changes || typeof changes !== 'object') {
      throw new TypeError(
        'Project changes must be an object.'
      );
    }

    const existing = this.findById(id);

    if (!existing) {
      throw createFalconError(
        'PROJECT_NOT_FOUND',
        'Falcon project was not found.',
        {
          projectId: id.trim(),
        }
      );
    }

    const updatedProject = {
      ...existing,
      ...changes,
      id: existing.id,
      uuid: existing.uuid,
      createdAt: existing.createdAt,
    };

    if (
      typeof updatedProject.name !== 'string' ||
      updatedProject.name.trim() === ''
    ) {
      throw new TypeError(
        'Project name must be a non-empty string.'
      );
    }

    this.database.execute(
      `
        UPDATE projects
        SET
          name = ?,
          location = ?,
          address = ?,
          rera_number = ?,
          status = ?,
          updated_at = ?
        WHERE id = ?;
      `,
      [
        updatedProject.name.trim(),
        updatedProject.location ?? null,
        updatedProject.address ?? null,
        updatedProject.reraNumber ?? null,
        updatedProject.status ?? 'ACTIVE',
        updatedProject.updatedAt,
        id.trim(),
      ]
    );

    return this.findById(id);
  }

  delete(id) {
    this.validateId(id);

    const result = this.database.execute(
      `
        DELETE FROM projects
        WHERE id = ?;
      `,
      [id.trim()]
    );

    return Boolean(
      result &&
      Number(result.changes) > 0
    );
  }

  exists(id) {
    this.validateId(id);

    const row = this.database.queryOne(
      `
        SELECT 1 AS found
        FROM projects
        WHERE id = ?
        LIMIT 1;
      `,
      [id.trim()]
    );

    return row !== null;
  }

  validateId(id) {
    if (
      typeof id !== 'string' ||
      id.trim() === ''
    ) {
      throw new TypeError(
        'Project ID must be a non-empty string.'
      );
    }
  }

  validateProject(project) {
    if (!project || typeof project !== 'object') {
      throw new TypeError(
        'Project must be an object.'
      );
    }

    this.validateId(project.id);

    if (
      typeof project.uuid !== 'string' ||
      project.uuid.trim() === ''
    ) {
      throw new TypeError(
        'Project UUID must be a non-empty string.'
      );
    }

    if (
      typeof project.name !== 'string' ||
      project.name.trim() === ''
    ) {
      throw new TypeError(
        'Project name must be a non-empty string.'
      );
    }

    if (
      typeof project.createdAt !== 'string' ||
      project.createdAt.trim() === ''
    ) {
      throw new TypeError(
        'Project createdAt is required.'
      );
    }

    if (
      typeof project.updatedAt !== 'string' ||
      project.updatedAt.trim() === ''
    ) {
      throw new TypeError(
        'Project updatedAt is required.'
      );
    }
  }

  mapRow(row) {
    return Object.freeze({
      id: row.id,
      uuid: row.uuid,
      name: row.name,
      location: row.location,
      address: row.address,
      reraNumber: row.rera_number,
      status: row.status,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    });
  }
}

module.exports = {
  ProjectRepository,
};