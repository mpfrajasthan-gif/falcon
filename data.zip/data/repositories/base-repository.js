'use strict';

const {
  createFalconError,
} = require('../../core/errors/falcon-error');

class BaseRepository {
  constructor(entityName) {
    if (
      typeof entityName !== 'string' ||
      entityName.trim() === ''
    ) {
      throw new TypeError(
        'Repository entity name must be a non-empty string.'
      );
    }

    this.entityName = entityName.trim();
  }

  async create() {
    throw this.createNotImplementedError('create');
  }

  async findById() {
    throw this.createNotImplementedError('findById');
  }

  async findAll() {
    throw this.createNotImplementedError('findAll');
  }

  async update() {
    throw this.createNotImplementedError('update');
  }

  async delete() {
    throw this.createNotImplementedError('delete');
  }

  async exists() {
    throw this.createNotImplementedError('exists');
  }

  createNotImplementedError(methodName) {
    return createFalconError(
      'REPOSITORY_METHOD_NOT_IMPLEMENTED',
      `${this.entityName} repository method "${methodName}" is not implemented.`,
      {
        entityName: this.entityName,
        methodName,
      }
    );
  }
}

module.exports = {
  BaseRepository,
};