'use strict';

const {
  BaseRepository,
} = require('./base-repository');

const {
  createFalconError,
} = require('../../core/errors/falcon-error');

const PLOT_STATUSES = Object.freeze([
  'AVAILABLE',
  'HOLD',
  'BOOKED',
  'SOLD',
]);

class PlotRepository extends BaseRepository {
  constructor(database) {
    super('Plot');

    if (
      !database ||
      typeof database.execute !== 'function' ||
      typeof database.queryOne !== 'function' ||
      typeof database.queryAll !== 'function'
    ) {
      throw new TypeError(
        'A valid Falcon database adapter is required.'
      );
    }

    this.database = database;
  }

  create(plot) {
    this.validatePlot(plot);

    this.database.execute(
      `
        INSERT INTO plots (
          id,
          uuid,
          project_id,
          plot_number,
          category,
          area_sq_yd,
          status,
          rate_per_sq_yd,
          total_price,
          geometry_json,
          created_at,
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
      `,
      [
        plot.id.trim(),
        plot.uuid.trim(),
        plot.projectId.trim(),
        plot.plotNumber.trim(),
        plot.category.trim(),
        Number(plot.areaSqYd),
        plot.status.trim().toUpperCase(),
        Number(plot.ratePerSqYd ?? 0),
        Number(plot.totalPrice ?? 0),
        plot.geometryJson ?? null,
        plot.createdAt,
        plot.updatedAt,
      ]
    );

    return this.findById(plot.id);
  }

  findById(id) {
    this.validateId(id);

    const row = this.database.queryOne(
      `
        SELECT
          id,
          uuid,
          project_id,
          plot_number,
          category,
          area_sq_yd,
          status,
          rate_per_sq_yd,
          total_price,
          geometry_json,
          created_at,
          updated_at
        FROM plots
        WHERE id = ?;
      `,
      [id.trim()]
    );

    return row ? this.mapRow(row) : null;
  }

  findByProjectAndNumber(projectId, plotNumber) {
    this.validateProjectId(projectId);
    this.validatePlotNumber(plotNumber);

    const row = this.database.queryOne(
      `
        SELECT
          id,
          uuid,
          project_id,
          plot_number,
          category,
          area_sq_yd,
          status,
          rate_per_sq_yd,
          total_price,
          geometry_json,
          created_at,
          updated_at
        FROM plots
        WHERE project_id = ?
          AND plot_number = ?
        LIMIT 1;
      `,
      [projectId.trim(), plotNumber.trim()]
    );

    return row ? this.mapRow(row) : null;
  }

  findAll() {
    const rows = this.database.queryAll(
      `
        SELECT
          id,
          uuid,
          project_id,
          plot_number,
          category,
          area_sq_yd,
          status,
          rate_per_sq_yd,
          total_price,
          geometry_json,
          created_at,
          updated_at
        FROM plots
        ORDER BY project_id ASC, plot_number ASC, id ASC;
      `
    );

    return rows.map((row) => this.mapRow(row));
  }

  findByProjectId(projectId) {
    this.validateProjectId(projectId);

    const rows = this.database.queryAll(
      `
        SELECT
          id,
          uuid,
          project_id,
          plot_number,
          category,
          area_sq_yd,
          status,
          rate_per_sq_yd,
          total_price,
          geometry_json,
          created_at,
          updated_at
        FROM plots
        WHERE project_id = ?
        ORDER BY plot_number ASC, id ASC;
      `,
      [projectId.trim()]
    );

    return rows.map((row) => this.mapRow(row));
  }

  findByStatus(status, projectId = null) {
    this.validateStatus(status);

    let rows;

    if (projectId === null) {
      rows = this.database.queryAll(
        `
          SELECT
            id,
            uuid,
            project_id,
            plot_number,
            category,
            area_sq_yd,
            status,
            rate_per_sq_yd,
            total_price,
            geometry_json,
            created_at,
            updated_at
          FROM plots
          WHERE status = ?
          ORDER BY project_id ASC, plot_number ASC, id ASC;
        `,
        [status.trim().toUpperCase()]
      );
    } else {
      this.validateProjectId(projectId);

      rows = this.database.queryAll(
        `
          SELECT
            id,
            uuid,
            project_id,
            plot_number,
            category,
            area_sq_yd,
            status,
            rate_per_sq_yd,
            total_price,
            geometry_json,
            created_at,
            updated_at
          FROM plots
          WHERE status = ?
            AND project_id = ?
          ORDER BY plot_number ASC, id ASC;
        `,
        [
          status.trim().toUpperCase(),
          projectId.trim(),
        ]
      );
    }

    return rows.map((row) => this.mapRow(row));
  }

  search(keyword, projectId = null) {
    if (projectId !== null) {
      this.validateProjectId(projectId);
    }

    if (
      typeof keyword !== 'string' ||
      keyword.trim() === ''
    ) {
      return projectId === null
        ? this.findAll()
        : this.findByProjectId(projectId);
    }

    const searchValue = `%${keyword.trim()}%`;
    let rows;

    if (projectId === null) {
      rows = this.database.queryAll(
        `
          SELECT
            id,
            uuid,
            project_id,
            plot_number,
            category,
            area_sq_yd,
            status,
            rate_per_sq_yd,
            total_price,
            geometry_json,
            created_at,
            updated_at
          FROM plots
          WHERE
            id LIKE ?
            OR plot_number LIKE ?
            OR category LIKE ?
            OR status LIKE ?
          ORDER BY project_id ASC, plot_number ASC, id ASC;
        `,
        [
          searchValue,
          searchValue,
          searchValue,
          searchValue,
        ]
      );
    } else {
      rows = this.database.queryAll(
        `
          SELECT
            id,
            uuid,
            project_id,
            plot_number,
            category,
            area_sq_yd,
            status,
            rate_per_sq_yd,
            total_price,
            geometry_json,
            created_at,
            updated_at
          FROM plots
          WHERE project_id = ?
            AND (
              id LIKE ?
              OR plot_number LIKE ?
              OR category LIKE ?
              OR status LIKE ?
            )
          ORDER BY plot_number ASC, id ASC;
        `,
        [
          projectId.trim(),
          searchValue,
          searchValue,
          searchValue,
          searchValue,
        ]
      );
    }

    return rows.map((row) => this.mapRow(row));
  }

  update(id, changes) {
    this.validateId(id);

    if (!changes || typeof changes !== 'object') {
      throw new TypeError(
        'Plot changes must be an object.'
      );
    }

    const existing = this.findById(id);

    if (!existing) {
      throw createFalconError(
        'PLOT_NOT_FOUND',
        'Falcon plot was not found.',
        { plotId: id.trim() }
      );
    }

    const updatedPlot = {
      ...existing,
      ...changes,
      id: existing.id,
      uuid: existing.uuid,
      projectId: existing.projectId,
      createdAt: existing.createdAt,
    };

    this.validatePlot(updatedPlot);

    this.database.execute(
      `
        UPDATE plots
        SET
          plot_number = ?,
          category = ?,
          area_sq_yd = ?,
          status = ?,
          rate_per_sq_yd = ?,
          total_price = ?,
          geometry_json = ?,
          updated_at = ?
        WHERE id = ?;
      `,
      [
        updatedPlot.plotNumber.trim(),
        updatedPlot.category.trim(),
        Number(updatedPlot.areaSqYd),
        updatedPlot.status.trim().toUpperCase(),
        Number(updatedPlot.ratePerSqYd ?? 0),
        Number(updatedPlot.totalPrice ?? 0),
        updatedPlot.geometryJson ?? null,
        updatedPlot.updatedAt,
        id.trim(),
      ]
    );

    return this.findById(id);
  }

  delete(id) {
    this.validateId(id);

    const result = this.database.execute(
      `
        DELETE FROM plots
        WHERE id = ?;
      `,
      [id.trim()]
    );

    return Boolean(
      result && Number(result.changes) > 0
    );
  }

  exists(id) {
    this.validateId(id);

    const row = this.database.queryOne(
      `
        SELECT 1 AS found
        FROM plots
        WHERE id = ?
        LIMIT 1;
      `,
      [id.trim()]
    );

    return row !== null;
  }

  plotNumberExists(projectId, plotNumber, excludePlotId = null) {
    this.validateProjectId(projectId);
    this.validatePlotNumber(plotNumber);

    let row;

    if (excludePlotId === null) {
      row = this.database.queryOne(
        `
          SELECT 1 AS found
          FROM plots
          WHERE project_id = ?
            AND plot_number = ?
          LIMIT 1;
        `,
        [projectId.trim(), plotNumber.trim()]
      );
    } else {
      this.validateId(excludePlotId);

      row = this.database.queryOne(
        `
          SELECT 1 AS found
          FROM plots
          WHERE project_id = ?
            AND plot_number = ?
            AND id <> ?
          LIMIT 1;
        `,
        [
          projectId.trim(),
          plotNumber.trim(),
          excludePlotId.trim(),
        ]
      );
    }

    return row !== null;
  }

  validateId(id) {
    if (typeof id !== 'string' || id.trim() === '') {
      throw new TypeError(
        'Plot ID must be a non-empty string.'
      );
    }
  }

  validateProjectId(projectId) {
    if (
      typeof projectId !== 'string' ||
      projectId.trim() === ''
    ) {
      throw new TypeError(
        'Plot project ID must be a non-empty string.'
      );
    }
  }

  validatePlotNumber(plotNumber) {
    if (
      typeof plotNumber !== 'string' ||
      plotNumber.trim() === ''
    ) {
      throw new TypeError(
        'Plot number must be a non-empty string.'
      );
    }
  }

  validateStatus(status) {
    if (
      typeof status !== 'string' ||
      !PLOT_STATUSES.includes(status.trim().toUpperCase())
    ) {
      throw new TypeError(
        `Plot status must be one of: ${PLOT_STATUSES.join(', ')}.`
      );
    }
  }

  validatePlot(plot) {
    if (!plot || typeof plot !== 'object') {
      throw new TypeError('Plot must be an object.');
    }

    this.validateId(plot.id);
    this.validateProjectId(plot.projectId);
    this.validatePlotNumber(plot.plotNumber);
    this.validateStatus(plot.status);

    if (
      typeof plot.uuid !== 'string' ||
      plot.uuid.trim() === ''
    ) {
      throw new TypeError(
        'Plot UUID must be a non-empty string.'
      );
    }

    if (
      typeof plot.category !== 'string' ||
      plot.category.trim() === ''
    ) {
      throw new TypeError(
        'Plot category must be a non-empty string.'
      );
    }

    if (
      typeof plot.areaSqYd !== 'number' ||
      !Number.isFinite(plot.areaSqYd) ||
      plot.areaSqYd <= 0
    ) {
      throw new TypeError(
        'Plot areaSqYd must be a positive finite number.'
      );
    }

    for (const [fieldName, value] of [
      ['ratePerSqYd', plot.ratePerSqYd ?? 0],
      ['totalPrice', plot.totalPrice ?? 0],
    ]) {
      if (
        typeof value !== 'number' ||
        !Number.isFinite(value) ||
        value < 0
      ) {
        throw new TypeError(
          `Plot ${fieldName} must be a non-negative finite number.`
        );
      }
    }

    if (
      plot.geometryJson !== null &&
      plot.geometryJson !== undefined &&
      typeof plot.geometryJson !== 'string'
    ) {
      throw new TypeError(
        'Plot geometryJson must be a string or null.'
      );
    }

    if (
      typeof plot.createdAt !== 'string' ||
      plot.createdAt.trim() === ''
    ) {
      throw new TypeError(
        'Plot createdAt is required.'
      );
    }

    if (
      typeof plot.updatedAt !== 'string' ||
      plot.updatedAt.trim() === ''
    ) {
      throw new TypeError(
        'Plot updatedAt is required.'
      );
    }
  }

  mapRow(row) {
    return Object.freeze({
      id: row.id,
      uuid: row.uuid,
      projectId: row.project_id,
      plotNumber: row.plot_number,
      category: row.category,
      areaSqYd: Number(row.area_sq_yd),
      status: row.status,
      ratePerSqYd: Number(row.rate_per_sq_yd),
      totalPrice: Number(row.total_price),
      geometryJson: row.geometry_json,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    });
  }
}

module.exports = {
  PLOT_STATUSES,
  PlotRepository,
};
