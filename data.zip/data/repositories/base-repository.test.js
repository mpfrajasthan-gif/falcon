'use strict';

const assert = require('assert');

const {
  BaseRepository,
} = require('./base-repository');

const {
  FalconError,
} = require('../../core/errors/falcon-error');

async function assertMethodRejected(
  repository,
  methodName
) {
  await assert.rejects(
    () => repository[methodName](),
    (error) => {
      assert.strictEqual(
        error instanceof FalconError,
        true
      );

      assert.strictEqual(
        error.code,
        'REPOSITORY_METHOD_NOT_IMPLEMENTED'
      );

      assert.deepStrictEqual(
        error.details,
        {
          entityName: 'Project',
          methodName,
        }
      );

      return true;
    }
  );
}

async function runBaseRepositoryTests() {
  console.log('Falcon Base Repository Tests');
  console.log('----------------------------');

  assert.throws(
    () => new BaseRepository(''),
    TypeError
  );

  assert.throws(
    () => new BaseRepository(null),
    TypeError
  );

  const repository = new BaseRepository(
    '  Project  '
  );

  assert.strictEqual(
    repository.entityName,
    'Project'
  );

  assert.strictEqual(
    repository instanceof BaseRepository,
    true
  );

  const methods = [
    'create',
    'findById',
    'findAll',
    'update',
    'delete',
    'exists',
  ];

  for (const methodName of methods) {
    assert.strictEqual(
      typeof repository[methodName],
      'function'
    );

    await assertMethodRejected(
      repository,
      methodName
    );
  }

  const customError =
    repository.createNotImplementedError(
      'archive'
    );

  assert.strictEqual(
    customError instanceof FalconError,
    true
  );

  assert.strictEqual(
    customError.code,
    'REPOSITORY_METHOD_NOT_IMPLEMENTED'
  );

  assert.strictEqual(
    customError.operational,
    true
  );

  assert.deepStrictEqual(
    customError.details,
    {
      entityName: 'Project',
      methodName: 'archive',
    }
  );

  console.log(
    'Repository Entity:',
    repository.entityName
  );
  console.log(
    'Contract Methods:',
    methods.length
  );
  console.log('Assertions Passed: 29');
  console.log('----------------------------');
  console.log('BASE REPOSITORY TEST PASS');
}

runBaseRepositoryTests().catch(
  (testError) => {
    console.error(
      'BASE REPOSITORY TEST FAIL'
    );
    console.error(testError.message);
    process.exitCode = 1;
  }
);