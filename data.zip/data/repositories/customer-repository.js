'use strict';

const {
  BaseRepository,
} = require('./base-repository');

const {
  createFalconError,
} = require('../../core/errors/falcon-error');

class CustomerRepository extends BaseRepository {
  constructor(database) {
    super('Customer');

    if (
      !database ||
      typeof database.execute !== 'function' ||
      typeof database.queryOne !== 'function' ||
      typeof database.queryAll !== 'function'
    ) {
      throw new TypeError(
        'A valid Falcon database adapter is required.'
      );
    }

    this.database = database;
  }

  create(customer) {
    this.validateCustomer(customer);

    this.database.execute(
      `
        INSERT INTO customers (
          id,
          uuid,
          name,
          mobile,
          address,
          created_at,
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?);
      `,
      [
        customer.id.trim(),
        customer.uuid.trim(),
        customer.name.trim(),
        customer.mobile.trim(),
        customer.address ?? null,
        customer.createdAt,
        customer.updatedAt,
      ]
    );

    return this.findById(customer.id);
  }

  findById(id) {
    this.validateId(id);

    const row = this.database.queryOne(
      `
        SELECT
          id,
          uuid,
          name,
          mobile,
          address,
          created_at,
          updated_at
        FROM customers
        WHERE id = ?;
      `,
      [id.trim()]
    );

    return row ? this.mapRow(row) : null;
  }

  findByMobile(mobile) {
    this.validateMobile(mobile);

    const row = this.database.queryOne(
      `
        SELECT
          id,
          uuid,
          name,
          mobile,
          address,
          created_at,
          updated_at
        FROM customers
        WHERE mobile = ?
        LIMIT 1;
      `,
      [mobile.trim()]
    );

    return row ? this.mapRow(row) : null;
  }

  findAll() {
    const rows = this.database.queryAll(
      `
        SELECT
          id,
          uuid,
          name,
          mobile,
          address,
          created_at,
          updated_at
        FROM customers
        ORDER BY name ASC, id ASC;
      `
    );

    return rows.map((row) => this.mapRow(row));
  }

  search(keyword) {
    if (
      typeof keyword !== 'string' ||
      keyword.trim() === ''
    ) {
      return this.findAll();
    }

    const searchValue = `%${keyword.trim()}%`;

    const rows = this.database.queryAll(
      `
        SELECT
          id,
          uuid,
          name,
          mobile,
          address,
          created_at,
          updated_at
        FROM customers
        WHERE
          id LIKE ?
          OR name LIKE ?
          OR mobile LIKE ?
          OR address LIKE ?
        ORDER BY name ASC, id ASC;
      `,
      [
        searchValue,
        searchValue,
        searchValue,
        searchValue,
      ]
    );

    return rows.map((row) => this.mapRow(row));
  }

  update(id, changes) {
    this.validateId(id);

    if (!changes || typeof changes !== 'object') {
      throw new TypeError(
        'Customer changes must be an object.'
      );
    }

    const existing = this.findById(id);

    if (!existing) {
      throw createFalconError(
        'CUSTOMER_NOT_FOUND',
        'Falcon customer was not found.',
        {
          customerId: id.trim(),
        }
      );
    }

    const updatedCustomer = {
      ...existing,
      ...changes,
      id: existing.id,
      uuid: existing.uuid,
      createdAt: existing.createdAt,
    };

    this.validateCustomer(updatedCustomer);

    this.database.execute(
      `
        UPDATE customers
        SET
          name = ?,
          mobile = ?,
          address = ?,
          updated_at = ?
        WHERE id = ?;
      `,
      [
        updatedCustomer.name.trim(),
        updatedCustomer.mobile.trim(),
        updatedCustomer.address ?? null,
        updatedCustomer.updatedAt,
        id.trim(),
      ]
    );

    return this.findById(id);
  }

  delete(id) {
    this.validateId(id);

    const result = this.database.execute(
      `
        DELETE FROM customers
        WHERE id = ?;
      `,
      [id.trim()]
    );

    return Boolean(
      result &&
      Number(result.changes) > 0
    );
  }

  exists(id) {
    this.validateId(id);

    const row = this.database.queryOne(
      `
        SELECT 1 AS found
        FROM customers
        WHERE id = ?
        LIMIT 1;
      `,
      [id.trim()]
    );

    return row !== null;
  }

  mobileExists(mobile, excludeCustomerId = null) {
    this.validateMobile(mobile);

    let row;

    if (excludeCustomerId === null) {
      row = this.database.queryOne(
        `
          SELECT 1 AS found
          FROM customers
          WHERE mobile = ?
          LIMIT 1;
        `,
        [mobile.trim()]
      );
    } else {
      this.validateId(excludeCustomerId);

      row = this.database.queryOne(
        `
          SELECT 1 AS found
          FROM customers
          WHERE mobile = ?
            AND id <> ?
          LIMIT 1;
        `,
        [
          mobile.trim(),
          excludeCustomerId.trim(),
        ]
      );
    }

    return row !== null;
  }

  validateId(id) {
    if (
      typeof id !== 'string' ||
      id.trim() === ''
    ) {
      throw new TypeError(
        'Customer ID must be a non-empty string.'
      );
    }
  }

  validateMobile(mobile) {
    if (
      typeof mobile !== 'string' ||
      mobile.trim() === ''
    ) {
      throw new TypeError(
        'Customer mobile must be a non-empty string.'
      );
    }
  }

  validateCustomer(customer) {
    if (!customer || typeof customer !== 'object') {
      throw new TypeError(
        'Customer must be an object.'
      );
    }

    this.validateId(customer.id);

    if (
      typeof customer.uuid !== 'string' ||
      customer.uuid.trim() === ''
    ) {
      throw new TypeError(
        'Customer UUID must be a non-empty string.'
      );
    }

    if (
      typeof customer.name !== 'string' ||
      customer.name.trim() === ''
    ) {
      throw new TypeError(
        'Customer name must be a non-empty string.'
      );
    }

    this.validateMobile(customer.mobile);

    if (
      typeof customer.createdAt !== 'string' ||
      customer.createdAt.trim() === ''
    ) {
      throw new TypeError(
        'Customer createdAt is required.'
      );
    }

    if (
      typeof customer.updatedAt !== 'string' ||
      customer.updatedAt.trim() === ''
    ) {
      throw new TypeError(
        'Customer updatedAt is required.'
      );
    }
  }

  mapRow(row) {
    return Object.freeze({
      id: row.id,
      uuid: row.uuid,
      name: row.name,
      mobile: row.mobile,
      address: row.address,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    });
  }
}

module.exports = {
  CustomerRepository,
};
