'use strict';

const assert = require('assert');

const {
  PLOT_STATUSES,
  PlotRepository,
} = require('./plot-repository');

const {
  FalconError,
} = require('../../core/errors/falcon-error');

function createFakeDatabase() {
  const rows = new Map();

  function sortRows(values) {
    return [...values].sort((first, second) => {
      const projectCompare = first.project_id.localeCompare(
        second.project_id
      );

      if (projectCompare !== 0) {
        return projectCompare;
      }

      return first.plot_number.localeCompare(
        second.plot_number,
        'en',
        { numeric: true }
      );
    });
  }

  return {
    execute(sql, parameters = []) {
      if (sql.includes('INSERT INTO plots')) {
        rows.set(parameters[0], {
          id: parameters[0],
          uuid: parameters[1],
          project_id: parameters[2],
          plot_number: parameters[3],
          category: parameters[4],
          area_sq_yd: parameters[5],
          status: parameters[6],
          rate_per_sq_yd: parameters[7],
          total_price: parameters[8],
          geometry_json: parameters[9],
          created_at: parameters[10],
          updated_at: parameters[11],
        });

        return { changes: 1 };
      }

      if (sql.includes('UPDATE plots')) {
        const existing = rows.get(parameters[8]);

        if (!existing) {
          return { changes: 0 };
        }

        rows.set(parameters[8], {
          ...existing,
          plot_number: parameters[0],
          category: parameters[1],
          area_sq_yd: parameters[2],
          status: parameters[3],
          rate_per_sq_yd: parameters[4],
          total_price: parameters[5],
          geometry_json: parameters[6],
          updated_at: parameters[7],
        });

        return { changes: 1 };
      }

      if (sql.includes('DELETE FROM plots')) {
        const deleted = rows.delete(parameters[0]);
        return { changes: deleted ? 1 : 0 };
      }

      return { changes: 0 };
    },

    queryOne(sql, parameters = []) {
      if (
        sql.includes('SELECT 1 AS found') &&
        sql.includes('project_id = ?') &&
        sql.includes('plot_number = ?')
      ) {
        const [projectId, plotNumber, excludedId = null] = parameters;

        const found = [...rows.values()].some(
          (row) =>
            row.project_id === projectId &&
            row.plot_number === plotNumber &&
            row.id !== excludedId
        );

        return found ? { found: 1 } : null;
      }

      if (sql.includes('SELECT 1 AS found')) {
        return rows.has(parameters[0])
          ? { found: 1 }
          : null;
      }

      if (
        sql.includes('WHERE project_id = ?') &&
        sql.includes('AND plot_number = ?')
      ) {
        return (
          [...rows.values()].find(
            (row) =>
              row.project_id === parameters[0] &&
              row.plot_number === parameters[1]
          ) ?? null
        );
      }

      return rows.get(parameters[0]) ?? null;
    },

    queryAll(sql, parameters = []) {
      let result = [...rows.values()];

      if (
        sql.includes('WHERE project_id = ?') &&
        sql.includes('AND (')
      ) {
        const projectId = parameters[0];
        const keyword = String(parameters[1])
          .replaceAll('%', '')
          .toLowerCase();

        result = result.filter(
          (row) =>
            row.project_id === projectId &&
            [
              row.id,
              row.plot_number,
              row.category,
              row.status,
            ].some((value) =>
              String(value).toLowerCase().includes(keyword)
            )
        );
      } else if (
        sql.includes('WHERE status = ?') &&
        sql.includes('AND project_id = ?')
      ) {
        result = result.filter(
          (row) =>
            row.status === parameters[0] &&
            row.project_id === parameters[1]
        );
      } else if (sql.includes('WHERE status = ?')) {
        result = result.filter(
          (row) => row.status === parameters[0]
        );
      } else if (sql.includes('WHERE project_id = ?')) {
        result = result.filter(
          (row) => row.project_id === parameters[0]
        );
      } else if (sql.includes('WHERE')) {
        const keyword = String(parameters[0])
          .replaceAll('%', '')
          .toLowerCase();

        result = result.filter((row) =>
          [
            row.id,
            row.plot_number,
            row.category,
            row.status,
          ].some((value) =>
            String(value).toLowerCase().includes(keyword)
          )
        );
      }

      return sortRows(result);
    },
  };
}

function runPlotRepositoryTests() {
  console.log('Falcon Plot Repository Tests');
  console.log('----------------------------');

  assert.deepStrictEqual(
    PLOT_STATUSES,
    ['AVAILABLE', 'HOLD', 'BOOKED', 'SOLD']
  );

  assert.throws(
    () => new PlotRepository(null),
    TypeError
  );

  const database = createFakeDatabase();
  const repository = new PlotRepository(database);

  const firstPlot = {
    id: 'FPL-000001',
    uuid: '33333333-3333-4333-8333-333333333333',
    projectId: 'FP-000001',
    plotNumber: '1',
    category: 'Residential',
    areaSqYd: 100,
    status: 'AVAILABLE',
    ratePerSqYd: 5000,
    totalPrice: 500000,
    geometryJson: '{"type":"Polygon"}',
    createdAt: '2026-07-25T10:00:00.000Z',
    updatedAt: '2026-07-25T10:00:00.000Z',
  };

  const secondPlot = {
    id: 'FPL-000002',
    uuid: '44444444-4444-4444-8444-444444444444',
    projectId: 'FP-000001',
    plotNumber: '2',
    category: 'Commercial',
    areaSqYd: 120,
    status: 'HOLD',
    ratePerSqYd: 6000,
    totalPrice: 720000,
    geometryJson: null,
    createdAt: '2026-07-25T10:05:00.000Z',
    updatedAt: '2026-07-25T10:05:00.000Z',
  };

  const createdFirst = repository.create(firstPlot);
  const createdSecond = repository.create(secondPlot);

  assert.strictEqual(createdFirst.id, 'FPL-000001');
  assert.strictEqual(createdFirst.projectId, 'FP-000001');
  assert.strictEqual(createdFirst.plotNumber, '1');
  assert.strictEqual(createdFirst.areaSqYd, 100);
  assert.strictEqual(createdFirst.status, 'AVAILABLE');
  assert.strictEqual(Object.isFrozen(createdFirst), true);
  assert.strictEqual(createdSecond.status, 'HOLD');

  assert.strictEqual(repository.exists('FPL-000001'), true);
  assert.strictEqual(repository.exists('FPL-999999'), false);

  assert.strictEqual(
    repository.plotNumberExists('FP-000001', '1'),
    true
  );

  assert.strictEqual(
    repository.plotNumberExists('FP-000001', '99'),
    false
  );

  assert.strictEqual(
    repository.plotNumberExists(
      'FP-000001',
      '1',
      'FPL-000001'
    ),
    false
  );

  assert.strictEqual(
    repository.findById('FPL-000001').uuid,
    firstPlot.uuid
  );

  assert.strictEqual(
    repository.findByProjectAndNumber(
      'FP-000001',
      '2'
    ).id,
    'FPL-000002'
  );

  assert.strictEqual(
    repository.findByProjectAndNumber(
      'FP-000001',
      '99'
    ),
    null
  );

  assert.strictEqual(repository.findAll().length, 2);
  assert.strictEqual(
    repository.findByProjectId('FP-000001').length,
    2
  );
  assert.strictEqual(
    repository.findByStatus('AVAILABLE').length,
    1
  );
  assert.strictEqual(
    repository.findByStatus('HOLD', 'FP-000001').length,
    1
  );

  assert.strictEqual(repository.search('Residential').length, 1);
  assert.strictEqual(repository.search('HOLD').length, 1);
  assert.strictEqual(
    repository.search('2', 'FP-000001').length,
    1
  );
  assert.strictEqual(repository.search('').length, 2);

  const updated = repository.update(
    'FPL-000001',
    {
      category: 'Residential Corner',
      areaSqYd: 105,
      status: 'BOOKED',
      ratePerSqYd: 5500,
      totalPrice: 577500,
      geometryJson: '{"type":"Polygon","updated":true}',
      updatedAt: '2026-07-25T11:00:00.000Z',
    }
  );

  assert.strictEqual(updated.category, 'Residential Corner');
  assert.strictEqual(updated.areaSqYd, 105);
  assert.strictEqual(updated.status, 'BOOKED');
  assert.strictEqual(updated.totalPrice, 577500);
  assert.strictEqual(updated.id, firstPlot.id);
  assert.strictEqual(updated.uuid, firstPlot.uuid);
  assert.strictEqual(updated.projectId, firstPlot.projectId);

  assert.throws(
    () =>
      repository.update('FPL-999999', {
        status: 'SOLD',
        updatedAt: '2026-07-25T12:00:00.000Z',
      }),
    (error) =>
      error instanceof FalconError &&
      error.code === 'PLOT_NOT_FOUND'
  );

  assert.strictEqual(repository.delete('FPL-000002'), true);
  assert.strictEqual(repository.findById('FPL-000002'), null);
  assert.strictEqual(repository.delete('FPL-000002'), false);

  assert.throws(() => repository.findById(''), TypeError);
  assert.throws(
    () => repository.findByProjectId(''),
    TypeError
  );
  assert.throws(
    () => repository.findByStatus('INVALID'),
    TypeError
  );
  assert.throws(
    () =>
      repository.create({
        id: 'FPL-000003',
      }),
    TypeError
  );

  console.log('Created Plot:', createdFirst.id);
  console.log('Updated Plot Status:', updated.status);
  console.log('Plot Deleted:', true);
  console.log('Assertions Passed: 37');
  console.log('----------------------------');
  console.log('PLOT REPOSITORY TEST PASS');
}

try {
  runPlotRepositoryTests();
} catch (testError) {
  console.error('PLOT REPOSITORY TEST FAIL');
  console.error(testError.stack || testError.message);
  process.exitCode = 1;
}
