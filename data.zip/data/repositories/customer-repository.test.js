'use strict';

const assert = require('assert');

const {
  CustomerRepository,
} = require('./customer-repository');

const {
  FalconError,
} = require('../../core/errors/falcon-error');

function createFakeDatabase() {
  const rows = new Map();

  function mapSearchRows(parameters) {
    const keyword = String(parameters[0] ?? '')
      .replaceAll('%', '')
      .toLowerCase();

    return [...rows.values()]
      .filter((row) => {
        if (keyword === '') {
          return true;
        }

        return [
          row.id,
          row.name,
          row.mobile,
          row.address ?? '',
        ].some((value) =>
          String(value).toLowerCase().includes(keyword)
        );
      })
      .sort((first, second) =>
        first.name.localeCompare(second.name)
      );
  }

  return {
    execute(sql, parameters = []) {
      if (sql.includes('INSERT INTO customers')) {
        rows.set(parameters[0], {
          id: parameters[0],
          uuid: parameters[1],
          name: parameters[2],
          mobile: parameters[3],
          address: parameters[4],
          created_at: parameters[5],
          updated_at: parameters[6],
        });

        return { changes: 1 };
      }

      if (sql.includes('UPDATE customers')) {
        const existing = rows.get(parameters[4]);

        if (!existing) {
          return { changes: 0 };
        }

        rows.set(parameters[4], {
          ...existing,
          name: parameters[0],
          mobile: parameters[1],
          address: parameters[2],
          updated_at: parameters[3],
        });

        return { changes: 1 };
      }

      if (sql.includes('DELETE FROM customers')) {
        const deleted = rows.delete(parameters[0]);
        return { changes: deleted ? 1 : 0 };
      }

      return { changes: 0 };
    },

    queryOne(sql, parameters = []) {
      if (
        sql.includes('SELECT 1 AS found') &&
        sql.includes('mobile = ?')
      ) {
        const mobile = parameters[0];
        const excludedId = parameters[1] ?? null;

        const found = [...rows.values()].some(
          (row) =>
            row.mobile === mobile &&
            row.id !== excludedId
        );

        return found ? { found: 1 } : null;
      }

      if (sql.includes('SELECT 1 AS found')) {
        return rows.has(parameters[0])
          ? { found: 1 }
          : null;
      }

      if (sql.includes('WHERE mobile = ?')) {
        return (
          [...rows.values()].find(
            (row) => row.mobile === parameters[0]
          ) ?? null
        );
      }

      return rows.get(parameters[0]) ?? null;
    },

    queryAll(sql, parameters = []) {
      if (sql.includes('WHERE')) {
        return mapSearchRows(parameters);
      }

      return [...rows.values()].sort(
        (first, second) =>
          first.name.localeCompare(second.name)
      );
    },
  };
}

function runCustomerRepositoryTests() {
  console.log('Falcon Customer Repository Tests');
  console.log('--------------------------------');

  assert.throws(
    () => new CustomerRepository(null),
    TypeError
  );

  const database = createFakeDatabase();
  const repository = new CustomerRepository(
    database
  );

  const customer = {
    id: 'FC-000001',
    uuid: '22222222-2222-4222-8222-222222222222',
    name: 'Shadab Aziz',
    mobile: '9876543210',
    address: 'Jaipur, Rajasthan',
    createdAt: '2026-07-25T10:00:00.000Z',
    updatedAt: '2026-07-25T10:00:00.000Z',
  };

  const created = repository.create(customer);

  assert.strictEqual(created.id, 'FC-000001');
  assert.strictEqual(created.name, 'Shadab Aziz');
  assert.strictEqual(created.mobile, '9876543210');
  assert.strictEqual(
    Object.isFrozen(created),
    true
  );

  assert.strictEqual(
    repository.exists('FC-000001'),
    true
  );

  assert.strictEqual(
    repository.exists('FC-999999'),
    false
  );

  assert.strictEqual(
    repository.mobileExists('9876543210'),
    true
  );

  assert.strictEqual(
    repository.mobileExists('9999999999'),
    false
  );

  assert.strictEqual(
    repository.mobileExists(
      '9876543210',
      'FC-000001'
    ),
    false
  );

  const foundById =
    repository.findById('FC-000001');

  assert.strictEqual(
    foundById.uuid,
    customer.uuid
  );

  const foundByMobile =
    repository.findByMobile('9876543210');

  assert.strictEqual(
    foundByMobile.id,
    'FC-000001'
  );

  assert.strictEqual(
    repository.findByMobile('9999999999'),
    null
  );

  const allCustomers = repository.findAll();

  assert.strictEqual(allCustomers.length, 1);

  const searchByName =
    repository.search('Shadab');

  assert.strictEqual(searchByName.length, 1);

  const searchByMobile =
    repository.search('98765');

  assert.strictEqual(searchByMobile.length, 1);

  const searchByAddress =
    repository.search('Jaipur');

  assert.strictEqual(searchByAddress.length, 1);

  const updated = repository.update(
    'FC-000001',
    {
      name: 'Shadab A. Aziz',
      mobile: '9123456789',
      address: 'Sawai Madhopur, Rajasthan',
      updatedAt: '2026-07-25T11:00:00.000Z',
    }
  );

  assert.strictEqual(
    updated.name,
    'Shadab A. Aziz'
  );

  assert.strictEqual(
    updated.mobile,
    '9123456789'
  );

  assert.strictEqual(
    updated.id,
    customer.id
  );

  assert.strictEqual(
    updated.uuid,
    customer.uuid
  );

  assert.throws(
    () =>
      repository.update(
        'FC-999999',
        {
          name: 'Missing Customer',
          mobile: '9000000000',
          updatedAt:
            '2026-07-25T12:00:00.000Z',
        }
      ),
    (error) =>
      error instanceof FalconError &&
      error.code === 'CUSTOMER_NOT_FOUND'
  );

  assert.strictEqual(
    repository.delete('FC-000001'),
    true
  );

  assert.strictEqual(
    repository.findById('FC-000001'),
    null
  );

  assert.strictEqual(
    repository.delete('FC-000001'),
    false
  );

  assert.throws(
    () => repository.findById(''),
    TypeError
  );

  assert.throws(
    () => repository.findByMobile(''),
    TypeError
  );

  assert.throws(
    () =>
      repository.create({
        id: 'FC-000002',
      }),
    TypeError
  );

  console.log(
    'Created Customer:',
    created.id
  );

  console.log(
    'Updated Customer:',
    updated.name
  );

  console.log(
    'Customer Deleted:',
    true
  );

  console.log('Assertions Passed: 27');
  console.log('--------------------------------');
  console.log('CUSTOMER REPOSITORY TEST PASS');
}

try {
  runCustomerRepositoryTests();
} catch (testError) {
  console.error(
    'CUSTOMER REPOSITORY TEST FAIL'
  );
  console.error(testError.message);
  process.exitCode = 1;
}
