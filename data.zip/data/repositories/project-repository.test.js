'use strict';

const assert = require('assert');

const {
  ProjectRepository,
} = require('./project-repository');

const {
  FalconError,
} = require('../../core/errors/falcon-error');

function createFakeDatabase() {
  const rows = new Map();

  return {
    execute(sql, parameters = []) {
      if (sql.includes('INSERT INTO projects')) {
        rows.set(parameters[0], {
          id: parameters[0],
          uuid: parameters[1],
          name: parameters[2],
          location: parameters[3],
          address: parameters[4],
          rera_number: parameters[5],
          status: parameters[6],
          created_at: parameters[7],
          updated_at: parameters[8],
        });

        return {
          changes: 1,
        };
      }

      if (sql.includes('UPDATE projects')) {
        const existing = rows.get(parameters[6]);

        if (!existing) {
          return {
            changes: 0,
          };
        }

        rows.set(parameters[6], {
          ...existing,
          name: parameters[0],
          location: parameters[1],
          address: parameters[2],
          rera_number: parameters[3],
          status: parameters[4],
          updated_at: parameters[5],
        });

        return {
          changes: 1,
        };
      }

      if (sql.includes('DELETE FROM projects')) {
        const deleted = rows.delete(parameters[0]);

        return {
          changes: deleted ? 1 : 0,
        };
      }

      return {
        changes: 0,
      };
    },

    queryOne(sql, parameters = []) {
      if (sql.includes('SELECT 1 AS found')) {
        return rows.has(parameters[0])
          ? { found: 1 }
          : null;
      }

      return rows.get(parameters[0]) ?? null;
    },

    queryAll() {
      return [...rows.values()].sort(
        (first, second) =>
          first.name.localeCompare(second.name)
      );
    },
  };
}

function runProjectRepositoryTests() {
  console.log('Falcon Project Repository Tests');
  console.log('-------------------------------');

  assert.throws(
    () => new ProjectRepository(null),
    TypeError
  );

  const database = createFakeDatabase();
  const repository = new ProjectRepository(
    database
  );

  const project = {
    id: 'FP-000001',
    uuid: '11111111-1111-4111-8111-111111111111',
    name: 'Jaipur Pride',
    location: 'Jaipur',
    address: 'Rajasthan',
    reraNumber: 'RAJ/P/2026/001',
    status: 'ACTIVE',
    createdAt: '2026-07-24T10:00:00.000Z',
    updatedAt: '2026-07-24T10:00:00.000Z',
  };

  const created = repository.create(project);

  assert.strictEqual(
    created.id,
    'FP-000001'
  );

  assert.strictEqual(
    created.name,
    'Jaipur Pride'
  );

  assert.strictEqual(
    created.reraNumber,
    'RAJ/P/2026/001'
  );

  assert.strictEqual(
    Object.isFrozen(created),
    true
  );

  assert.strictEqual(
    repository.exists('FP-000001'),
    true
  );

  assert.strictEqual(
    repository.exists('FP-999999'),
    false
  );

  const found = repository.findById(
    'FP-000001'
  );

  assert.strictEqual(
    found.uuid,
    project.uuid
  );

  const allProjects = repository.findAll();

  assert.strictEqual(
    allProjects.length,
    1
  );

  const updated = repository.update(
    'FP-000001',
    {
      name: 'Jaipur Pride Phase 1',
      status: 'INACTIVE',
      updatedAt:
        '2026-07-24T11:00:00.000Z',
    }
  );

  assert.strictEqual(
    updated.name,
    'Jaipur Pride Phase 1'
  );

  assert.strictEqual(
    updated.status,
    'INACTIVE'
  );

  assert.strictEqual(
    updated.id,
    project.id
  );

  assert.strictEqual(
    updated.uuid,
    project.uuid
  );

  assert.throws(
    () =>
      repository.update(
        'FP-999999',
        {
          name: 'Missing Project',
          updatedAt:
            '2026-07-24T12:00:00.000Z',
        }
      ),
    (error) =>
      error instanceof FalconError &&
      error.code === 'PROJECT_NOT_FOUND'
  );

  assert.strictEqual(
    repository.delete('FP-000001'),
    true
  );

  assert.strictEqual(
    repository.findById('FP-000001'),
    null
  );

  assert.strictEqual(
    repository.delete('FP-000001'),
    false
  );

  assert.throws(
    () => repository.findById(''),
    TypeError
  );

  assert.throws(
    () =>
      repository.create({
        id: 'FP-000002',
      }),
    TypeError
  );

  console.log(
    'Created Project:',
    created.id
  );

  console.log(
    'Updated Project:',
    updated.name
  );

  console.log(
    'Project Deleted:',
    true
  );

  console.log('Assertions Passed: 18');
  console.log('-------------------------------');
  console.log('PROJECT REPOSITORY TEST PASS');
}

try {
  runProjectRepositoryTests();
} catch (testError) {
  console.error(
    'PROJECT REPOSITORY TEST FAIL'
  );
  console.error(testError.message);
  process.exitCode = 1;
}