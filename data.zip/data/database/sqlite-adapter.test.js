'use strict';

const assert = require('assert');

const {
  DEFAULT_DATABASE_PATH,
  SQLiteAdapter,
} = require('./sqlite-adapter');

const {
  FalconError,
} = require('../../core/errors/falcon-error');

function createFakeDriver() {
  const state = {
    closed: false,
    statements: [],
  };

  return {
    state,

    exec(sql, parameters = []) {
      state.statements.push({
        method: 'exec',
        sql,
        parameters,
      });

      return {
        changes: 1,
      };
    },

    prepare(sql) {
      return {
        run(...parameters) {
          state.statements.push({
            method: 'run',
            sql,
            parameters,
          });

          return {
            changes: 1,
            lastInsertRowid: 1,
          };
        },

        get(...parameters) {
          state.statements.push({
            method: 'get',
            sql,
            parameters,
          });

          return {
            id: 'FP-000001',
          };
        },

        all(...parameters) {
          state.statements.push({
            method: 'all',
            sql,
            parameters,
          });

          return [
            {
              id: 'FP-000001',
            },
            {
              id: 'FP-000002',
            },
          ];
        },
      };
    },

    transaction(work) {
      return () => {
        state.statements.push({
          method: 'transaction',
        });

        return work();
      };
    },

    close() {
      state.closed = true;
    },
  };
}

function runSQLiteAdapterTests() {
  console.log('Falcon SQLite Adapter Tests');
  console.log('---------------------------');

  assert.throws(
    () => new SQLiteAdapter(),
    TypeError
  );

  assert.throws(
    () =>
      new SQLiteAdapter({
        driverFactory: () => ({}),
        databasePath: '',
      }),
    TypeError
  );

  let fakeConnection = null;

  const adapter = new SQLiteAdapter({
    driverFactory: () => {
      fakeConnection = createFakeDriver();
      return fakeConnection;
    },
  });

  assert.strictEqual(adapter.isOpen, false);

  assert.throws(
    () => adapter.queryAll('SELECT 1'),
    (error) =>
      error instanceof FalconError &&
      error.code === 'DATABASE_NOT_OPEN'
  );

  const openedConnection = adapter.open();

  assert.strictEqual(adapter.isOpen, true);

  assert.strictEqual(
    openedConnection,
    fakeConnection
  );

  assert.ok(
    fakeConnection.state.statements.some(
      (statement) =>
        statement.sql ===
        'PRAGMA foreign_keys = ON;'
    ),
    'Foreign-key enforcement must be enabled.'
  );

  assert.strictEqual(
    adapter.open(),
    openedConnection,
    'Repeated open must reuse the connection.'
  );

  const executionResult = adapter.execute(
    'INSERT INTO projects (id) VALUES (?);',
    ['FP-000001']
  );

  assert.strictEqual(
    executionResult.changes,
    1
  );

  const singleRow = adapter.queryOne(
    'SELECT * FROM projects WHERE id = ?;',
    ['FP-000001']
  );

  assert.deepStrictEqual(singleRow, {
    id: 'FP-000001',
  });

  const allRows = adapter.queryAll(
    'SELECT * FROM projects;'
  );

  assert.strictEqual(allRows.length, 2);

  const transactionResult = adapter.transaction(
    (database) => {
      database.execute(
        'UPDATE projects SET name = ? WHERE id = ?;',
        ['Jaipur Pride', 'FP-000001']
      );

      return 'COMMITTED';
    }
  );

  assert.strictEqual(
    transactionResult,
    'COMMITTED'
  );

  assert.ok(
    fakeConnection.state.statements.some(
      (statement) =>
        statement.method === 'transaction'
    ),
    'Driver transaction must be used.'
  );

  assert.throws(
    () => adapter.execute('', []),
    TypeError
  );

  assert.throws(
    () => adapter.execute('SELECT 1', null),
    TypeError
  );

  assert.throws(
    () => adapter.transaction(null),
    TypeError
  );

  assert.strictEqual(adapter.close(), true);
  assert.strictEqual(adapter.isOpen, false);
  assert.strictEqual(
    fakeConnection.state.closed,
    true
  );

  assert.strictEqual(
    adapter.close(),
    false,
    'Closing an already closed adapter must be safe.'
  );

  assert.ok(
    DEFAULT_DATABASE_PATH.endsWith('falcon.db')
  );

  assert.ok(
    DEFAULT_DATABASE_PATH.includes(
      'FalconHybrid'
    )
  );

  console.log(
    'Database Path:',
    DEFAULT_DATABASE_PATH
  );
  console.log(
    'Executed Statements:',
    fakeConnection.state.statements.length
  );
  console.log('Assertions Passed: 20');
  console.log('---------------------------');
  console.log('SQLITE ADAPTER TEST PASS');
}

try {
  runSQLiteAdapterTests();
} catch (testError) {
  console.error('SQLITE ADAPTER TEST FAIL');
  console.error(testError.message);
  process.exitCode = 1;
}