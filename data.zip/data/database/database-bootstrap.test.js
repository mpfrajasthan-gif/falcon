'use strict';

const assert = require('assert');

const {
  bootstrapDatabase,
  validateDatabaseAdapter,
} = require('./database-bootstrap');

function createFakeDatabase(options = {}) {
  const {
    failOnOpen = false,
    initiallyAppliedVersions = [],
  } = options;

  const state = {
    open: false,
    appliedVersions: new Set(
      initiallyAppliedVersions
    ),
    statements: [],
    transactions: 0,
  };

  return {
    state,
    databasePath:
      'C:\\FalconTest\\falcon-test.db',

    get isOpen() {
      return state.open;
    },

    open() {
      if (failOnOpen) {
        throw new Error(
          'Simulated database open failure.'
        );
      }

      state.open = true;
      return this;
    },

    close() {
      state.open = false;
      return true;
    },

    execute(sql, parameters = []) {
      state.statements.push({
        sql,
        parameters,
      });

      if (
        sql.includes(
          'INSERT INTO schema_migrations'
        )
      ) {
        state.appliedVersions.add(
          parameters[0]
        );
      }

      return {
        changes: 1,
      };
    },

    queryAll(sql) {
      state.statements.push({
        sql,
        parameters: [],
      });

      return [...state.appliedVersions]
        .sort((first, second) => first - second)
        .map((version) => ({
          version,
        }));
    },

    transaction(work) {
      state.transactions += 1;
      return work(this);
    },
  };
}

function runDatabaseBootstrapTests() {
  console.log('Falcon Database Bootstrap Tests');
  console.log('-------------------------------');

  assert.throws(
    () => validateDatabaseAdapter(null),
    TypeError
  );

  assert.throws(
    () =>
      validateDatabaseAdapter({
        open() {},
      }),
    TypeError
  );

  const database = createFakeDatabase();

  assert.strictEqual(
    validateDatabaseAdapter(database),
    database
  );

  const firstResult =
    bootstrapDatabase(database);

  assert.strictEqual(
    firstResult.success,
    true
  );

  assert.strictEqual(
    firstResult.code,
    'DATABASE_BOOTSTRAP_COMPLETE'
  );

  assert.strictEqual(
    firstResult.data.databaseOpen,
    true
  );

  assert.strictEqual(
    firstResult.data.latestMigrationVersion,
    1
  );

  assert.strictEqual(
    firstResult.data.appliedMigrationCount,
    1
  );

  assert.strictEqual(
    firstResult.data.appliedMigrations.length,
    1
  );

  assert.strictEqual(
    firstResult.data.appliedMigrations[0].version,
    1
  );

  assert.strictEqual(
    database.state.appliedVersions.has(1),
    true
  );

  assert.strictEqual(
    database.state.transactions,
    1
  );

  const secondResult =
    bootstrapDatabase(database);

  assert.strictEqual(
    secondResult.success,
    true
  );

  assert.strictEqual(
    secondResult.data.appliedMigrationCount,
    0,
    'Previously applied migrations must not run again.'
  );

  assert.strictEqual(
    database.state.transactions,
    1,
    'Second bootstrap must not create another migration transaction.'
  );

  const failingDatabase = createFakeDatabase({
    failOnOpen: true,
  });

  const failureResult =
    bootstrapDatabase(failingDatabase);

  assert.strictEqual(
    failureResult.success,
    false
  );

  assert.strictEqual(
    failureResult.code,
    'DATABASE_BOOTSTRAP_FAILED'
  );

  assert.strictEqual(
    failureResult.details.operational,
    false
  );

  assert.strictEqual(
    Object.isFrozen(firstResult),
    true
  );

  assert.strictEqual(
    Object.isFrozen(failureResult),
    true
  );

  console.log(
    'Latest Schema Version:',
    firstResult.data.latestMigrationVersion
  );

  console.log(
    'First Run Applied:',
    firstResult.data.appliedMigrationCount
  );

  console.log(
    'Second Run Applied:',
    secondResult.data.appliedMigrationCount
  );

  console.log('Assertions Passed: 19');
  console.log('-------------------------------');
  console.log('DATABASE BOOTSTRAP TEST PASS');
}

try {
  runDatabaseBootstrapTests();
} catch (testError) {
  console.error(
    'DATABASE BOOTSTRAP TEST FAIL'
  );
  console.error(testError.message);
  process.exitCode = 1;
}