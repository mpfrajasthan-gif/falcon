'use strict';

const {
  MigrationRunner,
} = require('../migrations/migration-runner');

const {
  getMigrations,
  getLatestMigrationVersion,
} = require('../migrations');

const {
  normalizeError,
} = require('../../core/errors/falcon-error');

const {
  success,
  failure,
} = require('../../core/errors/result');

const {
  info,
  error: logError,
} = require('../../core/logging/logger');

function validateDatabaseAdapter(database) {
  if (
    !database ||
    typeof database.open !== 'function' ||
    typeof database.close !== 'function' ||
    typeof database.execute !== 'function' ||
    typeof database.queryAll !== 'function' ||
    typeof database.transaction !== 'function'
  ) {
    throw new TypeError(
      'A valid Falcon database adapter is required.'
    );
  }

  return database;
}

function bootstrapDatabase(database) {
  validateDatabaseAdapter(database);

  try {
    database.open();

    const migrations = getMigrations();

    const runner = new MigrationRunner(
      database,
      migrations
    );

    const migrationResult = runner.runPending();

    const result = success(
      'DATABASE_BOOTSTRAP_COMPLETE',
      'Falcon database initialized successfully.',
      {
        databasePath:
          typeof database.databasePath === 'string'
            ? database.databasePath
            : null,

        latestMigrationVersion:
          getLatestMigrationVersion(),

        appliedMigrationCount:
          migrationResult.appliedCount,

        appliedMigrations:
          migrationResult.applied,

        databaseOpen:
          database.isOpen === true,
      }
    );

    info(
      'Falcon database bootstrap completed.',
      result.data
    );

    return result;
  } catch (bootstrapError) {
    const normalizedError = normalizeError(
      bootstrapError,
      'DATABASE_BOOTSTRAP_FAILED',
      'Falcon database initialization failed.'
    );

    logError(
      'Falcon database bootstrap failed.',
      normalizedError.toJSON()
    );

    return failure(
      normalizedError.code,
      normalizedError.message,
      normalizedError.toJSON()
    );
  }
}

module.exports = {
  bootstrapDatabase,
  validateDatabaseAdapter,
};