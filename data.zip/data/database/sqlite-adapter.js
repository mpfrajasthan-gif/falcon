'use strict';

const path = require('path');

const { APP_CONFIG } = require('../../core/config/app-config');
const { ensureDirectory } = require('../../core/config/path-manager');
const {
  createFalconError,
  normalizeError,
} = require('../../core/errors/falcon-error');

const DEFAULT_DATABASE_PATH = path.join(
  APP_CONFIG.paths.dataRoot,
  'falcon.db'
);

class SQLiteAdapter {
  constructor(options = {}) {
    const {
      driverFactory,
      databasePath = DEFAULT_DATABASE_PATH,
    } = options;

    if (typeof driverFactory !== 'function') {
      throw new TypeError(
        'SQLite driver factory must be a function.'
      );
    }

    if (
      typeof databasePath !== 'string' ||
      databasePath.trim() === ''
    ) {
      throw new TypeError(
        'SQLite database path must be a non-empty string.'
      );
    }

    this.driverFactory = driverFactory;
    this.databasePath = databasePath.trim();
    this.connection = null;
  }

  get isOpen() {
    return this.connection !== null;
  }

  open() {
    if (this.isOpen) {
      return this.connection;
    }

    try {
      ensureDirectory(
        path.dirname(this.databasePath)
      );

      const connection = this.driverFactory(
        this.databasePath
      );

      if (
        !connection ||
        typeof connection !== 'object'
      ) {
        throw new TypeError(
          'SQLite driver factory returned an invalid connection.'
        );
      }

      this.connection = connection;

      this.execute('PRAGMA foreign_keys = ON;');

      return this.connection;
    } catch (error) {
      this.connection = null;

      throw normalizeError(
        error,
        'DATABASE_OPEN_FAILED',
        'Falcon database could not be opened.'
      );
    }
  }

  requireConnection() {
    if (!this.isOpen) {
      throw createFalconError(
        'DATABASE_NOT_OPEN',
        'Falcon database connection is not open.'
      );
    }

    return this.connection;
  }

  execute(sql, parameters = []) {
    this.validateStatement(sql, parameters);

    const connection = this.requireConnection();

    if (typeof connection.exec === 'function') {
      return connection.exec(sql, parameters);
    }

    if (typeof connection.prepare === 'function') {
      return connection.prepare(sql).run(...parameters);
    }

    throw createFalconError(
      'DATABASE_DRIVER_UNSUPPORTED',
      'SQLite driver does not support statement execution.'
    );
  }

  queryOne(sql, parameters = []) {
    this.validateStatement(sql, parameters);

    const connection = this.requireConnection();

    if (typeof connection.prepare !== 'function') {
      throw createFalconError(
        'DATABASE_DRIVER_UNSUPPORTED',
        'SQLite driver does not support prepared queries.'
      );
    }

    return (
      connection.prepare(sql).get(...parameters) ??
      null
    );
  }

  queryAll(sql, parameters = []) {
    this.validateStatement(sql, parameters);

    const connection = this.requireConnection();

    if (typeof connection.prepare !== 'function') {
      throw createFalconError(
        'DATABASE_DRIVER_UNSUPPORTED',
        'SQLite driver does not support prepared queries.'
      );
    }

    const rows = connection
      .prepare(sql)
      .all(...parameters);

    return Array.isArray(rows) ? rows : [];
  }

  transaction(work) {
    if (typeof work !== 'function') {
      throw new TypeError(
        'Transaction work must be a function.'
      );
    }

    const connection = this.requireConnection();

    if (typeof connection.transaction === 'function') {
      return connection.transaction(
        () => work(this)
      )();
    }

    this.execute('BEGIN TRANSACTION;');

    try {
      const result = work(this);
      this.execute('COMMIT;');
      return result;
    } catch (error) {
      try {
        this.execute('ROLLBACK;');
      } catch {
        // Preserve the original transaction error.
      }

      throw error;
    }
  }

  close() {
    if (!this.isOpen) {
      return false;
    }

    const connection = this.connection;

    try {
      if (typeof connection.close === 'function') {
        connection.close();
      }

      this.connection = null;
      return true;
    } catch (error) {
      throw normalizeError(
        error,
        'DATABASE_CLOSE_FAILED',
        'Falcon database could not be closed.'
      );
    }
  }

  validateStatement(sql, parameters) {
    if (
      typeof sql !== 'string' ||
      sql.trim() === ''
    ) {
      throw new TypeError(
        'SQL statement must be a non-empty string.'
      );
    }

    if (!Array.isArray(parameters)) {
      throw new TypeError(
        'SQL parameters must be an array.'
      );
    }
  }
}

module.exports = {
  DEFAULT_DATABASE_PATH,
  SQLiteAdapter,
};