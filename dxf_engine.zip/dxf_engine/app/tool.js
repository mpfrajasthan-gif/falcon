(() => {
  "use strict";
  const $ = (id) => document.getElementById(id),
    state = {
      file: null,
      text: "",
      repairedText: "",
      repairs: [],
      hash: "",
      outputHash: "",
      audit: null,
      draft: null,
      parsed: null,
      roleOverrides: {},
    };
  const ROLES = ["UNMAPPED","PLOT GEOMETRY","PLOT NUMBER","PLOT AREA","ROAD GEOMETRY","ROAD WIDTH/TEXT","KHASRA BOUNDARY","KHASRA NUMBER","DIMENSION","SURVEY CONTROL","SCHEME BOUNDARY","SPECIAL AREA","UTILITY"];
  function download(name, data, type = "application/json") {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([data], { type }));
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1500);
  }
  const safeName = (s) =>
    String(s || "PROJECT")
      .replace(/[^a-z0-9_-]+/gi, "_")
      .replace(/^_+|_+$/g, "")
      .toUpperCase();
  const escSql = (s) => String(s ?? "").replaceAll("'", "''");
  function pairs(text) {
    const lines = text
        .replace(/^\uFEFF/, "")
        .replace(/\r/g, "")
        .split("\n"),
      out = [];
    for (let i = 0; i + 1 < lines.length; i += 2)
      out.push([Number(lines[i].trim()), lines[i + 1].trim()]);
    return out;
  }
  function parse(text) {
    // V1.1: use the complete parser first so nested BLOCKS and every layer are audited.
    // The compact legacy parser below remains as a safe fallback for unusual ASCII DXFs.
    if (window.DxfParser) {
      try {
        const doc = new window.DxfParser().parseSync(text);
        const normalize = (e) => {
          const out = { type:e.type, layer:e.layer || "0", closed:!!(e.shape || e.closed), vertices:[] };
          if (Array.isArray(e.vertices)) out.vertices = e.vertices.map(v => [Number(v.x ?? v[0] ?? 0), Number(v.y ?? v[1] ?? 0)]);
          if (/TEXT/.test(e.type || "")) {
            out.text = e.text || "";
            out.x = Number(e.position?.x ?? e.startPoint?.x ?? 0);
            out.y = Number(e.position?.y ?? e.startPoint?.y ?? 0);
          }
          if (e.type === "LINE" && e.vertices?.length >= 2) {
            out.x1=Number(e.vertices[0].x); out.y1=Number(e.vertices[0].y);
            out.x2=Number(e.vertices[1].x); out.y2=Number(e.vertices[1].y);
          }
          return out;
        };
        const scopes = [
          { name:"TOP", raw:doc.entities || [] },
          ...Object.entries(doc.blocks || {}).map(([name, block]) => ({ name, raw:block.entities || [] })),
        ].filter(scope => scope.raw.length).map(scope => {
          const items = scope.raw.map(normalize), numericLabels = new Set(
            items.filter(e => /TEXT/.test(e.type) && /^\s*\d{1,3}[A-Za-z-]*\s*$/.test(e.text || "")).map(e => e.text.trim())
          );
          const closedPolygon = items.filter(e => /POLYLINE/.test(e.type) && e.closed && /^POLYGON$/i.test(e.layer)).length;
          const plotGeometry = items.filter(e => /POLYLINE/.test(e.type) && /^(?:PLOT|POLYGON)$/i.test(e.layer)).length;
          return { ...scope, items, numericLabels:numericLabels.size, closedPolygon, plotGeometry,
            score:closedPolygon * 1000 + numericLabels.size * 10 + plotGeometry };
        }).sort((a,b) => b.score - a.score);
        const selected = scopes[0] || { name:"TOP", items:[] };
        // Never combine geometry from different nested coordinate frames. The layer
        // table still reports the complete DXF, while preview/export use one scope.
        const entities = selected.items;
        const layers = [...new Set([
          ...Object.keys(doc.tables?.layer?.layers || {}),
          ...entities.map(e => e.layer)
        ])].sort((a,b)=>a.localeCompare(b));
        return {
          entities, layers, blocks:Object.keys(doc.blocks || {}), fullDocument:doc,
          selectedScope:selected.name,
          scopeSummary:scopes.slice(0,12).map(s => ({name:s.name, entities:s.items.length, numeric_labels:s.numericLabels, closed_polygon:s.closedPolygon, score:s.score})),
        };
      } catch (error) {
        console.warn("Complete DXF parser fallback:", error);
      }
    }
    const ps = pairs(text),
      entities = [],
      layers = new Set();
    let inEntities = false,
      current = null,
      polyline = null,
      vertex = null;
    const finishCurrent = () => {
      if (!current) return;
      if (current.type === "LWPOLYLINE" && current.pendingX != null)
        current.vertices.push([current.pendingX, current.pendingY || 0]);
      delete current.pendingX;
      delete current.pendingY;
      entities.push(current);
      layers.add(current.layer || "0");
      current = null;
    };
    const finishVertex = () => {
      if (vertex && polyline)
        polyline.vertices.push([Number(vertex.x || 0), Number(vertex.y || 0)]);
      vertex = null;
    };
    const finishPolyline = () => {
      finishVertex();
      if (polyline) {
        entities.push(polyline);
        layers.add(polyline.layer || "0");
      }
      polyline = null;
    };
    for (const [code, value] of ps) {
      if (code === 2 && value === "ENTITIES") {
        inEntities = true;
        continue;
      }
      if (!inEntities) continue;
      if (code === 0 && value === "ENDSEC") {
        finishCurrent();
        finishPolyline();
        inEntities = false;
        continue;
      }
      if (code === 0) {
        if (
          value === "LWPOLYLINE" ||
          value === "TEXT" ||
          value === "MTEXT" ||
          value === "LINE"
        ) {
          finishCurrent();
          finishPolyline();
          current = { type: value, layer: "0", vertices: [], closed: false };
          continue;
        }
        if (value === "POLYLINE") {
          finishCurrent();
          finishPolyline();
          polyline = {
            type: "POLYLINE",
            layer: "0",
            vertices: [],
            closed: false,
          };
          continue;
        }
        if (value === "VERTEX" && polyline) {
          finishVertex();
          vertex = { x: 0, y: 0 };
          continue;
        }
        if (value === "SEQEND") {
          finishPolyline();
          continue;
        }
        finishCurrent();
        continue;
      }
      const target = vertex || current || polyline;
      if (!target) continue;
      if (code === 8) target.layer = value;
      if (code === 70 && (current?.type === "LWPOLYLINE" || polyline))
        target.closed = (Number(value) & 1) === 1;
      if (vertex) {
        if (code === 10) vertex.x = Number(value);
        if (code === 20) vertex.y = Number(value);
        continue;
      }
      if (current?.type === "LWPOLYLINE") {
        if (code === 10) {
          if (current.pendingX != null)
            current.vertices.push([current.pendingX, current.pendingY || 0]);
          current.pendingX = Number(value);
          current.pendingY = 0;
        } else if (code === 20) current.pendingY = Number(value);
      } else if (current?.type === "TEXT" || current?.type === "MTEXT") {
        if (code === 1 || code === 3)
          current.text = (current.text || "") + value;
        if (code === 10) current.x = Number(value);
        if (code === 20) current.y = Number(value);
      } else if (current?.type === "LINE") {
        if (code === 10) current.x1 = Number(value);
        if (code === 20) current.y1 = Number(value);
        if (code === 11) current.x2 = Number(value);
        if (code === 21) current.y2 = Number(value);
      }
    }
    return { entities, layers: [...layers] };
  }
  function inside(point, poly) {
    let yes = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const a = poly[i],
        b = poly[j];
      if (
        a[1] > point[1] !== b[1] > point[1] &&
        point[0] <
          ((b[0] - a[0]) * (point[1] - a[1])) /
            (b[1] - a[1] || Number.EPSILON) +
            a[0]
      )
        yes = !yes;
    }
    return yes;
  }
  function area(vertices) {
    let sum = 0;
    for (let i = 0; i < vertices.length; i++) {
      const a = vertices[i],
        b = vertices[(i + 1) % vertices.length];
      sum += a[0] * b[1] - b[0] * a[1];
    }
    return Math.abs(sum) / 2;
  }
  function centroid(vertices) {
    let a2 = 0,
      x = 0,
      y = 0;
    for (let i = 0; i < vertices.length; i++) {
      const p = vertices[i],
        q = vertices[(i + 1) % vertices.length],
        c = p[0] * q[1] - q[0] * p[1];
      a2 += c;
      x += (p[0] + q[0]) * c;
      y += (p[1] + q[1]) * c;
    }
    return Math.abs(a2) < 1e-9
      ? vertices.reduce(
          (s, p) => [
            s[0] + p[0] / vertices.length,
            s[1] + p[1] / vertices.length,
          ],
          [0, 0],
        )
      : [x / (3 * a2), y / (3 * a2)];
  }
  function solve3(rows, values) {
    const m = rows.map((r, i) => [...r, values[i]]);
    for (let c = 0; c < 3; c++) {
      let pivot = c;
      for (let r = c + 1; r < 3; r++) if (Math.abs(m[r][c]) > Math.abs(m[pivot][c])) pivot = r;
      [m[c], m[pivot]] = [m[pivot], m[c]];
      if (Math.abs(m[c][c]) < 1e-12) return null;
      const d = m[c][c]; for (let j = c; j < 4; j++) m[c][j] /= d;
      for (let r = 0; r < 3; r++) if (r !== c) { const f = m[r][c]; for (let j = c; j < 4; j++) m[r][j] -= f * m[c][j]; }
    }
    return m.map(r => r[3]);
  }
  function affineFit(local, world) {
    if (local.length < 3 || local.length !== world.length) return null;
    let sx=0,sy=0,sxx=0,syy=0,sxy=0, su=0,sv=0,sxu=0,syu=0,sxv=0,syv=0;
    local.forEach((p,i)=>{ const [x,y]=p,[u,v]=world[i]; sx+=x;sy+=y;sxx+=x*x;syy+=y*y;sxy+=x*y;su+=u;sv+=v;sxu+=x*u;syu+=y*u;sxv+=x*v;syv+=y*v; });
    const normal=[[sxx,sxy,sx],[sxy,syy,sy],[sx,sy,local.length]], ax=solve3(normal,[sxu,syu,su]), ay=solve3(normal,[sxv,syv,sv]);
    if (!ax || !ay) return null;
    let sum=0,max=0; local.forEach((p,i)=>{ const u=ax[0]*p[0]+ax[1]*p[1]+ax[2],v=ay[0]*p[0]+ay[1]*p[1]+ay[2],e=Math.hypot(u-world[i][0],v-world[i][1]);sum+=e*e;max=Math.max(max,e); });
    return { pairs:local.length, x:ax, y:ay, rms_m:Math.sqrt(sum/local.length), max_error_m:max };
  }
  function pointXY(e) { const p=e?.position || e?.vertices?.[0] || e?.startPoint; return p ? [Number(p.x ?? p[0]),Number(p.y ?? p[1])] : null; }
  function coordinateIntel(parsed, crs) {
    const doc=parsed.fullDocument, nested=doc?.blocks?.HHHH?.entities || [], top=doc?.entities || [];
    const local=nested.filter(e=>e.type==="POINT" && /SURVEYPOINT/i.test(e.layer||"")).map(pointXY).filter(Boolean);
    const world=top.filter(e=>e.type==="POINT" && /SURVEYPOINT/i.test(e.layer||"")).map(pointXY).filter(Boolean);
    const pairCount=Math.min(local.length,world.length), fit=affineFit(local.slice(0,pairCount),world.slice(0,pairCount));
    const epsg=String(crs||"").match(/326\d{2}/)?.[0] || null;
    return { source_crs:crs, epsg, local_survey_points:local.length, world_survey_points:world.length, transform:fit, status:fit && fit.rms_m < .05 ? "CALIBRATED" : pairCount ? "REVIEW REQUIRED" : "NO CONTROL PAIRS" };
  }
  function buildTopology(entities, unitScale, overrides = {}) {
    if (!window.jsts) return { plots:[], candidate_faces:0, verified_faces:0, ambiguous_faces:0, missing_labels:[], dangles:0, error:"Topology library unavailable" };
    const mapped=(name,regex,role)=>overrides[name]?overrides[name]===role:regex.test(name),
      source=entities.filter(e=>(mapped(e.layer,/^PLOT$/i,"PLOT GEOMETRY")||mapped(e.layer,/ROAD/i,"ROAD GEOMETRY"))&&(e.type==="LINE"||/POLYLINE/.test(e.type))),
      labels=entities.filter(e=>/TEXT/.test(e.type)&&mapped(e.layer,/^PLOT NO\.?$/i,"PLOT NUMBER")&&/^\s*\d{1,3}[A-Za-z-]*\s*$/.test(e.text||"")),
      gf=new jsts.geom.GeometryFactory(), C=jsts.geom.Coordinate, lines=[], points=[];
    source.forEach(e=>{ const vs=e.type==="LINE"?[[e.x1,e.y1],[e.x2,e.y2]]:e.vertices; if(!vs||vs.length<2)return; vs.forEach(p=>points.push(p)); for(let i=0;i+1<vs.length;i++)lines.push(gf.createLineString([new C(vs[i][0],vs[i][1]),new C(vs[i+1][0],vs[i+1][1])])); if(e.closed&&vs.length>2)lines.push(gf.createLineString([new C(vs[vs.length-1][0],vs[vs.length-1][1]),new C(vs[0][0],vs[0][1])])); });
    if (!lines.length) return { plots:[], candidate_faces:0, verified_faces:0, ambiguous_faces:0, missing_labels:labels.map(x=>x.text.trim()), dangles:0, error:"No mapped plot/road linework" };
    try {
      const xs=points.map(p=>p[0]),ys=points.map(p=>p[1]),diag=Math.hypot(Math.max(...xs)-Math.min(...xs),Math.max(...ys)-Math.min(...ys)),tolerance=Math.max(.001,Math.min(.1,diag*1e-7)),
        multi=gf.createMultiLineString(lines), snapped=jsts.operation.overlay.snap.GeometrySnapper.snapToSelf(multi,tolerance,true), noded=jsts.operation.union.UnaryUnionOp.union(snapped), polygonizer=new jsts.operation.polygonize.Polygonizer();
      polygonizer.add(noded);
      const it=polygonizer.getPolygons().iterator(), locator=new jsts.algorithm.PointLocator(), faces=[], verified=[], captured=new Set();
      while(it.hasNext()) faces.push(it.next());
      faces.forEach(poly=>{ const found=labels.filter(t=>locator.intersects(new C(t.x,t.y),poly)); if(found.length!==1)return; const ring=Array.from(poly.getExteriorRing().getCoordinates()).map(p=>[p.x,p.y]); if(ring.length>3&&Math.hypot(ring[0][0]-ring.at(-1)[0],ring[0][1]-ring.at(-1)[1])<1e-8)ring.pop(); const plotNo=found[0].text.trim(); if(captured.has(plotNo))return; captured.add(plotNo); const lengths=ring.map((p,i)=>{const q=ring[(i+1)%ring.length];return Math.hypot(q[0]-p[0],q[1]-p[1])*Number(unitScale)*3.280839895;}); verified.push({plot_no:plotNo,layer:"TOPOLOGY_BUILDER",vertices:ring,centroid:centroid(ring),area_sq_m:area(ring)*Number(unitScale)*Number(unitScale),area_sq_yd:area(ring)*Number(unitScale)*Number(unitScale)*1.195990046,side_lengths_ft:lengths,topology_verified:true}); });
      const missing=[...new Set(labels.map(x=>x.text.trim()))].filter(x=>!captured.has(x));
      return { plots:verified, candidate_faces:faces.length, verified_faces:verified.length, ambiguous_faces:faces.length-verified.length, missing_labels:missing, dangles:polygonizer.getDangles().size(), cut_edges:polygonizer.getCutEdges().size(), snap_tolerance:tolerance };
    } catch(error) { return { plots:[],candidate_faces:0,verified_faces:0,ambiguous_faces:0,missing_labels:labels.map(x=>x.text.trim()),dangles:0,error:error.message }; }
  }
  function cleanVertices(vertices) {
    const out = vertices.map((p) => [...p]);
    if (
      out.length > 3 &&
      Math.hypot(
        out[0][0] - out[out.length - 1][0],
        out[0][1] - out[out.length - 1][1],
      ) < 1e-9
    )
      out.pop();
    return out;
  }
  function safeRepair(text, unitScale) {
    const ps = pairs(text).map(([code, value]) => [code, value]),
      changes = [],
      tolerance = 0.05 / Number(unitScale || 1);
    let inEntities = false;
    for (let i = 0; i < ps.length; i++) {
      if (ps[i][0] === 2 && ps[i][1] === "ENTITIES") {
        inEntities = true;
        continue;
      }
      if (inEntities && ps[i][0] === 0 && ps[i][1] === "ENDSEC") {
        inEntities = false;
        continue;
      }
      if (!inEntities || ps[i][0] !== 0 || ps[i][1] !== "LWPOLYLINE")
        continue;
      let end = i + 1;
      while (end < ps.length && ps[end][0] !== 0) end++;
      const entity = ps.slice(i, end),
        layer = entity.find((p) => p[0] === 8)?.[1] || "0";
      if (
        !/plot|residential/i.test(layer) ||
        /road|facility|plant|other|informal|ibadat/i.test(layer)
      )
        continue;
      const vertices = [];
      let current = null;
      entity.forEach((p, index) => {
        if (p[0] === 10) {
          current = { x: Number(p[1]), y: 0, xIndex: index, yIndex: -1 };
          vertices.push(current);
        } else if (p[0] === 20 && current && current.yIndex < 0) {
          current.y = Number(p[1]);
          current.yIndex = index;
        }
      });
      if (vertices.length < 3) continue;
      const first = vertices[0],
        last = vertices[vertices.length - 1],
        exactDuplicate = Math.hypot(last.x - first.x, last.y - first.y) < 1e-9;
      if (exactDuplicate && vertices.length > 3) {
        const remove = new Set([last.xIndex, last.yIndex].filter((x) => x >= 0));
        const count = entity.find((p) => p[0] === 90);
        if (count) count[1] = String(Math.max(3, Number(count[1]) - 1));
        const compact = entity.filter((_, index) => !remove.has(index));
        ps.splice(i, end - i, ...compact);
        end = i + compact.length;
        changes.push({
          rule: "DUPLICATE_CLOSING_VERTEX",
          layer,
          action: "Removed an exact duplicate final vertex; coordinates unchanged.",
        });
      }
      const currentEnd = (() => {
          let value = i + 1;
          while (value < ps.length && ps[value][0] !== 0) value++;
          return value;
        })(),
        currentEntity = ps.slice(i, currentEnd),
        flagIndex = currentEntity.findIndex((p) => p[0] === 70),
        oldFlag = flagIndex >= 0 ? Number(currentEntity[flagIndex][1]) : 0,
        endpointGap = exactDuplicate
          ? 0
          : Math.hypot(last.x - first.x, last.y - first.y);
      if ((oldFlag & 1) === 0 && endpointGap <= tolerance) {
        if (flagIndex >= 0) ps[i + flagIndex][1] = String(oldFlag | 1);
        else {
          const layerIndex = currentEntity.findIndex((p) => p[0] === 8);
          ps.splice(i + Math.max(1, layerIndex + 1), 0, [70, "1"]);
        }
        changes.push({
          rule: "NEAR_CLOSED_PLOT_FLAG",
          layer,
          endpoint_gap_m: Number((endpointGap * Number(unitScale)).toFixed(6)),
          action: "Set the closed flag without moving any vertex.",
        });
      }
      i = currentEnd - 1;
    }
    if (!ps.some((p) => p[0] === 0 && p[1] === "EOF")) {
      ps.push([0, "EOF"]);
      changes.push({
        rule: "MISSING_EOF",
        action: "Added the required DXF EOF marker.",
      });
    }
    return {
      text: ps.map(([code, value]) => `${code}\n${value}`).join("\n") + "\n",
      changes,
    };
  }
  function analyse(parsed, unitScale, crs, overrides = {}) {
    const mapped = (name, regex, role) => overrides[name] ? overrides[name] === role : regex.test(name),
      blocks = [],
      warnings = [],
      entities = parsed.entities,
      coordinates = coordinateIntel(parsed, crs),
      inferredScale = coordinates.transform ? Math.sqrt(Math.abs(coordinates.transform.x[0]*coordinates.transform.y[1]-coordinates.transform.x[1]*coordinates.transform.y[0])) : null,
      measurementScale = inferredScale && coordinates.status === "CALIBRATED" ? inferredScale : Number(unitScale),
      polys = entities.filter(
        (e) => /POLYLINE/.test(e.type) && e.vertices.length >= 3,
      ),
      texts = entities.filter((e) => /TEXT/.test(e.type) && e.text),
      plotLabels = texts.filter((e) => mapped(e.layer,/^PLOT NO\.?$/i,"PLOT NUMBER") && /^\s*\d{1,3}[A-Za-z-]*\s*$/.test(e.text)),
      uniquePlotLabels = [...new Set(plotLabels.map(e => e.text.trim()))],
      candidates = polys.filter((e) => mapped(e.layer,/^(?:PLOT(?:S| BOUNDARY| POLYGON)?|POLYGON)$/i,"PLOT GEOMETRY") && e.closed),
      plotLinework = entities.filter((e) => mapped(e.layer,/^(?:PLOT|POLYGON)$/i,"PLOT GEOMETRY") && (e.type === "LINE" || /POLYLINE/.test(e.type))),
      roads = parsed.layers.filter((x) => mapped(x,/ROAD/i,"ROAD GEOMETRY")),
      khasra = parsed.layers.filter((x) => mapped(x,/KHASRA/i,"KHASRA BOUNDARY")),
      specials = parsed.layers.filter((x) => mapped(x,/facility|plant|other|informal|ibadat|w\.t|s\.w\.m|scheme boundary/i,"SPECIAL AREA")),
      topology = !candidates.length && plotLinework.length ? buildTopology(entities,measurementScale,overrides) : null;
    if (!candidates.length && plotLinework.length) {
      if (topology?.error) blocks.push(`Topology Builder failed: ${topology.error}.`);
      else if (topology.verified_faces < uniquePlotLabels.length) blocks.push(`Topology Builder verified ${topology.verified_faces}/${uniquePlotLabels.length} labelled plot faces; ${topology.missing_labels.length} labels remain open or ambiguous and require AutoCAD review.`);
      warnings.push(`Topology diagnostics: ${topology?.candidate_faces||0} candidate faces, ${topology?.ambiguous_faces||0} ambiguous faces, ${topology?.dangles||0} dangling edges.`);
      warnings.push("Khasra and scheme boundaries were excluded from plot construction.");
    } else if (!candidates.length) blocks.push("No approved PLOT boundary geometry was found on the mapped plot layer.");
    if (!uniquePlotLabels.length) blocks.push("No numeric plot labels were detected on the PLOT NO. layer.");
    if (!roads.length) blocks.push("No ROAD layer detected.");
    if (!khasra.length) warnings.push("No KHASRA layer detected.");
    if (!specials.length) warnings.push("No explicit facility/special layer detected; special areas may require manual layer-role mapping.");
    const scale = measurementScale,
      resolvedFaces = candidates.map((poly, index) => {
        const vertices = cleanVertices(poly.vertices);
        const numbers = plotLabels.filter((t) => inside([t.x, t.y], vertices));
        const plotNo = numbers.length === 1 ? numbers[0].text.trim() : "";
        const lengths = vertices.map((p, i) => {
          const q = vertices[(i + 1) % vertices.length];
          return Math.hypot(q[0] - p[0], q[1] - p[1]) * scale * 3.280839895;
        });
        return {
          plot_no: plotNo,
          layer: poly.layer,
          vertices,
          centroid: centroid(vertices),
          area_sq_m: area(vertices) * scale * scale,
          area_sq_yd: area(vertices) * scale * scale * 1.195990046,
          side_lengths_ft: lengths,
          source_index:index + 1,
          contained_labels:numbers.length,
        };
      }),
      // A source block may include both individual plots and larger enclosing polygons.
      // For every label select the smallest exact-one-label face without changing vertices.
      bestByLabel = new Map();
    resolvedFaces.filter(face => face.plot_no).forEach(face => {
      const prior = bestByLabel.get(face.plot_no);
      if (!prior || face.area_sq_m < prior.area_sq_m) bestByLabel.set(face.plot_no, face);
    });
    const closedPlots = [...bestByLabel.values()],
      plots = candidates.length ? closedPlots : (topology?.plots || []);
    if (candidates.length) {
      const missing = uniquePlotLabels.filter(label => !bestByLabel.has(label));
      if (missing.length) blocks.push(`Closed-polygon resolver verified ${closedPlots.length}/${uniquePlotLabels.length} plot labels; unresolved: ${missing.join(", ")}.`);
      const ignored = candidates.length - closedPlots.length;
      if (ignored > 0) warnings.push(`${ignored} enclosing, duplicate or unlabelled POLYGON face(s) were safely excluded; original DXF was not modified.`);
    }
    const roadTextEntities = texts.filter(t => /^ROAD\s+\d+(?:\.\d+)?['’]?\s*WIDE$/i.test((t.text || "").trim())),
      roadFeatures = roadTextEntities.map((t, index) => ({
        id:`ROAD-${index + 1}`, name:(t.text || "").trim(),
        width_ft:Number(((t.text || "").match(/\d+(?:\.\d+)?/) || [0])[0]),
        geometry_type:"LABEL_POINT", label_point:[t.x,t.y], vertices:[[t.x,t.y]],
      })),
      specialTextEntities = texts.filter(t => /^(?:OTHER LAND|INFORMAL|FACILITY|PLANTATION|IBADATGAH|S\.W\.M\.|W\.T\.|M\.T\.)$/i.test((t.text || "").trim())),
      specialByFace = new Map();
    specialTextEntities.forEach(t => {
      const containing = resolvedFaces.filter(face => inside([t.x,t.y],face.vertices)).sort((a,b) => a.area_sq_m - b.area_sq_m);
      if (!containing.length) return;
      const face = containing[0], key = `${face.source_index}:${(t.text || "").trim().toUpperCase()}`;
      if (!specialByFace.has(key)) specialByFace.set(key, {
        name:(t.text || "").trim(), category:(t.text || "").trim().toUpperCase(), layer:face.layer,
        vertices:face.vertices, centroid:face.centroid, area_sq_m:face.area_sq_m,
        area_sq_yd:face.area_sq_yd, source_index:face.source_index,
      });
    });
    const specialAreas = [...specialByFace.values()], unresolvedSpecials = specialTextEntities.length - specialAreas.length;
    if (unresolvedSpecials > 0) warnings.push(`${unresolvedSpecials} special-area label(s) have no closed containing POLYGON; retained for AutoCAD/category review.`);
    const nums = plots.map((p) => p.plot_no).filter(Boolean),
      dups = [...new Set(nums.filter((n, i) => nums.indexOf(n) !== i))];
    if (dups.length)
      blocks.push("Duplicate plot number(s): " + dups.join(", "));
    const zero = candidates.reduce(
      (n, p) =>
        n +
        cleanVertices(p.vertices).filter((v, i, vertices) => {
          const q = vertices[(i + 1) % vertices.length];
          return Math.hypot(q[0] - v[0], q[1] - v[1]) < 1e-7;
        }).length,
      0,
    );
    if (zero) blocks.push(`${zero} zero-length polygon side(s) detected.`);
    const autoRoleForLayer = (name) => {
        if (/^PLOT NO\.?$/i.test(name)) return "PLOT NUMBER";
        if (/^(?:PLOT(?:S| AREA| BOUNDARY| POLYGON)?|POLYGON)$/i.test(name)) return /AREA/i.test(name) ? "PLOT AREA" : "PLOT GEOMETRY";
        if (/KHASRA.*(?:TEST|TEXT|NO)/i.test(name)) return "KHASRA NUMBER";
        if (/KHASRA/i.test(name)) return "KHASRA BOUNDARY";
        if (/ROAD.*TEXT/i.test(name)) return "ROAD WIDTH/TEXT";
        if (/ROAD/i.test(name)) return "ROAD GEOMETRY";
        if (/DIMENSION|DIMANSION|FORMATE|FORMAT/i.test(name)) return "DIMENSION";
        if (/SURVEYPOINT|CODE|NAME|HEIGHT|T\.B\.M/i.test(name)) return "SURVEY CONTROL";
        if (/SCHEME BOUNDARY/i.test(name)) return "SCHEME BOUNDARY";
        if (/FACILITY|PLANT|OTHER|INFORMAL|IBADAT|S\.W\.M|W\.T/i.test(name)) return "SPECIAL AREA";
        if (/EPLINE|HT\.LINE|L\.T LINE/i.test(name)) return "UTILITY";
        return "UNMAPPED";
      },
      roleForLayer = (name) => overrides[name] || autoRoleForLayer(name),
      layerSummary = parsed.layers.map((name) => {
        const items = entities.filter((e) => e.layer === name), types = {};
        items.forEach((e) => { types[e.type] = (types[e.type] || 0) + 1; });
        return { name, role:roleForLayer(name), entities:items.length, types };
      });
    if (coordinates.status === "NO CONTROL PAIRS") warnings.push("No paired survey-control points found; precise coordinate calibration is unavailable.");
    else if (coordinates.status === "REVIEW REQUIRED") blocks.push(`Survey coordinate calibration residual is ${coordinates.transform.rms_m.toFixed(4)} m; control points require review.`);
    return {
      approved: blocks.length === 0,
      safeRepairAvailable: candidates.length > 0 && zero > 0,
      blocks,
      warnings,
      plots,
      metrics: {
        entities: entities.length,
        layers: parsed.layers.length,
        plot_labels: uniquePlotLabels.length,
        plot_faces: plots.length,
        candidate_faces: topology?.candidate_faces || candidates.length,
        unresolved_labels: topology?.missing_labels?.length || 0,
        road_layers: roads.length,
        khasra_layers: khasra.length,
        special_layers: specials.length,
        road_features: roadFeatures.length,
        special_features: specialAreas.length,
        control_pairs: coordinates.transform?.pairs || 0,
        drawing_scale_m: Number(measurementScale.toFixed(8)),
        selected_scope: parsed.selectedScope || "ENTITIES",
      },
      layerRoles: { plotLabels:"PLOT NO.", plotGeometry:"PLOT", roads, khasra, specials },
      layerSummary,
      layers: parsed.layers,
      coordinates,
      role_overrides: overrides,
      topology,
      roads: roadFeatures,
      special_areas: specialAreas,
    };
  }
  function render(parsed, audit) {
    const svg = $("svg");
    svg.innerHTML = "";
    const polys = parsed.entities.filter(
        (e) => /POLYLINE/.test(e.type) && e.vertices.length >= 3,
      ),
      lines = parsed.entities.filter(e => e.type === "LINE" && Number.isFinite(e.x1) && Number.isFinite(e.x2)),
      texts = parsed.entities.filter(e => /TEXT/.test(e.type) && e.text && Number.isFinite(e.x)),
      all = [...polys.flatMap((p) => p.vertices), ...lines.flatMap(e => [[e.x1,e.y1],[e.x2,e.y2]])];
    if (!all.length) return;
    const xs = all.map((p) => p[0]),
      ys = all.map((p) => p[1]),
      minX = Math.min(...xs),
      maxX = Math.max(...xs),
      minY = Math.min(...ys),
      maxY = Math.max(...ys),
      pad = 25,
      s = Math.min(
        (1000 - pad * 2) / (maxX - minX || 1),
        (600 - pad * 2) / (maxY - minY || 1),
      ),
      pt = (p) => [pad + (p[0] - minX) * s, 575 - (p[1] - minY) * s];
    for (const p of polys) {
      const node = document.createElementNS(
        "http://www.w3.org/2000/svg",
        "polygon",
      );
      node.setAttribute(
        "points",
        p.vertices.map((v) => pt(v).join(",")).join(" "),
      );
      const isRoad = /road/i.test(p.layer),
        isSpecial = /facility|plant|other|informal|ibadat/i.test(p.layer);
      node.setAttribute(
        "fill",
        isRoad ? "#515b5f" : isSpecial ? "#85905b" : "#f3ead6",
      );
      node.setAttribute("stroke", "#2b302d");
      node.setAttribute("stroke-width", "1");
      svg.appendChild(node);
    }
    for (const p of audit.plots.filter(p=>p.topology_verified)) {
      const node=document.createElementNS("http://www.w3.org/2000/svg","polygon");node.setAttribute("points",p.vertices.map(v=>pt(v).join(",")).join(" "));node.setAttribute("fill","#f3ead6");node.setAttribute("fill-opacity",".92");node.setAttribute("stroke","#b89532");node.setAttribute("stroke-width","1.4");svg.appendChild(node);
    }
    for (const p of audit.special_areas || []) { const node=document.createElementNS("http://www.w3.org/2000/svg","polygon");node.setAttribute("points",p.vertices.map(v=>pt(v).join(",")).join(" "));node.setAttribute("fill",/INFORMAL/i.test(p.category)?"#a96c47":"#85905b");node.setAttribute("fill-opacity",".9");node.setAttribute("stroke","#4d5636");node.setAttribute("stroke-width","1.2");svg.appendChild(node); }
    for (const e of lines) {
      const node=document.createElementNS("http://www.w3.org/2000/svg","line"), a=pt([e.x1,e.y1]),b=pt([e.x2,e.y2]);
      node.setAttribute("x1",a[0]);node.setAttribute("y1",a[1]);node.setAttribute("x2",b[0]);node.setAttribute("y2",b[1]);
      node.setAttribute("stroke",/ROAD/i.test(e.layer)?"#515b5f":"#333a36");node.setAttribute("stroke-width",/PLOT/i.test(e.layer)?"1.5":"1");svg.appendChild(node);
    }
    for (const e of texts.filter(e=>/^PLOT NO\.?$/i.test(e.layer))) { const q=pt([e.x,e.y]),t=document.createElementNS("http://www.w3.org/2000/svg","text");t.textContent=e.text.trim();t.setAttribute("x",q[0]);t.setAttribute("y",q[1]);t.setAttribute("text-anchor","middle");t.setAttribute("font-size","8");t.setAttribute("font-weight","800");svg.appendChild(t); }
    for (const p of audit.plots) {
      if (!p.plot_no) continue;
      const q = pt(p.centroid),
        t = document.createElementNS("http://www.w3.org/2000/svg", "text");
      t.textContent = p.plot_no;
      t.setAttribute("x", q[0]);
      t.setAttribute("y", q[1]);
      t.setAttribute("text-anchor", "middle");
      t.setAttribute("font-size", "9");
      t.setAttribute("font-weight", "800");
      svg.appendChild(t);
    }
    $("empty").style.display = "none";
  }
  async function sha256(text) {
    const hash = await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(text),
    );
    return [...new Uint8Array(hash)]
      .map((x) => x.toString(16).padStart(2, "0"))
      .join("");
  }
  function makeDraft(audit, project, crs, hash) {
    return {
      app: "Falcon Hybrid",
      schema_version: "1.0-draft",
      project: {
        name: project,
        source_crs: crs,
        source_sha256: hash,
        approval_status: "APPROVED",
        approved_at: new Date().toISOString(),
      },
      layers: { plots: audit.plots, roads: audit.roads || [], special_areas: audit.special_areas || [] },
      import_profile: { renderer:"FALCON_V10_POLISHED_2D", road_surface_rule:"BACKGROUND_GAPS", road_labels:"ROAD_TEXT_POINTS", original_geometry_locked:true },
      audit: { metrics: audit.metrics, warnings: audit.warnings },
    };
  }
  function sqlDraft(d) {
    const plotRows = d.layers.plots.map(p => `INSERT INTO plots(project_id,plot_no,layer,status,area_sq_yd,centroid_x,centroid_y,vertices_json,side_lengths_ft_json) VALUES(1,'${escSql(p.plot_no)}','${escSql(p.layer)}','Available',${p.area_sq_yd.toFixed(6)},${p.centroid[0]},${p.centroid[1]},'${escSql(JSON.stringify(p.vertices))}','${escSql(JSON.stringify(p.side_lengths_ft))}');`).join("\n"),
      roadRows = (d.layers.roads || []).map(r => `INSERT INTO roads(project_id,name,width_ft,vertices_json) VALUES(1,'${escSql(r.name)}',${Number(r.width_ft || 0)},'${escSql(JSON.stringify(r.vertices || []))}');`).join("\n"),
      specialRows = (d.layers.special_areas || []).map(s => `INSERT INTO special_areas(project_id,name,category,vertices_json) VALUES(1,'${escSql(s.name)}','${escSql(s.category)}','${escSql(JSON.stringify(s.vertices || []))}');`).join("\n");
    return `PRAGMA foreign_keys=ON;\nCREATE TABLE projects(id INTEGER PRIMARY KEY,name TEXT NOT NULL,source_crs TEXT NOT NULL,source_sha256 TEXT NOT NULL,approval_status TEXT NOT NULL,approved_at TEXT NOT NULL);\nCREATE TABLE plots(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL REFERENCES projects(id),plot_no TEXT NOT NULL,layer TEXT,status TEXT NOT NULL DEFAULT 'Available',area_sq_yd REAL,centroid_x REAL,centroid_y REAL,vertices_json TEXT NOT NULL,side_lengths_ft_json TEXT,UNIQUE(project_id,plot_no));\nCREATE TABLE special_areas(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL REFERENCES projects(id),name TEXT,category TEXT,vertices_json TEXT NOT NULL);\nCREATE TABLE roads(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL REFERENCES projects(id),name TEXT,width_ft REAL,vertices_json TEXT NOT NULL);\nINSERT INTO projects(id,name,source_crs,source_sha256,approval_status,approved_at) VALUES(1,'${escSql(d.project.name)}','${escSql(d.project.source_crs)}','${d.project.source_sha256}','APPROVED','${d.project.approved_at}');\n${plotRows}\n${roadRows}\n${specialRows}\n`;
  }
  function show(a) {
    $("status").textContent = a.approved
      ? "APPROVED FOR FALCON"
      : "TOPOLOGY / ADMIN REVIEW REQUIRED";
    $("status").className = "status " + (a.approved ? "good" : "bad");
    $("metrics").innerHTML = Object.entries(a.metrics)
      .map(
        ([k, v]) => `<div class="metric"><small>${k}</small><b>${v}</b></div>`,
      )
      .join("");
    $("layerCount").textContent = `${a.layerSummary.length} layers`;
    $("layerList").innerHTML = a.layerSummary.map((layer) => {
      const types = Object.entries(layer.types).map(([type,count]) => `${type}: ${count}`).join(" • ") || "Table definition only";
      const options=ROLES.map(role=>`<option${role===layer.role?" selected":""}>${role}</option>`).join("");
      return `<div class="layer-row"><div><div class="layer-name">${layer.name.replaceAll("&","&amp;").replaceAll("<","&lt;")}</div><div class="layer-meta">${layer.entities} entities${types ? ` • ${types}` : ""}</div></div><select class="layer-role-select" data-layer="${encodeURIComponent(layer.name)}">${options}</select></div>`;
    }).join("");
    document.querySelectorAll(".layer-role-select").forEach(select=>select.onchange=()=>{ state.roleOverrides[decodeURIComponent(select.dataset.layer)]=select.value; });
    const repairItems = state.repairs.map(
      (x) => `<li class="warning">SAFE REPAIR: ${x.rule} — ${x.action}</li>`,
    );
    const topologyItems = a.topology?.missing_labels?.length ? [`<li class="blocking">AUTOCAD REVIEW — unresolved plot labels: ${a.topology.missing_labels.slice(0,40).join(", ")}${a.topology.missing_labels.length>40?" …":""}</li>`] : [];
    $("issues").innerHTML =
      [
        ...repairItems,
        ...topologyItems,
        ...a.blocks.map((x) => `<li class="blocking">BLOCKING: ${x}</li>`),
        ...a.warnings.map((x) => `<li class="warning">WARNING: ${x}</li>`),
        `<li class="warning">COORDINATES: ${a.coordinates.status} • local ${a.coordinates.local_survey_points} • world ${a.coordinates.world_survey_points}${a.coordinates.transform ? ` • RMS ${a.coordinates.transform.rms_m.toFixed(6)} m` : ""}</li>`,
      ].join("") || "<li>No blocking issues detected.</li>";
    ["approvedDxf", "manifest", "database", "sql"].forEach(
      (id) => ($(id).disabled = !a.approved),
    );
    $("report").disabled = false;
    $("repair").disabled = a.approved || !a.safeRepairAvailable;
    $("saveRoles").disabled = false;
    $("resetRoles").disabled = false;
  }
  $("audit").onclick = async () => {
    const file = $("file").files[0],
      project = $("project").value.trim(),
      crs = $("crs").value.trim();
    if (!file || !project || !crs)
      return alert("DXF file, project name and source CRS are required");
    const text = await file.text();
    if (!/SECTION[\s\S]*ENTITIES/.test(text))
      return alert("This does not appear to be a valid ASCII DXF");
    const parsed = parse(text),
      savedRoles = JSON.parse(localStorage.getItem(`falconRoles:${safeName(project)}`) || "{}"),
      audit = analyse(parsed, $("unit").value, crs, savedRoles),
      hash = await sha256(text);
    state.file = file;
    state.text = text;
    state.repairedText = "";
    state.repairs = [];
    state.hash = hash;
    state.outputHash = hash;
    state.audit = audit;
    state.parsed = parsed;
    state.roleOverrides = savedRoles;
    state.draft = makeDraft(audit, project, crs, hash);
    render(parsed, audit);
    show(audit);
  };
  $("repair").onclick = async () => {
    if (!state.text) return;
    const result = safeRepair(state.text, $("unit").value);
    if (!result.changes.length)
      return alert(
        "No safe automatic repair is available. Remaining blocking items require AutoCAD correction.",
      );
    const parsed = parse(result.text),
      audit = analyse(parsed, $("unit").value, $("crs").value.trim(), state.roleOverrides),
      outputHash = await sha256(result.text);
    state.repairedText = result.text;
    state.repairs = result.changes;
    state.outputHash = outputHash;
    state.audit = audit;
    state.parsed = parsed;
    state.draft = makeDraft(
      audit,
      $("project").value.trim(),
      $("crs").value.trim(),
      outputHash,
    );
    render(parsed, audit);
    show(audit);
    alert(
      `${result.changes.length} safe repair(s) applied to a derived copy. Original upload remains locked.`,
    );
  };
  $("approvedDxf").onclick = () =>
    download(
      `${safeName($("project").value)}_FALCON_APPROVED.dxf`,
      state.repairedText || state.text,
      "application/dxf",
    );
  $("manifest").onclick = () =>
    download(
      `${safeName($("project").value)}_APPROVAL.json`,
      JSON.stringify(
        {
          tool: "Falcon DXF Intelligence Engine V1.5",
          approved: true,
          source_file: state.file.name,
          source_sha256: state.hash,
          approved_output_sha256: state.outputHash || state.hash,
          project: $("project").value,
          crs: $("crs").value,
          approved_at: new Date().toISOString(),
          original_upload_modified: false,
          vertex_coordinates_modified: false,
          safe_repairs: state.repairs,
          audit: state.audit,
        },
        null,
        2,
      ),
    );
  $("database").onclick = () =>
    download(
      `${safeName($("project").value)}_FALCON_DB_DRAFT.json`,
      JSON.stringify(state.draft, null, 2),
    );
  $("sql").onclick = () =>
    download(
      `${safeName($("project").value)}_FALCON_DB_DRAFT.sql`,
      sqlDraft(state.draft),
      "text/sql",
    );
  $("report").onclick = () =>
    download(
      `${safeName($("project").value)}_DXF_AUDIT.json`,
      JSON.stringify(
        {
          file: state.file?.name,
          hash: state.hash,
          output_hash: state.outputHash || state.hash,
          safe_repairs: state.repairs,
          audit: state.audit,
          generated_at: new Date().toISOString(),
        },
        null,
        2,
      ),
    );
  $("saveRoles").onclick = () => {
    if (!state.parsed) return;
    localStorage.setItem(`falconRoles:${safeName($("project").value)}`,JSON.stringify(state.roleOverrides));
    state.audit=analyse(state.parsed,$("unit").value,$("crs").value.trim(),state.roleOverrides);
    state.draft=makeDraft(state.audit,$("project").value.trim(),$("crs").value.trim(),state.outputHash||state.hash);
    render(state.parsed,state.audit);show(state.audit);alert("Layer role template saved for this project and audit refreshed.");
  };
  $("resetRoles").onclick = () => {
    if (!state.parsed) return;
    state.roleOverrides={};localStorage.removeItem(`falconRoles:${safeName($("project").value)}`);
    state.audit=analyse(state.parsed,$("unit").value,$("crs").value.trim(),{});render(state.parsed,state.audit);show(state.audit);
  };
  $("reset").onclick = () => location.reload();
})();
