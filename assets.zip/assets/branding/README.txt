BRANDING ASSETS

Future logo:
logo.png

Future Windows icon:
app.ico

These files are intentionally not supplied by this patch.
When final branding is selected, replace/add the assets here and update
config\branding.json if filenames change.
